The Hemophagocytic Lymphohistiocytosis Post-HCT Data Form is one of the Comprehensive Report Forms. This form captures HLH-specific Post-HCT data such as the disease assessment since the date of the last report.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “histiocytic disorders” and question 635 as “hemophagocytic lymphohistiocytosis (HLH).” The HLH Post-HCT Data (Form 2118) must be completed in conjunction with each Post-HCT follow-up form (Forms 2100, 2200, and 2300) completed. The form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100 for Form 2100; between day 100 and the six-month date of contact for six-month follow-up Form 2200; and between the date of contact for the six-month follow-up Form 2200 and the date of contact for the one-year follow-up Form 2200, etc.).

[Q1-32: Disease Assessment Since the Date of Last Report](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-32-disease-assessment-since-the-date-of-last-report)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/24/17 | Comprehensive Disease-Specific Manuals | Modify | Updated explanations of triggers for disease inserts to refer to the primary disease reported on the Pre-TED Disease Classification Form (Form 2402) instead of the Pre-TED Form (Form 2400) |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)