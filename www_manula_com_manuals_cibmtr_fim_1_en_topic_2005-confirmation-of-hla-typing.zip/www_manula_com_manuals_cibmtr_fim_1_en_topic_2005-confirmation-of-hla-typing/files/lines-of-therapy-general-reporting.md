Pre-infusion lines of therapy data fields capture data related to drugs, surgery, and radiation therapy used to treat the primary disease for infusion. Additionally, the best response to the line of therapy, and relapse / progression following therapy is captured.

This section provides general instructions used for all diseases when reporting the pre-infusion lines of therapy on the disease specific forms.

### Reporting Lines of Therapy

A single line of therapy refers to any agent administered during the same time period with the same intent (i.e., induction, consolidation, etc.).

In general, when the disease status changes resulting in a change of treatment, a new line of therapy should be reported. When there is a change in therapy because a favorable response was not achieved, a new line of therapy should be reported.

For many diseases, but not all, when there is a change in therapy (i.e., swapping of drugs, discontinuation of drugs, dose change), due to a toxicity, all drugs can be reported as a single instance. Review the disease-specific lines of therapy sections for information on reporting separate lines of therapy, depending on the disease, if applicable.

For information on how to report COG therapies for recipients with ALL, review the [ALL Lines of Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-lines-of-therapy) section.

### First vs Subsequent Infusions: Which Therapy to Report

All therapy since the initial diagnosis should be reported on the pre-infusion disease-specific forms. Review the guidelines below to determine which therapies to report when there was a prior infusion (HCT or CT).


- If there was a prior infusion and a pre-infusion disease specific form was not previously completed, report all lines of therapy administered from the time of the original diagnosis up to the infusion that is being reported.
- If there was a prior infusion and a pre-infusion disease specific form was previously completed, report lines of therapy administered following the prior infusion up until the infusion that is being reported.

### Intent of Therapy

Depending on the diseases-specific pre-infusion form, the intent of therapy is captured. Below is common terminology used for describing the intent of therapy.


- Induction: The first line of therapy following diagnosis to achieve complete remission.
- Re-induction: Therapy given if the first line of therapy fails to produce a complete remission or relapse occurs.
- The disease-specific forms do not have a re-induction option.
- Report this type of therapy as
**Induction**if the first line of therapy did not produce complete remission. - Report this type of therapy as
**Treatment for relapse**if complete remission was achieved but relapse occurred.

- Report this type of therapy as

- The disease-specific forms do not have a re-induction option.
- Consolidation: Therapy given once a clinical / hematologic remission is achieved. May be given as part of a protocol to eliminate minimal residual disease (MRD).
- Maintenance: Therapy given following induction and consolidation. Given to ‘maintain’ the current disease status and prevent relapse / progression.
- Treatment for relapse: Therapy given to induce complete remission following relapse.
- Bridging therapy: Therapy given between apheresis and infusion. Given to ‘hold over’ until the infusion.
- The disease-specific forms do not have a bridging therapy option.
- Report this type of therapy as
**Consolidation**if relapse did not occur - Report this type of therapy as
**Treatment for relapse**if relapse occurred

- Report this type of therapy as

- The disease-specific forms do not have a bridging therapy option.

### Types of Therapy

Depending on the pre-infusion disease-specific forms, various types of therapy are collected.


- Systemic therapy: Delivered via the blood and distributed throughout the body. May be administered orally or intravenously.
- Examples: Busulfan, fludarabine, thiotepa, melphalan

- Intrathecal therapy: Chemotherapy administered via lumbar puncture to treat or prevent disease in the central nervous system.
- Examples: Triple IT, IT methotrexate, IT cytarabine

- Radiation therapy: Consists of gamma rays, high energy x-rays, electron beams, or proton beams to kill cancer cells. Radiation is either delivered as a single dose or in several treatments (fractions). Includes both treatment and palliative radiation.
- Report both treatment and palliative radiation as a line of therapy.
- Depending on the scenario, radiation may be reported as a separate line of therapy or in conjunction with another type of therapy.


- Report both treatment and palliative radiation as a line of therapy.
- Surgery: Surgical treatment, resection
- Intraocular therapy: Chemotherapy administered via injection to the eye.
- Photopheresis: Removing blood from the body, exposing it to psoralen and ultraviolet light, and then reinfusing the blood.

### Start and Stop Dates

Therapy start and stop dates of each line of therapy are captured on the pre-infusion disease specific forms. Use the following guidelines to report therapy start and stop dates:


- Therapy start date: Report the date when therapy began. If the start date is partially known (e.g., mid-July 2010), use the process for reporting
[estimated dates](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). - Therapy end date: Report the date of the final administration of therapy is reported. If therapy is administered in cycles, report the date when the last cycle was started. If the start date is partially known (e.g., mid-July 2010), use the process for reporting
[estimated dates](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).- If only one cycle is given, report the end date as the final administration of the drug.


### Best Response to Line of Therapy

The best response (clinical / hematologic) to therapy, prior to the initiation of any new therapy is captured on the pre-infusion disease-specific form.


- Some pre-infusion disease specific forms may also capture the minimal residual disease (MRD) status.

The first date when the best response was achieved should be reported. This date may be date during the line of therapy, or after, but prior to starting the next line of therapy.

### What Not to Report

The following should not be reported on the pre-infusion disease-specific forms:


- Prior transplants
- Including preparative regimen

- Prior cellular therapies
- Including lymphodepleting therapy
- The pre-infusion disease-specific forms list ‘cellular therapy’ as a line of therapy option; however, this is disabled and will be removed with future form revisions.

- Therapy given for other reason then to treat the primary disease for infusion.
- Examples include, but not limited to: EBV, prior malignancies, new malignancies


### Helpful Tips and Reminders

**Progress Notes**

Reviewing the following notes may be helpful to understand the treatment and disease history


- Initial Consult H&P: May provide an overview since the initial diagnosis of the primary disease for infusion until the first visit at the transplant center
- HCT / CT Consult: May provide an overview since the initial consult at the transplant center until the opinion for HCT / CT
- Admission H&P: Depending on the case, may provide an overview since the last discharge / HCT or CT consult / initial consult H&P and the current admission
- Discharge summary: Provides an overview of what happened during the most recent admission

**Disease trackers**

Creating disease trackers can be time consuming; however, they are very useful. Utilizing disease trackers allows the following:


- Track each disease assessment along with each therapy
- Helps to ensure the correct best response and assessment date are accurately reported

- Allows one to identify why therapy is changing
- Provides one document, with the entire disease history and treatment, to review with the physician when there are questions

**Understand Why Therapy Changed**

It is important to ask why therapy changed


- Did therapy change due to a change (or lack of response) in disease?
- Did therapy change for another reason?

The reason therapy changes will help determine if therapy should be reported as separate instances or as one instance

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)