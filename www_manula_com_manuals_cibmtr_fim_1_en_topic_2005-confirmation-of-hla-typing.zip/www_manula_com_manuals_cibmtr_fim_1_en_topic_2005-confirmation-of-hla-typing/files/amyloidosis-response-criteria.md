### Hematologic Response

#### Complete Response

Requires **all** of the following:


- Serum and urine negative for monoclonal proteins by immunofixation
- Normal serum free light chain ratio

#### Very Good Partial Response

- Reduction in the difference between the involved and uninvolved serum free light chain to < 40 mg/L.

#### Partial Response (PR)

Requires **any** of the following:


- ≥ 50% reduction in serum monoclonal protein levels (if > 0.5 g / dL or > 5 g / L at baseline)
- ≥ 50% reduction in urine light chains (if >100 mg / day at baseline)
- ≥ 50% decrease in difference between the involved and uninvolved serum free light chain (if >10 mg / dL or >100 mg / L at baseline)

#### No Response (NR)/Stable Disease (SD)

Does not meet the criteria for CR, PR, or progressive disease.

#### Progressive Disease (PD)

Requires **any** of the following:


- If progressing from CR, any detectable monoclonal protein or abnormal free light chain ratio (light chain must double)
- If progressive from PR or SD, ≥ 50% increase in the serum M protein to > 0.5 g/dL, or ≥ 50% increase in urine M protein to > 200mg/day with visible peak present.
- Serum free light chain increase of ≥ 50% to > 10 mg/dL (100 mg/L)

### Cardiac Response

#### Cardiac Response

Requires **any** of the following:


- > 30% and > 300 ng /l decrease in recipients with baseline N-terminal prohormone of brain natriuretic peptide (NT-proBNP) ≥ 650 ng/L
*or* - ≥ 2 class decrease in recipients with baseline
[New York Heart Association functional class](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/new-york-heart-association-function-classification)class of 3 or 4

#### No Response/Stable Disease

Does not meet the criteria for cardiac response or progressive disease

#### Progressive Disease

Requires **any** of the following:


- > 30% and > 300 ng/l increase in N-terminal prohormone of brain natriuretic peptide (NT-proBNP)
1*or* - ≥ 33% increase in cardiac troponin (cTn)
*or* - ≥ 10% decrease in ejection fraction

1 Recipients with progressively worsening renal function cannot be score for NT-proBNP progression. Progressively worsening renal function is defined as 50% increase (at least 1 g / day) of 24-hour urine protein from baseline to > 1 g / day or 25% worsening of serum creatinine or creatinine clearance from baseline

### Hepatic Response

#### Hepatic Response

Requires **all** of the following:


- ≥ 2 cm decrease in liver span if hepatomegaly present (liver > 15 cm)
- ≥ 50% decrease and/or normalization of serum alkaline phosphatase (ALP) level

#### No Response/Stable Disease

Does not meet the criteria for hepatic response or progressive disease

#### Progressive Disease

Requires the following:


- ≥ 50% increase in the serum alkaline phosphatase (ALP) level

### Autonomic Neuropathy Response

#### Autonomic Neuropathy Response

Resolution of symptomatic orthostatic hypotension

#### No Response/Stable Disease

Does not meet the criteria for autonomic neuropathy response or progressive disease

#### Progressive Disease

Worsening of symptomatic orthostatic hypotension

### Peripheral Neuropathy Response

#### Peripheral Neuropathy Response

Requires **any** of the following:


- Resolution of abnormal physical findings
- Resolution or improvement of abnormal electromyography (EMG) and/or Nerve Conduction Velocity (NCV) findings

#### No Response/Stable Disease

Does not meet the criteria for peripheral neuropathy response or progressive disease

#### Progressive Disease

Requires **any** of the following:


- Worsening of physical findings
- Worsening of EMG and/or NCV findings

### Renal Response

#### Renal Response

- ≥ 50% decrease of at least 0.5 g/day (500mg/24hr) in 24-hour urine protein of > 0.5 g/day (500mg/24hr) pre-treatment
**and** - Creatinine clearance or serum creatinine must not have worsened by ≥ 25% over baseline

If only serum creatinine is obtained, an estimated creatinine clearance can be calculated using the following formula:

**Estimated Creatinine Clearance** = [(140 – Age (years)) * Weight (kg)] / [72 * Serum Creatinine (mg/dL)]

The calculation should be multiplied by 0.85 for women

#### No Response/Stable Disease

Does not meet the criteria for renal response or progressive disease

#### Progressive Disease

Requires **any** of the following:


- ≥ 50% increase of at least 1 g/day (1000mg/24hr) for urine protein to > 1g/day (1000mg/24hr)
- 25% worsening of serum creatinine or creatinine clearance

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/18/22 |
|

*The Hematologic Response requires two consecutive assessments made by the same method at any time before the institution of any new therapy. Organ responses (i.e., Hepatic, Peripheral Neuropathy, Cardiac) do not require confirmatory assessments.*[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)*≥ 50% decrease in*~~clonal serum free light chain levels~~difference between the involved and uninvolved serum free light chain (if >10 mg / dL or >100 mg / L at baseline)

[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)*Progressive disease:*~~≥ 2 mm decrease in mean intraventricular septal wall thickness by echocardiogram, ≥ 20% increase in left ventricular ejection fraction, ≥ 2 grade decrease in New York Heart Association functional class without increase in diuretic use and no increase in wall thickness, Reduction (≥ 30% and ≥ 300ng/L) of NT-proBNP in patients whom the eGFR is ≥ 45 ml/minute/1.73m2~~ > 30 % and > 300 ng /l decrease in recipients with baseline N-terminal prohormone of brain natriuretic peptide (NT-proBNP) ≥ 650 ng/L or ≥ 2 class decrease in recipients with baseline New York Heart Association class of 3 or 4~~≥ 2 mm increase from baseline in the intraventricular wall thickness by echocardiogram, ≥ 10% decrease in the left ventricular ejection fraction, ≥ 1 grade increase in New York Heart Association functional class~~ > 30 % and > 300 ng/l increase in N-terminal prohormone of brain natriuretic peptide (NT-proBNP) or ≥ 33 increase in cardiac troponin (cTn) or ≥ 10% decrease in ejection fraction%[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)** ≥ 50% reduction in*~~current~~ serum monoclonal protein levels (if > 0.5 g / dL or > 5 g / L at baseline) ~~> 0.5 g/dL~~** ≥ 50 reduction in urine light chains (if >100 mg / day at baseline)*~~≥ 50% reduction in current urine m-protein levels > 100 mg/day with a visible peak~~** ≥ 50 decrease in clonal serum free light chain levels (if >10 mg / dL or >100 mg / L at baseline)*~~≥ 50% reduction in current free light chain levels > 10mg/dL~~[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)*Requires***all**of the following:*Serum and urine negative for monoclonal proteins by immunofixation**Normal free light chain ratio*~~Plasma cells in marrow < 5%~~

[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)**Partial Response**:*≥ 50% reduction in current serum monoclonal protein levels > 0.5 g/dL**≥ 50% reduction in current*~~urine light chain~~urine m-protein levels > 100 mg/day with a visible peak*≥ 50% reduction in current free light chain levels > 10mg/dL*

**Renal Response**:*≥ 50% decrease of at least 0.5 g/day (500mg/24hr) in 24-hour urine protein of > 0.5 g/day (500mg/24hr) pre-treatment and**Creatinine clearance or serum creatinine must not have worsened by ≥ 25% over baseline*

*If only serum creatinine is obtained, an estimated creatinine clearance can be calculated using the following formula:*

**Estimated Creatinine Clearance**= [(140 – Age (years)) * Weight (kg)] / [72 * Serum Creatinine (mg/dL)]

*The calculation should be multiplied by 0.85 for women.*

[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)*≥ 50% decrease of at least 0.5 g/day (500mg/24hr) in 24-hour urine protein of > 0.5 g/day (500mg/24hr) pre-treatment***and***Creatinine clearance must not have worsened by ≥ 25% over baseline*

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)