All values reported in questions 1-19 must reflect testing performed prior to any treatment of ALL. If testing was not performed near the time of diagnosis (within approximately 30 days) and prior to the initiation of treatment, the center should report “Unknown” for that value.

#### Questions 1-3: WBC

Indicate whether the white blood count (WBC) in the peripheral blood is “Known” or “Unknown” at the time of diagnosis. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If the WBC at diagnosis is not known, report “Unknown” and go to question 4.

#### Questions 4-6: Blasts in blood

Indicate whether the percent blasts in the peripheral blood is “Known” or “Unknown” at the time of diagnosis. This may be determined by an automated differential, a manual count, or flow cytometry. Testing by any of these methods may be reported in questions 4-6. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If the percent blasts in blood at diagnosis is not known, report “Unknown” and go to question 7.

If a differential was performed and there were no blasts present in the peripheral blood, the lab report may not display a column for blasts. In this case, it can be assumed no blasts are present and ‘0’ should be reported.

#### Questions 7-9: Blasts in bone marrow

Indicate whether the percent blasts in the bone marrow is “Known” or “Unknown” at the time of diagnosis. The percent blasts may be assessed by manual differential or flow cytometry. If available, report the manual differential performed on the bone marrow aspirate sample. If a manual differential was not performed on an aspirate sample, other methods / sample types may be reported (such as flow cytometry on an aspirate sample, or testing on a core biopsy) may be reported.

If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If the percent blasts in bone marrow at diagnosis is not known, report “Unknown” and go to question 10.

#### Questions 10-19: Extramedullary disease

Extramedullary disease refers to any confirmed site of ALL other than the peripheral blood and bone marrow. Examples include detection of leukemic blasts in the cerebrospinal fluid and skin (leukemia cutis) as well as detection of soft tissue masses (myeloid sarcoma). If the recipient had extramedullary disease at the time of diagnosis, report “Yes” for question 10 and report all extramedullary sites of involvement in questions 11-19. If the recipient did not have any extramedullary disease at diagnosis, report “No” for question 10 and go to question 20. If extramedullary disease at diagnosis is not known, report “Unknown” and go to question 20.

If the primary disease for infusion is precursor T-cell and/or precursor B-cell lymphoblastic lymphoma (or lymphoma / leukemia), report “No” for question 10 and continue with question 20.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q4 – 6 | 8/12/2022 | Add | Indicate whether the percent blasts in the peripheral blood is “Known” or “Unknown” at the time of diagnosis. This may be determined by an automated differential, a manual count, or flow cytometry. Testing by any of these methods may be reported in questions 4-6. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in
|
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)