#### Question 2: Was sickle cell disease diagnosed at birth? (i.e., newborn screening)

The most common method of diagnosis for Sickle Cell Disease (SCD) is a blood screen which looks for the defective hemoglobin molecule in the circulating blood. In the United States, this blood test is available as part of routine newborn screening. Infants are often diagnosed at birth or *in utero*.

Report **Yes** if the recipient was diagnosed with Sickle Cell Disease (SCD) at birth (or *in utero*). If the recipient was not diagnosed as birth, report **No** and provide the date of diagnosis. If it is unknown whether the recipient was diagnosed at birth, report **Unknown**. This option should be used sparingly and only when no information exists regarding SCD screening as an infant.

#### Question 3: Date of diagnosis

Report the date of diagnosis of SCD. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside facility and no documentation of the laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the exact pathological diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 4 – 5: What is the recipient’s sickle cell disease genotype?

Genetics play a critical role in the development of sickle cell disorders. Clinical symptoms vary depending on which gene variants are inherited. Accurate identification of the recipient’s sickle genotype may help guide clinical management of symptoms.

Specify the recipient’s sickle cell disease genotype. If the recipient exhibits a sickle cell genotype that is not listed, select **Other genotype** and specify the sickle cell genotype in question 5.

See *Table 1. Sickle Cell Genotypes* below for a description and common characteristics of each genetic variant.

#### Table 1. Sickle Cell Genotypes

| Genotype | Description |
|---|---|
| Hb SC | One sickle gene is inherited from one parent and one abnormal hemoglobin-producing “C” gene is inherited from the other parent. Typically characterized by mild symptoms but increased likelihood of proliferative sickle retinopathy has been observed. |
| Hb SD | One sickle gene is inherited from one parent and one abnormal hemoglobin-producing “D” gene is inherited from the other parent. The severity of symptoms varies for recipients with this genotype. |
| Hb SO Arab | A rare, compound, heterozygous hemoglobinopathy characterized by inheritance of one sickle gene from one parent and one abnormal hemoglobin-producing “O” gene inherited from the other parent. Severity is similar to those of homozygous SCD. |
| Hb SS | Most common type of sickle cell disease and is often called homozygous sickle cell anemia. One sickle gene is inherited from each parent. Often characterized by higher prevalence of hemolysis and lower hemoglobin values compared to Hb SC or beta+ thalassemia. Incidence of leg ulcers and episodes of priapism are increased. Regarded as a severe form of SCD. |
Hb S beta thalassemia
|
A more severe form of Sickle Cell Disease (SCD) characterized by crescent-shaped red blood cells (RBC) (e.g., sickle cells) that break down prematurely as well as populations of smaller RBCs, simultaneously. |
| Hb S beta[+] thalassemia | A mild form of Sickle Cell Disease (SCD) characterized by crescent-shaped red blood cells (RBC) (e.g., sickle cells) that break down prematurely as well as populations of smaller RBCs, simultaneously. |
Hb S delta beta thalassemia
|
A rare, homozygous hemoglobinopathy characterized by decreased production of the delta- and beta-globin chains. There is a compensatory increase in the production and expression of Hb F in affected individuals. |

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)