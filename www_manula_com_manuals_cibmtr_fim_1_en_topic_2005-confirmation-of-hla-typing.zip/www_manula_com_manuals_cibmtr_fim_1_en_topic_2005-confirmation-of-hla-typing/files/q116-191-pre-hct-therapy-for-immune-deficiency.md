#### Question 116: Was treatment given (between diagnosis and prior to the preparative regimen)?

Since immune deficiencies are non-malignant diseases caused by genetic mutations, hematopoietic stem cell transplant is the main curative treatment at this time. Other treatments such as gene therapy are promising.

The questions below regarding prophylactic anti-infection and immunosuppressant drugs, refer to supportive therapy used to treat or prevent the sequelae (or condition as a result of the disease) such as infections, autoimmune issues, GVHD, etc. Additional questions ask about gene therapy or other significant treatments given to the recipient following the anti-infection and immunosuppresion therapy questions.

Indicate if the recipient received therapy between diagnosis and prior to the preparative regimen, including gene therapy, anti-infection drugs, immunosuppressive drugs, or any other significant and/or experimental therapies. If “yes,” continue with question 117. If “no,” continue with 176.

#### Questions 117-125: Prophylactic Drugs

Prophylactic drugs are used to prevent infection by a virus, bacteria, fungus, or parasite. Drugs started as a result of infection should not be reported as prophylactic drugs.

Indicate “yes” or “no” for each of the drug categories listed. If “yes,” continue with the subsequent questions regarding the stoppage of the prophylactic drug. If the drug was stopped, indicate “yes” and report the date the drug was stopped.

**Drug**

**Antifungal drugs** are used to prevent fungal infections. Common prophylactic antifungal drugs include fluconazole, caspofungin, voriconazole, etc.

**Antiviral drugs** are used to prevent viral infections. Common prophylactic antiviral drugs include acyclovir, ganciclovir, foscarnet, etc.

**Co-trimoxazole (Bactrim, Septra)** is a prophylactic drug used to prevent Pneumocystis jirovecii, a protozoan (i.e., parasitic) infection that colonizes the lungs of those with compromised immune systems.

**Prophylactic drug stopped?**

Indicate if the prophylactic drugs in each category were stopped. Prophylactic drugs stopped for a period of time shorter than one week should not be considered as “stopped.” For example, if any of the prophylactic drugs are held during the preparative regimen and restarted shortly thereafter, they would not be reported as stopped.

**Date stopped**

p. Report the date the last prophylactic drug in each category was stopped. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms.

#### Questions 126-170: Therapies

Pre-transplant therapies for immune deficiencies may include immunosuppressive therapies to prevent or treat GVHD (maternal or transfusion associated), autoimmune conditions, etc.

Indicate “yes” or “no” for each of the drugs listed. If “yes,” continue with the subsequent questions regarding the stoppage of the therapy. If the drug was stopped, indicate “yes” and report the date the drug was stopped.

**Therapy**

Each of the drugs in questions 126-170 have immunosuppressive properties.

Corticosteroids may be given topically or systemically. Budesonide, which is ingested orally, is considered a topical drug.

If the recipient is given a monoclonal antibody, select “yes” for question 141 and specify the monoclonal antibody in questions 142-157. If the monoclonal antibody is not listed, specify the drug in question 160.

If the recipient is given an immunosuppressant that is not listed, select “yes” for question 167 and specify the other immunosuppressant in question 170.

**Therapy stopped?**

Indicate if the therapy was stopped. Therapy that is stopped for a period of time shorter than one week should not be considered as “therapy stopped.”

For example, if any of the therapies are held during the preparative regimen and restarted shortly thereafter, they would not be reported as stopped.

**Date stopped**

Report the date the therapy was stopped. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms.

#### Question 171: Was gene therapy performed (between diagnosis and prior to the preparative regimen)?

Gene therapy is the process by which a faulty gene is replaced by a healthy one. This process uses a virus which is manipulated to include a functioning version of the gene. The recipient’s cells are “treated” with the functioning-gene-containing virus with the intention of the functioning rather than faulty gene proliferating.

#### Question 172: Specify date of infusion of gene therapy

Indicate the date the treated cells were infused to the recipient. If the recipient received several infusions, report the first date of infusion.

#### Question 173: Was the recipient considered to have failed gene therapy?

Gene therapy is considered a success if the healthy gene replaces the faulty one and the immune system begins to function normally. In the opinion of the physician, was the gene therapy considered a failure? If so, select “yes” and continue with question 174.

#### Questions 174-175: Did the recipient receive any other significant treatment(s) (between diagnosis and prior to the preparative regimen)?

Recipients with immune deficiency may receive treatments other than what is listed above. Treatments may include enzyme replacement therapy such as PEG-ADA. Each immune deficiency may have their own unique treatments, including interferon, growth factors, enzyme replacement, or other therapies.

If the recipient had any other significant treatments between diagnosis and prior to the preparative regimen, select “yes” and specify the treatments in question 175. If the recipient did not have additional significant treatments, select “no” and continue with question 176.

#### Question 176: Did the recipient receive parenteral nutrition (between diagnosis and prior to the preparative regimen)?

Parenteral nutrition is given to the recipients intravenously rather than through the digestive system. Parenteral nutrition contains the carbohydrates, proteins, fats, electrolytes, and other components needed for survival. The use of parenteral nutrition to deliver all required nutrients is called total parenteral nutrition (TPN).

Indicate “yes” if the recipient received parenteral nutrition between diagnosis and the start of the preparative regimen. If the recipient did not receive parenteral nutrition, select “no.”

#### Question 177: Did the recipient receive mechanical ventilation (between diagnosis and prior to the preparative regimen)?

Mechanical ventilation can occur as both an endotracheal tube and ventilator, or as a BIPAP machine with a tight fitting mask in continuous use. The one exception to BIPAP is CPAP used for sleep apnea, which generally involves overnight use only for patients with documented sleep apnea. Therefore, do not report a CPAP used for sleep apnea, as it does not have the same implications as other forms of mechanical ventilation.

Indications for mechanical ventilation include, but are not limited to:

- Apnea with respiratory arrest (excludes sleep apnea)
- Acute lung injury
- Vital capacity < 15 mL/kg
- Chronic obstructive pulmonary disease (COPD)
- Clinical deterioration
- Respiratory muscle fatigue
- Obtundation or coma
- Hypotension
- Tachypnea or bradypnea

If the recipient was placed on mechanical ventilation at any time after diagnosis but before the preparative regimen check “yes.” If the recipient does not have a history of mechanical ventilation during the time period, check “no.”

#### Question 178-191: Were any biologic specimens collected for this recipient (between diagnosis and prior to the preparative regimen)?

Indicate whether biologic specimens were collected for this recipient. Biologic specimens may be collected for more in-depth analyses and for research purposes. Different types of cells, for example B cells and T cells, can be isolated from whole blood and viral-transformed to establish permanent cell lines.

If “yes” continue with questions 179-191 and specify which specimens were collected and are available for future use. If “no” or “unknown” continue with “Signature Lines.”

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)