Complete questions 10-17 for allogeneic transplants only; if donor information is unknown, leave the data field blank. These data fields should be used to report new information available for donors that developed hepatitis post-transplant. If this is the first post-transplant report & the donor developed hepatitis, then report information from the date of the stem cell harvest; do not duplicate data reported on the Form 2047 prior to transplant. Complete all data fields for which relevant donor information is documented and available to the CIBMTR center completing the form.

#### Question 10: Hepatitis B core antibody (HBcAb)

The total hepatitis B core antibody refers to both IgG and IgM antibodies produced by the body in response to the presentation of the core antigen by liver cells. Since core antigen is present only in infected liver cells and cannot be detected in the blood of an infected individual, only core antibody is tested, since it circulates in the peripheral blood. After infection, total core antibodies will persist for life. Presence of core antibodies can indicate active and/or prior infection, but hepatitis core antibodies will not be present in individuals with no history of natural infection with HBV. This means that vaccinated individuals will not be anti-HBc positive because vaccination results in the body developing antibodies to the hepatitis B *surface* antigen. Chemiluminescent immunoassay (CIA), enzyme-linked immunosorbent assay (ELISA), or Elecsys anti-HBc is used to test for the presence of hepatitis B core antibodies. Currently, there is no licensed confirmatory test for anti-HBc in the United States; confirmation of antibody presence is done by performing a second anti-HBc test using a different manufacturer’s test kit.

Report the laboratory result of most recent donor testing as “positive” (reactive), “negative” (non-reactive), or “inconclusive” (indeterminate) for donor testing. If testing was not done, indicate “not tested.”

#### Question 11: Hepatitis B surface antigen (HBsAg)

The hepatitis B surface antigen is a protein expressed on the surface of the hepatitis B virus. Its presence in the blood serum indicates acute or active chronic infection. In acutely infected patients, blood will test HBsAg positive within one to nine weeks of exposure to the virus. Patients who do not go on to develop chronic infection will be surface antigen negative by 15 weeks after the onset of symptoms. Chemiluminescent immunoassay (CIA), electrochemiluminescent immunoassay (ECLIA), or enzyme-linked immunosorbent assay (ELISA) are used to test for the presence of hepatitis B surface antigens; research indicates CIA and ECLIA may be more sensitive for detecting low levels of HBsAg. 1 Positive HBsAg results require confirmation with a neutralization procedure using human Anti-HBs (HBsAg Confirmation Assay). If the sample is neutralizable in the confirmatory test, the specimen is considered positive for HBsAg.

Report the laboratory result of most recent donor testing during the reporting period as “positive” (reactive), “negative” (non-reactive), or “inconclusive” (indeterminate) for donor testing. If testing was not done, indicate “not tested.”

1 Fei CR, Ye AQ, Zhang J. (2011). Evaluation of different methods in determination of low level HBsAg. Zhejiang Da Xue Xue Bao Yi Xue Ban, 40(4):436-439.

#### Question 12: Hepatitis B e antigen (HBeAg)

The hepatitis B e antigen is the extracellular form of the hepatitis B core antigen. Hepatitis B core antigen does not circulate and therefore cannot be detected in serum testing; as a result, hepatitis B e antigen may be used as a proxy measure. Its presence is associated with active viral replication and increased infectivity. The hepatitis B e antigen is present in the serum during the early phase of acute HBV infection, shortly after the hepatitis B surface antigen is first seen. Hepatitis B e antigen would only be seen during active infection; however, there are some variants of hepatitis B virus which are known to be hepatitis e negative, even during periods of high viral replication and increased infectivity.

Report the laboratory result of most recent donor testing during the reporting period as “positive” (reactive), “negative” (non-reactive), or “inconclusive” (indeterminate) for donor testing. If testing was not done, indicate “not tested.”

#### Question 13: Hepatitis C antibody (HCAb)

The total hepatitis C antibody refers to both IgG and IgM antibodies produced by the body in response to the presentation of antigens by the hepatitis C virus. Antibodies can generally be detected as soon as four weeks after exposure and will persist for life. Enzyme-linked immunosorbent assay (ELISA) or chemiluminescent immunoassay (CIA) is used to screen for hepatitis C antibodies; confirmatory testing is done by recombinant immunoblot assay (RIBA). A positive ELISA or CIA result without confirmation by RIBA is considered an indeterminate result, unless HCV RNA is detected in the blood by PCR.

Report the laboratory result of most recent donor testing during the reporting period as “positive” (reactive), “negative” (non-reactive), or “inconclusive” (indeterminate) for donor testing. If testing was not done, indicate “not tested.”

**Donor Hepatitis B viral load testing**

Hepatitis B viral load testing is used to quantify hepatitis B viral DNA in the blood. The diagnosis of hepatitis B infection, either acute or chronic, is generally made by serologic testing, though DNA testing may be useful in the diagnosis of early acute HBV. Additionally, DNA testing is useful to determine whether the infection is active and to monitor response to anti-HBV therapies. Hepatitis B viral load testing is performed by PCR amplification of HBV DNA in the patient’s serum.

Report all instances of donor Hepatitis B viral load testing performed during the reporting period; create an instance for each test result. If no testing was performed, proceed with question 16.

#### Question 14: Donor Hepatitis B viral load – date

Specify the date donor Hepatitis B viral load testing was performed and continue with question 15.

#### Question 15: Hepatitis B viral load level

Report the result for donor viral load testing as indicated on the laboratory report. If necessary, convert values so they can be reported in the unit of measurement options available on the form.

**Donor Hepatitis C viral load testing**

Hepatitis C viral load testing is primarily used to monitor response to anti-viral therapy and confirm activity of infection; additionally, it may be used to diagnosis early acute HCV infection and to detect active chronic infection. Hepatitis C viral load testing is performed by RT-PCR amplification of HCV RNA in the patient’s serum.

Report all instances of donor Hepatitis C viral load testing performed during the reporting period; create an instance for each test result. If no testing was performed, proceed with question 18.

#### Question 16: Donor Hepatitis C viral load – date

Specify the date donor Hepatitis C viral load testing was performed and continue with question 17.

#### Question 17: Hepatitis C viral load level

Report the result for donor viral load testing as indicated on the laboratory report. If necessary, convert values so they can be reported in the unit of measurement options available on the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)