#### Questions 125-126: Specify POEMS clinical features (check all that apply)

POEMS syndrome is poorly understood, but generally refers to **P** olyneuropathy, **O** organomegaly, **E** ndocrinopathy, **M** protein, and **S** kin changes. Proper diagnosis is crucial for appropriate clinical management and varying clinical features help guide therapy. Indicate which clinical features, **specific to POEMS** only, are present at the time of diagnosis of POEMS syndrome or prior to the start of first therapy. Check all that apply. If there are other clinical features not listed in this section, select **Other** in question 125, in addition to any available options that apply, and specify the other clinical feature in question 126.

#### Questions 127 – 129: Thyroid stimulating hormone (TSH)

Indicate whether the thyroid stimulating hormone (TSH) level was Known or Unknown at the time of POEMS diagnosis. If **Known**, report the value (in mU/L) (mU/L is equivalent to μU/mL) and specify the upper limit of normal. If **Unknown**, continue with question 130.

#### Questions 130 – 132: Testosterone level

Indicate whether the testosterone level was **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value and unit of measure documented and specify the upper limit of normal. If **Unknown**, continue with question 133.

#### Questions 133 – 135: Estradiol level

Indicate whether the estradiol level was **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value (in pg/mL) and specify the upper limit of normal. If **Unknown**, continue with question 136.

#### Questions 136 – 138: Prolactin level

Indicate whether the prolactin level was **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value (in ng/mL) and specify the upper limit of normal. If **Unknown**, continue with question 139.

#### Questions 139 – 141: Cortisol level

Indicate whether the cortisol level **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value and unit of measure to the nearest tenth and the upper limit of normal as documented on the laboratory. If **Unknown**, continue with question 142.

#### Questions 142 – 144: Interleukin-6

Indicate whether the interleukin-6 value was **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value (in pg/mL) to the nearest tenth and the upper limit of normal as documented on the laboratory. If **Unknown**, continue with question 145.

#### Questions 145 – 146: Was pulmonary artery hypertension present?

Pulmonary hypertension (PH) refers to elevated pulmonary arterial pressure. PH can be due to primary elevation of pressure in the pulmonary arterial system alone (pulmonary arterial hypertension), or secondary to elevations of pressure in the pulmonary venous and pulmonary capillary systems (pulmonary venous hypertension; post-capillary PH). Indicate whether pulmonary artery hypertension was present at the time of POEMS diagnosis. If present, indicate **Yes** and report the estimated systolic artery pressure. If not present, indicate **No** and continue with question 147.

#### Questions 147 – 148: Forced vital capacity (FVC)

Forced vital capacity is the total amount of air exhaled during the forced expiratory volume test. FVC is a measurement taken during spirometry studies. Indicate whether the forced vital capacity percentage was **Known** or **Unknown** at the time of POEMS diagnosis or prior to the start of first therapy. If **Known**, report the percentage documented on the pulmonary function test (PFT). If **Unknown**, continue with question 149.

#### Questions 149 – 150: Total lung capacity

Indicate whether the total lung capacity was **Known** or **Unknown** at the time of POEMS diagnosis or prior to the start of first therapy. If **Known**, report the value documented on the laboratory report in. If **Unknown**, continue with question 151.

#### Questions 151 – 153: Vascular endothelial growth factor (VEGF) serum value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the serum-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value documented on the laboratory report and specify the upper limit of normal. If **Unknown**, continue with question 154.

#### Questions 154 – 156: Vascular endothelial growth factor (VEGF) plasma value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the plasma-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the time of POEMS diagnosis. If **Known**, report the value documented on the laboratory report and specify the upper limit of normal. If **Unknown**, continue with question 157.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)