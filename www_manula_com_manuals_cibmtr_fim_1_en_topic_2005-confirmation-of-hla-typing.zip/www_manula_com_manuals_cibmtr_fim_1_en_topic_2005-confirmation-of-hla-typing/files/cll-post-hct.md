The CLL Post-Infusion (2113) Form is a of the Comprehensive Report Forms. This form captures CLL-specific post-infusion data such as disease assessment at the time of best response to infusion, post-infusion planned treatment, disease relapse or progression, and disease status at the time of the last evaluation.

This form must be completed for all recipients assigned to the CRF track whose disease, reported on Pre-TED Disease Classification (2402) Form, is chronic lymphocytic leukemia (CLL), B-cell/small lymphocytic leukemia (SLL), or prolymphocytic leukemia (PLL). If the recipient underwent a transformation to diffuse large B-cell lymphoma (Richter’s transformation), only the CLL Pre-Infusion (2013) Form must be completed. Do not complete a CLL Post-Infusion (2113) Form.

The CLL Post-Infusion (2113) Form must be completed in conjunction with each Post-Infusion Follow-up (2100) Form.

**Links to Sections of Form**

[Q1 – 27: Disease Assessments at the Time of Best Response to Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-q1-3)

[Q28 – 32: Post-Infusion Planned Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-q4-26)

[Q33 – 64: Disease Relapse or Progression Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-q27-42)

[Q65 – 89: Disease Status at the Time of Evaluation for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-q43-88)

**Manual Updates**

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

To reference the historical Manual Change History for this form, please see the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

*Systemic therapy, radiation, withdrawal of immunosuppression, and/or other treatments may be administered for persistent, relapsed, or progressive disease. Additionally, therapy for measurable residual disease (MRD) may also be administered. Indicate if the recipient received treatment post-infusion for measurable residual disease (MRD), persistent, relapsed, or progressive disease in the current reporting period.*[2113: CLL Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-hct)*Report the date when treatment for measurable residual disease (MRD), persistent, relapsed, or progressive disease was started in the current reporting period. If multiple treatments were started in the reporting period, report the date of the first treatment.*[2113: CLL Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-hct)*Indicate if the recipient received treatment post-infusion for reasons other than treatment for measurable residual disease (MRD), relapse, progressive, or persistent disease during the current reporting period. Recipients generally receive a HCT / cellular therapy under a specific protocol which defines radiation and / or systemic therapy to be given post-infusion, along with prophylactic medication as well as any systemic therapy, radiation, and / or other treatments to be administered post-infusion as planned (or maintenance) therapy. Planned (maintenance or consolidation) therapy is given to assist in prolonging remission. Planned therapy may be described in a research protocol or standard of care protocol and these should be referred to when completing this section.*

If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR consider this ‘planned therapy,’ even if this was not documented prior to infusion. Do not include any treatment administered as a result of relapse, progression, or persistent disease.If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR consider this ‘planned therapy,’ even if this was not documented prior to infusion. Do not include any treatment administered as a result of relapse, progression, or persistent disease.

*Indicate if therapy was given for reasons other than measurable residual disease (MRD), relapse, progressive, or persistent disease in the current reporting period.*[2113: CLL Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-hct)*Use the following guidelines to determine how to report the best response when the recipient is not in CR pre-infusion and persistent disease was detected post-infusion:**If the first assessments complete post-infusion are consistent with persistent disease and treatment for persistent disease was not started, report the best response as***Stable disease**and the assessment date as the first assessments showing stable disease.*If the first assessments completed post-infusion are consistent with persistent disease and treatment for persistent disease was started, report the best response as***Stable disease**and the assessment date as the last assessments prior to initiating persistent disease treatment.

[2113: CLL Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-hct)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)