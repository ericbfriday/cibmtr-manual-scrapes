[December 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#dec2017)

[November 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#nov2017)

[October 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#oct2017)

[September 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#sep2017)

[August 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#august2017)

[July 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#july2017)

[June 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#june2017)

[May 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#may2017)

[April 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#april2017)

[March 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#march2017)

[February 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#february2017)

[January 2017](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2017-manual-updates#january2017)

**December 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 12/6/17 |
|

*If this is a report of a***second or subsequent transplant**for aplastic anemia and this baseline disease insert has previously been completed for a prior transplant, indicate if the recipient received treatment for aplastic anemia between Day 0 of the previous HCT and the start of the preparative regimen for the subsequent HCT.**November 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 11/21/17 |
|

~~, immunotherapy, or targeted therapies delivered via the blood stream and distributed throughout the body. Therapy may be~~ injected into a vein or given orally.**chemotherapy**~~Systemic~~ Cytotoxic Therapy:[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Interstitial pneumonitis / Acute respiratory distress syndrome (IPn/ARDS): IPn refers to inflammation of the alveolar walls. Acute respiratory distress syndrome typically refers to fluid build-up within the alveoli. In either case, gas exchange is impaired resulting in oxygen deprivation. Both conditions can result from infectious or non-infectious causes.*~~Infectious causes may be bacterial, viral (CMV, adenovirus, RSV, influenza, etc.), or fungal.~~ Only report IPn / ARDS resulting from non-infectious causes in questions 441-485.[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*If the date of diagnosis is***unknown**, leave question 158 blank and override the validation error using the code “Unknown.” However, question 158 may**not**be left blank if treatment for acute GVHD (question 185) is reported “Yes.” If the exact clinical diagnosis date is unknown, but the treatment start date is known, report the date treatment started as the date of acute GVHD diagnosis.[4100: Cellular Therapy Essential Data Follow-Up](#404)~~Liver, lungs, heart, kidneys, gastrointestinal, musculoskeletal, neurologic, or other organ. Based on the CTC criteria~~**Grade 4 organ toxicity:**As defined by the CTCAE criteria , grade 4 toxicity represents life-threatening consequences and urgent intervention is indicated[4000: Cellular Therapy Essential Data Pre-Infusion](#404)*Indicate whether the cellular therapy product reported in this instance contains viral-specific Cytotoxic T Lymphocytes (CTLs). These products are generally from allogeneic donors that have been cultured / expanded and modified to treat specific viruses such as CMV, EBV, Adenovirus, etc.*~~Cytotoxic T lymphocytes (CTLs) are a type of white blood cell that can kill foreign cells, cancer cells, and cells infected with a virus. Indicate “yes” or “no” for the donor being reported in this instance and continue with question 36.~~[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)- 270 Blastomyces (dermatitidis)
- 201 Candida albicans
- 208 Candida non-albicans
- 222 Cryptococcus gattii
- 221 Cryptococcus neoformans
- 261 Histoplamsa (capsulatum)
- 272 Scedosporium (all species)
- 503 Suspected fungal infection

**October 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/27/17 |
|

If the MDS/MPN subtype at diagnosis was “atypical chronic myeloid leukemia,”

[2556: Myelofibrosis CMS Study Pre-HCT Data](#404)Indicate “yes” if the patient was treated with a different JAK1 or JAK2 inhibitor (other than ruxolitinib) and specify the drug in question 27. Also, indicate “yes” if the recipient started and stopped ruxolinitib multiple times prior to HCT. In this case, the center should use questions 26-31 to report each treatment interval not captured in questions 19-25.

[2556: Myelofibrosis CMS Study Pre-HCT Data](#404)[2402: Disease Classification](#404)**Nodular Partial Remission**included under the instructions for question 266. This disease status is no longer captured on the forms.[CLL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-response-criteria)**Nodular Partial Remission**as this disease status is no longer captured on the forms.[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)~~For review of renal and hepatic comorbidities, criteria are met when the patient has two or more laboratory values meeting the threshold for reporting between days -24 and -10 (or the date of the last test prior to start of the preparative regimen). If the laboratory values are only assessed once in that period, extend review to between days -40 and -10.~~*In addition to the guidelines listed on the Pre-TED form, include the following time-specific guidelines when reporting hepatic and renal comorbidities***Hepatic Comorbidity:**The assessment of liver function tests (ALT, AST and/or Total Bilirubin) has to include at least 2 values per test on two different days within a period extending between day -24 and the start of the preparative regimen. If only a single value was reported in this time period, use the most recent test performed between days -40 & -25 as the second value.**Renal (Moderate/Severe) Comorbidity:**Serum creatinine > 2 mg/dL or > 177 μmol/L, as detected in at least two lab values on two different days within a period extending between day -24 and the start of the preparative regimen. If only a single value was reported in this time period, use the most recent test performed between days -40 & -25 as the second value.[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)~~& -10 (or between days -40 & -10 if only a single value was reported between days -24 & day -10) before HCT.~~ and the start of the preparative regimen. If only a single value was reported in this time period, use the most recent test performed between days -40 & -25 as the second value.**Hepatic Comorbidity:**The assessment of liver function tests (ALT, AST and/or Total Bilirubin) has to include at least 2 values per test on two different days within a period extending between days – 24~~& -10 (or between days -40 & -10 if only a single value was reported between days -24 & day -10) before HCT.~~ and the start of the preparative regimen. If only a single value was reported in this time period, use the most recent test performed between days -40 & -25 as the second value.**Renal (Moderate/Severe) Comorbidity:**Serum creatinine > 2 mg/dL or > 177 μmol/L, as detected in at least two lab values on two different days within a period extending between days – 24[2556: Myelofibrosis CMS Study Pre-HCT Data](#404)*The reported value must be in units of cells / µL.*[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*Use the multiple myeloma response criteria when determining the disease status for multiple myeloma and solitary plasmacytoma.**Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.*

[Plasma Cell Leukemia Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/pcl-response-criteria)**September 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 9/28/17 |
|

*Indicate whether cytogenetic studies were performed at the last evaluation prior to HCT / cellular therapy.*~~Do not report any testing performed after treatment for AML has started.~~ If cytogenetic studies were obtained at this time point, check “Yes” and go to question 60.[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2014: MDS/MPN Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)*Recipients transplanted for post-essential thrombocythemia myelofibrosis (post-ET MF) or post-polycythemia vera myelofibrosis (post-PV MF) will be reported as ET or PV at diagnosis (Q2). Question 123: ‘Did the recipient progress or transform to a different MDS/MPN subtype between diagnosis and the start of the preparative regimen?’ must be answered “Yes”.*~~Myelofibrosis that develops in patients with essential thrombocythemia (ET) or polycythemia vera (PV) is considered secondary myelofibrosis. Do not report this as a transformation; when a patient with ET or PV develops fibrosis, do not report primary myelofibrosis as the primary indication for transplant.~~**August 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 8/31/17 |
|

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Severe abdominal pain, with or without ileus, and / or grossly bloody stool*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Severe abdominal pain, with or without ileus, and / or grossly bloody stool*[2014: MDS/MPN Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)*Refer to the MDS / MPN Response Criteria section when determining the recipient’s disease status. Indicate if the disease relapsed from CR or progressed from hematologic improvement. If the disease relapsed or progressed, answer “Yes” and go to question 122. If “No,” go to question 123.**Progression or relapse should be reported even if it was reported in the previous set of questions regarding response to therapy (questions 118-120).**Relapse is the recurrence of disease after CR. MDS/MPN relapse requires one of the following:*

*Return to pre-treatment bone marrow blast percentage.**Decrease of ≥ 50% from maximum response levels in granulocytes or platelets**Transfusion dependence, or hemoglobin level ≥ 1.5 g/dL lower than prior to therapy.*

*Progression is the worsening of the disease following hematologic improvement or stable disease. Progression requires at least one of the following in the absence of another explanation (e.g., infection, bleeding, ongoing chemotherapy, etc.):**≥ 50% reduction from maximum response levels in granulocytes or platelets**Reduction in hemoglobin by ≥ 1.5 g/dL**Transfusion dependence**Progression to AML: ≥ 20% blasts in the blood or bone marrow*

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*For reporting purposes, “at diagnosis” is defined as the period between onset of signs / symptoms and the initiation of therapy to treat GVHD (topical or systemic).*[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Report the stage of each organ at diagnosis. For reporting purposes, “at diagnosis” is defined as the period between onset of signs / symptoms and the initiation of therapy to treat GVHD (topical or systemic).*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*For reporting purposes, “at diagnosis” is defined as the period between onset of signs / symptoms and the initiation of therapy to treat GVHD (topical or systemic).*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Report the stage of each organ at diagnosis. For reporting purposes, “at diagnosis” is defined as the period between onset of signs / symptoms and the initiation of therapy to treat GVHD (topical or systemic).***July 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/17 |
|

*Report the date of maximum chronic GVHD involvement, based on clinical grade , during the current reporting period.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Report the maximum chronic GVHD involvement, based on clinical grade, since the date of the last report.*~~as documented by the recipient’s primary care provider.~~[2402: Disease Classification](#404)[2046: Fungal Infection Pre-Infusion Data](#404)[2146: Fungal Infection Post-Infusion Data](#404)[4006: Cellular Therapy Infusion](#404)[4100: Cellular Therapy Essential Data Follow-Up](#404)[4000: Cellular Therapy Essential Data Pre-Infusion](#404)[2111: ALL Post-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111)[2011: ALL Pre-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2011)[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)[2110: AML Post-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110)[2010: AML Pre-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2010)[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)[Appendix D: How to Distinguish Infusion Types](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d)[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Report overall grade III if stage 2-3 liver involvement is documented at the time point being reported and there is no evidence of grade IV GVHD.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Report overall grade III if stage 2-3 liver involvement is documented at the time point being reported and there is no evidence of grade IV GVHD.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Report the date*~~of earliest administration of therapy for relapsed, persistent, or progressive disease or decreasing / loss of donor chimerism within the report period~~ therapy was started for the reason specified in question 165; if multiple instances, cycles, or lines of therapy are administered, report the date of the first treatment. If treatment was started in a prior reporting period and continues into the current reporting period, report the original therapy start date (prior to the start of the current reporting period) and override the validation error in FormsNet3SMusing the code “verified correct.” If therapy was stopped in a prior reporting period and restarted (or a new therapy was started) during the current reporting period, report the earliest date treatment was administered during the current reporting period. See the intervention reporting scenarios provided below for further clarification.[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Indicate the methods detecting the reason for which therapy for persistent disease, relapsed / progressive disease, or for decreased / loss of donor chimerism was given (as reported in question 165). For each option, select “yes” if the last assessment by that method was performed prior to the start of the intervention(s) and was consistent with the rationale reported in question 165.**… If multiple therapies were given during the reporting period for different reasons (e.g., the recipient initially receives treatment for decreased chimerism and subsequently receives different treatment for relapse during the same reporting period), report “yes” for any methods of detection confirming the reason in question 165. See the intervention reporting scenarios provided below for further clarification.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Indicate whether therapy was given for persistent disease, relapsed / progressive disease, or for decreased / loss of donor chimerism. In some instances, therapy may be given to treat disease and decrease / loss of chimerism. In these cases, report the indication pertaining to the recipient’s disease status (i.e., “persistent disease” or “relapsed / progressive disease”). If therapy continued from a prior reporting period and a new therapy was started for a different reason during the current reporting period, report the reason the new therapy was started. See the intervention reporting scenarios provided below for further clarification.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**June 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/30/17 |
|

[Appendix F: Response Evaluation Criteria in Solid Tumors](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-f)[Appendix A: Abbreviations and Definitions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-a-abbreviations-and-definitions)- Appendix M: Reporting Comorbidities is now Appendix J: Reporting Comorbidities
- Appendix N: Response Evaluation Criteria in Solid Tumors (RECIST) is now Appendix F: Response Evaluation Criteria in Solid Tumors (RECIST)
- Appendix O: How to Distinguish Infusion Types is now Appendix D: How to Distinguish Infusion Types
- Appendix P: Definition of a Product is now Appendix E: Definition of a Product
- Appendix R: Cytogenetic Abbreviations and Terminology is now Appendix C: Cytogenetic Assessments
- Appendix W: Tracking Disease Status for Multiple Myeloma is now Appendix G: Tracking Disease Status for Multiple Myeloma
- Appendix X: MDS/MPN Subtypes is now Appendix H: MDS/MPN Subytpes

- Appendix C: CIBMTR Data collection Forms – This information is now available in the Data Management Guide.
- Appendix D: Unique ID Assignment Form (CRID), Form 2804 – This information can be found in the
[2804: CIBMTR Research ID Assignment Form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2804-2814-crid-assignment-and-indication)section of the Forms Instructions Manual. - Appendix E: Public Health Authority (PHA) Status – This information is now available in the Data Management Guide.
- Appendix F: Validation Ranges – This appendix has been retired. An archived copy can be found on the
[Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx)webpage. - Appendix G: Continuous Process Improvement (CPI) and Procedures for Non-compliance – This information is now available in the Data Management Guide.
- Appendix H: Summary of CIBMTR On-Site Data Audit Program – This information will be moved to the
[CIBMTR website](https://www.cibmtr.org/pages/index.aspx). - Appendix J: CIBMTR Contact Information – This information is now available in the Data Management Guide.

Appendix Q: United States Abbreviations – This information is now available in[Appendix A: Abbreviations and Definitions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-a-abbreviations-and-definitions).

Appendix S: Multiple Donor Chimerism – This appendix has been retired. An archived copy can be found on the[Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx)webpage.

Appendix T: Pre-HCT Treatment for Lymphoma – This appendix has been retired. An archived copy can be found on the[Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx)webpage.

Appendix U: Helpful Hints for Reporting Co-Existing Diseases – This appendix has been retired. An archived copy can be found on the[Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx)webpage.

Appendix V: Multiple Myeloma – Defining What Baseline to Use When Determining Disease Status – This information is now available in Appendix G: Tracking Disease Status for Multiple Myeloma.

Appendix Y: Critical Fields – This information will be moved to the[CIBMTR website](https://www.cibmtr.org/pages/index.aspx).

Appendix Z: Primary Disease and Disease Inserts Due – This information is now available in the Data Management Guide.

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*When reporting the date started, report the first day the drug as given on or after the GVHD diagnosis date (reported in question 158).*~~If acute GVHD persisted since the date of the last report, report the first day the drug was given during the current reporting period.~~ For **prophylaxis medications**continued after the date of diagnosis of acute GVHD, report the date of diagnosis as the date started. If an acute GVHD treatment has continued from a previous reporting period, report the original start date and override the error in FormsNet3SMusing the code “verified correct.”[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)Report “no” if chronic GVHD was not clinically diagnosed – initially or as a flare – in the reporting period; this includes instances where chronic GVHD persists from a prior reporting period.

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Report “no” if chronic GVHD was not clinically diagnosed – initially or as a flare – in the reporting period; this includes instances where chronic GVHD persists from a prior reporting period.*~~without flare in the current reporting period.~~[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)- Myelofibrosis absent or ≤ grade 1 fibrosis (mild reticulin fibrosis)

[2402: Pre-TED Disease Classification](#404)*Indicate the disease status of the PCD at the last evaluation prior to the start of the preparative regimen. If the primary disease is Amyloidosis or POEMS, report “Not applicable” and go to the signature line.***May 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/31/17 |
|

**not**report the following scenarios:”- Yeast infection in the groin, vagina, or under the breasts
- Pneumocystis jiroveci

[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Steroids and Non-Steroid Immunosuppression for GVHD**warning box to the instructions for question 37 and 38.[2012: CML Pre-Infusion Data Form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-cml-pre-hct-data)Translocation of three or more chromosomes, one of which must be chromosome 22 [e.g., t( 3; 9; 22)]

[2553: VOD/SOS](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2553-vod-sos)*The Veno-occlusive Disease (VOD) / Sinusoidal Obstruction Syndrome (SOS) Form, Form 2553, must be completed when VOD / SOS has been reported to have developed on the 100 Day Post-HCT Data Form (F2100) or the 100 Day Post-TED Form (Form 2450). Additionally, a Six Month VOD/SOS Form will come due if the center has reported VOD/SOS did not resolve during the 100 day reporting period (question 124). This form captures laboratory and pathologic studies at the time of diagnosis, treatment administered during the reporting period, and the maximum severity of VOD / SOS during the reporting period.*[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Graft failure / insufficient hematopoietic recovery:**Additional hematopoietic stem cells are required because the hematopoietic recovery indefinitely declined after the initial hematopoietic recovery (ANC was greater than or equal to 0.5 × 109/L for three consecutive days, and then declined to below 0.5 × 109/L for at least three consecutive days). This option also includes primary graft failure (no ANC recovery following HCT).[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Non-Malignant Diseases***If the HCT being reported was given to treat a non-malignant disease (as reported on the Pre-TED Disease Classification Form {Form 2402}), do not complete the following sections of the Post-TED Form:**Q75-97: Disease Assessment at the Time of Best Response to HCT**Q98-160: Post-HCT Therapy**Q235-238: Current Disease Status*

*Questions 161-163 will also be left blank if the HCT being reported was given to treat a non-malignant disease.*

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Therapy Over Multiple Reporting Periods**note box to the instructions for question 4.[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Therapy Over Multiple Reporting Periods**note box to the instructions for question 12.[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Malignant Diseases Only**warning box to the following pages of the Post-TED Manual:- Q75-97: Disease Assessment at the Time of Best Response to HCT
- Q98-160: Post-HCT Therapy
- Q161-234: Relapse or Progression Post-HCT
- Q235-238: Current Disease Status

[4006: Cellular Therapy Infusion](#404)*If the product was manufactured by a cell processing laboratory at the same center as the product is being infused, continue with question 27. If the product is from an NMDP donor used for a prior HCT, please select this option.*

If the product was manufactured by another site that does not fit a category listed above, specify the other site in question 24.~~and report the name and location in question 26.~~If the product was manufactured by another site that does not fit a category listed above, specify the other site in question 24.

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Previously Reported**warning box to instructions for questions 402-403 and 405-406.[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Previously Reported**warning box to instructions for questions 402-403 and 405-406.[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Corticosteriods**note box to instructions for question 401.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*A treatment where***all**of the following criteria met:*Serum and Urine M-protein detectable by immunoelectrophoresis*(immunofixation, IFE) but not on electrophoresis (SPEP and UPEP)[1](#fn59836243568596b184bd81-1)~~≤~~< 5% plasma cells in bone marrow.

**April 2017**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/17 |
|

*Cellular therapy refers to the infusion of human or animal derived cells, which may or may not be modified or processed to achieve a specific composition. Examples include T-cell, NK cell, and mesenchymal cell infusions as well as donor cellular infusions. Indicate “yes” if the recipient received any form of cellular therapy for*~~reasons other than~~ relapse, persistent, or progressive disease or decreasing / loss of donor chimerism; hematopoietic cell transplantation should not be reported as cellular therapy, as this is captured in questions 7-13 of the Post-TED form.[4100: Cellular Therapy Essential Data Follow-Up](#404)*Report the date (YYYY-MM-DD) the sample was collected for chimerism studies. If multiple studies were performed in the reporting period, report the most recent testing that documents persistence of cells by chimerism studies. If all the chimerism studies are negative for persistence of cells, then report the most recent test performed in the reporting period.*[4100: Cellular Therapy Essential Data Follow-Up](#404)*Report the date (YYYY-MM-DD) the sample was collected for flow cytometry testing (immunophenotyping). If multiple studies were performed in the reporting period, report the most recent testing that documents persistence of cells by flow cytometry. If all the flow cytometry tests are negative for persistence of cells, then report the most recent test performed in the reporting period.*[4100: Cellular Therapy Essential Data Follow-Up](#404)*Report the date (YYYY-MM-DD) the sample was collected for molecular assay. If multiple studies were performed in the reporting period, report the most recent testing that documents persistence of cells by molecular assay. If all the molecular assays are negative for persistence of cells, then report the most recent test performed in the reporting period.*[4000: Cellular Therapy Essential Data Pre-Infusion](#404)*Report the intended start date of the infusion for the instance being reported. If multiple infusions are planned within the first 100 days, each infusion must be reported as a separate instance / copy of questions 31-35 and the planned infusion date, question 31, will correspond to the specific infusion being reported. The planned infusion date of the earliest infusion must match the planned infusion date reported on one of the following forms:*- Indication for CRID Assignment Form (Form 2814) – This form will be used to generate a Cellular Therapy Essential Data Form (Form 4000) when the recipient has not received a HCT.
- Post-Transplant Essential Data Form (Form 2450) – This form will generate a Cellular Therapy Essential Data Form (Form 4000) when the recipient has received an HCT followed by a donor cellular infusion (excluding subsequent HCTs) or other cellular therapy.
- Post-HCT Follow-Up Data Form (Form 2100) – This form will generate a Cellular Therapy Essential Data Form (Form 4000) when the recipient has received an HCT followed by a donor cellular infusion (excluding subsequent HCTs) or other cellular therapy.

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Questions 645-647 will only be enabled / answered for pediatric patients (≤ 16 years old) when the form visit ID is 6 months or greater. These questions will be disabled / not answered for all recipients on the day 100 follow-up form.*[4000: Cellular Therapy Essential Data Pre-Infusion](#404)*The intent of question 34 is to determine whether an HLA Form (Form 2005) has already been completed for this donor so that duplicate reporting may be avoided. For infusions using an NMDP donor or cord blood unit, the donor’s HLA typing is reported on NMDP Form 22 (Confirmation of Donor HLA Typing) and the recipient’s HLA typing is reported on NMDP Form 117 (Final Recipient HLA Typing). Please contact your CRC if you think the Form 2005(s) should be removed.*[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Interventions for Decreased / Loss of Chimerism:***The Post-TED Form (Form 2450) captures interventions given for decreased or loss of chimerism in the relapse / progression section of the form. If the recipient receives an intervention for decreased or loss of chimerism during the reporting period, report the therapy in questions 164-234. This instruction may differ from prior guidelines regarding how to report interventions for decreased / loss of chimerism on past revisions (1-3) of the Post-TED Form.*[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Other site(s) involved with acute GVHD:**Indicate whether acute GVHD affected an organ other than skin, upper GI, lower GI, or liver manifesting with hyperbilirubinemia. This includes transaminitis attributed to acute GVHD. Report only other organ involvement at the time of acute GVHD diagnosis or flare in the reporting period. Do not report symptoms ongoing but not attributed to acute GVHD at the time of acute GVHD diagnosis or flare. Specify the other organ system involvement in question 28. If reporting transaminitis under “other site,” write in “transaminitis” rather than “liver” when specifying the site. This will prevent queries regarding incorrectly reporting liver GVHD (with bilirubin elevation) under “other site.”[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Other site(s) involved with acute GVHD:**Indicate whether acute GVHD affected an organ other than skin, upper GI, lower GI, or liver manifesting with hyperbilirubinemia. This includes transaminitis attributed to acute GVHD. Report only other organ involvement at the time of acute GVHD diagnosis or flare in the reporting period. Do not report symptoms ongoing but not attributed to acute GVHD at the time of acute GVHD diagnosis or flare. Specify the other organ system involvement in question 28. If reporting transaminitis under “other site,” write in “transaminitis” rather than “liver” when specifying the site. This will prevent queries regarding incorrectly reporting liver GVHD (with bilirubin elevation) under “other site.”[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Blood**in the instructions for questions 428-436.**Blood:**includes blood or serum obtained from a central IV line, catheter tip, or from a direct needle stick (Peripheral draw). Blood should be the reported site for infections identified in the**bone marrow**.[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Select the identified or suspected organism as reported on the microbiology report, laboratory report, or other physician documentation. If the specific organism is not listed, use the code “777 – Other organism” and report the name of the organism in the space provided. If a fungal infection is suspected, but not identified, report using code “503 – Suspected fungal infection.”*~~If a bacterial or viral infection is suspected, but not identified, report using code “777 – Other organism” and specify “suspected bacterial infection” or “suspected viral infection” as applicable.~~ As noted above, only report infections which are clinically significant.[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[2006 Title Page](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion):All recipients on the Comprehensive Report Form track must complete the Form 2006. Recipients on the Transplant Essential Data track must complete the Form 2006 for each product when the following product types are infused as part of the transplant:

- NMDP donor products
- NMDP and non-NMDP cord blood units

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Question 159 will only be enabled in FormsNet3*SMif the center has reported “no” for question 157 and, therefore, has not reported a date of diagnosis in question 158. If prompted to answer question 159, report “yes” if acute GVHD was diagnosed in a prior reporting period and**any**of the following conditions are met:*The recipient’s acute GVHD symptoms have been active since diagnosis and continue to be active during the current reporting period (i.e., no period of resolution or quiescence since diagnosis).**The recipient’s acute GVHD symptoms had resolved before the first day of the current reporting period, but a flare occurred***within 30 days**of symptom resolution / quiescence.*The recipient was not diagnosed with chronic GVHD on or before the date of the flare (see note above question 157).*

*Report “no” for questions 157 and 159 if the recipient had no active acute GVHD symptoms during the reporting period***OR**all acute GVHD signs / symptoms during the reporting period occurred after a diagnosis of chronic GVHD (see note above question 157).

~~Indicate whether acute GVHD was clinically diagnosed during a previous reporting period and persisted, with active symptoms, into the present reporting period. Do not report quiescent or inactive acute GVHD, or a prior history of GVHD. If “yes,” continue with question 176; questions concerning acute GVHD at the time of diagnosis will be skipped. See question 157 for instructions on reporting an acute GVHD flare or acute GVHD occurring after the onset of chronic GVHD.~~

~~If the recipient has no active symptoms during the reporting period, report “no” and continue with question 234.~~

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Questions 157 and 159 on the Post-HCT Follow-Up Data Form are meant to capture whether the recipient had active symptoms of acute GVHD during the reporting period. If the recipient had active acute GVHD during the reporting period, either question 157 or question 158 must be answered “yes” unless there has been a prior / concurrent diagnosis of chronic GVHD (refer to the note above question 157). There will not be a situation where “yes” is reported for both question 157 and question 159. If question 157 is answered yes and a diagnosis date has been reported in question 158, question 159 will be disabled in FormsNet3*SM. Centers should report “yes” for question 157 to indicate the recipient developed acute GVHD in the following scenarios:*Acute GVHD is diagnosed for the first time during the reporting period.**An acute GVHD flare is diagnosed during the current reporting period and***all**of the following conditions are met:*The recipient’s prior acute GVHD symptoms did***not**persist from the prior reporting period into the beginning of the current reporting period.*The flare is diagnosed after***at least 30 days**without any active acute GVHD symptoms.*The recipient was not diagnosed with chronic GVHD on or before the date of the flare (see note above question 157).*

*If the recipient does have active acute GVHD during the reporting period, but does not match either of the scenarios above, the center will likely need to report “no” for question 157 and “yes” for question 159. Question 159 is intended to capture acute GVHD which has continued from a prior reporting period. This includes any flares which do not meet the above conditions. The intent of classifying GVHD episodes as newly developed or persistent is to avoid having centers re-report diagnosis information which has been captured on a prior form. Refer to the Acute GVHD Diagnosis Scenarios below to see examples of how to answer questions 157 and 159.*

*Report “no” for questions 157 and 159 if the recipient had no active acute GVHD symptoms during the reporting period***OR**all acute GVHD signs / symptoms during the reporting period occurred after a diagnosis of chronic GVHD (see note above question 157).

~~Indicate whether a new clinical diagnosis of acute GVHD was documented during the reporting period. If acute GVHD was diagnosed during the reporting period, report “yes” and continue with question 158.~~

~~If the recipient had a flare of acute GVHD occurring after at least a 30 day period of symptom quiescence, report “yes” and continue with question 158. Report “no” if symptoms resolve or become quiescent prior to the date of last report and then flare within 30 days. This should be reported as persistent acute GVHD which is captured in question 159.~~

~~Indicate “no” if acute GVHD was not clinically diagnosed – initially or as a flare – in the reporting period; this includes instances where acute GVHD persists from a prior reporting period without flare in the current reporting period.~~


[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Question 21 will only be enabled in FormsNet3*SMif the center has reported “no” for question 19 and, therefore, has not reported a date of diagnosis in question 20. If prompted to answer question 21, report “yes” if acute GVHD was diagnosed in a prior reporting period and**any**of the following conditions are met:*The recipient’s acute GVHD symptoms have been active since diagnosis and continue to be active during the current reporting period (i.e., no period of resolution or quiescence since diagnosis).**The recipient’s acute GVHD symptoms had resolved before the first day of the current reporting period, but a flare occurred***within 30 days**of symptom resolution / quiescence.*The recipient was not diagnosed with chronic GVHD on or before the date of the flare (see note above question 19).*

*Report “no” for questions 19 and 21 if the recipient had no active acute GVHD symptoms during the reporting period***OR**all acute GVHD signs / symptoms during the reporting period occurred after a diagnosis of chronic GVHD (see note above question 19).

~~Indicate whether acute GVHD was clinically diagnosed during a previous reporting period and persisted, with active symptoms, into the present reporting period. Do not report quiescent or inactive acute GVHD, or a prior history of GVHD. If “yes,” continue with question 29; questions concerning acute GVHD at the time of diagnosis will be skipped. See question 19 for instructions on reporting an acute GVHD flare or acute GVHD occurring after the onset of chronic GVHD.~~

~~If the recipient has no active symptoms during the reporting period, report “no” and continue with question 31.~~

[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Questions 19 and 21 on the Post-TED Form are meant to capture whether the recipient had active symptoms of acute GVHD during the reporting period. If the recipient had active acute GVHD during the reporting period, either question 19 or question 21 must be answered “yes” unless there has been a prior / concurrent diagnosis of chronic GVHD (see note above question 19). There will not be a situation where “yes” is reported for both question 19 and question 21. If question 19 is answered yes and a diagnosis date has been reported in question 20, question 21 will be disabled in FormsNet3*SM. Centers should report “yes” for question 19 to indicate the recipient developed acute GVHD in the following scenarios:*Acute GVHD is diagnosed for the first time during the reporting period.**An acute GVHD flare is diagnosed during the current reporting period and***all**of the following conditions are met:*The recipient’s prior acute GVHD symptoms did***not**persist from the prior reporting period into the beginning of the current reporting period.*The flare is diagnosed after***at least 30 days**without any active acute GVHD symptoms.*The recipient was not diagnosed with chronic GVHD on or before the date of the flare (see note above question 19).*

*If the recipient does have active acute GVHD during the reporting period, but does not match either of the scenarios above, the center will likely need to report “no” for question 19 and “yes” for question 21. Question 21 is intended to capture acute GVHD which has continued from a prior reporting period. This includes any flares which do not meet the above conditions. The intent of classifying GVHD episodes as newly developed or persistent is to avoid having centers re-report diagnosis information which has been captured on a prior form. Refer to the Acute GVHD Diagnosis Scenarios below to see examples of how to answer questions 19 and 21.*

*Report “no” for questions 19 and 21 if the recipient had no active acute GVHD symptoms during the reporting period***OR**all acute GVHD signs / symptoms during the reporting period occurred after a diagnosis of chronic GVHD (see note above question 19).

~~Indicate whether a new clinical diagnosis of acute GVHD was documented during the reporting period. If acute GVHD was diagnosed during the reporting period, report “yes” and continue with question 20.~~

~~If the recipient had a flare of acute GVHD occurring after at least a 30 day period of symptom quiescence, report “yes” and continue with question 20. Report “no” if symptoms resolve or become quiescent prior to the date of last report and then flare within 30 days. This should be reported as persistent acute GVHD which is captured in question 21.~~

~~Indicate “no” if acute GVHD was not clinically diagnosed – initially or as a flare – in the reporting period; this includes instances where acute GVHD persists from a prior reporting period without flare in the current reporting period.~~


Age range for Lansky Scale has been updated from

**March 2017**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/29/17 |
|

Indicate whether systemic therapy was given to treat chronic GVHD during the reporting period. If systemic therapy was given as treatment for chronic GVHD, report “yes” and continue with question 326. If systemic therapy was not given for treatment of chronic GVHD, report “no” and continue with question 399. See questions 328-399 for Chronic GVHD Treatment Reporting Scenarios.

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)If treatment is started for a flare of chronic GVHD (see question 234 for definition of flare), report “no” for question 326 and report the date treatment was started for the flare in question 327.

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)Report the first date when therapy was started for chronic GVHD if the date has not been previously reported. If the recipient continued GVHD prophylaxis drugs after the onset of chronic GVHD, report the date of diagnosis of chronic GVHD as the treatment start date. If the recipient starts treatment multiple times during the same reporting period, report the earliest treatment start date.

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)If treatment is started and subsequently escalated during the same reporting period, report the earliest date treatment was actually given during the reporting period. If a dose is required, contact your center’s liaison to determine how to complete the data field. Additionally, report the earliest start date if a drug is started multiple times during the same reporting period.

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)* Lower intestinal tract involvement where the stage cannot be determined in select scenarios

[lower intestinal tract](#404)involvement description above[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)* Lower intestinal tract involvement where the stage cannot be determined in select scenarios (see

[lower intestinal tract involvement](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#lowergi)description below)[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)If “not applicable” was reported for question 176, question 177 must be left blank.

[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)If “not applicable” was reported for question 29, question 30 must be left blank.

[4000: Cellular Therapy Essential Data Pre-Infusion](#404)**Reporting Consent Status for DCI**If this form is being completed for a DCI reported on a Post-TED Form (Form 2450) or Post-HCT Follow-Up Data Form (Form 2100), report “Not applicable” for question 1. The consent status will be reported on the Pre-TED Form (Form 2400) and should not be re-reported here. If the recipient’s consent status has changed since the Pre-TED Form was completed, update the consent status on the Pre-TED Form.

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)The intent of this question is to determine the recipient’s history of smoking cigarettes only. Do not report the use of cigars, pipe tobacco, chewing tobacco, or other drugs. Indicate whether the recipient has smoked tobacco cigarettes since the date of the last report. If “yes,” complete questions 659-660. If the recipient has not smoked tobacco cigarettes since the date of the last report, or their smoking history is not known, report “no” or “unknown” respectively and continue with question 661.

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100a)*Questions 645-647 will only be enabled / answered for pediatric patients (≤ 16 years old).*[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Indicate “not applicable” in any of the following scenarios:**The recipient has never received systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD.**This form is being completed for a subsequent HCT and the recipient has never received systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD since the start of the preparative regimen for the most recent infusion (or since the date of the most recent infusion if no preparative regimen is given).**The recipient stopped taking systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD in a previous reporting period and did not restart systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) during the current reporting period.*

[2450: Post-TED Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*Indicate “not applicable” in any of the following scenarios:**The recipient has never received non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD.**This form is being completed for a subsequent HCT and the recipient has never received non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD since the start of the preparative regimen for the most recent infusion (or since the date of the most recent infusion if no preparative regimen was given).**The recipient stopped taking non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD in a previous reporting period and did not restart non-steroidal immunosuppressive agents (including PUVA) during the current reporting period.*

[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)Relapse is defined as the recurrence of disease after CR, meeting one or more of the following criteria:

- ≥ 5% blasts in the marrow or peripheral blood
- Extramedullary disease
- Disease presence determined by a physician upon clinical assessment

[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*If chronic GVHD was diagnosed during the reporting period, report the maximum severity of acute GVHD prior to the onset of chronic GVHD. See question 19 for further instructions. Acute GVHD grading scenario D below has been provided for further clarification.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)*If acute GVHD is diagnosed prior to chronic GVHD, report the diagnosis information, maximum severity of any symptoms, and treatment administered up to the date of diagnosis of chronic GVHD in the acute GVHD section of the form (questions 19-30). Do not include any signs, symptoms, or treatment occurring on or after the onset of chronic GVHD when completing the acute GVHD section.*

Report any~~(persistent or newly diagnosed)~~ occurring on or after the ~~date of diagnosis~~ onset of chronic GVHD only in the chronic GVHD section. ~~of the form (questions 234-323). See the examples included in the instructions for questions 252-301.~~ If chronic GVHD was diagnosed in a prior reporting period, ~~the center should-report “no” for questions 19 and 21 in each subsequent reporting period. -Any GVHD symptoms occurring in each subsequent reporting period must be reported in the chronic GVHD section of the form and should not be re-reported in the acute GVHD data fields.~~ See reporting scenarios included in question 19.Report any

**new or persistent acute**GVHD symptoms[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*If a recipient has signs / symptoms of both acute and chronic GVHD*~~on or after the date chronic GVHD is diagnosed, report all signs / symptoms in the chronic GVHD section of the form. If acute GVHD signs / symptoms are identified prior to the diagnosis of chronic GVHD, they should also be reported in the acute GVHD section of the form (questions 157-183) during the reporting period,~~ refer to question 157 for additional instructions. Scenarios C and D below have also been provided for further clarification.[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*Chronic GVHD can be separated into two different categories; classical chronic GVHD and overlap syndrome. Overlap syndrome is a condition where there are features of both acute and chronic GVHD at the time of diagnosis. Indicate whether signs of acute GVHD were present at the time of diagnosis of chronic GVHD (overlap syndrome).*~~Ensure any features of acute GVHD are reported in questions 169-183. Report all GVHD signs / symptoms (acute and chronic) occurring on or after the diagnosis of chronic GVHD in the chronic GVHD section of the form. See questions 252-301 below for further instructions on reporting acute and chronic GVHD signs / symptoms.~~ Refer to question 157 for instructions on how to complete acute and chronic GVHD sections for recipients with overlap syndrome.[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*If chronic GVHD was diagnosed during the reporting period, report the maximum severity of acute GVHD prior to the onset of chronic GVHD. See question 157 for further instructions. Acute GVHD grading scenario D below has been provided for further clarification.*[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)*If acute GVHD is diagnosed prior to chronic GVHD, report the diagnosis information, maximum severity of any symptoms, and treatment administered up to the date of diagnosis of chronic GVHD in the acute GVHD section of the form (questions 157-233). Do not include any signs, symptoms, or treatment occurring on or after the onset of chronic GVHD when completing the acute GVHD section.*

Report any~~(persistent or newly diagnosed)~~ occurring on or after the ~~date of diagnosis~~ onset of chronic GVHD only in the chronic GVHD section. ~~of the form (questions 234-323). See the examples included in the instructions for questions 252-301.~~ If chronic GVHD was diagnosed in a prior reporting period, ~~the center should-report “no” for questions 157 and 159 in each subsequent reporting period. -Any GVHD symptoms occurring in each subsequent reporting period must be reported in the chronic GVHD section of the form and should not be re-reported in the acute GVHD data fields.~~ See reporting scenarios included in question 157.Report any

**new or persistent acute**GVHD symptoms[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**Lower Intestinal Tract**description beneath questions 23-28:If diarrhea is attributed to acute GVHD during the reporting period, but the volume of stool output is not documented, report “stage 0” for lower intestinal tract involvement. In this case, report “Not Applicable” for the overall grade unless stage 4 acute skin GVHD, stage 4 acute liver GVHD, or an extreme decrease in performance status was also documented at the time point being reported (at diagnosis or maximum grade during the reporting period). Report an overall grade of IV if stage 4 acute skin GVHD, stage 4 acute liver GVHD, or an extreme decrease in performance status is documented at the time point being reported (see GVHD Staging and Grading Table).

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)**Lower Intestinal Tract**description beneath questions 170-175:If diarrhea is attributed to acute GVHD during the reporting period, but the volume of stool output is not documented, report “stage 0” for lower intestinal tract involvement. In this case, report “Not Applicable” for the overall grade unless stage 4 acute skin GVHD, stage 4 acute liver GVHD, or an extreme decrease in performance status was also documented at the time point being reported (at diagnosis or maximum grade during the reporting period). Report an overall grade of IV if stage 4 acute skin GVHD, stage 4 acute liver GVHD, or an extreme decrease in performance status is documented at the time point being reported (see GVHD Staging and Grading Table).

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)Use questions 153-155 to report any prior

**hematologic**malignancies that were not listed in questions 136-152.**Solid tumors should be reported in questions 144-131, not in questions 153-155.**[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)If an acute GVHD treatment has continued from a previous reporting period, report the original start date and override the error in FormsNet3

SMusing the code “verified correct.”[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)If therapy has continued from a previous reporting period, report the original start date and override the validation error in FormsNet3

SMusing the code “verified correct.”[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)If acute GVHD is diagnosed prior to chronic GVHD, report the diagnosis information, maximum severity of any symptoms, and treatment administered up to the date of diagnosis of chronic GVHD in the acute GVHD section of the form (questions 19-30). Report any GVHD symptoms (persistent or newly diagnosed) occurring on or after the date of diagnosis of chronic GVHD in the chronic GVHD section of the form (questions 31-36). See the examples included in the instructions for question 19.

If chronic GVHD was diagnosed in a prior reporting period, the center should report “no” for questions

[2100: Post-HCT Follow-Up Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[Chronic GVHD Organ Scoring](#404)table included under questions 252-301. The criteria were documented incorrectly and have been updated to match the[2014 NIH Consensus Criteria.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4329079/)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[Chronic GVHD Organ Scoring](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#cgvhdscore)table included under question 34. The criteria were documented incorrectly and have been updated to match the[2014 NIH Consensus Criteria.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4329079/)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)Questions 14-15 can only be completed on the 100 day, 6 month, 1 year, and 2 year follow-up forms. These questions will be skipped for all subsequent reporting periods. Question 16 must be answered on all follow-up forms.

**February 2017**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/27/17 |
|

This question was removed from the Form 2400 and included in the Form 2402 during the Winter Forms Revision 2017 (January 31, 2017). The ISS staging criteria are correct on the Form 2402.

[4000: Cellular Therapy Essential Data Pre-Infusion](#404)Indicate if the allogeneic unrelated or related donor reported in question 32 was used for prior cellular therapies

**or HCT**for this recipient. Do not answer this question for autologous donors.**The intent of question 34 is to determine whether an HLA Form (Form 2005) has already been completed for this donor so that duplicate reporting may be avoided.**[2016: PCD Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)[2402: Pre-TED Disease Classification](#404)[4000: Cellular Therapy Essential Data Pre-Infusion](#404)**Questions 19-27 HCT History**[4100: Cellular Therapy Essential Data Follow-Up](#404)**Question 1 Date of Contact**[4100: Cellular Therapy Essential Data Follow-Up](#404)**Questions 15-16 Subsequent HCT**[4100: Cellular Therapy Essential Data Follow-Up](#404)**Questions 22-26 New Malignancy****January 2017**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/31/17 |
|

[2012: CML Pre-Infusion Data Form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-cml-pre-hct-data)[2556: Myelofibrosis CMS Study Pre-HCT Data](#404)[2557: Myelofibrosis CMS Study Post-HCT Data](#404)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[2402: Pre-TED Disease Classification](#404)[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[2005: Confirmation of HLA Typing](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2005-confirmation-of-hla-typing)[2900: Recipient Death](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2900)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Appendix V](#404)[General Instructions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-instructions)- Stem Cells Therapeutic Outcomes Database
- Center Type and Data Collection Forms
- Autologous Hematopoietic Stem Cell Transplant
- EBMT Centers
- Protocols and Consent Forms
- Unique ID Assignment (CRID) & Protected Health Information, Form 2804
- FormsNet
- Forms Due Report
- CIBMTR Campus & CRC Assignment
- Declaring Recipients Lost to Follow-Up
- Recipient Transfers
- How to Avoid Errors
- Reimbursement for Forms Completion
- Continuous Process Improvement
- On-site Data Audits
- Helpful Websites and CIBMTR Contact Information

Please contact your center’s CRC for assistance with any of these topics while this information is being updated and transferred. Retired versions of these sections may be found[here](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx).

Last modified:
Sep 10, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)