#### Question 1: Were any red blood cell (RBC) transfusions administered?

Red blood cell (RBC) transfusions are often given as supportive care for recipients with thalassemia.

Transfusions may be referred to as “simple” or “exchange” transfusions. A simple transfusion refers to a direct infusion of a blood product. An exchange transfusion refers to the slow removal and replacement of the recipient’s blood with that of a healthy donor’s blood.

Indicate if any red blood cell (RBC) transfusions were administered within the current reporting period. If the recipient did not receive RBC transfusions in the current reporting period, select **No**.

#### Question 2: Date of RBC transfusion event

Report the date of the RBC transfusion administered. If the exact date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 3: Number of RBC units

Specify the number of RBC transfusion units administered on the date reported above.

#### Question 4: Hemoglobin level prior to transfusion

Indicate the hemoglobin level and unit of measurement *prior* to the administration of the RBC transfusion. If the hemoglobin was assessed multiple times prior to the RBC transfusion, report the most recent value.

#### Question 5: Indication for RBC transfusion

Report the reason for the RBC transfusion from the following options:

**Supportive transfusion at time of infusion, hospitalization, or during recovery from infusion:**RBC transfusions are required due to cytopenias associated with the infusion (i.e., gene therapy).**β-thalassemia related, after recovery from infusion:**Following the infusion (i.e., gene therapy), RBC transfusions are required due to β-thalassemia related cytopenias.**Not related to β-thalassemia (e.g. acute event, surgery, pre-procedure prophylaxis):**RBC transfusions are required due to cytopenias for other reasons, such as surgery, an acute event (i.e., GI bleed), prophylaxis prior to a procedure). The RBC transfusions are not required due to the infusion (i.e., gene therapy) or β-thalassemia.

If the reason is unclear, seek physician clarification. If the reason cannot be determined, select **Unknown**.

#### Question 6: Were any platelet transfusions administered?

Indicate if any platelet transfusions were administered within the current reporting period. If the recipient did not receive platelet transfusions in the current reporting period, select **No**.

#### Question 7: Date of platelet transfusion event

Report the date of the platelet transfusion administered. If the exact date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 8: Platelet count prior to transfusion

Indicate the platelet count and unit of measurement *prior* to the administration of the platelet transfusion. If platelets were assessed multiple times prior to the platelet transfusion, report the most recent value.

#### Question 9: Number of platelet units

Specify the number of platelet transfusion units administered on the date reported above.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 1 | 2/20/2025 | Add | New blue note box above question 1: Zyntelgo®, For the 100d follow up form, include the last RBC transfusion given prior to discharge from the hospital post-infusion. | Clarification from sponsor for reporting RBC transfusions |
| 1 | 2/20/2025 | Add | New blue note box above question 6: Zyntelgo®, Report only the first and last platelet transfusion in the reporting period. | Clarification from sponsor for reporting platelet transfusions |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)