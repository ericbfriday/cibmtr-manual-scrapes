[December 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#december2016)

[August 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#august2016)

[July 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#july2016)

[June 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#june2016)

[April 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#april2016)

[March 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#march2016)

[February 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#february2016)

[January 2016](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-manual-updates#january2016)

**December 2016**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 12/12/2016 |
|

[2113: CLL Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-hct)**August 2016**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 8/29/16 |
|

[2804 introduction page](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2804-cibmtr-research-id-assignment-form):Reporting of all HCTs is important to ensure the continued epidemiological integrity of the CIBMTR outcomes registry. The exception to this is if your center performs but does not report autologous HCTs.

[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)[question 25](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-43-laboratory-studies-post-hct#25): If CD56+ cells were not tested, centers may report CD16+ results in these data fields.[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)[question 33](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-50-laboratory-studies-at-diagnosis#33): If CD56+ cells were not tested, centers may report CD16+ results in these data fields.[2200: Six Months to Two Years Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2200)[question 43](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q26-47-immune-reconstitution#43): The CD20+ data field can capture CD19+ or CD20+ cells. The CD56+ data field can capture CD56+ or CD16+ cells.[2100: 100 Days Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[question 72](#404): The CD20+ data field can capture CD19+ or CD20+ cells.*The CD56+ data field can capture CD56+ or CD16+ cells.*[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)[question 24](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-43-laboratory-studies-post-hct#q24):If CD20+ cells were not tested, centers may report CD19+ results in these data fields.

[2031/2131: Immune Deficiencies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-2131-immune-deficiencies-id)[question 32](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-50-laboratory-studies-at-diagnosis#q32): If CD20+ cells were not tested, centers may report CD19+ results in these data fields.[2200: Six Months to Two Years Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2200)[Table 3](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q48-73-chimerism-studies)to clarify how centers should report chimerism testing performed on sorted marrow samples.[2100: 100 Days Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[Table 3](#404)to clarify how centers should report chimerism testing performed on sorted marrow samples.[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)Relapse is defined as the recurrence of disease after CR, meeting

*at least one of*the following criteria[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria

*at time of diagnosis*):[2100: 100 Days Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[question 452](#404):If the recipient receives a subsequent HCT prior to day 100, do not include the start date of the preparative regimen for the subsequent HCT (or the date of the subsequent infusion if no preparative regimen was given).

**July 2016**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/29/16 |
|

[4006: Cellular Therapy Infusion](#404)[4100: Cellular Therapy Essential Data Follow-Up](#404)[2553: VOD/SOS](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2553-vod-sos)[2814: Indication for CRID Assignment](#404)[2013: CLL Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2013-cll-pre-hct)**June 2016**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/27/16 |
|

**Urine Studies**:In order to report a Stringent Complete Remission

*(sCR)*or Complete Remission*(CR)*, urine studies MUST be performed and agree with the international*myeloma*working group*(IMWG)*criteria provided above.*As long as the negative serum electrophoresis and immunofixation studies have been confirmed, only one set of negative urine studies needs to be documented to report sCR or CR.**IMWG*criteria for the disease status being reported. In any case, serum studies MUST be performed and agree with the international working group criteria for the disease status being reported*(excluding non-secretory myeloma)*.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Urine Studies**In order to report a Stringent Complete Remission or Complete Remission, urine studies MUST be performed and agree with the international working group criteria provided above. Urine electrophoresis and immunofixation studies may not be performed in all cases. The disease response options below (Near Complete Remission, Very Good Partial Response, and Partial Response) may still be reported even if urine studies were never obtained or were only obtained at diagnosis. If urine studies were performed following the most recent line of therapy, the results must agree with the international working group criteria for the disease status being reported. In any case, serum studies MUST be performed and agree with the international working group criteria for the disease status being reported.

[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[Hematologic Improvement](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#hi)Section:Hypomethylating agents (e.g. Vidaza) should not be considered cytotoxic therapy; therefore, Hematologic Improvement may still be reported if the recipient meets the criteria below while continuing to receive hypomethylating agents.

[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[Progression from Hematologic Improvement](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#MDSPHI)for MDS and MPN Response Criteria:If the above criteria for progression have been met, but a hematologic improvement was not previously achieved, report “No Response (NR) / Stable Disease (SD)”.

[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[Hematologic Improvement](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#MPNHI):Requires one measurement of the following maintained for at least eight weeks without ongoing cytotoxic therapy:

[2014: MDS/MPN Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)[Q157](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q154-161-disease-assessment-at-the-last-evaluation-prior-to-the-preparative-regimen#157):“Never Treated” is not an option choice on revision three of the Myelodysplasia / Myeloproliferative Disorders Pre-HSCT Data (MDS) Form. When completing revision three of this form, centers should report “No Response (NR) / Stable Disease (SD)” for recipients who have only received supportive care prior to transplant.

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[Q568](#404):“Never Treated” is not an option choice on revision four of the Pre-TED Form. When completing revision four of this form, centers should report “No Response (NR) / Stable Disease (SD)” for recipients who have only received supportive care prior to transplant.

**April 2016**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/6/16 |
|

Reporting a subsequent transplant using the indication form is not allowed. Report the subsequent transplant on the latest follow up form for the most recent transplant.

[2800: Log of Appended Documents](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2800)**New FormsNet3 feature**:The ‘Attachment’ feature of FormsNet3 allows users to attach documents directly to a form. Direct attachment to the form eliminates the need to fax/scan documents separately with a 2800 form. Training on this feature is available here:

[https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf)[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[questions 46-50](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/donor-information#46):If the recipient receives a cord blood unit and another product from the same related donor, complete two instances of the Donor Information section (questions 31-62) on the Pre-TED Form 2400.

For example, if a related donor gave a cord blood unit and bone marrow, you would report the cord blood unit information in one instance with the donor type listed as ‘Related cord blood unit’. Create another instance with the donor type reported as ‘Related donor’ to report the bone marrow information. This allows CIBMTR to capture all the necessary donor information needed.

For these cases, complete a Form 2004 for each product. When the donor type is an HLA matched or mismatched relative, only one Form 2005 is required.

[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[questions 66-73](#404)to reflect the possibility of multiple causes of death (i.e., select all that apply), rather than a single primary cause of death.**March 2016**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/31/16 |
|

The website

[Human Gene Nomenclature Committee or Genenames.org](http://www.genenames.org)may be helpful in deciphering common cytogenetic abnormalities.[2014: MDS/MPN Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)[question 123](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation#123):Myelofibrosis that develops in patients with essential thrombocythemia (ET) or polycythemia vera (PV) is considered secondary myelofibrosis. Do not report this as a transformation; when a patient with ET or PV develops fibrosis, do not report primary myelofibrosis as the primary indication for transplant.

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 525](#404):Myelofibrosis that develops in patients with essential thrombocythemia (ET) or polycythemia vera (PV) is considered secondary myelofibrosis. Do not report this as a transformation; when a patient with ET or PV develops fibrosis, do not report primary myelofibrosis as the primary indication for transplant.

[2100: 100 Days Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[question 74](#404):The CD20+ data field can capture CD19+ or CD20+ cells

[2200: Six Months to Two Years Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2200)[question 46](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q26-47-immune-reconstitution#43):The CD20+ data field can capture CD19+ or CD20+ cells

[2118: LYM Post-HCT](#404)[questions 35-36](#404):Questions 35 and 36 are meant to refer to the PET or PET/CT scan at relapse.

[2016: PCD Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)[question 188](#404):If this form is being completed for a second or subsequent transplant for relapse or progression of the same disease, report all therapy given for relapse or progression of disease. Do not report maintenance therapy given after the prior transplant, as this will be captured on the post-transplant disease inserts associated with the prior transplant.

[2016: PCD Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)[question 1](#404)to:[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 589](#404)to:[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 93](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q90-93-clinical-status-of-recipient-prior-to-the-preparative-regimen-conditioning#93). [see table in text][2000: Recipient Baseline](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2000)[question 65](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q55-75-infection#64). [see table in text]**February 2016**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/16/16 |
|

*[see table in text]*[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[obesity comorbidity](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q94-154-comorbid-conditions#97)to include pediatric patients:**Obesity:**Patients with a body mass index > 35 kg/m2or*BMI-for-age ≥ 95% (pediatric recipients only) during pre-transplant work-up period.*[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)[2133: WAS Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2133-was-post-hct-data)[question 171 [2131]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q167-172-status-of-hematologic-engraftment#171)and[question 173 [2133]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q169-174-status-of-hematologic-engraftment#173):Myeloid subsets may be reported as

*CD15+*or CD33+ on the laboratory report.[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[2100: 100 Days Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[2200: Six Months to Two Years Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2200)[2300: Greater Than Two Years Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2300)[15 [2450]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#15),[151 [2100]](#404),[92 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q81-128-acute-graft-vs-host-disease-gvhd#92), and[22 [2300]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-58-acute-graft-vs-host-disease-gvhd#22). See table for details.[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 53](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/donor-information#53)to:Report the total number of mobilization events performed

*for this HCT*. Include all mobilization events,*even if a product from the mobilization event for this HCT was not used during the transplant. For example, if 2 mobilization events were performed to collect enough stem cells for this transplant, but the first collection wasn’t necessary for the transplant, report two mobilization events.*[Appendix V: Multiple Myeloma – Defining What Baseline to Use When Determining Disease Status](#404)*Appendix V: Multiple Myeloma – Defining What Baseline to Use When Determining The Best Response to HCT*to*Appendix V: Multiple Myeloma – Defining What Baseline to Use When Determining Disease Status***January 2016**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/22/16 |
|

Persistent nausea with

*or without*histologic evidence of GVHD in the stomach or duodenum.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)The method of the two consecutive assessments may be any of the biochemical tests (urine/serum testing) listed in the disease status criteria available in the manual. Though it is preferable the biochemical confirmatory testing include both the urine & serum, this disease status does not require two consecutive assessments by each method. As an example: [see in text]

Last modified:
Sep 10, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)