**Myeloproliferative Neoplasms** (**MPN**) are characterized by the overproduction of blood cells (red blood cells, white blood cells, and/or platelets) or collagen in the bone marrow. Often the MPN will be identified because of a blood test for another condition, as some recipients are asymptomatic. Common symptoms found in the array of myeloproliferative disorders include fatigue and the enlargement of the spleen (splenomegaly).

#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the disease. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the recipient’s MPN progressed to from a lower grade MPN to a higher grade MPN, report the diagnosis date of the original MPN diagnosis (i.e., the lower MPN grade). The transformation date (i.e., diagnosis of the higher grade) is captured below.

If the recipient’s MPN transformed to AML prior to HCT, report diagnosis date of AML and ensure the primary disease for infusion is reported as AML. The AML section of the Disease Classification Form should be completed appropriately. The MPN diagnosis date is captured below.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

#### Question 273: What was the MPN subtype at diagnosis?

CIBMTR captures the MPN classification based on the World Health Organization (WHO) 2022 classification. Indicate the MPN subtype at diagnosis.

If the MPN subtype is **Myeloproliferative neoplasm (MPN), NOS**, continue with *Was documentation submitted to the CIBMTR*. If the MPN subtype is **Systemic mastocytosis**, specify the type of systemic mastocytosis.

#### Question 274: Specify systemic mastocytosis

Specify the systemic mastocytosis sub-type / variant.

The diagnosis of systemic mastocytosis can be made when the major criterion and at least 1 minor criterion are present, or when >/= 3 minor criteria are present.


- Major criterion
- Multifocal dense infiltrates of mast cells (>/= 15 mast cells in aggregates) detected in sections of bone marrow and/or other extracutaneous organs(s).

- Minor criteria:
- In biopsy sections of bone marrow or other extracutaneous organs, >25% of the mast cells in the infiltrate are spindle-shaped or have atypical morphology; or >25% of all mast cells in bone marrow aspirate smears are immature or atypical.
- Detection of an activating point mutation at codon 816 of KIT in the bone marrow, blood or another extracutaneous organ.
- Mast cells in bone marrow, blood or another extracutaneous organ express CD25, with or without CD2, in addition to normal mast cell markers.
- Serum total tryptase is persistently >20 ng/ml, unless there is an associated myeloid neoplasm, in which case this parameter is not valid.


The diagnostic criteria for the systemic mastocytosis sub-types/variants are as follows. Each sub-type/variant meets the general criteria for systemic mastocytosis with additional criteria for each.


**Indolent systemic mastocytosis**: Low mast cell burden; no evidence of an associated hematologic neoplasm; skin lesions are almost invariably present; no “C” findings.**Smoldering systemic mastocytosis**: +>+2 “B” findings and no “C” findings; high mast cell burden; no evidence of an associated hematologic neoplasm; does not meet criteria for mast cell leukemia**Systemic mastocytosis with an associated hematologic neoplasm**: Meets the criteria for an associated hematologic neoplasm (i.e., MDS, MPN,AML, lymphoma or another hematological neoplasm classified as a distinct entity in the WHO classification).**Aggressive systemic mastocytosis**: >/=1 “C” findings; does not meet the criteria for mast cell leukemia; skin lesions are usually absent.**Mast Cell leukemia**: Bone marrow biopsy shows diffuse infiltrate of atypical, immature mast cells; bone marrow aspirate smears show +>+20% mast cells. In classic cases, mast cells account for +>+10% of the peripheral blood WBC, but the aleukemic variant (in which mast cells account for <10%) is more common. Skin lesions are usually absent**Bone marrow mastocytosis**: Absence of skin lesions and B-findings. Additionally, the basal serum tryptase is < 125 ng / ml.

*“B” (burden of disease) and “C” (cytoreduction-requiring) findings in systemic mastocytosis.*

**“B” findings**


- BM biopsy showing +>+30% infiltration by MC (focal, dense aggregates) and/or serum total tryptase level >200 ng/mL
- Signs of dysplasia or myeloproliferation, in non‐MC lineage(s), but insufficient criteria for definitive diagnosis of a hematopoietic neoplasm (AHNMD), with normal or slightly abnormal blood counts.
- Hepatomegaly without impairment of liver function, and/or palpable splenomegaly without hypersplenism, and/or lymphadenopathy on palpation or imaging.

**“C” findings**


- Bone marrow dysfunction manifested by one or more cytopenia(s) (ANC <1.0 × 109/L, Hgb <10 g/dL, or platelets <100 × 109/L), but no obvious non-mast cell hematopoietic malignancy.
- Palpable hepatomegaly with impairment of liver function, ascites and/or portal hypertension.
- Skeletal involvement with large osteolytic lesions and/or pathological fractures.
- Palpable splenomegaly with hypersplenism.
- Malabsorption with weight loss due to gastrointestinal mast cell infiltrates.

#### Question 275: Was documentation submitted to the CIBMTR (e.g., pathology report used for diagnosis)?

Indicate whether documentation for Myeloproliferative neoplasm, unclassifiable was submitted to the CIBMTR (e.g., pathology report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 276: Did the recipient have constitutional symptoms (> 10% weight loss in six months, night sweats, unexplained fever higher than 37.5°C) in six months before diagnosis?

Indicate if constitutional symptoms were present at diagnosis. Constitutional symptoms are often called “B” symptoms and include unexplained fever greater than 38°C (100.4°F), night sweats, or unexplained weight loss in the six months prior to diagnosis. Indicate “**Yes** if any constitutional symptoms were present at or six months prior to diagnosis.

Indicate **No** if constitutional symptoms were not present at or prior to diagnosis. Indicate **Unknown** if it is not possible to determine the presence or absence of constitutional symptoms at or six months prior to diagnosis.

#### Question 277: Date CBC drawn

These questions are intended to capture the laboratory studies performed at that diagnosis of MPN. All values must reflect testing performed prior to the start of first treatment of the primary disease for HCT. If the recipient’s MPN transformed, report the studies from the original diagnosis.

Report the date the sample was collected for testing.

#### Questions 278 – 279: WBC

Indicate whether the white blood cell (WBC) count was **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Questions 280 – 281: Neutrophils

Indicate whether the neutrophil percentage in the blood was **Known** or **Unknown** at diagnosis. If **Known**, report the value documented on the laboratory report.

#### Questions 282 – 283: Blasts in blood

Indicate whether the percent blasts in the peripheral blood is **Known** or **Unknown** at the time of diagnosis.

If **Known**, report the laboratory value. Note, blasts are not typically found in the peripheral blood. If blasts are not noted on the differential, Known and report “0%” can still be reported.

#### Questions 284 – 285: Hemoglobin

Indicate whether the hemoglobin was **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory value and unit of measure documented on the laboratory report.

#### Question 286: Was RBC transfused ≤ 30 days before the CBC sample date?

Transfusions temporarily increase the red blood cell count. It is important to distinguish between a recipient whose body is creating these cells and a recipient who requires transfusions to support the counts.

Indicate if red blood cells were transfused less than or equal to 30 days prior to the date reported above.

#### Questions 287 – 288: Platelets

Indicate whether the platelet count was **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Question 289: Were platelets transfused ≤ 7 days before the CBC sample date?

Transfusions temporarily increase the platelet count. It is important to distinguish between a recipient whose body is creating the platelets and a recipient who requires transfusions to support the counts.

Indicate if platelets were transfused less than or equal to 7 days prior to the date reported above.

#### Questions 290 – 291: Blasts in bone marrow

Indicate whether the percentage of blasts in the bone marrow was **Known** or **Unknown** at the diagnosis. If **Known**, report the percentage documented on the laboratory report.

#### Questions 292 – 301: Were tests for driver mutations performed?

Testing for driver mutations may be performed by different methods including next generation sequencing (NGS), polymerase chain reaction (PCR), microarray, and fluorescence in situ hybridization (FISH). If testing was performed by any / all of these methods at diagnosis, report **Yes** and report the results for the most recent test(s) prior to the start of therapy.

If testing for driver mutations were not performed / sample failed or is not known if performed, report **No** or **Unknown**, respectively.

#### Question 302: Was documentation submitted to the CIBMTR (e.g. pathology report used for diagnosis)?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 303: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Indicate if cytogenetic studies were obtained at diagnosis. If cytogenetic studies were obtained, select **Yes**.

If no cytogenetic studies were obtained, or it is unknown if chromosome studies were performed, select **No** or **Unknown**, respectively.

#### Question 304: Were cytogenetics tested via FISH?

Indicate if FISH studies were performed at diagnosis. If FISH studies were performed, report **Yes**.

If FISH studies were not performed at diagnosis, FISH sample was inadequate, or it is not known if performed, report **No**. See [Appendix C, Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c) , for assistance interpreting FISH results.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Question 305: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used to test FISH, the preferred sample source to report is the bone marrow.

#### Question 306: Results of tests

Specify if FISH abnormalities were detected at diagnosis.

#### Questions 307 – 310: Specify cytogenetic abnormalities (FISH) at diagnosis

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable.

Report the number of abnormalities detected by FISH at diagnosis, then select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality**, and specify the abnormality. If multiple other abnormalities were detected, report See attachment and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Question 311: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Question 312: Were cytogenetics tested via karyotyping?

If karyotyping was performed at diagnosis, report **Yes**. Report **Yes** even if there were no evaluable metaphase cells (these results will be specified below).

If karyotyping was not performed at diagnosis or it is unknown if performed, report **No**.

#### Question 313: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used for karyotyping analyses, the preferred sample source to report is the bone marrow.

#### Question 314: Results of tests

Specify if abnormalities were detected by karyotype at diagnosis.

If karyotyping assessments failed, select **No evaluable metaphases.**

#### Questions 315 – 318: Specify cytogenetic abnormalities (karyotyping) identified at diagnosis

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping at diagnosis. After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality**, and specify the abnormality. If multiple other abnormalities were detected, report See attachment and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Question 319: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., karyotype report). For further instructions on how to attach documents in FormsNet3 SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome)

#### Question 320: Did the recipient progress or transform to a different MPN subtype or AML between diagnosis and the start of the preparative regimen / infusion?

MPN subtypes may also transform/progress from one into another. Indicate if the recipient’s disease progressed to AML or transformed into a different MPN subtype between initial diagnosis and the start of the preparative regimen / infusion. Progression to AML is defined by an increase in blood or bone marrow blasts > 20%.

If the recipient’s disease did transform or progress, select **Yes**. If there was no documented transformation or progression select **No**.

#### Question 321: Specify the MPN subtype or AML after transformation

Indicate the recipient’s current MPN subtype after transformation. If the recipient experienced more than one transformation after diagnosis, report the most recent subtype.

If the disease **Transformed to AML**, continue with *Date of MPN diagnosis*.

For all other progressions or transformations, continue with to report the date of the most recent transformation.

#### Question 322: Specify the date of the most recent transformation

Report the date of assessment that determined the most recent disease transformation (i.e., if there were multiple transformations, report the most recent). Report the date of the pathological evaluation (e.g., bone marrow) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluations.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, Guidelines for Completing Forms.

#### Question 323: Date of MPN Diagnosis

If the recipient’s MPN transformed to AML prior to HCT, report the date of diagnosis of MPN. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, Guidelines for Completing Forms.

Ensure the date of diagnosis for AML has been reported as the date of diagnosis, AML is reported as the primary disease for infusion, and the AML section of the Disease Classification Form has been completed. Go to the signature line.

#### Question 324: Specify transfusion dependence at the last evaluation prior to the start of the preparative regimen / infusion

Indicate the transfusion dependence for the recipient at the last evaluation prior to the start of the preparative regimen / infusion.

Select **Non-transfused (NTD)** if the recipient was without RBC transfusions as supportive care for the disease within a period of 16 weeks prior to the start of the preparative regimen / infusion.

Select **Low-transfusion burden (LTB)** if the recipient had 3-7 RBC transfusions within a period of 16 weeks in at least 2 transfusion episodes with a maximum of 3 RBC transfusions in 8 weeks prior to the start of the preparative regimen / infusion.

Select **High-transfusion burden (HTB)** if the recipient had ≥8 RBCs transfusions within a period of 16 weeks or ≥4 within 8 weeks prior to the start of the preparative regimen / infusion.

#### Questions 325: Did the recipient have constitutional symptoms ( >10% weight loss in six months, night sweats, unexplained fever higher than 37.5°C) in six months before the last evaluation prior to the start of the preparative regimen / infusion?

Report **Yes** if constitutional symptoms were present within six months before the last evaluation prior to the preparative regimen / infusion. Constitutional symptoms are often called “B” symptoms and include unexplained fever greater than 38°C (100.4°F), night sweats, or unexplained weight loss in the six months before the last evaluation prior to the start of the preparative regimen / infusion.

Report **No** if constitutional symptoms were not present at this timepoint.

Report **Unknown** if it is not possible to determine the presence or absence of constitutional symptoms at this timepoint.

#### Question 326: Did the recipient have splenomegaly at last evaluation prior to the start of the preparative regimen / infusion?

Indicate if the recipient had splenomegaly at the last evaluation. Splenomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate **Yes** if splenomegaly was present at the last evaluation prior to the start of the preparative regimen / infusion.

Indicate **No** if splenomegaly was not present at the last evaluation prior to the start of the preparative regimen / infusion.

Indicate **Unknown** if it is not possible to determine the presence or absence of splenomegaly at the last evaluation prior to the start of the preparative regimen / infusion.

Indicate **Not applicable** if the question does not apply to the recipient (e.g., prior splenectomy).

#### Question 327: Specify the method used to measure spleen size

Indicate the method used to measure the spleen size. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific, and preferred, assessment.

If the method selected is **Physical assessment**, specify the spleen size below the left coastal margin below.

If the method selected is **Ultrasound** or **CT / MRI**, specify the spleen size.

#### Question 328: Specify the spleen size below the left coastal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam.

#### Question 329: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI).

#### Question 330: Did the recipient have hepatomegaly at last evaluation prior to the start of the preparative regimen / infusion?

Indicate if the recipient had hepatomegaly at the last evaluation prior to the start of the preparative regimen / infusion. Hepatomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding.

Indicate **Yes** if hepatomegaly was present at the last evaluation prior to the start of the preparative regimen / infusion.

Indicate **No** if hepatomegaly was not present at the last evaluation.

Indicate **Unknown** if it is not possible to determine the presence or absence if hepatomegaly at the last evaluation prior to the start of the preparative regimen / infusion.

#### Question 331: Specify the method used to measure liver size

Indicate the method used to measure the liver size. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific, and preferred, assessment.

If the method selected is **Physical assessment**, report the liver size below the right coastal margin below.

If the method selected is **Ultrasound** or **CT / MRI**, report the liver size below.

#### Question 332: Specify the liver size below the right coastal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam.

#### Question 333: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI).

#### Question 334: Date CBC drawn

Report the date of the CBC was drawn at the last evaluation prior to the start of the preparative regimen / infusion. If multiple CBCs were drawn, report the most recent one prior to the start of the preparative regimen / infusion.

#### Questions 335 – 336: WBC

Indicate whether the white blood cell (WBC) count was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen infusion / infusion. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Questions 337 – 338: Neutrophils

Indicate whether the neutrophil percentage in the blood was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the value documented on the laboratory report.

#### Questions 339 – 340: Blasts in the blood

Indicate whether the percent blasts in the peripheral blood is **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion.

If **Known**, report the laboratory value. Note, blasts are not typically found in the peripheral blood. If blasts are not noted on the differential, **Known** and report “0%” can still be reported.

#### Questions 341 – 342: Hemoglobin

Indicate whether the hemoglobin was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the laboratory value and unit of measure documented on the laboratory report.

#### Question 343: Were RBCs transfused ≤ 30 days before the CBC sample date?

Transfusions temporarily increase the red blood cell count. It is important to distinguish between a recipient whose body is creating these cells and a recipient who requires transfusions to support the counts.

Indicate if red blood cells were transfused less than or equal to 30 days prior to the CBC sample date reported above.

#### Questions 344 – 345: Platelets

Indicate whether the platelet count was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Question 346: Were platelets transfused ≤ 7 days before date of test?

Transfusions temporarily increase the platelet count. It is important to distinguish between a recipient whose body is creating the platelets and a recipient who requires transfusions to support the counts.

Indicate if platelets were transfused less than or equal to 7 days prior to the CBC sample date reported above.

#### Questions 347 – 348 Blasts in bone marrow

Indicate whether the percentage of blasts in the bone marrow was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the percentage documented on the pathology report.

#### Questions 349 – 358: Were tests for driver mutations performed?

Testing for driver mutations may be performed by different methods including next generation sequencing (NGS), polymerase chain reaction (PCR), microarray, and fluorescence in situ hybridization (FISH). If testing was performed by any / all of these methods at the last evaluation prior to the start of the preparative regimen / infusion, report Yes and report the results for the most recent test(s).

If testing for driver mutations were not performed / sample was inadequate or is unknown, report **No** or **Unknown**, respectively.

#### Question 359: Was documentation submitted to the CIBMTR (e.g. pathology report used for diagnosis)?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 360: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Indicate if cytogenetic studies were obtained at the last evaluation prior to the preparative regimen / infusion. If cytogenetic studies were obtained, select **Yes**.

If no cytogenetic studies were obtained, or it is unknown if chromosome studies were performed, select **No** or **Unknown**, respectively.

#### Question 361: Were cytogenetics tested via FISH?

If FISH studies were performed at the last evaluation prior to the start of the preparative regimen / infusion, report **Yes**. If FISH studies were not performed at this time point, FISH sample was inadequate, or it is unknown if performed, report **No**. See” Appendix C: Cytogenetics”:https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c, for assistance interpreting FISH results.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Question 362: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used to test FISH, the preferred sample source to report is the bone marrow.

#### Question 363: Results of tests

If FISH assessments identified abnormalities, indicate **Abnormalities identified**.

If FISH assessments were unremarkable, indicate **No abnormalities identified**.

#### Questions 364 – 367: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable.

Report the number of abnormalities detected by FISH at the last evaluation prior to the preparative regimen / infusion. After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality**, and specify the abnormality in the allocated space. If multiple other abnormalities were detected, report See attachment and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 368: Was documentation submitted to the CIBMTR? (e.g., FISH report)

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 369: Were cytogenetics tested via karyotyping?

If karyotyping was performed at the last evaluation prior to the preparative regimen / infusion, report **Yes.** Report **Yes** even if there were no evaluable metaphase cells (these results will be specified below).

If karyotyping was not performed at this time point or it is unknown, indicate **No**.

#### Question 370: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used to for karyotyping analyses, the preferred sample source to report is the bone marrow.

#### Question 371: Results of tests

If karyotyping assessments identified abnormalities, indicate **Abnormalities identified**.

If karyotyping assessments yielded **No evaluable metaphases** or there were **No abnormalities identified**, indicate such.

#### Questions 372 – 375: Specify cytogenetic abnormalities (karyotyping) at last evaluation prior to the start of the preparative regimen / infusion

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping at the last evaluation prior to the start of the preparative regimen / infusion. After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality. If multiple other abnormalities were detected, report ‘see attachment’ and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 376: Was documentation submitted to the CIBMTR (e.g., karyotyping report)?

Indicate whether documentation was submitted to the CIBMTR (e.g., karyotype report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 377: What was the disease status?

Indicate the disease status of MPN at the last assessment prior to the start of the preparative regimen / infusion. **Refer to the MPN Response Criteria section of the Forms Instructions Manual for definitions of each disease response**.

If the disease status is **Clinical Improvement (CI)**, continue with *Was an anemia response achieved*.

If the disease status is **Not Assessed**, continue with *Specify the cytogenetic response*.

For all other disease statuses, go to *Date assessed*.

#### Question 378: Was an anemia response achieved?

Specify if an anemia response has been achieved at the last evaluation prior to the preparative regimen / infusion.

An anemia response is characterized by a ≥ 20 g/L (or > 2.0 g/dL) increase in hemoglobin level (for transfusion-independent recipients

#### Question 379: Was a spleen response achieved?

Specify if a spleen response has been achieved at the last evaluation prior to the preparative regimen / infusion.

A spleen response is achieved when a baseline splenomegaly that is palpable at 5 – 10 cm below the left costal margin (LCM) becomes not palpable or baseline splenomegaly that is palpable at > 10 cm below the LCM, decreases by ≥ 50%.

A baseline splenomegaly that is palpable at < 5 cm, below the LCM, is not eligible for spleen response.

A spleen response can be documented by a physician but should be confirmed by MRI / computed tomography showing ≥ 35% spleen volume reduction.

#### Question 380: Was a symptom response achieved?

The Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS) is used to evaluate the recipient’s symptom response. The MPN-SAF TSS is used to provide an accurate assessment of MPN symptom burden. The evaluation tool allows recipients with MPN to report their symptom severity at the worst level. They rate their symptom severity on a scale from zero to ten, zero being absent to ten being the worst imaginable. Adding the scores for all symptoms together will result in the recipient’s MPN-SAF TSS. See Table 1 below for an example of this assessment:

**Table 1.** Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS)

| Symptom | 1 to 10 (0 if absent) ranking – 1 is most favorable and 10 least favorable |
|---|---|
| Please rate your fatigue (weariness, tiredness) by circling the one number that best describes your WORST level of fatigue during the past 24 hours | (No fatigue) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
Circle the one number that describes how, during the past week how much difficulty you have had with each of the following symptoms. |
— |
| Filling up quickly when you eat (early satiety) | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Abdominal discomfort | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Inactivity | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Problems with concentration – Compared to prior to my MPD | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Numbness / tingling (in my hands and feet) | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Night sweats | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Itching (pruritus) | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Bone pain (diffuse not joint pain or arthritis) | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Fever (>100 F) | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |
| Unintentional weight loss last 6 months | (Absent) 0 1 2 3 4 5 6 7 8 9 10 (Worst imaginable) |

A symptom response is achieved when there is a ≥ 50% reduction in the Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS).

Specify if a symptom response has been achieved at the last evaluation prior to preparative regimen / infusion.

#### Question 381: Date assessed

Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen / infusion. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 382: Specify the cytogenetic response

Specify the recipient’s cytogenetic response at the last evaluation prior to the start of the preparative regimen / infusion.

If there is eradication of the previous reported abnormality select **Complete response (CR)**.

If there is a ≥ 50% reduction in abnormal metaphases, select **Partial Remission (PR)**.

Select **Re-emergence** of pre-existing cytogenetic abnormality if the cytogenetic abnormality was eradicated and reemerged at the last evaluation.

If cytogenetic response was not tested at the last evaluation, select **Not assessed** and continue with *Specify the molecular response*.

Select **Not applicable** if cytogenetic abnormalities were never identified and continue with *Specify the molecular response*.

If the recipient does not meet the criteria for **CR** or **PR**, select **None of the above** and continue with *Date assessed* (e.g., if a new cytogenetic abnormality is identified but there is also eradication of a previous abnormality).

Example: A recipient had 10 abnormal metaphases (out of 20) at diagnosis. At the last evaluation prior to the start of the preparative regimen, they had 2 abnormal metaphases (out of 20). As this is a ≥ 50% reduction in abnormal metaphases, Partial Remission (PR) should be reported.

#### Question 383: Date assessed

Report the date the cytogenetic response was established. Enter the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear).

#### Question 384: Specify the molecular response

Specify the recipient’s molecular response at the last evaluation prior to the start of the preparative regimen / infusion, based on the four drive mutations (JAK2, CALR, MPL, and CSF3R).

If there is eradication of the previously reported driver mutation (JAK2, CALR, MPL, and/or CSF3R), select **Complete response (CR)**.

If there is a 50% decrease in allele burden of the driver mutation (JAK2, CALR, MPL, and/or CSF3R), select **Partial Remission (PR)**.

Example: A recipient was found to have a molecular mutation identified (JAK2, CALR, MPL, and/or CSF3R) in 80% of cells examined at diagnosis. At their last evaluation prior to transplant, the molecular mutation was only identified in 40% of cells examined. The number of cells with the molecular mutation identified decreased from 80% to 40%, which is a 50% reduction. In this case, “Partial Remission” should be reported as their molecular response.

Select **Re-emergence of pre-existing molecular abnormality** if the molecular abnormality (JAK2, CALR, MPL, and/or CSF3R) was eradicated and reemerged at the last evaluation.

Select **Not applicable** if JAK2, CALR, MPL, and CSF3R were never identified and go to first name.

If molecular response was not tested at the last evaluation select **Not assessed** and go to first name. If the recipient does not meet the criteria for **CR** or **PR**, select **None of the above** and go to first name.

#### Question 385: Date assessed

Report the date the molecular response was established. Enter the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear).

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q292 | 1/124/2025 | Modify | CALR Testing blue box updated: If CALR testing was performed and positive but the lab report does not specify the type, select . Not done for CALR 1 and CALR 2, and Positive Not done |
Incorrect instructions |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)