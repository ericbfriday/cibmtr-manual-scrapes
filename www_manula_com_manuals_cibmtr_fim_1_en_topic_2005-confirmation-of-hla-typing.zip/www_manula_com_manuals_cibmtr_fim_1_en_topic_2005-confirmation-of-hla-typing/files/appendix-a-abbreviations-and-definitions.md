Appendix A provides definitions of [common manual abbreviations](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-a-abbreviations-and-definitions#comabrev) and [United States abbreviations](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-a-abbreviations-and-definitions#usabrev).

### Common Manual Abbreviations

**YYYY:** 4 digit year

**MM:** 2 digit month

**DD:** 2 digit day

**AHOP:** Adult, Hematology, Oncology or Pediatric Unit (select only one)

**ALLO:** Allogeneic

**ANC:** Absolute Neutrophil Count

**AUTO:** Autologous

**BM:** Bone Marrow

**BMT-CTN:** Blood & Marrow Transplant Clinical Trials Network

**CIBMTR:** Center for International Blood & Marrow Transplant Research

**CIC:** Center Identification Code

**CMV:** Cytomegalovirus

**CPI:** Continuous Process Improvement

**CR:** Complete Remission

**CRF:** Comprehensive Report Form =

*2000* Baseline

*2004* IDM

*2005* HLA

*2006* INF

*20xx* Disease (pre-HSCT)

*2100* Day-100

*2200* Six month- two year

*2300* Greater than two year

*21xx* Disease Follow-Up (Post-HSCT)

*2046* FNG

*2047, 2147* HEP

*2048,2148* HIV

*2900* Death

**CTA:** Consecutive Transplant Audit

**CTN:** Blood & Marrow Transplant – Clinical Trials Network

**CVDR:** Center Volumes Data Report – A summary of five years of transplant volumes provided to the [Health Resources and Services Administration](https://bloodstemcell.hrsa.gov/data/donation-and-transplantation-statistics/transplant-activity-report)

**d-0:** Day zero, a.k.a. Date of HCT

**DCI:** Donor Cellular Infusion

**DLI:** Donor Lymphocyte Infusion

**EBMT:** European Group for Blood & Marrow Transplantation

**EBV:** Epstein Barr Virus

**FACT:** Foundation for the Accreditation of Cellular Therapy

**FDR:** Forms Due Report

**FGF:** Fibroblast Growth Factor

**FISH:** Fluorescent In-situ Hybridization

FN3: FormsNet3

**FU:** Follow-up

**GVHD:** Graft versus Host Disease

**HSCT:** Hematopoietic Stem Cell Transplant

**HCT:** Hematopoietic Cell Transplant

**KGF:** Keratinocyte Growth Factor

**NMDP:** National Marrow Donor Program

**NOS:** Not Otherwise Specified

**NST:** Non-Myeloablative Stem Cell Transplant

**PBSC:** Peripheral Blood Stem Cells

**PCL:** Plasma Cell Leukemia

**PHI:** Protected Health Information

**Product Form:** This was a transitional term used to temporarily describe the form pieces that came out of the ‘95/’02 CIBMTR Graft insert. The three Forms are IDM, HLA & INF. The term “Product Form” may have appeared in communication from Summer 2007; it is being retired.

**ProMISe:** Electronic data collection system for EBMT

**PTLD:** Posttransplant lymphoproliferative disorder

**RBC:** Red Blood Cell

**RCI-BMT:** Resource for Clinical Investigations in Blood & Marrow Transplant

**RIC:** Reduced Intensity Conditioning

**SCTOD:** Stem Cell Therapeutic Outcomes Database

**TBI, TLI, TNI:** Total (Body, Lymphoid, Nodal) Irradiation

**TCSA:** Transplant Center Specific Analysis – A one-year survival model based on first allogeneic transplants reported to CIBMTR. This data is used to populate the following:


- HRSA – Donations and Transplantation Statistics
- Be The Match – Choose a transplant center

**U:**Unclassifiable

**UCB:**Umbilical Cord Blood

**UIA Form:**Unique ID Assignment Form

**Unit:**Adult, Hematology, Oncology, Pediatric (AHOP) Note: select only one.

**VOD:**Veno-occlusive disease

### United States Abbreviations

| State or Territory Name | Abbreviation |
|---|---|
| ALABAMA | AL |
| ALASKA | AK |
| AMERICAN SAMOA
|
AS |
| ARIZONA | AZ |
| ARKANSAS | AR |
| CALIFORNIA | CA |
| COLORADO | CO |
| CONNECTICUT | CT |
| DELAWARE | DE |
| DISTRICT OF COLUMBIA | DC |
| FEDERATED STATES OF MICRONESIA
|
FM |
| FLORIDA | FL |
| GEORGIA | GA |
| GUAM
|
GU |
| HAWAII | HI |
| IDAHO | ID |
| ILLINOIS | IL |
| INDIANA | IN |
| IOWA | IA |
| KANSAS | KS |
| KENTUCKY | KY |
| LOUISIANA | LA |
| MAINE | ME |
| MARSHALL ISLANDS
|
MH |
| MARYLAND | MD |
| MASSACHUSETTS | MA |
| MICHIGAN | MI |
| MINNESOTA | MN |
| MISSISSIPPI | MS |
| MISSOURI | MO |
| MONTANA | MT |
| NEBRASKA | NE |
| NEVADA | NV |
| NEW HAMPSHIRE | NH |
| NEW JERSEY | NJ |
| NEW MEXICO | NM |
| NEW YORK | NY |
| NORTH CAROLINA | NC |
| NORTH DAKOTA | ND |
| NORTHERN MARIANA ISLANDS
|
MP |
| OHIO | OH |
| OKLAHOMA | OK |
| OREGON | OR |
| PALAU
|
PW |
| PENNSYLVANIA | PA |
| PUERTO RICO | PR |
| RHODE ISLAND | RI |
| SOUTH CAROLINA | SC |
| SOUTH DAKOTA | SD |
| TENNESSEE | TN |
| TEXAS | TX |
| UTAH | UT |
| VERMONT | VT |
| VIRGIN ISLANDS US
|
VI |
| VIRGINIA | VA |
| WASHINGTON | WA |
| WEST VIRGINIA | WV |
| WISCONSIN | WI |
| WYOMING | WY |

1 The CIBMTR requests that the full name of U.S. Territories is used whenever possible.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for any of the appendices, please reference the retired appendix on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/6/2020 | Appendix A: Abbreviations and Definitions | Add | Added definitions for CPI, CTA, CVDR, and TCSA. |
| 6/30/17 | Appendix A: Abbreviations and Definitions | Add | Added all information pertaining to US Abbreviations. This information was taken from the retired Appendix Q: United States Abbreviations |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)