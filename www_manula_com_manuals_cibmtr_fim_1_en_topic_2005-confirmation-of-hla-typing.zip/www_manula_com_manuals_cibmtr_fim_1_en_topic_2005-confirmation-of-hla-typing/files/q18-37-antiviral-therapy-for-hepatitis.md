This section is related to antiviral therapy given to the **recipient**.

#### Question 18: Was therapy given for hepatitis since the date of the last report (or, if this is the first post-HCT report, since diagnosis)?

Hepatitis antiviral therapy is intended to prevent progression of the disease and minimize sequelae of infection. The National Institutes of Health (NIH) in the United States recommends antiviral therapy for Hepatitis B patients with acute liver failure, cirrohsis or advanced cirrhosis with positive viral load, and for reactivation of chronic HBV during or after chemotherapy and/or immunosuppression. [2] Lamivudine, pegylated interferon alfa, entecavir, and tenofovir are medications currently used to treat Hepatitis B. Hepatitis C therapy has similar goals of sustaining a viral response and minimizing sequelae of infection. Therapy is recommended for patients with elevated liver enzymes and/or significant histologic damage on biopsy.

Indicate if the recipient received antiviral therapy for hepatitis at any time during the current reporting period; for the first post-transplant report, report any therapy since transplant. If “yes,” continue with question 19. If “no,” continue with question 25.

2 Sorrell MF, Belongia EA, Costa J, Gareen IF, Grem JL, Inadomi JM, et al. (2009). National Institutes of Health Consensus Devlopement Conference Statement: management of Hepatitis B. Annals of Internal Medicine, 150(2):104-110.

For each therapeutic agent below, create an instance for each course. A course is defined as the period from therapy start to discontinuation of therapy, during which the patient is regularly scheduled to receive a certain dose of medication; if the dose is changed, please continue the course and only report therapy stopped if the medication is discontinued for at least 14 consecutive days.

#### Question 19: Lamivudine therapy – course given

Indicate if the recipient received a course at any time during the current reporting period; create an instance for each course given. If “yes,” continue with question 20; if “no,” continue with question 25.

#### Question 20: Date started

Report the date therapy was initiated and continue with question 21.

#### Question 21: Daily dose

Report the daily prescribed dose at the start of the therapy.

#### Question 22: Reason started

This is a free text data field. Concisely document the rationale for starting this course of therapy; suggested examples include “prophylaxis” and “treatment.” If the patient received multiple courses of therapy, use this field to provide rationale for the dose change at onset of new course. If the rationale for therapy is not available in the records, document “unknown.”

#### Question 23: Therapy stopped?

Indicate if therapy was stopped during the current reporting period. If “yes,” continue with question 24. If “no,” continue with question 25.

#### Question 24: Date stopped

Report the date therapy was stopped and continue with question 25.

#### Question 25: Interferon therapy – course given

Indicate if the recipient received a course at any time during the current reporting period; create an instance for each course given. If “yes,” continue with question 26; if “no,” continue with question 31.

#### Question 26: Date started

Report the date therapy was initiated and continue with question 27.

#### Question 27: Daily dose

Report the daily prescribed dose at the start of the therapy.

#### Question 28: Reason started

This is a free text data field. Concisely document the rationale for starting this course of therapy; suggested examples include “prophylaxis” and “treatment.” If the patient received multiple courses of therapy, use this field to provide rationale for the dose change at onset of new course. If the rationale for therapy is not available in the records, document “unknown.”

#### Question 29: Therapy stopped?

Indicate if therapy was stopped during the current reporting period. If “yes,” continue with question 30. If “no,” continue with question 31.

#### Question 30: Date stopped

Report the date therapy was stopped and continue with question 31.

#### Questions 31-32: Other antiviral therapy – course given

Indicate if the recipient received a course of any other (not Lamivudine or interferon) antiviral therapy for hepatitis infection at any time during the current reporting period; create an instance for each course of each agent given. If “yes,” continue with question 32 and specify the other antiviral therapy given; if “no,” continue with continue with signature section of the form.

#### Question 33: Date started

Report the date therapy was initiated and continue with question 34.

#### Question 34: Daily dose

Report the daily prescribed dose at the start of therapy.

#### Question 35: Reason started

This is a free text data field. Concisely document the rationale for starting this course of therapy; suggested examples include “prophylaxis” and “treatment.” If the patient received multiple courses of therapy, use this field to provide rationale for the dose change at onset of new course. If the rationale for therapy is not available in the records, document “unknown.”

#### Question 36: Therapy stopped?

Indicate if therapy was stopped during the current reporting period. If “yes,” continue with question 37. If “no,” continue with question signature lines, review of form, and form submission.

#### Question 37: Date stopped

Report the date therapy was stopped and continue with question signature lines, review of form, and form submission.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)