The Myelodysplastic Pre-Infusion Data Form is one of the Comprehensive Report Forms. This form captures MDS-specific pre-infusion data such as: disease assessment at diagnosis, laboratory studies at diagnosis, pre-infusion therapy, disease transformation, most recent disease assessments, laboratory studies, and disease status prior to the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track and whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “Myelodysplastic (MDS) diseases (50) (Please classify all preleukemias)” and recipients with AML whose disease progressed from MDS.

[Q1: Subsequent Transplant or Cellular Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mdsq1-18-disease-assessment-at-diagnosis)

[Q2-17: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q19-39-laboratory-studies-at-diagnosis)

[Q18-47: Diagnostic Studies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q40-122-pre-hct-therapy)

[Q48-81: IPSS-R Prognosis Score](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation)

[Q82-156: Pre-HCT / Pre-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q127-153-laboratory-studies-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

[Q157-193: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q154-161-disease-assessment-at-the-last-evaluation-prior-to-the-preparative-regimen)

[Q194-208: Disease Assessment at Last Evaluation Prior to the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q194-208-disease-assessment-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/2025 |
|

*ET or PCV to MDS Transformation and Disease Assessments at Diagnosis: If MDS transformed from ET or PCV, report assessments from the time of the MDS transformation. Do not report assessments from the time of ET or PCV diagnosis.*[2014: Myelodysplastic Syndrome (MDS) Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)*As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form*[2014: Myelodysplastic Syndrome (MDS) Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)[2014: MDS Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)**Lines of Therapy and Subsequent Infusions***If this is a subsequent infusion and a 2014 was completed for the previous infusion, lines of therapy do not need to be reported in duplication on the subsequent 2014. Please report from post previous infusion to time of preparative regimen / infusion for the current infusion. If a 2014 was not previously completed, all lines of therapy from diagnosis to the current preparative regimen / infusion must be completed.*[2014: MDS Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)*Refer to the MDS Response Criteria section when determining the recipient’s disease status. Indicate if the disease relapsed from CR or progressed from hematologic improvement. If the disease relapsed, progressed, or transformed to AML (see red box below) answer “Yes” and go to question 156. If “No,” go to question 157.*[2014: MDS Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)[2014: MDS Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)[2014: MDS/MPN Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)**at the time of transplant**for recipients with secondary myelofibrosis, report “Primary Myelofibrosis (PMF)” to accurately capture these cases on the CIBMTR Forms.*Recipients transplanted for post-essential thrombocythemia myelofibrosis (post-ET MF) or post-polycythemia vera myelofibrosis (post-PV MF) will be reported as ET or PV at diagnosis (Q2). Question 123: ‘Did the recipient progress or transform to a different MDS/MPN subtype between diagnosis and the start of the preparative regimen?’ must be answered “Yes”.*~~Myelofibrosis that develops in patients with essential thrombocythemia (ET) or polycythemia vera (PV) is considered secondary myelofibrosis. Do not report this as a transformation; when a patient with ET or PV develops fibrosis, do not report primary myelofibrosis as the primary indication for transplant.~~*Refer to the MDS / MPN Response Criteria section when determining the recipient’s disease status. Indicate if the disease relapsed from CR or progressed from hematologic improvement. If the disease relapsed or progressed, answer “Yes” and go to question 122. If “No,” go to question 123.**Progression or relapse should be reported even if it was reported in the previous set of questions regarding response to therapy (questions 118-120).**Relapse is the recurrence of disease after CR. MDS/MPN relapse requires one of the following:*

*Return to pre-treatment bone marrow blast percentage.**Decrease of ≥ 50% from maximum response levels in granulocytes or platelets**Transfusion dependence, or hemoglobin level ≥ 1.5 g/dL lower than prior to therapy.*

*Progression is the worsening of the disease following hematologic improvement or stable disease. Progression requires at least one of the following in the absence of another explanation (e.g., infection, bleeding, ongoing chemotherapy, etc.):**≥ 50% reduction from maximum response levels in granulocytes or platelets**Reduction in hemoglobin by ≥ 1.5 g/dL**Transfusion dependence**Progression to AML: ≥ 20% blasts in the blood or bone marrow*

[Q157](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q154-161-disease-assessment-at-the-last-evaluation-prior-to-the-preparative-regimen#157):“Never Treated” is not an option choice on revision three of the Myelodysplasia / Myeloproliferative Disorders Pre-HSCT Data (MDS) Form. When completing revision three of this form, centers should report “No Response (NR) / Stable Disease (SD)” for recipients who have only received supportive care prior to transplant.

[question 123](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation#123):Myelofibrosis that develops in patients with essential thrombocythemia (ET) or polycythemia vera (PV) is considered secondary myelofibrosis. Do not report this as a transformation; when a patient with ET or PV develops fibrosis, do not report primary myelofibrosis as the primary indication for transplant.

[MDS transformation table](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation#123)to include RA, 5q- syndrome, MDS-U, and chronic eosinophilia transformations[121](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q40-122-pre-hct-therapy#121)and[123](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation#123)to include the following concept:Progression to AML: ≥ 20% blasts in the

**blood or**bone marrow
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)