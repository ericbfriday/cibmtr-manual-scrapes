This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track and whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as **Inherited Bone Marrow Failure Syndromes** with a sub classification of **Fanconi anemia**.

The Fanconi Anemia Post-HSCT Data (Form 2129) must be completed in conjunction with each Post-HSCT follow-up form completed (Form 2100) within each reporting timeframe such as the 100-day reporting period, 6 – month reporting period, annually through 6 years and then every other year thereafter.

Links to Sections of Form:

[Q1 – 6: Current Hematologic Parameters](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-6-current-hematologic-parameters)

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/25/2021 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)