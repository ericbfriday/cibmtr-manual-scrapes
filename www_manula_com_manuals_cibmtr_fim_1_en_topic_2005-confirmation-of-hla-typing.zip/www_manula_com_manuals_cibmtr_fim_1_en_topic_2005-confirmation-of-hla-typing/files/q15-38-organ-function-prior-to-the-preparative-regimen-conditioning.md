#### Questions 4-22: Provide last laboratory values recorded for recipient’s organ function (testing done within 30 days prior to the start of the preparative regimen).

These questions are intended to determine the clinical status of the recipient prior to the start of the preparative regimen for stem cell transplantation. Testing may be performed multiple times within the pre-transplant work-up period (approximately 30 days prior to the start of the preparative regimen); report the most *recent* laboratory value obtained for each specific test. Laboratory values obtained on the first day of the preparative regimen may be reported as long as the blood was drawn **before** any radiation or systemic therapy was administered. If the assessment was not performed during the pre-transplant work-up period, report “unknown.”

For each organ function test below, indicate if the value is “known” or “unknown” prior to the start of the preparative regimen. Indicate the values and units for each test, taking care to convert them to a unit available on the form, if necessary.

**AST (SGOT):** Aspartate aminotransferase, or serum glutamic oxalic transaminase, is an enzyme measured in serum or plasma that reflects liver function and liver cell integrity. Elevated levels of AST may indicate liver damage.

**ALT (SGPT):** Alanine aminotransferase, or serum glutamic pyruvic transaminase, is an enzyme measured in the blood that reflects liver function. Elevated levels of ALT indicates liver injury, minor or severe.

**FEV1:** Forced expiratory volume is the maximal amount of air one can forcefully exhale in one second which is then converted to a percentage of normal. FEV1 is used to assess airway obstruction.

**DLCO (corrected):** Corrected diffusion capacity of carbon monoxide is the extent to which oxygen travels from the alveoli of the lungs to the blood stream and is adjusted for the hemoglobin concentration. Use the Dinakara equation below to determine the corrected DLCO if only an uncorrected value is provided.

Dinakara Equation: DLCOc = {uncorrected DLCO} / [0.06965 x {hemoglobin g/dL}]

**Total serum bilirubin:** Bilirubin is a pigment that is formed from the breakdown of hemoglobin in red blood cells. Serum bilirubin is a test of liver function that reflects the ability of the liver to take up, process, and secrete bilirubin. Total bilirubin includes the direct (conjugated) and indirect (unconjugated) bilirubin values. If your laboratory reports direct and indirect separately, add the two together to report the total serum bilirubin.

**LDH:** Lactate dehydrogenase is an enzyme found in the cytoplasm of almost all tissues, which converts L-lactate into pyruvate, or pyruvate into L-lactate depending on the oxygen level. For some diseases, high levels indicate active disease (e.g., lymphoma and multiple myeloma).

**Serum creatinine:** Creatinine is a normal metabolic waste that is primarily filtered from the blood by the kidneys and then excreted in the urine. Since it is generally produced at a constant rate, the clearance rate and the serum level are widely used as indicators of kidney function.

Upper Limit of Normal for your Institution:

Report the upper limit of normal for each assessment result. Normal values may vary by laboratory, so it is important to report the upper limit of normal for each assessment.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q4 | 4/4/2024 | Add | Plasma vs Serum Samples blue box added above Q4 | Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)