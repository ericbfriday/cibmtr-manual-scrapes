#### Question 1: Compared to the disease status prior to the preparative regimen, what was the best response to infusion? *(include response to any therapy given for post-infusion maintenance or consolidation, but exclude any therapy given for relapse, persistent, or progressive disease)*

The intent of this question is to determine the best overall response to HCT, or cellular therapy based on the planned HCT or cellular therapy course. This includes response to any therapy given for post-infusion maintenance or consolidation, and does not include response to treatment given for measurable residual disease, relapse, progressive, or persistent disease.

When evaluating the best response, determine the disease status within the reporting period using the international working group criteria provided in the in [CLL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-response-criteria) section of the Forms Instructions Manual. Compare this response to all previous post-infusion reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status.

If relapse / progression or persistent disease occurs post-infusion and treatment for relapse / progression or persistent disease is administered, the response to the additional therapy should not be reported. Report the best response prior to relapse / progression. For subsequent reporting periods, continue to report the best response prior to relapse / progression and specify **Yes**, the date was previously reported in the next question.

Use the following guidelines to determine how to report the best response when the pre-infusion disease status is CR:

- If the first assessments completed post-infusion are still consistent with complete remission, report the best response as
**Complete remission**and the assessment date as the first assessments confirming CR. - If the first assessments completed post-infusion are consistent with disease progression, report the best response as
**Progressive disease**and the assessment date as the first assessments showing progression.

Use the following guidelines to determine how to report the best response when the recipient is not in CR pre-infusion and persistent disease was detected post-infusion:

- If the first assessments complete post-infusion are consistent with persistent disease and treatment for persistent disease was not started, report the best response as
**Stable disease**and the assessment date as the first assessments showing stable disease. - If the first assessments completed post-infusion are consistent with persistent disease and treatment for persistent disease was started, report the best response as
**Stable disease**and the assessment date as the last assessments prior to initiating persistent disease treatment.

#### Question 2: Was the date of best response previously reported?

Indicate if the date when the best response to HCT / cellular therapy was first achieved was reported in a previous reporting period. Report **No** if the date when the best response was first achieved occurred in the current reporting period. Report **Yes** if the date when the best response was first achieved occurred in a prior reporting period.

The **Yes** option is not applicable for the Day 100 reporting period.

#### Question 3: Date assessed

Report the first date when the best response to HCT / cellular therapy occurred. This date should be the earliest date when all international working group criteria for the response reported above were met. Report the date the sample was collected for pathologic evaluation (i.e., bone marrow biopsy) or blood / serum assessment (i.e., CBC, peripheral blood smear). If no pathologic, radiographic, or laboratory assessments were performed to establish the best response, report the office visit in which the physician clinically evaluated the response.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

### Disease Assessments at Time of Best Response

The disease assessment questions (i.e., molecular, clonoSEQ, flow cytometry, and cytogenetic assessments) refer to disease assessments performed at the time of best response (Date assessed). Only assessments performed within the time windows listed below should be reported. If assessments were performed during the reporting period, but the samples were not collected within the indicated time window at the time when the best response occurred, report **No** for the assessment.

Table 1. Disease Assessment Time Windows

| Follow-Up Form | Approximate Time Window |
|---|---|
| Day 100 | + / – 15 days of best response |
| 6 Month | + / – 15 days of best response |
| Annual | + / – 30 days of best response |

#### Question 4: Were tests for molecular markers performed (e.g., PCR)?

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR methods. Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include Sanger sequencing, and next generation sequencing (i.e., Illumina, Roche 454, Proton / PGM, SOLiD).

Indicate if molecular marker testing was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If testing was not completed within the applicable time window or unknown if completed, report **No**.

#### Question 5: Date sample collected

Specify the date when the sample was collected for molecular marker testing, prior to relapse / progression, if applicable. If testing was completed multiple times within the applicable time windows, as listed above, report the date performed nearest to the date of best response.

If date partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 6 – 9: Specify positive mutation(s) (check all that apply)

Report all *positive* markers identified at the time of best response to HCT or cellular therapy.

If **BTK** was detected, specify the BTK mutation(s) identified. If **Other** is selected, specify the other BTK mutation identified.

If an **Other** molecular marker was detected, specify the marker identified.

#### Question 10: P53 / TP53 mutation

P53, also known as TP53 or tumor protein p53 gene, is a tumor suppressor, preventing cells from growing and dividing too fast. Understanding if the P53 / TP53 mutation was assessed is important for research.

Specify if the P53 / TP53 mutation was detected by molecular testing (i.e., PCR, NGS), at the time of best response to HCT or cellular therapy. If molecular testing for the P53 / TP53 mutation was not completed or is unknown if completed, select **Not done**.

#### Question 11: Was the disease status assessed via clonoSEQ?

ClonoSEQ is a type of measurable residual disease testing, which identifies and quantifies the number of cancer cells.1

Indicate if clonoSEQ was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If testing was not completed within the applicable time window or unknown if completed, report **No**.

1 clonoSEQ® by Adaptive Biotechnologies. (n.d.). ClonoSEQ. https://www.clonoseq.com/hcp-home/?gad_source=1&gclid=CjwKCAjwuMC2BhA7EiwAmJKRrCLoK5aZwMM5jAHZu3o3GBCYmIAK4Z0-OSyM9up8GkCWAw7-J1O9BRoCShYQAvD_BwE&utm_source=google&utm_medium=cpc&utm_campaign=hcp_priority&utm_medium=cpc&utm_campaign=hcp_priority

#### Question 12: Date sample collected

Specify the date when the sample was collected for clonoSEQ, prior to relapse / progression, if applicable. If testing was completed multiple times within the applicable time windows, as listed above, report the date performed nearest to the date of best response.

If date partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 13: Sample source

Specify the sample source for the date of the clonoSEQ assessment reported above.

#### Question 14: Was disease or measurable residual disease detected?

Indicate if the clonoSEQ reported above detected disease *or* measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Question 15: Was the disease status assessed via flow cytometry? *(minimum 4-color flow) (immunophenotyping)*

Flow cytometry (immunophenotyping) is a technique that can be performed on blood, bone marrow, or tissue preparations where cell surface markers can be detected on cellular material.

Indicate if flow cytometry was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If testing was not completed within the applicable time window or unknown if completed, report **No**.

#### Question 16: Date sample collected

Specify the date when the sample was collected for flow cytometry, prior to relapse / progression, if applicable. If testing was completed multiple times within the applicable time windows, as listed above, report the date performed nearest to the date of best response

If date partially known, use the process for reporting partial or unknown dates as described in the General Instructions, General Guidelines for Completing Forms.

#### Question 17: Sample source

Specify the sample source for the date of the flow cytometry assessment reported above.

#### Question 18: Was disease or measurable residual disease detected?

Indicate if the flow cytometry reported above detected disease *or* measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Question 19: Specify the sensitivity of test for MRD *(i.e., level of detection)*

Specify the level of the flow cytometry sensitivity (i.e., level of detection) as listed on the flow cytometry report. If the level of sensitivity is unclear, seek clinician clarification.

#### Question 20: Was the disease status assessed by cytogenetic testing? *(FISH or karyotyping)*

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality which reflects the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH).

Indicate if cytogenetics (karyotyping or FISH) was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If testing was not completed within the applicable time window or unknown if completed, report **No**.

#### Question 21: Was the disease status assessed via FISH?

Indicate if FISH was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If FISH was not performed, unknown if performed, or if FISH was performed but ‘failed’ or the sample was inadequate, report **No**.

Indicate if flow cytometry was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If testing was not completed within the applicable time window or unknown if completed, report **No**.

#### Question 22: Date sample collected

Specify the date when the sample was collected for FISH, prior to relapse / progression, if applicable. If testing was completed multiple times within the applicable time windows, as listed above, report the date performed nearest to the date of best response

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 23: Was disease or measurable residual disease detected?

Indicate if the FISH assessment reported above detected disease *or* measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Question 24: Was the disease status assessed via karyotyping?

Indicate if karyotyping was completed within the time windows listed in Table 1. Disease Assessment Time Windows above. If karyotyping was not performed or unknown if performed, report **No**.

#### Question 25: Date sample collected

Specify the date when the sample was collected for karyotyping, prior to relapse / progression, if applicable. If testing was completed multiple times within the applicable time windows, as listed above, report the date performed nearest to the date of best response.

If date partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 26: Was disease or measurable residual disease detected?

Indicate if the karyotyping assessment reported above detected disease or measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

If karyotyping ‘failed’ or had ‘insufficient growth,’ select **No evaluable metaphases**.

#### Question 27: Hypogammaglobulinemia

Hypogammaglobulinemia refers to low levels of circulating gammaglobulins, or immunoglobulins, in the blood and often determined by quantitative levels of immunoglobulins G (IgG), A (IgA) and M (IgM), or most commonly IgG only. For adults, levels lower than 600 mg/dL of circulating IgG are considered to be hypogammaglobulinemia. Children ages 4 to 18, levels lower than 500 mg/dL are considered hypogammaglobulinemia. Children younger than four years, as levels of IgG can be much lower and still be within normal ranges for the age, the diagnosis of hypogammaglobulinemia needs to be confirmed with the treating physician.

If the IgG was assessed within the time windows listed in Table 1. Disease Assessment Time Windows above, specify if hypogammaglobulinemia was present using guidelines provided below:

**Yes**: IgG was assessed and the IgG < 600 mg/dL for adults or < 500 mg/dL for children 4 – 18 years old.**No**: IgG was assessed and the IgG > 600 mg/dL for adults > 500 mg/dL for children 4-18 years old.

If the IgG was not assessed or unknown if an IgG assessment was completed within the time windows listed in Table 1. Disease Assessment Time Windows above, select **Not applicable**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q1 | 1/24/2025 | Modify | Clarified best response does not include a response if MRD treatment is given: The intent of this question is to determine the best overall response to HCT, or cellular therapy based on the planned HCT or cellular therapy course. This includes response to any therapy given for post-infusion maintenance or consolidation |
|
| Q1 | 1/24/2025 | Add | Instructions added on how to report the best response when not in CR pre-infusion and persistent disease detected post-infusion: Use the following guidelines to determine how to report the best response when the recipient is not in CR pre-infusion and persistent disease was detected post-infusion:
|
Additional instructions determined after form / manual release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)