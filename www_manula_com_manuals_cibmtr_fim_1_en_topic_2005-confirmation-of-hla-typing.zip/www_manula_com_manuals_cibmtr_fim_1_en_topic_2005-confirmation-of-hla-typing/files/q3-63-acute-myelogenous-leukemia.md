**Acute Myelogenous Leukemia (AML)** is a cancer of the white blood cells. It is characterized by the rapid proliferation of abnormal, immature myelocytes, known as myeloblasts, in the bone marrow. This accumulation of blasts in the marrow prevents the formation of healthy red blood cells, white blood cells, and/or platelets. Normal myeloblasts develop into neutrophils, basophils, and eosinophils, which are all white blood cells that fight infection. In AML, the leukemic myeloblasts do not fully develop and are unable to fight infection. The symptoms of AML result from a drop in red blood cell, platelet, and normal white blood cell counts caused by the replacement of normal bone marrow with leukemic cells.

Certain prognostic indicators are associated with poorer outcomes. These include advanced age (50+ years of age), AML arising from MDS or secondary / therapy-related AML, and certain genetic mutations that are described in greater detail later in this manual.

#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the disease. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If AML transformed from MPS or MPN, report the diagnosis date of the AML. The MPS or MPN diagnosis date will be captured in the MDS or MPN sections below.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

#### Question 3: Specify the AML classification

CIBMTR captures the classification of AML based on the World Health Organization (WHO) 2022, but also recognizes International Consensus Classification (ICC) 2022 and those classifications are also included, when applicable. Additionally, the European LeukemiaNet (ELN) 2022 is also included from a risk stratification standpoint. Indicate the disease classification at diagnosis.

Report the most specific entity that applies to the recipient. For example, if the disease classification is defined by both genetic abnormalities and differentiation, the defining genetic abnormality classification should be reported for classification purposes.

In some cases, disease specific cytogenetic and / or molecular abnormalities are not identified at the initial diagnosis but identified at some point prior to the infusion, report the most disease specific entity. Review the example below for further clarification:

- Example 1: A recipient diagnosed with AML had only a bone marrow biopsy and FISH testing for BCR-ABL performed at diagnosis. The bone marrow identified AML with maturation and FISH was negative for BCR-ABL. Induction began and additional molecular testing completed after starting treatment which identified NPM1. The disease classification should be reported as
**AML with NPM1 mutation**.

For some AML classifications, the requirement of > 20% blasts in blood or bone marrow is no longer applicable. The guidelines below provide an overview of which AML classifications require > 20% blasts in the blood or bone marrow.


- If the disease is a ‘AML with defining genetic abnormalities,’ > 20% blasts in blood or bone marrow is no longer required, except for
**AML with BCR::ABL1 fusion**,**AML with CEBPA mutation**, and**AML with myelodysplasia – related**.- For
**AML with BCR::ABL1 fusion**and**AML with CEBPA mutation**, > 20% blasts in blood or bone marrow is required - For
**AML with myelodysplasia – related**, the following is required:- > 20% blasts in blood or bone marrow are required, and
*one*of the following:- History of MDS / MPN; or
- At least one defining cytogenetic abnormality present; or
- Complex karyotype (i.e., > 3 abnormalities)
- Deletion or loss 5q
- Monosomy 7, deletion, or loss 7q
- Deletion 11q
- Deletion or loss 12p
- Monosomy 13 or deletion 13q
- Deletion or loss 17p
- Isochromosome 17q
- Idic(X)(q13)

- At least one defining somatic mutation present
- ASXL1
- BCOR
- EZH2
- SF3B1
- SRSF2
- STAG2
- U2AF1
- ZRSR2



- > 20% blasts in blood or bone marrow are required, and
- If the disease is
**AML with other defined genetic alterations**, > 20% blasts in blood or bone marrow is not required; however, seek physician clarification if it is unclear if the disease should be reported as AML.

- For
- If the disease is a ‘AML, defined by differentiation,’ > 20% blasts in blood or bone marrow is required.

#### Question 4: Did AML transform from MDS or MPN?

AML often evolves from MDS or MPN. This transformation is typically distinguished by the percentage of blasts in the bone marrow

AML that transforms from MDS or MPN has a lower survival prognosis because of the association with unfavorable cytogenetic abnormalities.

AML can also evolve from Juvenile Myelomonocytic Leukemia (JMML). JMML is a rare form of chronic leukemia that affects young children, usually before the age of five. JMML results from DNA mutations in cells called monocytes. Normal monocytes attack invading microorganisms and assist lymphocytes in carrying out immune functions. Abnormal monocytes in JMML accumulate in the bone marrow and interfere with the production of normal white blood cells, red blood cells, and platelets.

If AML transformed from MDS (including JMML), check **Yes, MDS** and complete both the AML and MDS disease classification section of the form.

If AML transformed from MPN, check **Yes, MPN** and complete both the AML and MPN disease classification section of the form.

If AML did not transform from MDS or MPN, check **No**.

If MDS / MPN is suspected, but not confirmed by documented laboratory or pathologic findings, or if there is documentation of MDS / MPN **concurrent** with AML, check **No**.

#### Question 5: Is the disease (AML) therapy related?

Agents such as radiation or systemic therapy used to treat other diseases (e.g., Hodgkin lymphoma, non-Hodgkin lymphoma, or breast cancer) can damage the marrow and lead to a secondary malignancy such as AML. If the diagnosis of AML is therapy-related, check **Yes**.

If the diagnosis of AML is not therapy-related, check **No**.

- If AML was preceded by therapy-related MDS, check
**No**. - If the recipient developed AML after an environmental exposure (e.g., exposure to benzene), check
**No**.

If it is unknown whether or not the diagnosis of AML was therapy-related, check **Unknown**.

#### Question 6: Did the recipient have a predisposing condition?

A predisposing condition is a condition that contributes to the susceptibility of developing leukemia. Therefore, diagnosis of the condition increases the likelihood that the recipient will develop leukemia. If the recipient has a documented history of a predisposing condition, check **Yes**. If there is no history of a predisposing condition or if predisposition is unknown, indicate **No** or **Unknown**, respectively.

#### Questions 7 – 8: Specify condition

Specify the recipient’s predisposing condition prior to the diagnosis of leukemia. If the recipient has a documented history of a predisposing condition but it is not listed as an option, select **Other condition** and specify the condition.

**Biallelic germline BLM variant**(Bloom syndrome) is an autosomal recessive genetic disorder characterized by excessive chromosome breakage and corresponding rearrangements, proportional dwarfism, and sun sensitivity. The chromosomal instability seen in Bloom syndrome is generally assumed to be responsible for these individuals’ predisposition to malignancy.**Down syndrome**is also a chromosomal disorder (trisomy 21). It is characterized by an additional chromosome 21. Down syndrome patients exhibit a particular set of facial characteristics, growth deficiency, and cognitive impairment. Although Down syndrome patients have a reduced risk of developing many common malignancies, they have an increased risk of developing leukemia.**Fanconi anemia**is a rare genetic blood disorder that prevents the body from producing a sufficient number of new blood cells to function properly. Abnormal blood cells may also be produced. These patients are short in stature, exhibit skeletal anomalies, and have an increased risk of developing solid tumors and leukemias.**Germline CEBPA variant (CEBPA-associated familial AML)**is the presence of a heterozygous germline CEBPA pathogenic variation in an AML patient and/or a family with multiple AML cases.**Germline DDX41 variant**is a rare germline heterozygous mutation. DDX41 represents a class of tumor suppressor genes in myeloid neoplasms.**Germline TP53 variant (Li-Fraumeni Syndrome)**is a rare genetic disorder which increases the risk of developing several types of cancers, notably: breast cancer, osteosarcoma, sarcoma, brain tumors and leukemias. Li- Fraumeni syndromes are associated with mutations in the TP53 gene.**Germline RUNX1 variant**typically present with mild to moderate thrombocytopenia with normal-sized platelets, functional platelets defects leading to prolonged bleeding and an increased risk to develop myelodysplastic syndromes (MDS), acute myeloid leukemia (AML), or T-cell acute lymphoblastic leukemia (T-ALL).*(familial platelet disorder with associated myeloid malignancy, FPD-MM)***Germline ANKRD26 variant (Thrombocytopenia 2)**is an inherited disorder that causes a mild to moderate decrease in the number of normal platelets leading to uncontrolled bleeding.**Germline ETV6 variant (Thrombocytopenia 5)**is a mutation in hematological precursor cells that lead to leukemia and thrombocytopenia.**Germline GATA2 variant (GATA2-deficiency)**is a rare genetic disorder which can cause a variety of issues including viral and bacterial infections, cytopenias, myelodysplasia, myeloid leukemias, pulmonary alveolar proteinosis and lymphedema.**Germline SAMD9 variant (MIRAGE Syndrome)**is a rare disorder that results in myelodysplasia, infection, restriction of growth, adrenal hypoplasia, genital phenotypes, and enteropathy.**Germline SAMD9L variant (SAMD9L-related Ataxia Pancytopenia Syndrome)**is a disorder that results in symptoms such as cerebellar ataxia, myelodysplasia, and myeloid leukemia.**RASopathies (Neurofibromatosis type 1, CBL syndrome, Noonan syndrome, Noonan syndrome-like disorders)**are a group of genetic syndromes affected by mutations in the regulation of Ras/mitogen-activated protein kinase pathway (MAPK).**Severe congenital neutropenia (SCN)**are germline mutations which can result in a spectrum of multisystem disorders that carry a markedly increased risk of developing myeloid malignancies.**Shwachman-Diamond syndrome (SDS)**is a rare autosomal recessive disorder which is characterized by exocrine pancreatic insufficiency, bone marrow dysfunction, and skeletal abnormalities**Telomere biology disorder**is a genetic form of a bone marrow failure where the recipient is unable to produce sufficient blood cells. Subdivisions of dyskeratosis congenita includes dyskeratosis congenita (autosomal dominant), Scoggins type, dyskeratosis congenita (autosomal recessive), dyskeratosis congenita (X-linked), Zinsser-Cole-Engleman syndrome, Hoyeraal-Hreidarsson syndrome, and Revesz syndrome.*(including dyskeratosis congenita and others)*

#### Question 9: Were cytogenetics tested (karyotyping or FISH)? (at diagnosis)

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality which reflects the recipient’s disease. Testing methods you may see include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells.

**Table 3. Examples of AML Cytogenetic Findings Categorized by Prognosis**


| Favorable | Intermediate | Poor |
|---|---|---|
| t(15;17) t(8;21) inv(16) or t(16;16) |
Normal +8 t(9;11) All other abnormalities |
≥ 3 abnormalities 5- or 5q- 7- or 7q- t(9;22) |

Indicate whether cytogenetic studies were performed at diagnosis. Do not report any testing performed after treatment for AML has started. If cytogenetic studies were obtained at diagnosis, check **Yes**. If cytogenetic studies were not obtained at this time point or it is not known whether chromosome studies were performed, indicate **No** or **Unknown**, respectively.

#### Questions 10 – 11: Were cytogenetics tested via FISH?

If FISH studies were performed at diagnosis (see the At Diagnosis, Last Evaluation, and In Between blue note box above) report **Yes** and indicate whether clonal abnormalities were detected. Do not report any testing performed after treatment for AML has started. If FISH studies were not performed at this time point or FISH sample was inadequate it is not known if performed, report **No**.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Questions 12 – 15: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable.

Specify the number of abnormalities detected by FISH at diagnosis (see the At Diagnosis, Last Evaluation, and In Between blue note box above). After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify. If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 16 – 17: Were cytogenetics tested via karyotyping?

If karyotyping was performed at diagnosis, report **Yes** and indicate whether clonal abnormalities were detected. Do not report any testing performed after treatment for AML has started. If karyotyping was not performed at this time point or it is not known if performed, indicate **No**.

#### Questions 18 – 21: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping at diagnosis. After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality. If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 22: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported above. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 23: Were tests for molecular markers performed (e.g., PCR, NGS)? (at diagnosis)

Testing for molecular markers is often performed by using PCR based methods to assess specific genetic sequences. Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If testing for molecular markers was performed at diagnosis, report **Yes**.

If molecular marker testing was not performed at diagnosis or it is not known if testing was done, report **No** or **Unknown**, respectively.

#### Questions 24 – 35: Specify results

For each molecular marker listed, report whether testing was **Positive**, **Negative**, or **Not done** at diagnosis (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If tests identified a molecular marker other than those listed, including variance of unknown significance(VUS) markers, report the results in *Other molecular marker* and specify the marker.

If multiple other molecular markers were tested, specify the results in *Other molecular marker* data field, using the following guidelines:


- Report one instance for all
**Positive**other molecular markers and specify the markers (or report ‘see attachment’ and upload the report(s) using the attachment feature in FormsNet3SM) - Report one instance for any
**Negative**other molecular markers and specify the markers (or report ‘see attachment’ and upload the report(s) using the attachment feature in FormsNet3SM)

If CEBPA is reported as **Positive**, specify the CEBPA mutation. If the lab report does not specify whether the detected marker was biallelic / homozygous or monoallelic / heterozygous, confirm with the laboratory whether this information can be determined prior to reporting **Unknown**.

If FLT3-ITD is reported as **Positive**, specify the FLT3-ITD allelic ratio. If the allelic ratio is **Known**, report the value. If the lab report does not specify the allelic ratio, confirm with the laboratory whether this information can be determined prior to reporting **Unknown.**

The allelic ratio data field is intended to capture the ratio of the FLT3-ITD mutation. This data field does not collect the allelic frequency, the allelic frequency is used to calculate the allelic ratio. The FLT-3 ITD allelic ratio (or signal ratio) compares the number of ITD-mutated alleles to the number of wild-type (normal) alleles. If the allele frequency was assessed, the ITD-mutated allele frequency will be documented on the molecular report; however, the wild-type allele frequency will need to be calculated. To determine the wild-type allele frequency, subtract the ITD-mutated allele frequency from 1 (or 100.0%). After determining the wild-type allele frequency, the allelic ratio can be assessed. To calculate the allelic ratio, divide the mutant allele frequency by the wild-type (normal) allele frequency. Review the example below for more information:

Example:


- ITD variant allele frequency: 1.14% (0.0114)
- As documented in the molecular report

- Wild-type allele frequency: 98.86% (0.9886)
- Determined by subtraction 1.14% from 100.0%

- FLT3-ITD allelic ratio: 0.0114 / 0.9886 = 0.0115

Report the FLT3-ITD allelic ratio as 0.0115

**Table 4. Common Molecular Markers Associated with AML**

| Molecular Abnormality | Characteristics |
|---|---|
| CEBPA | CEBPA, aka CCAAT/enhancer binding protein α, is a transcription factor required for the differentiation of granulocytes. Numerous CEBPA mutations have been identified in relation to AML, with the majority of patients displaying biallelic mutations ultimately resulting in the down regulation of gene activity. Decreased gene activity results in decreased differentiation potential for immature granulocytes. An estimated 7-15% of AML patients have CEBPA mutations and CEBPA mutations are generally found in M1 and M2 subtypes in conjunction with intermediate-risk cytogenetics. Studies show an association with more favorable outcomes.
|
| FLT3-D835 point mutation | FLT3 encodes a receptor tyrosine kinase. The FLT3-D835 point mutation, aka FLT3-TKD, is an activating mutation impacting tyrosine-kinase domains. FLT3 mutations are found in up to 1/3 of all AML patients. The clinical significance of TKD activation remains unclear. FLT3-D385 mutations are often found in conjunction with other mutations. Overall, FLT3-D385 is not considered a favorable or poor prognostic indicator. However, in certain combinations with other mutations, there are associations with both improved and diminished survival.
|
| FLT3-ITD mutation | FLT3 encodes a receptor tyrosine kinase. The FLT3-ITD (internal tandem duplication) interferes with certain down regulation functions within receptor tyrosine kinases, leading to activation of TK activity. FLT3 mutations are found in up to 1/3 of all AML patients. FLT3-ITD is considered a poor prognostic factor. Sorafenib (Nexavar) has been shown to initially improve disease response in FLT3-ITD-positive AML.
|
| IDH1 | Isocitrate Dehydrogenase (IDH) is an oxidative enzyme involved in the citric acid cycle. IDH1 mutations result in incorrect catalytic activity, leading to increased levels of an oncometabolite, 2-hydroxyglutarate. The pathologic activity of IDH1 mutations is still being studied, but it has been suggested that IDH mutations may be a distinct mechanism in AML pathogenesis; research models show they may cause an accumulation of hematopoietic progenitor cells. Early research suggests IDH1 mutation may be a less favorable prognostic indicator.
|
| IDH2 | Isocitrate Dehydrogenase (IDH) is an oxidative enzyme involved in the citric acid cycle. IDH2 is a mitochondrial homolog to IDH1. Much like IDH1 mutations, IDH2 mutations result in incorrect catalytic activity, leading to increased levels of (D)-2-hydroxyglutarate. The pathologic activity of IDH2 mutations are still being studied, but it has been suggested that IDH mutations may be a distinct mechanism in AML pathogenesis; research models show they may cause an accumulation of hematopoietic progenitor cells. Early research suggests IDH2 mutation may be a more favorable prognostic indicator, unlike IDH1 mutation, though there may be differences based on where the IDH2 mutation occurs in gene.
|
| KIT | KIT encodes a receptor tyrosine kinase. The KIT mutations at exons 8 and 17 are associated with activation of encoded proteins, resulting in activation impacting tyrosine-kinase domains. Patients with t(8;21) and inv(16) cytogenetics are frequently screened for KIT mutations, which adversely affect prognosis in these patients.
|
| NPM1 | NPM1 encodes a protein responsible for multiple cellular functions, including the regulation of the ARF-p53 tumor suppressor pathway. Mutations in NPM1 result in gene over-expression and subsequent inactivation of ARF-p53 tumor suppression pathway. NPM1 mutations are one of the most common molecular markers seen in AML and are associated with improved survival.
|
| Other molecular marker | Assessments for other molecular markers known or believed to be associated with AML may be performed. If these studies are performed, indicate Positive or Negative and specify the marker. |

1 Lin L, Chen C, Lin D, Tsay W, Tang J, Yeh Y, Shen H, Su F, Yao M, Huang S, Tien H. (2005). Characterization of CEBPA Mutations in Acute Myeloid Leukemia: Most patients with CEBPA mutations have biallelic mutations and show a distinct immunophenotype of the leukemic cells. *Clin Cancer Res*, 11, 1372-9.

2 Mead AJ, Linch DC, Hills RK, Wheatley K, Burnett AK, Gale RE. (2007). FLT3 tyrosine kinase domain mutations are biologically distinct from and have a significantly more favorable prognosis than FLT3 international tandem duplications in patient with acute myeloid leukemia. *Blood*, 110, 1262-70.

3 Whitman SP, Ruppert AS, Radmacher, MD, et al. (2008). FLT3 D835/I836 mutations are associated with poor disease-free survival and a distinct gene-expression signature among younger adults with de novo cytogenetically normal acute myeloid leukemia lacking FLT3 internal tandem duplications. *Blood*, 111, 1552-59.

4 Man CH, Fung TK, Ho C, et al. (2011). Sorafenib treatment of FLT-ITD+ acute myeloid leukemia: favorable initial outcome and mechanisms of subsequent non-responsiveness associated with the emergence of a D835 mutation. *Blood*, 119 (22), 5133-43.

5 Marucci G, Maharry K, Wu YZ, et al. (2010). IDH1 and IDH2 Gene Mutations Identify Novel Molecular Subsets Within De Novo Cytogenetically Normal Acute Myeloid Leukemia: A Cancer and Leukemia Group B Study. *J Clin Oncol*, 28(14), 2348-55.

6 Green CL, Evans CM, Zhao L, et al. (2011).The prognostic significance of IDH2 mutations in AML depends on the location of the mutation. *Blood*, 118(2), 409-12.

7 Döhner K, Döhner H. (2008).Molecular characterization of acute myeloid leukemia. *Haematologica*, 93(7), 976-82.

8 Varhaak RGW, Goudswaard CS, van Putten W, et al. (2005).Mutations in nucleophosmin (NPM1) in acute myeloid leukemia (AML): association with other gene abnormalities and previously established gene expression signatures and their favorable prognostic significance. *Blood*, 106(12), 3747-54.

#### Question 36: Were cytogenetics tested (karyotyping or FISH)? (between diagnosis and last evaluation)

Indicate whether cytogenetic studies were performed between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If cytogenetic studies were obtained during this time, check **Yes**. If cytogenetic studies were not obtained at this time point or it is not known whether chromosome studies were performed, indicate **No** or **Unknown**, respectively.

#### Questions 37 – 38: Were cytogenetics tested via FISH?

If FISH studies were performed between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above), report **Yes** and indicate whether clonal abnormalities were detected. If multiple FISH assessments were performed, report **Abnormalities Identified** if any testing showed clonal abnormalities during this period. If FISH studies were not performed during this period, FISH samples were inadequate, or is unknown if performed, report **No**.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Questions 39 – 42: Specify cytogenetic abnormalities (FISH) identified between diagnosis and last evaluation

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable.

Report the number of abnormalities detected by FISH between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If FISH studies showed different clonal abnormalities during this time, report the total number of clonal abnormalities detected. After indicating the number of clonal abnormalities, select all clonal abnormalities detected during this period. This includes all clonal abnormalities detected any FISH assessment performed during this period.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify. If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 43 – 44: Were cytogenetics tested via karyotyping?

If karyotyping was performed between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above), report **Yes** and indicate whether clonal abnormalities were detected. If multiple karyotypes were performed, report **Abnormalities Identified** if any testing showed clonal abnormalities during this period. If karyotyping was performed, but there weren’t any evaluable metaphase cells, report **Not evaluable metaphases**. If karyotyping was not performed during this period, report **No**.

#### Questions 45 – 48: Specify cytogenetic abnormalities (karyotyping) identified between diagnosis or relapse and last evaluation

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If karyotype studies showed different clonal abnormalities during this time, report the total number of clonal abnormalities detected. After indicating the number of clonal abnormalities, select all clonal abnormalities detected during this period. This includes all clonal abnormalities detected any karyotype performed during this period.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify. If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 49: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 50: Were tests for molecular markers performed (e.g., PCR, NGS)? (between diagnosis, and last evaluation)

Indicate whether testing for molecular markers was performed between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If testing for molecular markers was performed during this time, check **Yes**. If molecular marker testing was not obtained during this period or it is not known whether testing for molecular markers was performed, indicate **No** or **Unknown**.

#### Questions 51 – 62: Specify molecular markers identified between diagnosis and the last evaluation

For each molecular marker listed, report whether testing was **Positive**, **Negative**, or **Not done** between diagnosis and the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If tests identified a molecular marker other than those listed, including variance of unknown significance (VUS) markers, report the results in *Other molecular marker* and specify the marker.

If multiple other molecular markers were tested, specify the results in *Other molecular marker* data field, using the following guidelines:


- Report one instance for all
**Positive**other molecular markers and specify the markers (or report ‘see attachment’ and upload the report(s) using the attachment feature in FormsNet3SM) - Report one instance for any
**Negative**other molecular markers and specify the markers (or report ‘see attachment’ and upload the report(s) using the attachment feature in FormsNet3SM)

If CEBPA is reported as **Positive**, specify the CEBPA mutation. If the lab report does not specify whether the detected marker was biallelic / homozygous or monoallelic / heterozygous, confirm with the laboratory whether this information can be determined prior to reporting **Unknown**.

If FLT3-ITD is reported as **Positive**, specify the FLT3-ITD allelic ratio. If the allelic ratio is **Known**, report the value. If the lab report does not specify the allelic ratio, confirm with the laboratory whether this information can be determined prior to reporting **Unknown**.

The allelic ratio data field is intended to capture the ratio of the FLT3-ITD mutation. This data field does not collect the allelic frequency, the allelic frequency is used to calculate the allelic ratio. The FLT-3 ITD allelic ratio (or signal ratio) compares the number of ITD-mutated alleles to the number of wild-type (normal) alleles. If the allele frequency was assessed, the ITD-mutated allele frequency will be documented on the molecular report; however, the wild-type allele frequency will need to be calculated. To determine the wild-type allele frequency, subtract the ITD-mutated allele frequency from 1 (or 100.0%). After determining the wild-type allele frequency, the allelic ratio can be assessed. To calculate the allelic ratio, divide the mutant allele frequency by the wild-type (normal) allele frequency. Review the example below for more information:

Example:


- ITD variant allele frequency: 1.14% (0.0114)
- As documented in the molecular report

- Wild-type allele frequency: 98.86% (0.9886)
- Determined by subtraction 1.14% from 100.0%

- FLT3-ITD allelic ratio: 0.0114 / 0.9886 = 0.0115

Report the FLT3-ITD allelic ratio as 0.0115

#### Question 63: Were cytogenetics tested (karyotyping or FISH)? (at last evaluation)

Indicate whether cytogenetic studies were performed at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If cytogenetic studies were obtained at this time point, check **Yes**. If cytogenetic studies were not obtained at this time point or it is not known whether chromosome studies were performed, indicate **No** or **Unknown**, respectively.

#### Questions 64 – 65: Were cytogenetics tested via FISH?

If FISH studies were performed at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above), report **Yes** and indicate whether clonal abnormalities were detected. If FISH studies were not performed at this time point, FISH samples were inadequate, or it is unknown if performed, report **No**.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Questions 66 – 69: Specify cytogenetic abnormalities (FISH) at last evaluation

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable.

Report the number of abnormalities detected by FISH at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality. If multiple other abnormalities were detected, report “see attachment” in and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 70 – 71: Were cytogenetics tested via karyotyping?

If karyotyping was performed at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above), report **Yes** and indicate whether clonal abnormalities were detected. If karyotyping was performed, but there weren’t any evaluable metaphase cells, report **No evaluable metaphases**. If karyotyping was not performed at this time point or it is unknown is performed, indicate **No**.

#### Questions 72 – 75: Specify cytogenetic abnormalities (karyotyping) identified at last evaluation

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify. If multiple “Other abnormalities” were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 76: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 77: Were tests for molecular markers performed (e.g., PCR, NGS)? (at last evaluation)

If testing for molecular markers was performed at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above), report **Yes**. If molecular marker testing was not performed at this time point or it is not known if testing was done, report **No** or **Unknown**, respectively.

#### Questions 78 – 89: Specify molecular marker results identified at last evaluation

For each molecular marker listed, report whether testing was **Positive**, **Negative**, or **Not done** at the last evaluation prior to infusion (see the At Diagnosis, Last Evaluation, and In Between blue note box above). If tests identified a molecular marker other than those listed, including variance of unknown significance (VUS) markers, report the results in *Other molecular marker* and specify the marker.

If testing for other molecular markers were performed, specify the results in the *Other molecular marker* data field, using the following guidelines:


- Report one instance for all
**Positive**other molecular markers and specify the markers (or report ‘see attachment’ and upload the report(s) using the attachment feature in FormsNet3SM) - Report one instance for any
**Negative**other molecular markers and specify the markers (or report ‘see attachment’ and upload the report(s) using the attachment feature in FormsNet3SM)

If CEBPA is reported as **Positive**, specify the CEBPA mutation. If the lab report does not specify whether the detected marker was biallelic / homozygous or monoallelic / heterozygous, confirm with the laboratory whether this information can be determined prior to reporting **Unknown**.

If FLT3-ITD is reported as **Positive**, specify the FLT3-ITD allelic ratio. If the allelic ratio is **Known**, report the value. If the lab report does not specify the allelic ratio, confirm with the laboratory whether this information can be determined prior to reporting **Unknown**.

The allelic ratio data field is intended to capture the ratio of the FLT3-ITD mutation. This data field does not collect the allelic frequency, the allelic frequency is used to calculate the allelic ratio. The FLT-3 ITD allelic ratio (or signal ratio) compares the number of ITD-mutated alleles to the number of wild-type (normal) alleles. If the allele frequency was assessed, the ITD-mutated allele frequency will be documented on the molecular report; however, the wild-type allele frequency will need to be calculated. To determine the wild-type allele frequency, subtract the ITD-mutated allele frequency from 1 (or 100.0%). After determining the wild-type allele frequency, the allelic ratio can be assessed. To calculate the allelic ratio, divide the mutant allele frequency by the wild-type (normal) allele frequency. Review the example below for more information:

Example:


- ITD variant allele frequency: 1.14% (0.0114)
- As documented in the molecular report

- Wild-type allele frequency: 98.86% (0.9886)
- Determined by subtraction 1.14% from 100.0%

- FLT3-ITD allelic ratio: 0.0114 / 0.9886 = 0.0115

Report the FLT3-ITD allelic ratio as 0.0115

#### Question 90: Did the recipient have central nervous system leukemia at any time prior to the start of the preparative regimen / infusion?

Central nervous system (CNS) involvement by leukemia may be detected via pathologic examination of cerebrospinal fluid or tumor tissue as well as by radiological examinations (e.g., MRI, PET/CT, MIBG, etc.). If the recipient had documented involvement of AML in the CNS, report **Yes**. If all CNS testing was negative since the time of diagnosis, report **No**. If testing for CNS involvement was not performed from the time of diagnosis to the time of HCT / cellular therapy, report **Unknown**.

#### Question 91: What was the disease status (based on hematologic test results)?

Indicate the disease status of AML at the last assessment prior to the start of the preparative regimen. Refer to the AML Response Criteria section of the Forms Instructions Manual for definitions of each response. For reporting purposes, consider complete remission with incomplete hematologic recovery (CRi) a complete remission (CR1, CR2, or CR3+).

If the recipient did not receive any treatment for AML from the time of diagnosis to the start of the preparative regimen / infusion, report **No treatment** and continue with *Date assessed*.

If the recipient’s disease status is **Primary induction failure** at the time of HCT / cellular therapy, continue with *Date assessed*.

If the recipient’s disease status is **CR / CRi** at the time of HCT / cellular therapy, continue with the next question.

If the recipient’s disease status is **Relapse** at the time of HCT / cellular therapy, go to *Date of most recent relapse*.

#### Question 92: How many cycles of induction therapy were required to achieve 1st complete remission (CR)? (includes CRi)

Chemotherapy is initially given as induction therapy intended to bring the disease into remission. Recipients usually have one to two cycles of induction therapy; disease prognosis is considered less favorable if the patient fails to achieve remission with the first induction therapy and even poorer if patients fail two or more induction therapies.1 An example of a common induction therapy for all AML subtypes (except M3) is a combination of an anthracycline and cytarabine, commonly known as “7+3.” In this regimen, cytarabine is typically administered for seven days at a dose of 100 mg/m2/day. The anthracycline (usually daunorubicin at 45 to 60 mg/m2/day or idarubicin at 12 mg/m2/day) is generally given on the first three days the cytarabine is given.

The second phase of chemotherapy is known as consolidation therapy. The goal of consolidation therapy is to destroy any remaining leukemia cells and sustain remission. An example of a common consolidation therapy for all AML subtypes (except M3) is high-dose cytarabine, commonly referred to as “HiDAC.” In this regimen, cytarabine is typically administered at a dose exceeding 10 g/m2 per cycle.

Maintenance chemotherapy may follow consolidation therapy. Maintenance chemotherapy is given in lower doses and is intended to prolong a remission. Maintenance therapy is used less commonly for the treatment of AML than other malignancies. Treatment may also be administered for relapsed disease. Much like induction therapy, treatment for relapse is intended to bring the disease back into remission. Systemic therapeutic agents used to induce remission following relapse often differ from those used in the initial induction, since the disease is often resistant to many of the agents used earlier in the disease course and is considered high-risk with a poor prognosis. Allogeneic HCT is often considered the only potential “cure” for relapsed disease.

Indicate the number of cycles of induction therapy that were required to achieve the first CR. If this is a subsequent infusion and a CR was achieved prior to the previous infusion, the same value will be re-reported.

**Example**: A recipient diagnosed with AML, received two cycles of induction, achieved a CR and then received one cycle of maintenance before going on to transplant. Post-transplant, the recipient relapsed, received two additional cycles of re-induction before achieving a second CR, followed by a cycle of consolidation and second transplant. The number of cycles of induction therapy to achieve the first CR should be reported as ‘two.’

1 Ravandi F, Cortes J, Faderl S, et al. (2010). Characteristics and outcome of patients with acute myeloid leukemia refractory to one cycle of high-dose cytarabine-based induction therapy. Blood, 116(26):5818-23.

#### Question 93: Specify method(s) that was used to assess measurable residual disease status (check all that apply)

Specify the method(s) how the minimal residual status was assessed at the last evaluation, approximately 30 days prior to the start of the preparative regimen / infusion. Select all that apply.

**FISH**: A sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells.

If the measurable residual disease status was assessed by FISH at the last evaluation, continue with *Was measurable residual disease detected by FISH?*.

**Karyotype**: A technique performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

If the measurable residual disease status was assessed by Karyotype at the last evaluation, continue *Was measurable residual disease detected by karyotyping assay?*.

**Flow cytometry**: A method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics. Its primary clinical purpose in the setting of leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD,” or minimal residual disease, testing.

If the measurable residual disease status was assessed by Flow cytometry at the last evaluation, continue with *Which leukemia phenotype was used for detection? (check all that apply)*

**PCR**: Polymerase chain reaction (PCR) amplification is a molecular assessment used to detect single specific disease markers. Testing for molecular markers is often performed using PCR based methods. Once a marker has been identified, this method can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, marrow, or tissue.

If the measurable residual disease status was assessed by PCR at the last evaluation, continue with *Was measurable residual disease detected by PCR?*.

**NGS**: Next-generation sequencing (NGS), also known as massive parallel sequencing is another molecular assessment which is used to determine the order of nucleotides in a genome.

If the measurable residual disease status was assessed by NGS at the last evaluation, continue with *Was measurable residual disease detected by NGS?*.

If the minimal residual status was Not assessed at the last evaluation, continue with *Date assessed*.

#### Question 94: Was measurable residual disease detected by FISH?

Indicate if measurable residual disease was detected by FISH at the last evaluation prior to the start of the preparative regimen / infusion.

If the results are not clear, seek physician clarification to determine if measurable residual disease was detected by FISH at the last evaluation.

#### Question 95: Was measurable residual disease detected by karyotyping assay?

Indicate if measurable residual disease was detected by karyotype at the last evaluation prior to the start of the preparative regimen / infusion.

If the results are not clear, seek physician clarification to determine if minimal residual disease was detected by karyotype at the last evaluation.

#### Questions 96 – 99: Which leukemia phenotype was used for detection? (check all that apply)

Specify which leukemia phenotype was used for detection. Select all that apply.

If the **Original leukemia immunophenotype** was used, specify the lower limit of detection, and then indicate if measurable residual disease was detected by flow cytometry at the last evaluation prior to the start of the preparative regimen / infusion.

If an **Aberrant phenotype** was used, specify the lower limit of detection, and then indicate if measurable residual disease was detected by flow cytometry at the last evaluation prior to the start of the preparative regimen / infusion.

If the results are not clear, seek physician clarification to determine if minimal residual disease was detected by flow cytometry at the last evaluation.

#### Question 100: Was measurable residual disease detected by PCR?

Indicate if measurable residual disease was detected by PCR at the last evaluation prior to the start of the preparative regimen / infusion.

If the results are not clear, seek physician clarification to determine if measurable residual disease was detected by PCR at the last evaluation assay at the last evaluation prior to the start of the preparative regimen / infusion.

#### Question 101: Was measurable residual disease detected by NGS?

Indicate if measurable residual disease was detected by NGS at the last evaluation prior to the start of the preparative regimen / infusion.

If the results are not clear, seek physician clarification to determine if measurable residual disease was detected by NGS at the last evaluation assay at the last evaluation prior to the start of the preparative regimen / infusion.

#### Question 102: Date of most recent relapse

Enter the date of the most recent relapse prior to the start of the preparative regimen / infusion. If reporting a pathological evaluation (e.g., bone marrow) or blood/serum assessment (e.g., CBC, peripheral blood smear), enter the date the sample was collected. If extramedullary disease was detected by radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), enter the date the imaging took place. If the physician determines cytogenetic or molecular relapse, enter the date the sample was collected for cytogenetic or molecular evaluation. If the physician determines evidence of relapse following a clinical assessment during an office visit, report the date of assessment.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 103: Date assessed

Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)