#### SCD Pre-Infusion Data

The Sickle Cell Disease (SCD) Pre-Infusion Data Form (Form 2030) is one of the Comprehensive Report Forms. This form captures SCD-specific pre-infusion data such as: disease classification at diagnosis, transfusion status prior to the start of the preparative regimen, organ assessments prior to the start of the preparative regimen, and the indication for transplant.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as **Sickle Cell Disease (SCD)**.

#### Links to Sections of the Form

[Q1: Subsequent Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-subsequent-transplant-or-cellular-therapy)

[Q2 – 5: Sickle Cell Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-5-disease-classification-at-diagnosis)

[Q6 – 16: Transfusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q6-18-transfusion-therapy)

[Q17 – 19: Therapy for Iron Overload](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q19-21-iron-therapy)

[Q20 – 24: Pulmonary Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q22-26-pulmonary-assessments)

[Q25 – 34: Cardiovascular Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q27-37-cardiovascular-assessments)

[Q35 – 40: Renal Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q47-51-renal-assessments)

[Q41 – 45: Splenic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q52-56-splenic-assessments)

[Q46 – 50: Acute Chest Syndrome](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q57-61-acute-chest-syndrome)

[Q51 – 53: Pain](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q62-64-pain)

[Q54 – 56: Avascular Necrosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q65-67-avascular-necrosis)

[Q57 – 65: Central Nervous System](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q68-76-central-nervous-system)

[Q66 – 76: Other Symptoms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q77085-other-symptoms)

[Q77 – 87: Existing Organ Impairments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q77-87-existing-organ-impairments)

[Q88 – 94: Disease Modifying Therapies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/86-92-disease-modifying-therapies)

[Q95 – 118: Other Laboratory Studies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q93-119-other-laboratory-studies)

[Q119 – 120: Reason for Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q120-121-reason-for-transplant)

[Q121: Marrow Evaluation at Last Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q121-marrow-evaluation-at-last-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/25/2024 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)