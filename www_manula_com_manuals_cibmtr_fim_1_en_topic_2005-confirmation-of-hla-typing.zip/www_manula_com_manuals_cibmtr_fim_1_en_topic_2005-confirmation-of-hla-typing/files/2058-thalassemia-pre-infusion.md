The Thalassemia Pre-Infusion (2058) Form is one of the Comprehensive Report Forms. This form captures thalassemia-specific pre-infusion data such as the recipient’s thalassemia diagnosis, donor related information, transfusion, hepatic, cardiac, renal, iron overload assessment prior to the start of the preparative regimen, hematologic labs, organ impairment, and pre-infusion therapy.

This form must be completed for all transplant and gene therapy recipients, randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported as **Hemoglobinopathies – Transfusion dependent thalassemia: Transfusion beta dependent thalassemia** or **Other transfusion dependent thalassemia** on the Disease Classification (2402) Form.

Links to Sections of Form:

[Q1: Subsequent Transplant or Cellular Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-subsequent-transplant-or-cellular-therapyy)

[Q2 – 26: Thalassemia Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-26-thalassemia-diagnosis)

[Q27 – 52: Donor Related Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q27-52-donor-related-information)

[Q53 – 60: Transfusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q53-59-transfusion-therapy)

[Q61 – 63: Hepatic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q60-62-hepatic-assessments)

[Q64 – 72: Cardiac Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q63-67-cardiac-assessments)

[Q73 – 75: Renal Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q63-67-cardiac-assessments)

[Q76 – 78: Avascular Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q76-78-avascular-necrosis)

[Q79: Other Symptoms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q79-other-symptoms)

[Q80 – 89: Additional Iron Overload Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q80-89-additional-iron-overload-assessments)

[Q90 – 94: Additional Hematologic Labs}](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q90-94-additional-hematologic-labs)

[Q95 – 105: Existing Organ Impairments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q95-105-specify-existing-organ-impairments)

[Q106 – 112: Disease Modifying Therapies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q95-101-disease-modifying-therapy)

[Q113: Marrow Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q113-marrow-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/25/2024 |
|

*This section is only completed for*~~gene therapy~~ Zynteglo® infusions. Report the marrow results at last evaluation prior to the start of the preparative regimen.[2058: Thalassemia Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2058-thalassemia-pre-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)