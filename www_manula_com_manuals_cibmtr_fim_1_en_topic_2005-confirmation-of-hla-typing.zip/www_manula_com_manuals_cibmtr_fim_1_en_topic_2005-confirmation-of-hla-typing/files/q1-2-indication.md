#### Questions 1 – 2: Specify the indication for CIBMTR data reporting

Indicate whether the individual will be receiving an **Infusion** (e.g., hematopoietic cellular transplant (HCT), gene therapy, cellular therapy), **Marrow toxic injury**, or **Non-cellular therapy** (e.g., study enrollment, chemotherapy, immunotherapy, etc.).

For more information on infusion types, review [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

**Marrow toxic injury** should only be reported by Radiation Injury Treatment Network (RITN) centers in the event of mass casualty incident resulting in marrow toxic injury. Do not report marrow toxic injury for individuals receiving pre-infusion radiation therapy or for accidental, isolated exposures to radiation. If the indication is **Marrow toxic injury**, specify the date of the marrow toxic injury (i.e., radiation event).

If completing this form for a patient at a RITN center and it is uncertain if the patient’s data should be reported using the marrow toxic injury indication, contact [CIBMTR Center Support](https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Center-Support) or email RITN@nmdp.org.

**Non-cellular therapy** may include vaccine or immunomodulatory trials; report non-cellular therapy when the patient is enrolled on a trial or protocol requiring data submission to CIBMTR.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 1 | 1/28/2025 | Modify | Added new floating text to the non-cellular therapy option: Indicate whether the individual will be receiving an Infusion (e.g., hematopoietic cellular transplant (HCT), gene therapy, cellular therapy), Marrow toxic injury, or Non-cellular therapy (e.g., study enrollment, chemotherapy, immunotherapy, etc.). |
Floating text was updated in January 2025 release |
| 1 | 1/28/2025 | Remove | Removed the red warning box: |
Validation was updated in January 2025 release |
| 1 | 1/28/2025 | Add | New blue note box added: CMS Innovation Center’s Cell and Gene Therapy (CGT) Access Model for Sickle Cell Disease (SCD) Select “non-cellular therapy” when completing this form for the first time for a CRID to be enrolled in the CMS Innovation Center’s Cell and Gene Therapy (CGT) Access Model for Sickle Cell Disease (SCD). Contact CIBMTR Center Support with any questions. |
Validation was updated in January 2025 release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)