The Persistence of Gene Therapy Product Form (Form 2103) is post Gene Therapy follow up form. This form captures the testing results conducted on the Gene Therapy Product post infusion such as: method of testing, cell source, cell type, and if gene therapy product was detected.

Gene Therapy products are designed to achieve therapeutic effect through permanent or long-acting changes in the human body. Based upon the current FDA guidelines for long term follow up (LTFU) after the administration of Gene Therapy Products, an annual follow up timeframe for 15 years has been established. Reported Gene Therapy (HCTs) will have annual follow up CRF forms of the Post Infusion Follow Up Forms (F2100) for 15 years. The Persistence of Gene Therapy Product Form will be required for Gene Therapy infusions.

Links to Sections of Form:

[Q1-18: Persistence of Gene Therapy Product](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-18-persistence-of-gene-therapy-product)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/27/2023 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)