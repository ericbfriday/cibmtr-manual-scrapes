## Introduction to Cytogenetics

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing a sample of cells for the presence of chromosomal abnormalities. Cytogenetic assessment can also be done to determine chimerism following an allogeneic infusion when there is a sex mismatch between the donor and recipient. Specific methods of assessment include karyotyping and fluorescence in situ hybridization (FISH).

This section will provide information on the two methods of assessment captured on the CIBMTR forms: Karyotyping and FISH

Links to Sections

[Karyotyping](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/karyotyping)

[FISH (Fluorescence in situ hybridization](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/fish-fluorescence-in-situ-hybridization)

**Section Updates:**

| Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|
| 4/4/2024 | Add | The Reporting Other FISH Results section added to the FISH subsection | Added for clarification |
| 4/4/2024 | Add | The Reporting Other Karyotype Results section added to the Karyotype subsection | Added for clarification |
| 7/28/2023 | Add | Appendix C: Cytogenetics re-vamped. The original ‘Introduction to Chromosomes,’ and ‘Cytogenetic Assessment Methods,’ previously listed in version 2 of Appendix C is now separated into its own combined subsection and re-vamped in version 3 of Appendix C | Added with release of ISCN Functionality in the Summer 2023 release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)