The Solid Tumor Response (3507) Form must be completed for cell therapy recipients when the indication is to treat solid tumors and the sub-type is Bone sarcoma (excluding Ewing family tumors) (273), Myxoid round cell sarcoma (2217), or Synovial sarcoma (245). This form will be completed the Solid Tumor Pre-Infusion (2059) Form and with the Post-Cellular Therapy Essential Data (4100) Form at all timepoints .

Links to Sections of Form:

[Q1: Disease Status at Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-disease-status-at-infusion)

[Q2 – 5: Best Response to Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-5-best-response-to-infusion)

[Q6 – 9: Current Response](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q6-9-current-response)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)