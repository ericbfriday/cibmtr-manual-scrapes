#### Question 8: Was this product collected off-site and shipped to your facility?

If the product was shipped to the transplant center or contracted lab from an off-site collection center, select **Yes**. In general, the “yes” option will be used for unrelated donors.

However, there may be circumstances where the donor resides in the same geographic location as the recipient and the collection occurred at the same facility as the transplant; in this case, the “no” option should be used.

If the product **was not** shipped to the transplant center or contracted lab from an outside facility, or if the product **was** collected onsite then shipped off-site for laboratory processing, select **No**. The “no” option usually applies to autologous collections and related donors.

#### Question 9: Date of receipt of product at your facility

The intent of this question is to determine the date the transplant center assumed responsibility for the product from the collection center. Enter the date your institution became responsible for the product.

If multiple bags of the same product arrived on different days, report the date the first bag arrived at your facility.

If a contract laboratory processes the product prior to arrival at the transplant facility, report the date the product arrived at the contract laboratory.

#### Question 10: Time of receipt of product (24-hour clock)

Enter the exact time your institution or off-site laboratory received and became responsible for the product. Report the time using a 24-hour clock and indicate if daylight savings time or standard time was in effect. If the location of your institution or off-site laboratory does not observe daylight savings time, report the time as standard time. For more information about daylight savings time schedules, go to [http://www.timeanddate.com/time/dst/](http://www.timeanddate.com/time/dst/).

#### Questions 11-12: Specify the shipping environment of the product(s)

Indicate the shipping environment of the product.

**Room Temperature**: Shipping environment where controlled cooling is not required.**Cooled**: Shipping environment below ambient temperatures (e.g., 59° F – 77° F) but above freezing (e.g., 32° F>). Examples include shipments utilizing refrigerated gel packs (Re-FREEZ-R-BRIX, etc.).**Frozen (cryopreserved)**: Shipping environment where liquid components are maintained in a solid state. Examples include shipments utilizing dry ice, Crēdo coolers, or other thermo-insulated containers.

If the recipient’s product was shipped in a way other than described on the list, select **Other shipping environment** and specify the shipping environment. It is not necessary to provide the specific temperature of the product during shipment.

#### Question 13: Was there any indication that the environment within the shipper was outside the expected temperature range for this product at any time during shipment?

Indicate if there was any indication the environment within the shipper was outside the expected temperature range for this product at any time during shipment. For cord blood unit shipping containers, the temperature of the shipper is generally constant and tracked using a data-logger. Mishandling of the product shipper or spikes in temperature could impact the integrity of the product.

If there was any indication that the environment within the shipper was outside the expected temperature range upon arrival at your center, a product complaint form (Form 3010) must be completed.

#### Question 14: Were the secondary containers (e.g., insulated shipping containers and unit cassette) intact when they arrived at your center?

Indicate if the secondary containers were intact upon receipt of the product by your center.

If the secondary containers were not intact upon arrival, a product complaint form (Form 3010) must be completed.

If the product was *not* a CBU, continue with the Product Processing / Manipulation section.

#### Question 15: Was the cord blood unit stored at your center prior to thawing? (*Cord blood units only*)

Indicate **Yes** or **No** if the cord blood unit was stored at your center prior to thawing.

#### Question 16: Specify the storage method used for the cord blood unit

Indicate the storage method used for the cord blood unit. The storage method is generally standard and should be documented within the laboratory at your center. Note: **Liquid nitrogen** is also known as liquid phase.

#### Question 17: Temperature during storage

Indicate the storage temperature used for the cord blood unit. The storage temperature is generally standard and should be documented within the laboratory at your center.

#### Question 18: Date storage started

Report the date the cord blood unit was first stored at your center prior to thawing.

#### Question 19: Total Nucleated cells: (Cord blood units only)

Report the total nucleated cells for the cord blood product. This information is available within the documentation received with the product shipment and from the search documentation performed to select the product. These values are from the Cord Blood Bank and should not represent post-thaw values assessed at your center’s lab.

#### Questions 20-21: CD34+ cells: (Cord blood units only)

Indicate if the cord blood bank quantified CD34+ cells in the product. If the CD34+ cells were quantified, select “done” and report the total CD34+ cells for the cord blood product in question 21. This information is available within the documentation received with the product shipment and from the search documentation performed to select the product. These values are from the Cord Blood Bank and should not represent post-thaw values assessed at your center’s lab.

If the CD34+ cells were not quantified by the cord blood bank, report **Not done**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)