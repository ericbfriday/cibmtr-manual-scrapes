The Plasma Cell Disorder Post-HCT Data Form is one of the Comprehensive Report Forms. This form captures plasma cell disorder (PCD) post-HCT data such as: disease assessment at the time of best response, hematologic and organ parameters at the time of best response, post-HCT therapy, disease status at the time of evaluation for this reporting period, and current status of amyloidosis for this reporting period.

This form must be completed for all recipients whose primary disease reported on the Pre-TED Disease Classification Form (Form 2402) is “Multiple myeloma/plasma cell disorder (PCD).” The Post-HCT Plasma Cell Disorder form must be completed in conjunction with each Post-HCT follow-up form (Form 2100). This form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100; between day 100 and the six-month date of contact for six-month follow-up; and between the date of contact for the six-month follow-up and the date of contact for the one-year follow-up, etc.).

Links to Sections of the Form

[Q1 – 2: Disease Specificity](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-2-disease-specificity)

[Q3 – 53: Disease Assessment at the Time of Best Response to HCT or Cellular Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q3-53-disease-assessment-at-the-time-of-best-response-to-hct)

[Q54 – 109: Organ Parameters of Amyloidosis at the Time of Best Response](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q54-109-hematologic-and-organ-parameters-at-the-time-of-best-response-for-amyloid-patients-only)

[Q110 – 141: POEMS Syndrome Assessment at the Time of Best Response](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q110-141-poems-syndrome-assessment-at-the-time-of-best-response)

[Q142 – 210: Post-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q142-210-post-infusion-therapy)

[Q211 – 252: Disease Status at the Time of Evaluation for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q211-252-disease-status-at-the-time-of-evaluation-for-this-reporting-period)

[Q253 – 311: Current Status of Amyloidosis for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q253-311-current-status-of-amyloidosis-for-this-reporting-period-for-amyloid-patients-only)

[Q312 – 343: Current Status of POEMS Syndrome for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q312-343-current-status-of-poems-syndrome-for-this-reporting-period)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2116.PCD%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/20/2022 |
|

*Indicate if the date the radiation therapy stopped is Known, Unknown, or Not applicable. If Known, enter the date the line of radiation therapy ended. Report Not applicable if the recipient is still receiving therapy. When Not applicable is selected, the radiation dose will not be reported in the next question. However, once radiation stops (i.e., the radiation stop date is Known), the dose will be reported.*[2116: PCD Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2116-pcd-post-hct)*If radiation started in a previous reporting period (i.e., Not applicable was reported as the therapy end date for the prior reporting period) and continued into the current reporting period, report the total dose administered since radiation started (including the doses given in the previous reporting period).*

Example B: A recipient started radiation at end of the Day 100 reporting period. 200 cGy for 3 doses were given (total dose in the Day 100 reporting period is 600 cGy). Radiation continued into the 6-month reporting period and an additional 200 cGy for 4 doses were given (total dose given in the 6-month reporting period is 800 cGy). The total dose of radiation should be reported as 1400 cGy (600 cGy + 800 cGy).Example B: A recipient started radiation at end of the Day 100 reporting period. 200 cGy for 3 doses were given (total dose in the Day 100 reporting period is 600 cGy). Radiation continued into the 6-month reporting period and an additional 200 cGy for 4 doses were given (total dose given in the 6-month reporting period is 800 cGy). The total dose of radiation should be reported as 1400 cGy (600 cGy + 800 cGy).

[2116: PCD Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2116-pcd-post-hct)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)