The General Instructions section of the Forms Instruction Manual contains several sections meant to aid in forms completion.

[Introduction](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/introduction)

[Key Fields & Signature Lines](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/key-fields)

[General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/8/2024 | General Instructions | Add | General Number Reporting Guidelines added to the General Guidelines for Completing Forms subsection |
| 1/19/17 | General Instructions | Remove | The following subsections were removed Forms Instructions Manual and are being transferred into other data management resources:
|

Last modified:
Mar 08, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)