#### Question 21: Were tests performed to detect persistence of the cellular product since the date of last report?

Methods such as PCR assays, flow cytometry (immunophenotyping) or immunohistochemistry can be used to detect direct persistence of the cellular product in the recipient.

It is possible to use other testing methods, such as monitoring B cells, as a surrogate for ongoing cellular therapy persistence. Surrogate testing should not be reported here. Monitoring of B cells can be reported in question 43.

Indicate **Yes** or **No** whether tests were performed to detect direct persistence of the cellular product in the current reporting period.

#### Question 22: Was persistence evaluated by molecular assay (PCR)?

Molecular assessment involves testing blood, bone marrow, tumor or other source for the presence of known molecular markers. Molecular assessments are the most sensitive test and involve amplifying regions of cellular DNA by polymerase chain reaction (PCR), typically using RNA to generate complementary DNA through reverse transcription (RT-PCR). The amplified DNA fragments are compared to a control, providing a method of quantifying log increase of genetic mutation transcripts. Each log increase is a 10-fold increase of gene transcript compared to control.

Indicate **Yes** or **No** whether molecular assay testing was performed to detect the persistence of the genetically modified cellular therapy product within the reporting period.

#### Question 23: Date Sample collected:

Report the date (YYYY-MM-DD) the sample was collected for molecular assay. If multiple tests were performed in the reporting period and

- all tests were negative, report the date of the first negative test result
- there were positive and negative results, report the date of the last positive test (do not report negative results)

If the exact date is unknown, please view General Instructions, “General Guidelines for Completing Forms”:https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms for

more information on reporting partial and unknown dates.

#### Questions 24-25: Specify the cell source: (check all that apply)

Specify the cell source of the sample collected for evaluation by molecular assay. Select all that apply. If multiple cell sources were used and persistence was detected in some but not all the samples, report ONLY the cell sources that were positive. If **Other source** is selected, specify the source.

#### Question 26: Were the infused cells detected?

Indicate **Yes** or **No** if the infused cells were detected by molecular assay.

#### Question 27: Was persistence evaluated by flow cytometry testing (immunophenotyping)?

Flow cytometry is a technique that can be performed on blood, bone marrow, or tissue preparations where cell surface markers can be quantified on cellular material. The nature of flow cytometry is to detect cells based on a specific probe. To report flow cytometry results, the test must have been performed to specifically detect the genetically modified cellular therapy product.

Indicate **Yes** or **No** if flow cytometry testing was performed to detect the persistence of the genetically modified cellular therapy product within the reporting period.

#### Question 28: Date sample collected:

Report the date (YYYY-MM-DD) the sample was collected for flow cytometry testing (immunophenotyping). If multiple tests were performed in the reporting period and

- all tests were negative, report the date of the first negative test result
- there were positive and negative results, report the date of the last positive test (do not report negative results)

If the exact date is unknown, please view [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). for more information on reporting partial and unknown dates.

#### Question 29-30: Specify the cell source (check all that apply)

Specify the cell source of the sample collected for evaluation by flow cytometry. Select all that apply. If multiple cell sources were used and persistence was detected in some but not all the samples, report ONLY the cell sources that were positive. If Other source is selected, specify the source.

#### Question 31: Were the infused cells detected?

Indicate **Yes** or **No** if the infused cells were detected by flow cytometry.

#### Question 32: Was persistence evaluated by immunohistochemistry?

Immunohistochemistry is a process that uses antibodies to test for certain antigens (markers) in a sample. When the antibodies bind to the antigen in the tissue sample, the enzyme or dye is activated, and the antigen can then be seen under a microscope.

Indicate **Yes** or **No** if immunohistochemistry testing was performed to detect the persistence of the genetically modified cellular product within the reporting period.

#### Question 33: Date sample collected:

Report the date (YYYY-MM-DD) the sample was collected for immunohistochemistry. If multiple tests were performed in the reporting period and

- all tests were negative, report the date of the first negative test result
- there were positive and negative results, report the date of the last positive test (do not report negative results)

If the exact date is unknown, please view [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). for more information on reporting partial and unknown dates.

#### Question 34-36: Specify the cell source:

Specify the cell source of the sample collected for evaluation by immunohistochemistry. Select all that apply. If multiple cell sources were used and persistence was detected in some but not all the samples, report ONLY the cell sources that were positive. If **Other source** is selected, specify the source.

#### Question 36: Were the infused cells detected?

Indicate **Yes** or **No** if the infused cells were detected by immunohistochemistry testing.

#### Questions 37-38: Was persistence evaluated by other method?

Indicate **Yes** or **No** if persistence of cells was tested by a method not listed above. If **Yes**, specify the other method used to evaluate persistence of cells.

#### Question 39: Date sample collected:

Report the date (YYYY-MM-DD) the sample was collected for the other method. If multiple tests were performed in the reporting period and

- all tests were negative, report the
*date of the first negative test result* - there were positive and negative results, report the
*date of the last positive test (do not report negative results)*

If the exact date is unknown, please view General Instructions, “General Guidelines for Completing Forms”:https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms for more information on reporting partial and unknown dates.

#### Question 40-41: Specify the cell source:

Specify the cell source of the sample collected for evaluation by other method. Select all that apply. If multiple cell sources were used and persistence was detected in some but not all the samples, report ONLY the cell sources that were positive. If **Other source** is selected, specify the source.

#### Question 42: Were the infused cells detected?

Indicate **Yes** or **No** if the infused cells were detected by the other method being reported in these questions.

#### Question 43: Were B-cell counts monitored after infusion?

CAR-T cells that target antigens (e.g., CD19) on B-cells do not distinguish between cancerous and normal B-cells. As result, the recipient can develop B-cell aplasia (low number or absence of B-cells). B-cell aplasia can be used as a surrogate to track persistence of the product. If the recipient has B-cell aplasia, then the product may still be present. Examples include (but not limited to) “cellular immunology report”, “lymphocyte subsets”, or “B-cell panel” of applicable tests that will show B-cell populations.

Indicate **Yes** or **No** if B-cell counts were monitored during the current reporting period.

#### Question 44: Was there B-cell recovery?

A guideline for B-cell aplasia is a B-cell count of < 50 cells/µL of blood., If B-cell aplasia was identified and B-cells subsequently recovered (>50 cells/uL), select **Yes**. If B-cells never recovered, report **No**, or select **Unknown** if B-cell recovery is not documented.

B-cell counts in the blood do vary with age, and children have much higher counts than adults. The younger the child, the higher the concentration.

#### Question 45: Date of B-cell recovery

Report the date (YYYY-MM-DD) the flow cytometry report showed B-cell recovery.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 21 | 1/24/2025 | Add | New blue note box above question 21: There are currently no commercially available persistence tests for the commercially available BCMA CAR-T products (e.g. Abecma, Carvykti. You may select No for the question Were tests performed to detect persistence of the cellular product since the date of last report?. |
Update for new commercially available CD19+ CAR-T persistence test, there are still no tests for BCMA products. |
| 21 | 1/24/2025 | Modify | Modified blue note box above question 21: There is a No for the question Were tests performed to detect persistence of the cellular product since the date of last report? but please confirm if your site is using the new persistence test. |
Update for new commercially available CD19+ CAR-T persistence test. |
| 43 | 1/23/2024 | Add | Added the text in red: CAR-T cells that target antigens (e.g., CD19) on B-cells do not distinguish between cancerous and normal B-cells. As result, the recipient can develop B-cell aplasia (low number or absence of B-cells). B-cell aplasia can be used as a surrogate to track persistence of the product. If the recipient has B-cell aplasia, then the product may still be present. Examples include (but not limited to) “cellular immunology report”, “lymphocyte subsets”, or “B-cell panel” of applicable tests that will show B-cell populations. | Clarification of applicable report names. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)