#### Key Fields

Accuracy of the Key Fields is essential for ensuring that:


- Data are being reported for the correct recipient and infusion.
- Outcomes data accurately reflects appropriate transplant type and product for each transplant center.
- Data about donors are correctly linked across from for that donor
- Data are being shared with the correct donor center, cord blood bank, cooperative registry, or other agency.

The Key Fields precede the form body on each form. The key fields are automatically populated when a form (i.e., the “target form”) is opened in edit mode in the FormsNet3 application. The auto-population uses information provided on the CRID Assignment and other forms previously completed (i.e., the “source form”). Centers should review all auto-populated data for accuracy and completeness. If errors are noted in the key fields, the source will need to be updated first. Once the source is accurate, the center will need to reprocess any completed target forms to correct the key field data.

Auto-population Sources:

Source Form |
Data |
Target Forms |
| CRID Assignment | Recipient Demographics:
|
Pre-TED (2400) Cellular Therapy Essential Data Pre-Infusion (4000) |
| Indication for CRID Assignment (2814) | For first infusions only:
|
All forms completed for this infusion |
| Pre-TED (2400) | Donor details:
|
Infectious Disease Markers (2004) Confirmation of HLA Typing (2005) Hematopoietic Stem Cell Transplantation (HCT) Infusion (2006) |
| Disease Classification (2402) |
|
Pre-infusion disease specific forms Post-infusion disease specific forms |

#### Signature Lines

The FormsNet3 application will automatically populate the signature data fields, including name and email address of person completing the form and date upon submission of the form.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2400.Pre-TED%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/3/2023 |
|

*Accuracy of the Key Fields is essential for ensuring that:**Data are being reported for the correct recipient and infusion.**Outcomes data accurately reflects appropriate transplant type and product for each transplant center.**Data about donors are correctly linked across from for that donor**Data are being shared with the correct donor center, cord blood bank, cooperative registry, or other agency.*

~~The Key Fields precede the form body and are automatically populated in the FormsNet3 application based on information provided on the CRID Assignment Form 2804. If errors are noted in the key fields, correct Form 2804 and then review it for accuracy. After Form 2804 has been corrected, verify data has been updated on all completed forms. If the data has not been updated automatically, centers will need to reprocess the completed forms to correct the key field data. If errors are noted in key fields for second or subsequent transplants, contact your CRC to make any necessary corrections to the transplant or product type. Transplant and product type will not be automatically populated on product or donor specific forms (Forms 2004, 2005, and 2006) and will need to be manually reported.~~The Key Fields precede the form body on each form. The key fields are automatically populated when a form (i.e., the “target form”) is opened in edit mode in the FormsNet3 application. The auto-population uses information provided on the CRID Assignment and other forms previously completed (i.e., the “source form”). Centers should review all auto-populated data for accuracy and completeness. If errors are noted in the key fields, the source will need to be updated first. Once the source is accurate, the center will need to reprocess any completed target forms to correct the key field data.

[Key Fields & Signature Lines](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/key-fields)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)