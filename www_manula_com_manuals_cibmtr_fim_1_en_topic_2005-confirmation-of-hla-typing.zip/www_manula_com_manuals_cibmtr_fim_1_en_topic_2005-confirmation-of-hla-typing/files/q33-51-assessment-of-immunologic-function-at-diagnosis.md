Report findings from immune function studies at the time of diagnosis; if multiple studies were performed, report the initial values.

#### Question 33: NK cell function

Natural killer (NK) cells are cytotoxic lymphocytes implicated in viral response and tumor immunosurveillance. Patients with XLP often have normal numbers of NK cells, but the cells have functional defects. Indicate if the patient’s immune studies revealed absent (≤ 10% lower limit of normal), decreased (11-50% lower limit of normal), or normal (> 50% lower limit of normal) quantity of NK cells. If NK cell function was not assessed, indicate “not done.”

#### Questions 34-35: Invariant natural killer T-cells (iNKT)

Invariant natural killer T-cells (iNKT) are a subset of T-lymphocytes that have actions resembling mechanisms of both the innate and adaptive immune systems. They express T-cell receptors that act similarly to pattern-recognition receptors seen in the adaptive immune system. In terms of function, iNKT do not have a “memory” of previously seen antigens, similar to cells of the innate immune system. iNKT cells are absent in XLP patients with the *SH2D1A* mutation. Specify if iNKT quantification was “known” or “unknown.” If “known,” report the quantity of iNKT as cells/mm3 (or cells/µL) in question 35. If “unknown,” continue with question 36.

#### Questions 36-39: Mucosal-associated invariant T-cells (MAIT)

Mucosal-associated invariant T-cells (MAIT) are a subset of T-lymphocytes that act as part of the innate immune system. MAIT are decreased in XLP patients with the *SH2D1A* mutation. Specify if MAIT quantification was “known” or “unknown.” If “known,” report the quantity of MAIT as cells/mm3 (or cells/µL) in question 37; report the laboratory upper and lower limits of normal in questions 38-39 respectively. If “unknown,” continue with question 40.

#### Question 40: Signaling lymphocyte activation molecule (SLAM)-associated protein (SAP) expression

Signaling lymphocyte activation molecule-associated protein (SAP) is encoded for by *SH2D1A* and is expressed in T-cells and NK cells. SAP is implicated in the development of iNKT cells, as well as in the regulation of NK and T-lymphocytes. Indicate if SAP was or was not expressed. If protein expression was not evaluated, report “not done.”

#### Question 41: XIAP protein expression

X-linked inhibitor of apoptosis (XIAP) is encoded for by *BIRC4* and is part of an apoptosis inhibitor protein family. It is believed to be one of the more powerful inhibitors of apoptosis through its action blocking certain apoptosis cascade enzymes. Indicate if XIAP was or was not expressed. If protein expression was not evaluated, report “not done.”

#### Question 42: Did the recipient receive supplemental intravenous immunoglobulins (IVIG)?

IVIG is a product made from pooled human plasma that primarily contains IgG. It is used to provide immune-deficient recipients with antibody function to prevent infection.

Indicate whether the recipient received IVIG at diagnosis. If “yes,” continue with question 43. If “no,” continue with question 44.

#### Question 43: Was therapy ongoing within three months of immunoglobulin testing?

Indicate whether the recipient received IVIG within three months prior to the immunoglobulin testing done at diagnosis. Patients exhibiting signs of a compromised or dysfunctional immune system may have received IVIG prior to a diagnosis being made. If IVIG is given within three months of immunoglobulin testing, the IgG level would not represent the recipient’s native IgG.

#### Questions 44-45: IgG

Indicate whether IgG level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 45. If “unknown,” continue with question 46.

#### Questions 46-47: IgM

Indicate whether IgM level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 47. If “unknown,” continue with question 48.

#### Questions 48-49: IgA

Indicate whether IgA level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 49. If “unknown,” continue with question 50.

#### Questions 50-51: IgE

Indicate whether IgE level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value in question 51. If “unknown,” continue with question 52.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)