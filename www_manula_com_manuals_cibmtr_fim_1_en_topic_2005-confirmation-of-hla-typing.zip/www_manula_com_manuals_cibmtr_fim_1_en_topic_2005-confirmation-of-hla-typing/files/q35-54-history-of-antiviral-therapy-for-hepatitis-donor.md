Complete questions 35-54 for allogeneic transplants only; if donor information is unknown, leave the data field blank. Complete all data fields for which relevant donor information is documented and available to the CIBMTR center completing the form.

#### Question 35: Did the donor receive therapy for hepatitis prior to the stem cell harvest?

Hepatitis antiviral therapy is intended to prevent progression of the disease and minimize sequelae of infection. The National Institutes of Health (NIH) in the United States recommends antiviral therapy for Hepatitis B patients with acute liver failure, cirrhosis or advanced cirrhosis with positive viral load, and for reactivation of chronic HBV during or after chemotherapy and/or immunosuppression. 2 Lamivudine, pegylated interferon alfa, entecavir, and tenofovir are medications currently used to treat Hepatitis B. Hepatitis C therapy has similar goals of sustaining a viral response and minimizing sequelae of infection. Therapy is recommended for patients with elevated liver enzymes and/or significant histologic damage on liver biopsy.

Indicate if the donor received antiviral therapy for hepatitis at any time prior to the stem cell harvest. If “yes,” continue with question 36. If “no,” continue with the signature section. If “unknown,” leave the data field blank and continue with the signature section.

2 Sorrell MF, Belongia EA, Costa J, Gareen IF, Grem JL, Inadomi JM, et al. (2009). National Institutes of Health Consensus Development Conference Statement: management of Hepatitis B. Annals of Internal Medicine, 150(2):104-110.

For each therapeutic agent below, create an instance for each course. A course is defined as the period from therapy start to discontinuation of therapy, during which the donor is regularly scheduled to receive a certain dose of medication; if the daily dose is changed, report a new line of therapy starting with the date the changed dosage is administered. Complete all data fields for which information is available.

#### Question 36: Lamivudine therapy given?

Indicate if the donor received a course at any time prior to the stem cell harvest; create an instance for each course given. If “yes,” continue with question 37; if “no,” continue with question 42.

#### Question 37: Date started

Report the date therapy was initiated and continue with question 38.

#### Question 38: Currently receiving?

Indicate if the donor was receiving therapy at the time of stem cell donation. If they were continuing to receive Lamivudine, report “yes.”

#### Question 39: Therapy stopped?

Indicate if therapy was stopped prior to the stem cell harvest. If “yes,” continue with question 40. If “no,” continue with question 42.

#### Question 40: Date stopped

Report the date therapy was stopped and continue with question 41.

#### Question 41: Reason stopped

This is a free text data field. Concisely document the rationale for stopping this course of therapy; suggested examples include “planned stop” and “undesirable side effects.” If the donor received multiple courses of therapy, use this field to provide rationale for the dose change at onset of new course. If the rationale for therapy is not available in the records, document “unknown.”

#### Question 42: Interferon therapy given?

Indicate if the donor received a course at any time prior to the stem cell harvest; create an instance for each course given. If “yes,” continue with question 43; if “no,” continue with question 48.

#### Question 43: Date started

Report the date therapy was initiated and continue with question 44.

#### Question 44: Currently receiving?

Indicate if the donor was receiving therapy at the time of stem cell donation. If they were continuing to receive interferon therapy, report “yes.”

#### Question 45: Therapy stopped?

Indicate if therapy was stopped prior to the stem cell harvest. If “yes,” continue with question 46. If “no,” continue with question 48.

#### Question 46: Date stopped

Report the date therapy was stopped and continue with question 47.

#### Question 47: Reason stopped

This is a free text data field. Concisely document the rationale for stopping this course of therapy; suggested examples include “planned stop” and “undesirable side effects.” If the donor received multiple courses of therapy, use this field to provide rationale for the dose change at onset of new course. If the rationale for therapy is not available in the records, document “unknown.”

#### Questions 48-49: Other antiviral therapy given?

Indicate if the donor received a course of any other (not Lamivudine or interferon) antiviral therapy for hepatitis infection at any time prior to the stem cell harvest; create an instance for each course of each agent given. If “yes,” continue with question 49 and specify the other antiviral therapy given; if “no,” continue with continue with signature section of the form.

#### Question 50: Date started

Report the date therapy was initiated and continue with question 51.

#### Question 51: Currently receiving?

Indicate if the donor was receiving therapy at the time of stem cell donation. If they were continuing to receive another antiviral agent, report “yes.”

#### Question 52: Therapy stopped?

Indicate if therapy was stopped prior to the stem cell harvest. If “yes,” continue with question 53. If “no,” continue with the signature section.

#### Question 53: Date stopped

Report the date therapy was stopped and continue with question 54.

#### Question 54: Reason stopped

This is a free text data field. Concisely document the rationale for stopping this course of therapy; suggested examples include “planned stop” and “undesirable side effects.” If the donor received multiple courses of therapy, use this field to provide rationale for the dose change at onset of new course. If the rationale for therapy is not available in the records, document “unknown.”

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)