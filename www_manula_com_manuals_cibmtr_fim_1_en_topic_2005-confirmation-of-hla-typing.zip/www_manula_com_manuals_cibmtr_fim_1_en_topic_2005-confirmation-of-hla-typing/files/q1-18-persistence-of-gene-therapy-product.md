**Questions 1- 3: Method of testing**

Indicate the method of testing for persistence of gene therapy product:

**Allelic editing frequency**: How often on-target allele editing occurs. It is determined by counting how many times the allele (one of two version of a DNA sequence at a given location) appears, then dividing by the total number of copies of the gene to determine a percentage. If this method of testing was used, report the percentage of allelic editing in question 9.**Clonal expansion (most common clone)**: A small number of precursor cells proliferate into expanded clones. Note, if this method of testing was used, report the percentage of the most common clone in question 10.**Gene therapy globin expression**: Level of therapeutic globin production that occurs after gene therapy; Note, if this method was used, report the expression of the hemoglobin in Question 11 in g/dL and the type of globin in question 12.**Homology directed DNA repair (HDR) frequency**: How often DNA repair is detected. Precise gene editing causes a nick or double-strand break at targeted regions. HDR is a precise repair mechanism that uses homologous donor DNA to repair the DNA damage. Note, if this method was used, report the percentage of HDR in question 13.**Indel mutations frequency**: How often insertion-deletion mutations that may occur after gene editing and DNA repair are detected. Note, if this method was used, report the percentage of indel mutations in question 14.**Transgene expression**: How often the transgene introduced into the genome is expressed. If this method was used, report the percentage of expression in question 15.**Vector copy number (VCN, number of vector copies per diploid genome)**: If this method was used, report the number of vector copies per diploid genome in question 16.**Other method**: If a method of testing was utilized that is not currently listed, select this option and specify in question 2.

Report the date the sample was collected in YYYY-MM-DD format in question 3.

**Example 1.** Testing for Gene Therapy Product was conducted on B-cells for bone marrow and peripheral blood. One instance of testing and results should be reported for the bone marrow and another separate instance and results should be reported for the peripheral blood. For this example, a total of two instances would be reported.

**Example 2.** Testing for Gene Therapy Product was conducted on B-Cells of the bone marrow while additional testing was conducted on Granulocytes and T-cells from peripheral blood. One instance should be reported for B-cells of the bone marrow. An additional two instances should be reported for peripheral blood. One for Granulocytes and another for T-cells. For this example, a total of three instances would be reported.

**Questions 4 – 5: Cell Source**

Select from the list the tissue source(s) of the cellular product being reported in this instance. If the source is selected as **Other tissue source**, specify the other source in question 5.

**Questions 6 – 7: Cell Type**

Select from the list the cell type(s) tested in the gene therapy assay reported in this instance.

If a cell type that was analyzed that is not listed, select **Other cell type** and specify what cell type was analyzed in question 7.

**Questions 8 – 18: Gene Therapy Product Detection**

Based on the method reported in question 1, indicate if the gene therapy product was detected or not. If gene therapy product was detected, answer the according method with corresponding unit of measure.

If **Other** method was utilized that is not listed, please specify which method was used in Q17 and specify the specific unite of measure reported in Q18.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)