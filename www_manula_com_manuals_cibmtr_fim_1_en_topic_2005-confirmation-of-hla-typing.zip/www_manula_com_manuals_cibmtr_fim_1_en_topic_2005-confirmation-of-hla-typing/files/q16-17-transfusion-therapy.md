#### Questions 16 – 17: Were any red blood cell (RBC) transfusions administered?

Red blood cell (RBC) transfusions are often given as supportive care for recipients with thalassemia.

Indicate if any red blood cell transfusions were administered during the current reporting period. If **Yes**, report the date (YYYY-MM-DD) of the most recent RBC transfusion given in the reporting period. If the exact date is not known report an estimated date. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

If the recipient did not receive any RBC transfusions or no information is available to determine if the recipient received RBC transfusions in the current reporting period, select **No**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)