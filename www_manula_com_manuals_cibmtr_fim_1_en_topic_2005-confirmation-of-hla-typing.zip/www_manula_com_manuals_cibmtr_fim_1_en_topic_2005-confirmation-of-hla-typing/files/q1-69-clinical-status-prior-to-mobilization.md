This form is intended to capture the results of the Wechsler Preschool and Primary Scale of Intelligence (WPPSI-IV), Weschler Intelligence Scale for Children (WISC-V), or Wechsler Adult Intelligence Scale (WAIS-IV) neurocognitive assessment.

#### Question 1: Was the assessment administered in English?

Indicate **Yes** or **No** if the neurocognitive assessment was administered in English. If not documented select **Unknown**.

#### Questions 2: Was an interpreter used to administer the assessment?

When interpreting test results of the neurocognitive assessment, a strong understanding of the child’s language and communication competency is critical. Indicate if an interpreter was utilized to administer the neurocognitive assessment. If not documented, select **Unknown**.

#### Questions 3-69: Specify the Neurocognitive assessment edition and scores

The Wechsler Preschool and Primary Scale of Intelligence (WPPSI) is a widely used standardized intelligence test designed to assess young children’s cognitive abilities. The WPPSI is intended for children aged two years six months to seven years seven months, providing valuable insights into their intellectual functioning. The WPPSI measures cognitive abilities, including verbal comprehension, perceptual reasoning, working memory, and processing speed. These areas are assessed through a series of tasks and questions that are age-appropriate and engaging for young children. The test aims to evaluate a child’s intellectual potential, identifying their strengths and weaknesses in various cognitive domains.

The Wechsler Intelligence Scale for Children (WISC) is a test that measures a child’s cognitive abilities, including intelligence and problem-solving skills. The test is designed for children aged six to 16 years old and is often used to help identify children who may have learning or developmental difficulties. The WISC test consists of several subtests that assess a child’s verbal comprehension, perceptual reasoning, working memory, and processing speed. The results of these subtests are combined to produce an overall Intelligence Quotient (IQ) score.

The Wechsler Adults Intelligence Scale – Fourth Edition (WAIS-IV) is used to assess intellectual profile for people between 16 – 90 years old. It is composed of four scores and a general intelligence index. The four indexes are VCI, PRI, WMI and PSI. Every index is composed of two or three subtests that are required to obtain the total IQ score.

Specify the intelligence scale used and report the composite and the subtest scaled scores. See [Table 1](#404) below, Neurocognitive assessment and applicable composite and subtest scaled scores

**Composite scores:**

**Fluid Reasoning Index (FRI):**Measures both fluid and inductive reasoning skills, broad visual intelligence, simultaneous processing, conceptual thinking, and classification abilities in each student.**Full Scale Intelligence Quotient (FSIQ):**The score most representative of general intellectual functioning (g). The FSIQ is derived from a subset of the subtests that contribute to each primary index score available for a given age band.**General Ability Index (GAI):**Based only on the six subtests, it is intended to portray a snapshot of general intelligence that is less influenced by working memory and processing speed demands.**Perceptual Reasoning Index (PRI):**This index reflects an individual’s ability to accurately interpret, organize and think with visual information. It measures nonverbal reasoning skills and taps into thinking that is more fluid and requires visual perceptual abilities.**Processing Speed Index (PSI):**Assesses a student’s ability to quickly and correctly complete scanning and sequencing questions as well as discriminate amongst simple visual information as presented.**Verbal Comprehension Index (VCI):**Measures a student’s acquired knowledge, verbal reasoning and comprehension skills, and ability to pay attention to verbal stimuli as it is presented.**Visual Spatial Index (VSI):**Measures a student’s ability to attend to visual details, organize visual information, understand part-whole relationships, and simultaneously integrate visual and motor functions.**Working Memory Index (WMI):**Measures a student’s visual working memory, visual-spatial working memory and the child’s ability to resist proactive interference when using attention, concentration, mental control, and reasoning skills. A strong working memory is essential for other higher-order cognitive processes.

**Scaled scores:**


**Animal coding:**The child marks shapes that correspond to pictured animals.**Arithmetic:**This subtest consists of 22 timed arithmetic problems to be solved without the use of pencil and paper.**Block design:**Measures an individual’s ability to analyze and synthesize an abstract design and reproduce that design from colored plastic blocks. Spatial visualization and analysis, simultaneous processing, visual-motor coordination, dexterity, and nonverbal concept formation are involved. The students use logic and reasoning to successfully complete the items.**Bug search:**The child uses an ink dauber to mark the image of a bug in the search group that matches the target bug.**Cancellation:**The child scans two arrangements of objects and marks target objects.**Coding:**Children under eight years old mark rows of shapes with different lines according to a code, children over eight years old transcribe a digit-symbol code using a key. The task is time-limited.**Comprehension:**Is not just ordinary reading comprehension; this subtest measures the students’ common-sense social knowledge, practical judgment in social situations, and level of social maturation, along with the extent of development of their moral conscience.**Digit span:**Children listen to sequences of numbers orally and to repeat them as heard, in reverse order, and in ascending order.**Figure weights:**Children view a stimulus book that pictures shapes on a scale (or scales) with one empty side and select the choice that keeps the scale balanced.**Information:**Measures general cultural knowledge, long-term memory, and acquired facts. Here’s another subtest that challenges students to remember what has been taught previously in school.**Letter-number sequence:**Children are provided a series of numbers and letters and asked to provide them to the examiner in a predetermined order.- *Matrix reasoning The child looks at an incomplete matrix and selects the missing portion from 4 or 5 response options.
**Picture concepts:**Children are provided with a series of pictures presented in rows (either two or three rows) and asked to determine which pictures go together, one from each row.**Picture span:**Children view pictures in a stimulus book and select from options to indicate the pictures they saw, in order if possible.**Object assembly:**Measures an individual’s ability to analyze and synthesize an abstract design and reproduce that design from colored plastic blocks. Spatial visualization and analysis, simultaneous processing, visual-motor coordination, dexterity, and nonverbal concept formation are involved. The students use logic and reasoning to successfully complete the items.**Picture concepts:**The child is presented with two or three rows of pictures and chooses one picture from each row to form a group with a common characteristic.**Picture memory:**The child is presented with a stimulus page of one or more pictures for a specific time and then selects the picture from options on a response page.**Picture naming:**Assesses an individual’s ability to name pictorial stimuli. The student’s task is to separate essential and nonessential parts from the whole. It is necessary to observe each item closely and concentrate on picture detail. Students must name or indicate the missing part by saying the name of the part or by pointing to it.**Receptive vocabulary:**Measures an individual’s ability to identify correct responses to spoken words, for instance, at a picture that represents the word spoken by the examiner. Here’s one subtest in which prior word knowledge does play a role.**Similarities:**The child is read an incomplete sentence containing two concepts that share a common characteristic. The child is asked to complete the sentence by providing a response that reflects the shared characteristic.**Symbol search:**Children are given rows of symbols and target symbols, and asked to mark whether the target symbols appear in each row.**Visual puzzles:**Children view a puzzle in a stimulus book and choose from among pieces of which three could construct the puzzle**Vocabulary:**For Picture Items, the child names pictures that are displayed in a stimulus book. For Verbal Items, the child gives definitions for words that the examiner reads aloud.**Zoo locations:**The child views one or more animal cards placed on a zoo layout and then places each card in the previously displayed locations.

**Table 1. Neurocognitive assessment and applicable composite and subtest scaled scores.**


| Composite Scores | WIPPSI | WISC | WAIS-IV |
|---|---|---|---|
| Fluid Reasoning Index (FRI) | X | X | |
| Full Scale Intelligence Quotient (FSIQ) | X | X | X |
| General Ability Index (GAI) | X | ||
| Perceptual Reasoning Index (PRI) | X | ||
| Processing Speed Index (PSI) | X | X | X |
| Verbal Comprehension Index (VCI) | X | X | X |
| Visual Spatial Index (VSI) | X | X | |
| Working Memory Index (WMI) | X | X | X |
| Subtest scales scores | |||
| Animal coding | X | ||
| Arithmetic | X | X | |
| Block design | X | X | X |
| Bug search | X | ||
| Cancellation | X | X | X |
| Coding | X | X | |
| Comprehension | X | X | X |
| Digit span | X | X | |
| Figure weights | X | X | |
| Information | X | X | X |
| Letter- numbering sequencing | X | X | |
| Matrix reasoning | X | X | X |
| Object assembly | X | ||
| Picture completion | X | ||
| Picture concepts | X | X | |
| Picture memory | X | ||
| Picture naming | X | ||
| Picture span | X | ||
| Receptive vocabulary | X | ||
| Similarities | X | X | X |
| Symbol search | X | X | |
| Visual puzzles | X | X | |
| Vocabulary | X | X | X |
| Zoo locations | X |

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)