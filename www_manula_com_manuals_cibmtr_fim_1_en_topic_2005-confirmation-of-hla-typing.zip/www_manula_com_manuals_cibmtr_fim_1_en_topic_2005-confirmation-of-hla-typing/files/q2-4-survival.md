#### Question 2: Was the recipient admitted to the hospital post-infusion?

The practice of outpatient cellular therapy infusions is increasing however there might still be the need for admission for cellular therapy toxicities. In order to capture if patients require admission following cellular therapy a date of admission and discharge will be collected.

#### Question 3: Date of first hospital admission:

Report the first date (YYYY-MM-DD) the recipient was admitted to the hospital post-infusion.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 4: Date of first discharge:

Report the date (YYYY-MM-DD) of first discharge after the first hospital admission.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)