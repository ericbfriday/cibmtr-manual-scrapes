#### Question 15: Date complete blood count (CBC) sample drawn:

These questions are intended to determine the clinical status of the recipient prior to the start of lymphodepleting therapy for cellular therapy. Testing may be performed multiple times within the pre- infusion work-up time period; report the most recent CBC obtained. Laboratory values obtained on the first day of the lymphodepleting therapy may be reported as long as the blood was drawn before any lymphodepleting therapy was administered.

If no lymphodepleting therapy is given, report most recent CBC result prior to the infusion.

#### Questions 16-24: Complete blood count results available: (check all that apply)

For each cell type listed, checking the box will indicate a result is available. Provide the most recent laboratory values from the CBC on the date reported in the prior question.

**WBC:** The white blood cell count is a value that represents all of the white blood cells in the blood. If the count is too high or too low, the ability to fight infection may be impaired.

**Neutrophils:** Neutrophils are a subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage or an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage. Neutrophils are also known as polymorphonuclear leukocytes (PMNs).

**Lymphocytes:** Lymphocytes are another subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage of an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage.

**Hemoglobin:** Hemoglobin is a molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level.

**Hematocrit:** The hematocrit is the percentage (sometimes displayed as a proportion) of red blood cells relative to the total blood volume. A low hematocrit may require red blood cell transfusions or growth factors. Indicate if the recipient received a red blood cell transfusion within 30 days prior to obtaining the blood sample.

If a hematocrit value is reported, also indicate if the recipient received a red blood cell transfusion within 30 days prior to the date of the CBC reported in question 22.

**Platelets:** Platelets are formed elements within the blood that help with coagulation. A low platelet count, called thrombocytopenia, may lead to easy bleeding or bruising. Thrombocytopenia may require platelet transfusions. Indicate if the recipient received a platelet transfusion within 7 days prior to testing.

If a platelet value is reported, also indicate if the recipient received a platelet transfusion within 7 days prior to the date of the CBC reported in question 24.

#### Question 25: Did the recipient receive any growth factors <7 days before the start of systemic therapy?

Indicate if the recipient received any growth factor (e.g., GCS-F) within 7 days prior to the start of systemic therapy (i.e. lymphodepleting therapy). If no systemic therapy was given, indicate if the recipient received any growth factor (e.g., GCS-F) within 7 days prior to the infusion. In the event of a long acting growth factor (e.g., pegfilgrastim (Neulasta®), please answer this question as **Yes** if the recipient received it within 14 days prior.

#### Question 26-27: Total serum ferritin:

Ferritin is a protein that stores, transports, and release iron. Iron is toxic to cells, so it is stored within the ferritin protein for use. Ferritin that is too low might be indicative of iron deficiency related anemia. Ferritin that is too high might be indicative of iron overload. It is tracked for some diseases, such as hemophagocytic lymphohistiocytosis (HLH).

Date Sample Collected: Testing may be performed multiple times within the pre- infusion work-up time period; report the most recent total serum ferritin value obtained within 30 days of the start of lymphodepleting therapy. Laboratory values obtained on the first day of the lymphodepleting therapy may be reported as long as the blood was drawn before any lymphodepleting therapy was administered.

#### Question 28-31: C-reactive protein:

Testing may be performed multiple times within the pre- infusion work-up time period; report the most recent C-reactive protein value obtained within 30 days of the start of lymphodepleting therapy. Laboratory values obtained on the first day of the lymphodepleting therapy may be reported as long as the blood was drawn before any lymphodepleting therapy was administered.

Indicate whether the C-reactive protein result was **Known** or **Unknown** prior to the start of lymphodepleting therapy. If **Known**, report the date (MM-DD-YYYY) of the test, report the result and the unit of measure, and specify the upper limit of normal.

#### Question 32-33: Serum creatinine:

Creatinine is a normal metabolic waste that is primarily filtered from the blood by the kidneys and then excreted in the urine. Since it is generally produced at a constant rate, the clearance rate and the serum level are widely used as indicators of kidney function.

Testing may be performed multiple times within the pre- infusion work-up time period; report the most recent serum creatinine value obtained. Laboratory values obtained on the first day of the lymphodepleting therapy may be reported as long as the blood was drawn before any lymphodepleting therapy was administered.

Report the result and the unit of measure and report the date (MM-DD-YYYY) of the test.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)