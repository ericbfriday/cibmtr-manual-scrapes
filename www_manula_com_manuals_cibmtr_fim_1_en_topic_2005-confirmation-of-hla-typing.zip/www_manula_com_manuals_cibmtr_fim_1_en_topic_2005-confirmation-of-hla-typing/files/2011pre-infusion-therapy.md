The FormsNet3SM application allows questions 28-63 to be reported multiple times. Complete these questions for each line of therapy administered on or after the date of diagnosis of ALL and prior to the start of the preparative regimen (or prior to infusion if no preparative regimen was given). When submitting the paper version of the form for more than one line of therapy, copy the “Pre-HCT or Pre-Infusion Therapy” section and complete a copy of the section for each line of therapy administered.

A single line of therapy refers to any agents administered during the same time period with the same intent (induction, consolidation, etc.). If a recipient’s disease status changes resulting in a change to treatment, a new line of therapy should be reported. Additionally, if therapy is changed because a favorable disease response was not achieved, a new line of therapy should be reported.

#### Question 20-26: Was central nervous system prophylaxis given?

Central nervous system (CNS) prophylaxis may be administered as irradiation, chemotherapy, or other agents. Report therapy administered to the CNS as prophylaxis only if the recipient did not have any evidence of ALL in the CNS prior to the initiation of therapy. See the reporting scenarios below for further clarification.

If the recipient received CNS prophylaxis during the time frame indicated above, report “Yes” for question 20 and then report “Yes” for any prophylactic therapies included in questions 21-24 which were administered. If a prophylactic therapy was given, but is not included in questions 21-24, report “Yes” for question 25 and specify the therapy in question 26. If the recipient did not receive CNS prophylaxis during the time frame indicated above or it is not known whether CNS prophylaxis was given, report “No” or “Unknown” respectively for question 20 and go to question 27.

**CNS Prophylaxis Reporting Scenarios**

**A.** A recipient is diagnosed with ALL from a bone marrow biopsy. There is no indication of CNS disease involvement based on the available testing. Treatment is commenced with combination systemic chemotherapy followed by several doses of intrathecal chemotherapy. The recipient achieves a complete remission and proceeds to HCT.

**Question 20:** Report “Yes” to indicate CNS prophylaxis was given between diagnosis and HCT / cellular therapy.

**Questions 21-26:** Report “Yes” for intrathecal therapy and report “No” for all other questions.

**B.** A recipient is diagnosed with ALL from a bone marrow biopsy and a positive sample from their cerebrospinal fluid (CSF). Treatment is commenced with combination systemic chemotherapy and intrathecal therapy. The recipient achieves a morphologic complete remission. The CSF is tested and found to be negative and the patient commences consolidation therapy including several intrathecal treatments to prevent relapse in the CNS.

**Question 20:** Report “No” to indicate no CNS prophylaxis was given between diagnosis and HCT / cellular therapy. All intrathecal therapy was given after CNS involvement was discovered.

**Question 21-26:** These questions will be left blank.

#### Question 27: Was therapy given?

Indicate if the recipient received treatment for their primary disease between diagnosis and the start of the preparative regimen. This includes systemic chemotherapy, intrathecal therapy, radiation therapy, and cellular therapies. Do not report a prior HCT or any surgery in questions 27-49. If therapy was given to treat ALL during the time frame indicated above, report “Yes” and go to question 28. If reporting “No,” go to question 64.

#### Question 28: Purpose of therapy

The purpose of each line of therapy depends on the disease status at the time of administration. See below for general definitions of each option choice. Indicate the purpose of the line of therapy being reported and go to question 29.

**Induction:** The first line(s) of therapy given following diagnosis to achieve a complete remission (CR). If the first line of therapy (induction) fails to produce a CR, the recipient may undergo another cycle or a different line of therapy (re-induction) in order to achieve their first CR. Report “Induction” as the purpose for all lines of therapy given to achieve the first CR.

**Consolidation:** Once a recipient has achieved a hematologic CR (1st, 2nd, 3rd or greater), they may receive several additional lines of therapy as part of a protocol or to eliminate known minimal residual disease. In either case, report “Consolidation” as the purpose for these lines of therapy.

**Maintenance:** Following induction and consolidation, a recipient may receive low dose chemotherapy over an extended period of time to maintain a CR. Maintenance therapy is usually given as a single drug taken in the outpatient setting when the recipient has no known evidence of disease. Report “Maintenance” as the purpose for these lines of therapy.

**Treatment for disease relapse:** Once the recipient has achieved their first CR, their disease may relapse and require further treatment to produce another CR (2nd or greater). The intent is the same as induction, but setting is different as the recipient has already achieved at least one prior CR. Report “Treatment for disease relapse” as the purpose for all lines of therapy given to induce a CR following relapse.

#### Question 29: Intrathecal Therapy

Intrathecal therapy refers to chemotherapy administered via lumbar puncture to treat or prevent leukemic blasts in the central nervous system. Report “Yes” if intrathecal therapy was given as part of the line of therapy being reported. Report “No” if intrathecal therapy was not given as part of the line of therapy being reported.

#### Question 30: Systemic therapy

Systemic therapy is delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein / central line or given orally. Do not report intrathecal therapy as systemic therapy. If systemic therapy was administered as part of the line of therapy being reported, report “Yes” and continue with question 31. If not, report “No” and go to question 39.

#### Question 31-32: Date therapy started

Indicate whether the therapy start date is “Known” or “Unknown.” If the therapy start date is known, report the date the recipient began this line of therapy in question 32. If the start date is partially known (e.g., the recipient started in mid-July 2011), use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy started is “Unknown,” go to question 33.

#### Question 33-34: Date therapy stopped

Indicate if therapy stop date is “Known” or “Unknown.” If the therapy is being given in cycles, report the date the recipient started the last cycle for this line of therapy in question 34. Otherwise, report the final administration date for the therapy being reported. If the stop date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy stopped is “Unknown,” go to question 35.

#### Question 35-36: Number of cycles

Systemic therapy is usually administered in cycles with rest periods in-between. This enables cancer cells to be attacked at vulnerable times and provides healthy cells adequate time to recover from the damage sustained during therapy. A cycle can last one or more days and can repeat weekly, bi-weekly, or monthly. A single systemic therapy course may consist of multiple cycles.

Indicate whether the number of cycles is “Known” or “Unknown.” If “Known,” enter the number of cycles the recipient received in question 36. If “Unknown,” go to question 37.

If therapy is not being administered in cycles (e.g., daily chemotherapy), report “Unknown” for question 35 and go to question 37.

#### Question 37-38: Specify systemic therapy

Treatments vary based on protocol. A treatment may consist of a single drug or a combination of drugs. Additionally, the drugs may be administered on one day, over consecutive days, or continuously. If chemotherapy drugs were administered as part of the line of therapy, select the box for ‘chemotherapy’. You do not need to specify each drug. If the recipient received a systemic therapy which is not listed, select “Other systemic therapy” and specify the treatment in question 38. Report the generic name of the agent, not the name brand.

#### Question 39: Radiation therapy

Radiation therapy utilizes high-energy x-rays, gamma rays, electron beams, or proton beams to kill cancer cells. Radiation therapy may be used to kill cells that have invaded other tissues and lymph nodes. Radiation therapy may be given in conjunction with systemic chemotherapy or as a separate line of therapy.

If radiation therapy was given during or adjacent to administration of systemic therapy, report them together as single line of therapy on the form (i.e., one copy of questions 28-63). Otherwise, capture the radiation treatment as a separate line of therapy.

If the recipient received radiation therapy as part of the line of therapy being reported, report “Yes” and go to question 39. If not, report “No” and go to question 49.

#### Question 40-41: Date therapy started

Indicate whether the start date for radiation therapy is “Known” or “Unknown.” If “Known,” enter the date radiation therapy began in question 41. If the start date is partially known (e.g., the recipient started in mid-July 2011), use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy started is “Unknown,” go to question 42.

#### Question 42-43: Date therapy stopped

Indicate if the stop date for radiation therapy is “Known” or “Unknown.” If “Known,” enter the final date radiation was administered in question 43. If the stop date is partially known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy stopped is “Unknown,” go to question 44.

#### Question 44-48: Specify site(s) of radiation therapy

Report all sites of radiation therapy administered between the start and stop dates reported in questions 40-43. If “Yes” is reported for “Other site,” specify all other sites in question 48.

#### Question 49: Cellular Therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells).

Report “Yes” if the recipient received cellular therapy as part of the line of therapy being reported. For subsequent infusions, this includes any previous cell therapy infusion to treat disease already reported to the CIBMTR. If not, report “No.”

#### Question 50: Best response to line of therapy

Indicate the best response to the line of therapy using the international working group criteria provided in [ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria) section of the Forms Instructions Manual. The best response is determined by a disease assessment, such as hematologic testing, pathology study, and / or physician assessment.

#### Question 51: Date assessed

Report the date the best response to the line of therapy was established. This should be the earliest date all international working group criteria were met for the response reported in question 50. Enter the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear). If no pathologic, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically evaluated the recipient’s response.

If the best response was achieved prior to starting the line of therapy being reported, indicate the date of the first assessment which was performed after initiating the current line of therapy and confirms the sustained response.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 52: Was the recipient MRD negative following this line of therapy?

Minimal residual disease (MRD) can be assessed by different methods including, but not limited to, the following:


- Next generation sequencing
- Sanger sequencing
- Polymerase chain reaction (PCR) testing
- Chromosomal / genomic microarray analysis
- Fluorescence in situ hybridization (FISH)
- Karyotyping
- Flow cytometry

If any MRD testing was performed following the line of therapy being reported, answer question 52 based on the results of the testing performed within 30 days after the date therapy was stopped and prior to any new therapy being initiated. If any MRD testing during this timeframe was positive for markers of ALL, report “No” for question 52. If all MRD testing during this time frame was negative for markers of ALL, report “Yes” for question 52. If the recipient was MRD negative prior to therapy completion and not retested after therapy ended, report “Yes” for question 52.

If no MRD testing was performed during this timeframe, leave question 52 blank and override the error in FormsNetSM using the code “Unknown.”

#### Question 53: Did the recipient relapse following this line of therapy?

Refer to the international working group criteria provided in [ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria) section of the Forms Instructions Manual for more information on how to determine recurrence of disease. Report “Yes” if the recipient met the criteria for relapse after starting this line of therapy and prior to starting a subsequent line of therapy. If “Yes” is reported, also completed questions 54-63.

Report “No” if the recipient never relapsed following this line of therapy. Also, report “No” if the recipient relapsed *after* beginning a subsequent line of therapy. This episode of relapse will be captured in the instance (i.e., copy) of questions 28-63 completed for the subsequent line of therapy. If “No” is reported, go to question 64.

If this is the last line of therapy administered prior to infusion, only report “Yes” if relapse occurred prior to infusion. Relapse occurring after the infusion date will be reported on the ALL Post-Infusion Data Form (Form 2111).

#### Question 54: Date of relapse

Enter the assessment date relapse was established following initiation of this line of therapy. Report the date of the pathologic evaluation (e.g., bone marrow) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathologic and laboratory evaluations. If extranodal disease is detected upon radiographic examination (e.g., X-rays, CT scans, MRI scans, PET scans), enter the date the imaging took place. If the physician determines evidence of relapse following a clinical assessment during an office visit, report the date of assessment.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 55-63: Sites of Relapse

Report all known sites of active disease at the time of relapse in questions 55-63. This includes any sites identified between the date of relapse reported in question 54 and the time treatment for relapse is initiated. If “Yes” has been reported for “Other site” in question 62, use question 63 to specify all sites of active disease not already reported in questions 55-61. If relapse was detected via bone marrow and / or peripheral blood, report “Yes” for question 62 and specify these sites in question 63.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q28 | 4/2/2024 | Add | Purpose of Therapy for Bridging Therapy blue box added above Q28: Purpose of Therapy for Bridging TherapyFor recipients who receive bridging therapy, report this lines of therapy as Consolidation or Treatment for relapsed disease. If the recipient didn’t relapse, report the intent as Consolidation, otherwise, report the intent as Treatment for disease relapse. |
Added for clarification |
| Q49 | 6/28/2023 | Add | The Reporting Prior Cellular Therapy as a Line of Therapy blue information box added: As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form |
Due to change in FormsNet3 validation |
| Q49 | 10/17/2022 | Add | Instructions updated for clarification: Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells). Report “Yes” if the recipient received cellular therapy as part of the line of therapy being reported. For subsequent infusions, this includes any previous cell therapy infusion to treat disease already reported to the CIBMTR. If not, report “No.” |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)