Indicate which of the following clinical features and laboratory findings were present on the **most recent evaluation since the date of the last report.** For values assessed multiple times since the date of the last report, report the most recent results.

#### Question 1: Anemia (Hgb < 9 g/dL):

Indicate if the recipient had anemia on the most recent evaluation since the date of the last report. Anemia is defined as hemoglobin less than 9 g/dL. Select “yes,” “no,” or “unknown.”

#### Question 2: Degranulation assay of NK cells:

Degranulation in natural killer (NK) cells is the process by which NK cells release granules containing chemicals (perforin and granzymes) that are used to destroy targeted cells. In some subtypes of FHL (FHL3, 4, and 5), degranulation of NK cells is absent or abnormally low. A granule release assay (GRA) can be used to assess the degranulation indirectly by measuring the expression of CD107a on the cell surface following stimulation. This expression is only detectable when the granules fuse with the cell membrane, thus the absence of CD107a by GRA would indicate a defect in some part of NK degranulation. Indicate if the degranulation assay of NK cells was “normal,” “abnormal,” or “unknown” on the most recent evaluation since the date of the last report.

#### Question 3: Fever:

Indicate if the recipient had fever on the most recent evaluation since the date of the last report. Fever is defined as a temperature above 38.5° C (>101.3° F) for more than 7 days. Select “yes,” “no,” or “unknown.”

#### Question 4: Hepatomegaly (liver edge palpable > 3 cm below right costal margin)

Indicate if the recipient had hepatomegaly (enlargement of the liver) on the most recent evaluation since the date of the last report. Hepatomegaly is defined by the palpability of the liver edge 3 cm or more below the right costal margin. Indicate “yes,” “no,” or “unknown.”

#### Questions 5-6: Serum ferritin:

Indicate if the serum ferritin level was tested since the date of the last report. If “known,” indicate the most recent value in question 6. If “unknown,” continue with question 7.

#### Questions 7-8: Triglycerides:

Indicate if the triglyceride level was tested since the date of the last report. If “known,” indicate the most recent value in question 8. If “unknown,” continue with question 9.

#### Questions 9-10: Fibrinogen antigen assay (factor I; fibrinogen activity; functional fibrinogen; fibrinogen antigen):

Fibrinogen levels may be low in patients with HLH. Indicate if a fibrinogen antigen assay (factor 1; fibrinogen activity; functional fibrinogen; fibrinogen antigen) level was tested since the date of the last report. If “known,” indicate the most recent value (and corresponding unit) in question 10. If “unknown,” continue with question 11.

#### Question 11: NK cell function:

NK cell function is measured by a cytotoxicity assay.

NK cell function may be absent or reduced in those with HLH. Indicate the NK cell function on the most recent evaluation since the date of the last report; select “absent (≤ 10% lower limit of normal),” “decreased (11-50% lower limit of normal),” “normal,” or “unknown.”

#### Question 12: Neutropenia (ANC < 1.0 × 109/L):

Indicate if the recipient was neutropenic on the most recent evaluation since the date of the last report. Neutropenia is defined as an absolute neutrophil count (ANC) less than 1.0 × 109/L. Indicate “yes,” “no,” or “unknown.”

#### Question 13: Soluble interleukin-2 receptor alpha chain (sCD25): (As defined by local laboratory)

Indicate the soluble interleukin-2 receptor alpha chain (soluble IL-2R, sCD25) level on the most recent evaluation since the date of the last report. The results of the test should be reported as defined by the local laboratory. Indicate if the soluble IL-2R alpha chain level was “normal,” “elevated,” or “unknown.”

#### Question 14: Splenomegaly (spleen palpable > 3 cm below left costal margin):

Indicate if the recipient had splenomegaly (enlargement of the spleen) on the most recent evaluation since the date of the last report. Splenomegaly is defined by the palpability of the spleen edge 3 cm or more below the left costal margin. Indicate “yes,” “no,” or “unknown.”

#### Question 15: Thrombocytopenia (platelets < 100 × 109/L):

Indicate if the recipient was thrombocytopenic on the most recent evaluation since the date of the last report. Thrombocytopenia is defined as a platelet count less than 100 × 109/L. Indicate “yes,” “no,” or “unknown.”

#### Question 16: Neopterin level:

The measurement of neopterin in the cerebrospinal fluid (CSF) is useful to determine immune system activity. Indicate the neopterin level in the CSF on the most recent evaluation since the date of the last report. Indicate “normal” or “elevated.” “Elevated” indicates levels above the upper limit of normal for the laboratory processing the specimen. If an assessment of neopterin levels in the CSF was not done since the date of the last report, select “not done.”

#### Question 17: Protein:

Indicate the protein level in the cerebrospinal fluid (CSF) on the most recent evaluation since the date of the last report. Indicate “normal” or “elevated.” “Elevated” indicates levels above the upper limit of normal for the laboratory processing the specimen. If an assessment of protein levels in the CSF was not done since the date of the last report, select “not done.”

#### Question 18: WBC count:

Indicate the WBC count in the cerebrospinal fluid (CSF) on the most recent evaluation since the date of the last report. Indicate “normal” if there were less than or equal to 5 cells/μL in the CSF. Indicate “elevated” if there were greater than 5 cells/μL in the CSF. If an assessment of WBC count in the CSF was not done since the date of last report, select “not done.”

#### Question 19: Were central nervous system (CNS) abnormalities found on a computed tomography (CT or CAT) or magnetic resonance imaging (MRI) scan since the date of the last report?

Indicate if radiology (CT, CAT, and/or MRI) performed on the recipient since the date of the last report detected any abnormalities in the CNS. CNS abnormalities may include lesions, leptomeningeal enhancements, or edema.

If CNS abnormalities were detected on the radiological examination at the most recent evaluation since the date of the last report, select “yes” and continue with question 20. If no CNS abnormalities were detected on the radiological examination, select “no” and continue with question 21. If it is unknown if abnormalities were present or if no CT/CAT/MRIs were performed, select “unknown” and continue with question 21.

#### Question 20: Was documentation submitted to the CIBMTR?

Indicate if a copy of the CNS radiography results is attached. Use the Log of Appended Documents (Form 2800) to attach a copy. Attaching a copy of the report may prevent additional queries.

#### Question 21: Did any clinical neurologic abnormalities persist or develop?

Based on a clinical neurologic assessment, indicate if there were any clinical neurological abnormalities that persisted or developed since the date of the last report. Neurologic abnormalities include abnormal gait, cranial nerve palsies, developmental delay, motor weakness, seizures, and sensory deficits. If clinical neurological abnormalities were present on the most recent evaluation since the date of the last report, select “yes” and continue with question 22. If no clinical neurologic abnormalities were present, select “no” and continue with question 30. If it is unknown if a clinical neurological exam was performed or if the results of the exam are not known, select “unknown” and continue with question 30.

#### Questions 22-29: Specify neurologic abnormalities:

Indicate the clinical neurologic abnormalities identified since the date of last report. Select “yes” or “no” for each question, ensuring that no question is left blank. If a neurological abnormality is not listed but was present, select “yes” for question 28 (“Other neurologic abnormality”) and use question 29 to specify the abnormality.

#### Question 30: Were there any signs of disease relapse/reactivation?

Indicate if there were any signs of new or recurrent disease since the date of the last report. These signs may be present in the central nervous system and detected on radiology (CT/MRI) or clinical neurologic exam, **or** based on systemic disease assessments. If there were any signs of disease relapse or reactivation since the date of the last report, select “yes” and continue with question 31. If there was no evidence of disease relapse or reactivation since the date of the last report, select “no” and continue with the signature lines.

#### Question 31: Specify the date of the relapse/reactivation:

Indicate the date that relapse or reactivation was detected. Use the date of the radiological exam, the date of the clinical neurologic exam, or the date the sample was collected for systemic disease assessment when relapse/reactive was determined.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 32: Specify the site of the relapse/reactivation:

Indicate if the site of relapse or reactivation was CNS, systemic, or CNS and systemic. CNS disease is limited to findings in the central nervous system by radiology (CT or MRI) or features specific to the CNS in the clinical neurologic exam. Systemic disease includes findings in the blood counts, triglycerides, ferritin, fibrinogen, and/or hepatosplenomegaly evaluations.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)