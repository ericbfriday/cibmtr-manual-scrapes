The Solid Tumor Pre-Infusion (2059) Form is one of the Comprehensive Report Forms. This form captures Solid Tumor-specific pre-infusion data such as: disease assessment at diagnosis, initial therapy, last line of therapy prior to collection, bridging therapy prior to infusion, total cumulative exposure to systemic therapy / radiation therapy, and disease assessments at last evaluation.

The Solid Tumor Pre-Infusion (2059) Form must be completed for cell therapy recipients when the indication is to treat solid tumors and the sub-type is Bone sarcoma (excluding Ewing family tumors) (273), Myxoid round cell sarcoma (2217), or Synovial sarcoma (245). This form will be completed with the Solid Tumor Response (3507) Form.

Links to Sections of Form:

[Q1: Subsequent Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-subsequent-infusion-stu)

[Q2-26: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-26-disease-assessment-at-diagnosis)

[Q27-31: Initial Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q27-31-initial-therapy)

[Q32-42: Last Line of Therapy Prior to Collection](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q32-42-last-line-of-therapy-prior-to-collection)

[Q43-52: Bridging Therapy Prior to Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q43-52-bridging-therapy-prior-to-infusion)

[Q53-77: Total Cumulative Exposure to Systemic Therapy / Radiation Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q53-77-total-cumulative-exposure-to-systemic-therapy-radiation-therapy)

[Q78-102: Disease Assessments at Last Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q78-102-disease-assessments-at-last-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)