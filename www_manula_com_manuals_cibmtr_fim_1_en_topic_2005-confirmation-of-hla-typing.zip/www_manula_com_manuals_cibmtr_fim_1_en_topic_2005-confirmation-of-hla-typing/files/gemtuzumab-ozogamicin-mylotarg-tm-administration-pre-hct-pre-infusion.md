#### Question 1: Purpose of therapy

Indicate purpose of therapy:


- Induction (frontline)
- Consolidation/intensification after achieving first CR/Cri
- Maintenance/ continuation after achieving first CR/Cri
- Reinduction after fist disease relapse or later relapse
- Consolidation/intensification after disease relapse, after achieving second or later CR/CRi
- Maintenance/continuation after disease relapse, after achieving second or later CR/Cri
- Other (Go to question 2. If not, proceed to question 3.)

#### Question 2: Specify Other

Specify other purpose of therapy.

#### Question 3-4: Date line of therapy started

Indicate known or unknown. If known, report the date (YYYY-MM-DD) when therapy was started in Question 4.

#### Question 5-6: Date line of therapy stopped

Indicate known or unknown. If known, report the date (YYYY-MM-DD) when therapy was stopped in Question 5.

#### Question 7: Was Mylotarg™ given with combination chemotherapy as part of this line of therapy?

Indicate yes or no. If yes, move to Question 8. If no, move to question 10.

#### Question 8: Specify systemic therapy.

Check all therapies that apply to this line of therapy. If other, check “other systemic therapy” and move to question 9.

#### Question 9: Specify other therapy.

Indicate therapy that was used in combination with Mylotarg™ that was not listed.

#### Question 10: Height used for Mylotarg™ dose.

Indicate height used for dosage and check unit of measurement (inches or centimeters).

#### Question 11: Body weight used for Mylotarg™ use.

Indicate weight used for dosage and check unit of measurement (pounds or kilograms).

#### Questions 12: Specify the number of instances Mylotarg™ was administered as a part of this line of therapy.

Indicate the number of instances Mylotarg™ was used. CIBMTR also recommends to attach the medication administration record.

#### Questions 13-32: Instance.

Specify date dose administered (YYYY-MM-DD) for each instance. Specify dose administered (mg/mg 2) for each instance.

#### Question 33: Total Mylotarg™ dose given as part of this line of therapy

Indicate known or unknown. If known, go to question 34. If unknown, skip to question 35.

#### Question 34: Mylotarg™ dose

Indicate Mylotarg™ dose given as part of this line of therapy in mg/m 2.

#### Question 35: Best response to line of therapy

Indicate best response to line of therapy:


- Complete remission (CR): ALL of the following criteria without progression for at least four weeks: <5% blasts in the bone marrow, no blasts with Auer rods, no extramedullary disease, ANC of > 1,000/uL, platelets >1000,000/uL
- Complete remission with incomplete hematologic recovery (Cri): All CR criteria except for neutropenia (<1,000/uL) and/or thrombocytopenia (<100,000/uL)
- No complete remission

#### Question 36: Date Assessed

Indicate date of assessment (YYYY-MM-DD).

Repeat questions 1-36 for each line of therapy and submit the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)