# Q188-254:Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion

For questions 188 – 254, report values obtained at the last evaluation prior to the start of the preparative regimen / infusion. If testing is performed multiple times prior to the start of the preparative regimen, report the last test before the start of the preparative regimen.

#### Questions 188 – 189: Serum β2 microglobulin

An elevated serum β2 microglobulin protein at the last evaluation prior to the start of the preparative regimen may indicate a poorer prognosis. If this value is **Known**, report the value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 190.

#### Questions 190 – 191: Plasma cells in blood by flow cytometry

Indicate if the value of plasma cells in the blood was assessed by flow cytometry at the last evaluation prior to the start of the preparative regimen. Report if the value of plasma cells were **Known** or **Unknown**. If **Known**, report the percentage of plasma cells detected in the blood by flow cytometry at the last evaluation prior to the start of the preparative regimen / infusion.

If **Unknown**, continue with question 192.

#### Question 192 – 194: Plasma cells in blood by morphologic assessment

Indicate if plasma cells in the peripheral blood by morphologic assessment was **Known** or **Unknown** at the time of diagnosis. If **Known**, report the percentage of plasma cells detected in the blood by morphologic assessment and / or the absolute number as documented on the laboratory report.

If a differential was performed and the percentage of plasma cells are not listed, report **Known** and specify the plasma cell percentage as “0”.

If only the percentage of plasma cells is available, the absolute number of plasma cells can be determined by multiplying the percentage of plasma cells by the white blood count (WBC).

#### Questions 195 – 196: Serum albumin

Indicate whether the serum albumin at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. If **Known**, report the value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 197.

#### Questions 197 – 198: Serum monoclonal protein (M-spike) (only from electrophoresis)

Monoclonal gammopathy is defined as the increased production of abnormal immunoglobulins. The abnormal protein produced is called paraprotein or M-protein. Indicate whether the quantity serum monoclonal immunoglobulin at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. If **Known**, report the value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 199. Report **Not applicable** for recipients with non-secretory myeloma and continue with question 199.

#### Question 199: Serum immunofixation

Serum immunofixation is a laboratory technique that detects and types monoclonal antibodies or immunoglobulins in the blood. If **Known**, continue with question 200. If **Unknown** or **Not applicable**, continue with question 202. Report **Not applicable** for recipients with non-secretory myeloma.

#### Question 200: Original monoclonal bands

Indicate **Yes** if the original monoclonal band was present or **No** if it was not present.

#### Question 201: New monoclonal (or oligoclonal) bands

Indicate **Yes** if a new monoclonal band (or oligoclonal) was present or **No** if it was not present.

#### Questions 202 – 204: Serum free light chains – κ (kappa)

Indicate whether the serum κ (kappa) free light chain level at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. This value should reflect the quantity of serum free light chains, not a quantification of total light chains.

If **Known**, report the value, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 205. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 205 – 207: Serum free light chains – λ (lambda)

Indicate whether the serum λ (lambda) free light chain level at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. This value should reflect the quantity of serum free light chains, not a quantification of total light chains.

If **Known**, report the value, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 208. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 208 – 209: Urinary monoclonal protein (M-spike) / 24 hours

Indicate whether the amount of urinary monoclonal protein at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 210. Report **Not applicable** for recipients with non-secretory myeloma. Do not report immunofixation results here.

**Example:**

(total in g/dL of monoclonal protein) x (total urine volume) = **urinary M-protein/24 hours**

(0.145 g/dL of monoclonal protein) x (1500 mL total urine) x (1 dL/100 mL)= **2.175 g/24 hours**

#### Question 210: Urinary immunofixation

Urine immunofixation is a laboratory technique that detects and types monoclonal antibodies or immunoglobulins in the urine. Indicate if the results of urinary immunofixation at the last evaluation prior to the start of the preparative regimen are **Known** or **Unknown**. If **Unknown** or **Not applicable**, continue with question 213. Report **Not applicable** for recipients with non-secretory myeloma.

#### Question 211: Original monoclonal bands

Indicate **Yes** if the original monoclonal band was present or **No** if it was not present.

#### Question 212: New monoclonal (or oligoclonal) bands

Indicate **Yes** if a new monoclonal (or oligoclonal) band was present or **No** if it was not present.

#### Questions 213 – 214: Total urine protein in 24 hours

Indicate whether the amount of urinary protein at the last evaluation prior to the start of the preparative regimen was **Known** or **Unknown**. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 215. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 215 – 216: Urine albumin / creatinine ratio

Indicate whether the urinary albumin / creatinine ratio was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 217. This question is only required if the primary disease (question 1) is MGRS or Amyloidosis or if there is evidence / history of (question 2) MGRS or Amyloidosis.

#### Questions 217 – 218: Urine protein / creatinine ratio

Indicate whether the urinary protein / creatinine ratio was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 219. This question is only required if the primary disease (question 1) is MGRS or Amyloidosis or if there is evidence / history of (question 2) MGRS or Amyloidosis.

#### Question 219: Was minimal residual disease (MRD) assessed during the pre-HCT or pre-infusion evaluation? (report only bone marrow or blood results)

Minimal residual disease (MRD), is an indicator of increased risk for disease relapse and / or progression. MRD can be assessed by different methods including, but not limited to, next generation sequencing (NGS), Sanger sequencing, polymerase chain reaction (PCR) testing, chromosomal / genomic microarray analysis, fluorescence in situ hybridization (FISH), karyotyping, or flow cytometry.

Indicate if MRD was performed by next generation sequencing (NGS) or next generation flow (NGF) at the last evaluation prior to the start of the preparative regimen.

If any MRD testing was performed for patients with myeloma, answer question 219 as **Yes**. If no MRD testing methods were performed or it is not known if performed, report **No** or **Unknown** and continue with question 228.

#### Questions 220 – 221: Next generation sequencing (NGS)

Indicate whether the MRD result at the last evaluation prior to the start of the preparative regimen is **Positive**, **Negative**, or **Not done** by NGS testing. If **Positive**, report the sample source (**Blood** or **Bone marrow**). If **Negative** or **Not done**, continue with question 224.

#### Questions 222 – 223: Indicate the sensitivity of the next generation sequencing (NGS) testing

Indicate the testing sensitivity of the NGS testing performed at the last evaluation prior to the start of the preparative regimen. If the specificity is not listed in this section, report **Other** and specify the sensitivity as documented on the laboratory report in question 223.

#### Questions 224 – 225: Next generation flow (NGF)

Indicate whether the MRD result at the last evaluation prior to the start of the preparative regimen is **Positive**, **Negative**, or **Not done** by NGF testing. If **Positive**, report the sample source (**Blood** or **Bone marrow**). If **Negative** or **Not done**, continue with question 228.

#### Questions 226 – 227: Indicate the sensitivity of the next generation flow (NGF) testing

Indicate the testing sensitivity of the NGF testing performed at the last evaluation prior to the start of the preparative regimen.

NGF testing is used to identify minimal residual disease (MRD) in patients with multiple myeloma. Some NGF reports include a “level of detection” rather than a “level of sensitivity.” In these cases, the “level of sensitivity” can be derived from the level of detection. Please refer to the report and example below for further instruction.


**Example:**


- Level of Detection: 0.001
*is equal to:* - Level of Sensitivity: 10
-5(1/100,000 cells)*and should be reported in question 227)*

If the specificity is not listed in this section, report **Other** and specify the sensitivity as documented on the laboratory report in question 228.

#### Questions 228 – 229: Plasma cells in bone marrow aspirate by flow cytometry

Indicate whether the percentage of plasma cells in the bone marrow aspirate assessed by flow cytometry at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 230.

#### Questions 230 – 231: Plasma cells in bone marrow aspirate by morphologic assessment

Indicate whether the percentage of plasma cells in the bone marrow aspirate was **Known** or **Unknown** by morphologic assessment at the last evaluation prior to the start of the preparative regimen. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 232.

#### Questions 232 – 233: Plasma cells in bone marrow biopsy

Indicate whether the percentage of plasma cells in the bone marrow biopsy at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. If **Known**, report the percentage of plasma cells in the bone marrow biopsy. If **Unknown**, continue with question 234.

#### Question 234: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality which reflects the recipient’s disease. Testing methods you may see include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells.

Indicate **Yes** or **No** whether cytogenetic studies were tested at the last evaluation prior to the start of the preparative regimen. If cytogenetic studies were obtained, check **Yes**. If cytogenetic studies were not obtained, or it is unknown whether chromosome studies were performed, indicate **No** or **Unknown** respectively and go to question 247.

#### Question 235: Were cytogenetics tested via FISH?

FISH, fluorescence *in situ* hybridization, is a sensitive technique that assesses a large number of cells. This technique utilizes special probes that recognize and bind to fragments of DNA commonly found in plasma cell disorders. These probes are mixed with cells from the recipient’s blood. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells.

Indicate **Yes** or **No** if FISH studies were obtained at the last evaluation prior to the start of the preparative regimen.

If no FISH studies were obtained or it is unknown if FISH studies were performed, select **No** or **Unknown** and continue with question 241.

#### Question 236: Results of test

Indicate if FISH studies identified abnormalities. If there were no abnormalities identified, select **No abnormalities** and continue with question 240.

#### Questions 237 – 239: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable.

Specify each abnormality detected by FISH at the last evaluation prior to the start of the preparative regimen.

If a clonal abnormality is detected, but not listed as an option in question 238, select **Other abnormality**”and specify the abnormality. If multiple *other abnormalities* were detected, report “see attachment” in question 239 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 240: Was documentation submitted to the CIBMTR (e.g., FISH report)?

Indicate if a FISH testing report is attached to support the cytogenetic findings reported. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 241: Were cytogenetics tested via karyotyping?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality that reflects the recipient’s disease. Cytogenetics may also be referred to as karyotyping or g-banding.

Indicate **Yes** or **No** if cytogenetic studies were obtained by karyotyping at the last evaluation prior to the start of the preparative regimen. If karyotyping studies were not obtained, select **No** and continue with question 247.

#### Question 242: Results of test

Indicate if karyotyping studies identified abnormalities. If karyotyping studies yielded no evaluable metaphases or there were no abnormalities identified, select **No evaluable metaphases** or **No abnormalities**, respectively, and continue with question 246.

#### Questions 243 – 245: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable.

Specify each abnormality detected by karyotyping at the last evaluation prior to the start of the preparative regimen.

If a clonal abnormality is detected, but not listed as an option in question 244, select *Other abnormality*and specify the abnormality in question 244. If multiple *other abnormalities* were detected, report “see attachment” in question 245 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 246: Was documentation submitted to the CIBMTR (e.g., karyotyping report)?

Indicate if a karyotyping report is attached to support the cytogenetic findings reported. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 247: Did the recipient receive dialysis?

Indicate if the recipient received dialysis prior to the start of the preparative regimen. If the recipient was on dialysis at any point within approximately 30 days prior to the start of the preparative regimen, report **Yes**. If the recipient did not receive dialysis within approximately 30 days prior to the start of the preparative regimen, report **No** and continue with question 250.

#### Questions 248 – 249: Date of dialysis:

Indicate if the date the recipient received dialysis was **Known** or **Unknown**. If **Known**, report the date that dialysis began. If **Unknown**, continue with question 250.

#### Question 250: Was a PET / CT scan performed?

A PET / CT combines the results of the PET (Positron Emission Tomography) scan along with the results of a CT (Computed Tomography) scan. If a PET / CT scan was performed at the last evaluation prior to the start of the preparative regimen, indicate **Yes**. If a PET / CT scan was not performed, select **No** and continue with question 255.

#### Questions 251 – 252: Was the PET / CT scan positive for myeloma involvement at any disease site?

Indicate if the PET / CT scan was positive for myeloma involvement at any disease site. If positive at any site, report **Yes** and specify which area(s) show involvement (check all that apply). If negative, report **No** and continue with question 253.

#### Questions 253 – 254: Date of PET / CT scan

Indicate if the date of the PET / CT scan was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen. If **Known**, report the assessment date. If **Unknown**, continue with question 255.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)