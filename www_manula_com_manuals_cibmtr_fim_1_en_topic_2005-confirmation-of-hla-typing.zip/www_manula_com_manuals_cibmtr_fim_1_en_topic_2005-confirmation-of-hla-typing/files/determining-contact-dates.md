### Contact Dates

Contact dates are dates collected on all post-infusion TED, CRF, and cellular therapy (CTED) forms. Contact dates are important as they determine the reporting window for each reporting period and ensure there are no gaps in time for post-infusion follow-up. The contact date data field cannot be left blank and is required to be reported.

### Determining Contact Dates

The contact date should represent a date where there was actual contact with the recipient to determine the medical status for the current reporting period, based on a medical evaluation conducted by a clinician with the responsibility for the recipient’s care. Acceptable evaluations include those from the transplant center, referring physician, or other physician currently assuming responsibility for the recipient’s care. When possible, report a clinician evaluation that falls within the appropriate range, rather than other types of recipient contact that may be closer to the actual time point. In the absence of contact with a clinician, other contact, such as a documented phone call with the recipient or any other documented recipient interaction, may be used to establish the contact date.

In general, the date of contact should be reported as close to the 100-day, 6 month, or annual anniversary of infusion as possible. If an evaluation was not performed at Day+100, at 6 months, or on the infusion anniversary, choose the date of the visit closest to the actual time point. Time windows are provided below to guide selection of dates for reporting purposes. In scenarios where the recipient was not seen within the time windows used for reporting contact dates, some discretion is required when determining which date to report. If the recipient is not seen within the time window, report the date closest to the date of contact within reason (review example 1 and 2 for more information).

| Time Point | Approximate Range |
|---|---|
| 100 Days | + / – 15 days (Day 85 – 115) |
| 6 Months | + / – 30 days (Day 150 – 210) |
| 1 Year | + 60 days (Day 366 – 425) |
| Annual Reporting 2+ Years | + / – 30 days (Months 23 – 25, 35 – 37, etc.) |

If the recipient is alive but has not been seen by a clinician during the entire reporting period but the survival status is known, complete the [Survival Tool](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/survival-form-status?q=survival+tool) referenced in the CIBMTR Data Management Guide.

The following examples assume efforts were undertaken to retrieve outside medical records for the primary care provider, but no documentation was received.

**Example 1**:*The 100-day date of contact doesn’t fall within the ideal approximate range.*- The autologous recipient was transplanted on 1/1/2013 and is seen regularly until 3/1/2013. After that, the recipient was referred home and not seen again until 7/1/2013 for a restaging exam and 7/5/2013 for a meeting to discuss the results.
- Report the Day 100 contact date as 3/1/2013 as there was no contact closer to the ideal date of 4/11/2013 and the six-month contact date as 7/5/2013. The Day 100 form cannot be made lost to follow.


- The autologous recipient was transplanted on 1/1/2013 and is seen regularly until 3/1/2013. After that, the recipient was referred home and not seen again until 7/1/2013 for a restaging exam and 7/5/2013 for a meeting to discuss the results.
**Example 2**:*The 100-day date of contact doesn’t fall within the ideal approximate range and the recipient wasn’t seen again until one-year post-HCT.*- The autologous recipient was transplanted on 1/1/12 and is seen regularly until 3/1/2012. After that, the recipient was referred home and not seen again until 1/1/2013 for a restaging exam and 1/4/2013 for a meeting to discuss the results.
- Report the Day 100 contact date as 3/1/2012 as there was no contact closer to the ideal date of 4/11/2012. Report the six-month form as Lost to Follow-Up in FormNet3
SMand report the one-year contact date as 1/4/2013.

- Report the Day 100 contact date as 3/1/2012 as there was no contact closer to the ideal date of 4/11/2012. Report the six-month form as Lost to Follow-Up in FormNet3

- The autologous recipient was transplanted on 1/1/12 and is seen regularly until 3/1/2012. After that, the recipient was referred home and not seen again until 1/1/2013 for a restaging exam and 1/4/2013 for a meeting to discuss the results.

### Reminders

A date of contact should never be used multiple times for the same recipient’s forms.

**Example 3**: 6/1/2013 should not be reported for both the six-month and one-year forms. Instead, determine the best possible date of contact for each reporting period; if there is not a suitable date of contact for a reporting period, this may indicate that the recipient was lost to follow-up.

If the recipient has a disease evaluation just after the ideal date of contact, capturing that data on the form may be beneficial.

**Example 4**: if the recipient’s 90-day restaging exam was delayed until day 115 and the physician had contact with the recipient on day 117, the restaging exams can be reported as the latest disease assessment and day 117 would be the ideal date of contact, even though it is just slightly after the ideal approximate range for the date of contact.

### One Year Contact Date for Post-TED (2450) and Post-Infusion Follow-Up (2100)

**Example 5**:*A recipient is evaluated before and after Day 365*- The recipient had an allogeneic transplant on 1/5/2013 and is seen regularly until 6/20/2013. After that, the recipient was referred home and not seen again until 1/1/14 for a restaging exam and again on 1/15/2014 to review the results. Day 365 is 1/5/2014.
- Report the one-year contact date as 1/15/2014 since this date is > Day 365.


- The recipient had an allogeneic transplant on 1/5/2013 and is seen regularly until 6/20/2013. After that, the recipient was referred home and not seen again until 1/1/14 for a restaging exam and again on 1/15/2014 to review the results. Day 365 is 1/5/2014.
**Example 6**:*A recipient is evaluated before and after Day 365*- The recipient is transplanted on 2/28/2019 and seen regularly until 8/28/2019. The next visit is on 2/20/2020 for blood work and the lab results are phoned to the recipient on 2/21/2020. The recipient was not evaluated again until 4/1/2020. Day 365 is 2/28/2020.
- Report the one-year contact date as 4/1/2020 since this date is > Day 365.


- The recipient is transplanted on 2/28/2019 and seen regularly until 8/28/2019. The next visit is on 2/20/2020 for blood work and the lab results are phoned to the recipient on 2/21/2020. The recipient was not evaluated again until 4/1/2020. Day 365 is 2/28/2020.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)