This form must be completed for all recipients of cellular therapy (non-HCT), including post-HCT DCI infusions selected for CRF level reporting. It will be completed in conjunction with the Cellular Therapy Essential Data Follow-Up (4100) form. For more information on TED and CRF level reporting, [click here](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/).

For recipients of hematopoietic cellular transplants, complete the appropriate HCT follow-up form. For recipients of Donor Lymphocyte Infusions (DLI), complete the Donor Lymphocyte Infusion (2199) form

The Post-Cellular Therapy Follow up Form focuses on research level data for each reporting period, including post-infusion hospital admission, antigen escape, current hematologic findings, and persistence of the cellular product.

**Figure 1.** Disabled Edit Form Icon

[ ](https://manula.s3.amazonaws.com/user/3235/img/4101-edit-icon.jpg)

**Combined follow up**

In scenarios where both HCT and cellular therapy forms are being completed, there are two scenarios where the Post-CTED (4100) and Post-Cellular Therapy Follow-Up(4101) forms are completed:

**Example 1.** Cellular therapy after HCT: completion of this form should be based on the time period in relation to the CT infusion date (i.e., 100 days after the CT infusion date). The visit ID and date of contact should match between the corresponding Post-HSCT Data (2100) or Post-Transplant Essential Data (2450).

**Example 2.** HCT after cellular therapy: completion of this form should be based on the time period in relation to the HCT infusion date (i.e., 100 days after the HCT infusion date). The visit ID and date of contact should match between the corresponding Post-HSCT Data (2100) or Post-Transplant Essential Data (2450).

Duplicate questions between HCT and cellular therapy forms may be disabled on the Post-CTED. A full list of enabled/disabled fields can be found on the [Combined Follow Up](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/combined-follow-up-scenarios-hct-ct-genetically-modified) section of the Data Management Guide. Illustrations of the combined follow up scenarios can also be found the Guide.

Links to sections of form:

Q1: Product:

Q2-4: Survival:

Q5-22: Disease Relapse or Progression:

Q23-33: Current Hematologic Findings:

Q35-59: Persistence of Cells:

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

**No**for the question*Were tests performed to detect persistence of the cellular product since the date of last report?*.[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4101-post-cellular-therapy-follow-up)**No**for the question*Were tests performed to detect persistence of the cellular product since the date of last report?*but please confirm if your site is using the new persistence test.[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4101-post-cellular-therapy-follow-up)[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q5-9-disease-relapse-or-progression)[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q5-9-disease-relapse-or-progression)**Example 1**: A recipient has a CD19 expressing disease prior to the cell therapy infusion, such as acute lymphoblastic leukemia (ALL) or non-Hodgkin lymphoma (NHL). The recipient is given a CD19-directed CAR T-cell therapy, achieves a CR then relapses. At the time of relapse their leukemia/lymphoma cells no longer express CD19.[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q5-9-disease-relapse-or-progression)[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q5-9-disease-relapse-or-progression)[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4101-post-cellular-therapy-follow-up)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)