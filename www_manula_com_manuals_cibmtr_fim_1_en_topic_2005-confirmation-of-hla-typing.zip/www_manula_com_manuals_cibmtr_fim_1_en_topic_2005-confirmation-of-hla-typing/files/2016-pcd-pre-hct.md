The Plasma Cell Disorder Pre-Infusion Data Form (Form 2016) is one of the Comprehensive Report Forms. This form captures PCD-specific pre-infusion data such as: disease classification at diagnosis, hematologic findings at the time of diagnosis and prior to the start of the preparative regimen, amyloidosis organ involvement at diagnosis and prior to the start of the preparative regimen, pre-HCT treatments administered and the best response to each line of therapy, and disease status prior to the start of the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “Multiple myeloma/plasma cell disorder (PCD).”

#### Subsequent Transplant

Report “no” and go to question 1 in any of the following scenarios:


- This is the first infusion reported to the CIBMTR; or
- This is a second, or subsequent, transplant for a different disease (e.g., the patient was previously transplanted for a disease other than a Plasma Cell Disorder/Multiple Myeloma); or
- This is a second, or subsequent, infusion for the same disease subtype and this baseline disease insert was not completed for the previous transplant (e.g., the patient was on the TED track for the prior infusion, prior infusion was autologous with no consent, etc.).

Report “yes” and go to question 157 in any of the following scenarios:


- This is a second, or subsequent, transplant for relapse or progression of the same disease; or
- This is an infusion for the same disease, and this baseline PCD disease insert was completed previously.

Links to Sections of the Form

[Q1 – 2: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-2-pcd-disease-assessment-at-diagnosis)

[Q3 – 60: Diagnostic Studies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q3-60-laboratory-studies-at-diagnosis)

[Q61 – 124: Amyloidosis Organ Involvement at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q119-187-amyloidosis-organ-involvement-at-diagnosis)

[Q125 – 156: POEMS Syndrome Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q125-156-poems-syndrome-assessment-at-diagnosis)

[Q157 – 187: Pre-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q157-187-pre-hct-therapy)

[Q188 – 254: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q188-255-laboratory-studies-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

[Q255 – 289: Amyloidosis Assessment at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q256-290-amyloidosis-organ-involvement-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

[Q290 – 295: POEMS Syndrome Assessment at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q291-296-poems-syndrome-assessment-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen-infusion)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2016.PCD%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/28/2023 |
|

*As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form*[2016: PCD Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)*For questions 3-60, report values obtained at diagnosis or prior to the first treatment for the plasma cell disorder for which the transplant was performed. If testing is performed multiple times prior to the start of the first treatment, report the*~~last test before the start of treatment~~ testing performed closest to the diagnosis date.[2016: PCD Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)*Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR-T cells). Report***Yes**if the recipient received cellular therapy as part of the line of therapy being reported. For subsequent infusions, this includes any previous cell therapy infusions to treat disease already reported to the CIBMTR. If not, report**No**.[2016: PCD Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)