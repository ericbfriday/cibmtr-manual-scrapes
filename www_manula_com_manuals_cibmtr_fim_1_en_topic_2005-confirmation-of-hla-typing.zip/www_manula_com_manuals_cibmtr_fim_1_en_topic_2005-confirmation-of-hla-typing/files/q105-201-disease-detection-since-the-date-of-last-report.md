For each method of assessment, report **Yes** if that method detected the recipient’s MPN (or markers of MPN) during the reporting period. If testing by a particular method (e.g., molecular makers, cytogenetic, flow cytometry, etc.) was done, but did not shown evidence of disease during the reporting period, report **No** for that method. If testing for splenomegaly, hepatomegaly, driver mutations, molecular or cytogenetic markers / abnormalities, or bone marrow was not done during the reporting period or it is not known whether testing was performed, report **Unknown** for those methods. If testing by flow cytometry, extramedullary disease detection or other assessment was not done during the reporting period or it is not known whether testing was performed, report **No** for those methods.

#### Questions 105-106: Did the recipient have splenomegaly?

Indicate if the recipient had splenomegaly indicative of disease detection since the date of the last report. Splenomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate **Yes** if splenomegaly was present and indicated disease detection since the date of the last report and report the date of assessment in question 106. Indicate **No** if splenomegaly was not present, or if splenomegaly was not indicative of disease, since the date of the last report and continue with question 111.

Indicate **Unknown** if it is not possible to determine the presence or absence of splenomegaly since the date of the last report and continue with question 111.

Indicate **Not applicable** if the question does not apply to the recipient (e.g. prior Splenectomy) and continue with question 111.

#### Question 107: Specify the method used to measure spleen size:

Indicate the method used to measure the spleen size, if the method selected is **physical assessment** continue with question 108. If the method selected is **ultrasound** or **CT / MRI** continue with question 109. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 108: Specify the spleen size in centimeters below the left costal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 110.

#### Question 109: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 110.

#### Question 110: Was this considered a disease relapse?

If the physician believes the size of the spleen indicates a disease relapse, check **Yes**. If the recipient had an enlarged spleen, but the physician does not believe the result represents disease relapse, check **No**. Continue with question 111.

#### Questions 111-112: Did the recipient have hepatomegaly?

Indicate if the recipient had hepatomegaly indicative of disease detection since the date of the last report. Hepatomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding.

Indicate **Yes** if hepatomegaly was present and indicated disease detection since the date of the last report and report the date of assessment in question 112. Indicate **No** if hepatomegaly was not present, or if hepatomegaly was not indicative of disease, since the date of the last report and continue with question 117. Indicate **Unknown** if it is not possible to determine the presence or absence of hepatomegaly since the date of the last report and continue with question 117.

#### Question 113: Specify the method used to measure liver size:

Indicate the method used to measure the liver size, if the method selected is **physical assessment** continue with question 114. If the method selected is **ultrasound** or **CT / MRI** continue with question 115. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Questions 114: Specify the liver size in centimeters below the right costal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 116.

#### Question 115: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 116.

#### Question 116: Was this considered a disease relapse?

If the physician believes the size of the liver indicates a disease relapse, check **Yes**. If the recipient had an enlarged liver, but the physician does not believe the result represents disease relapse, check **No**. Continue with question 117.

#### Question 117-127: Were tests for driver mutations performed?

Testing for driver mutations may be performed by different methods including next generation sequencing (NGS), polymerase chain reaction (PCR), microarray, and fluorescence in situ hybridization (FISH).

If testing by any / all of these methods was performed, to assess JAK2, CALR, MPL and CSF3R, and at least one of the driver mutations were detected (i.e. positive for disease), report **Yes** for question 117 and continue with question 118.

If testing was completed during the reporting period but did not show evidence of disease, report **No**.

If testing was not done during the reporting period or it is unknown whether testing was completed, report **Unknown**.

#### Question 128: Was this considered disease relapse?

Indicate **Yes** or **No** if the driver mutations detected were considered disease relapse.

If testing for all of the listed driver mutations are negative, select **Not applicable** (negative results).

#### Question 129: Was documentation submitted to the CIBMTR (e.g. pathology report, FISH report)?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 130: Were molecular tests for molecular markers performed (e.g., PCR)? (please do not include driver mutations JAK2, CALR, MPL, and CSF3R as previously captured above)

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. **FISH testing for molecular markers should not be reported here**.

Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If any molecular testing for molecular markers was performed and disease was detected during the reporting period, report **Yes** and go to question 131.

If molecular testing for molecular markers was performed but did not detect disease at any time during the reporting period, report **No**.

If molecular testing was not done or it is not known if testing was done, report **Unknown** and go to question 139.

#### Question 131: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker was identified during the reporting period.

If a positive molecular marker was identified, select **Yes** and continue with question 132.

If there were no molecular markers identified, select **No** and continue with question 139.

#### Question 132: Date sample collected

Report the date the sample was collected for molecular testing. If disease was detected multiple times by this method of assessment in the reporting period, report the first assessment which detected disease.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 133-134: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 135. If a positive marker is detected, but not listed as an option, select **Other molecular marker** and specify the positive molecular marker in question 134.

#### Questions 135-136: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

**Figure 1**. Molecular disease assessment with amino acid changes documented (highlighted in yellow).


For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://http//varnomen.hgvs.org/recommendations/protein/).

For question 135, indicate if the amino acid change is **Known** or **Unknown** for the positive molecular marker reported in questions 133-134. If known, report the amino acid change in question 136. If **Unknown**, continue with question 137.

Copy questions 133-136 to report more than one positive molecular marker.

#### Question 137: Was this considered a disease relapse?

Indicate if the molecular abnormalities were considered a disease relapse. Criteria for molecular relapse are established by clinical judgment, and should reflect the clinical decision of the transplant physician. A recipient may be reported to have molecular relapse even in the setting of hematologic CR; criteria for complete remission are based on hematologic and pathologic characteristics and are independent of molecular markers of disease.

If the recipient has molecular abnormalities that the physician considers to be consistent with disease relapse, select **Yes.**

If the recipient has molecular abnormalities that the physician does not consider to be consistent with molecular relapse, select **No**.

#### Question 138: Was documentation submitted to the CIBMTR?

Indicate if the pathology report is attached to support the molecular findings reported in questions 133-136. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 139: Was disease detected via flow cytometry?

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

If disease was detected via flow cytometry, select **Yes** and continue with question 140.

If flow cytometry was done but disease was not detected or it is unknown if flow cytometry was done, select **No** and continue with question 148.

#### Question 140-142: Blood

Indicate whether flow cytometry detected disease in a blood sample at any time during the reporting period. If “yes,” report the date the sample was collected and the percent disease detected (i.e., percent leukemic blasts) in questions 141 and 142, respectively. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Report **no** for question 140 and go to question 144 in either of the following cases:


- all flow cytometry assessments performed on the blood were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the blood during the reporting period.

If multiple flow cytometry assessments performed on blood samples were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period

#### Question 143: Was this considered a disease relapse?

Indicate if the peripheral blood flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with relapse, select **yes**. Continue with question 144.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select **no**. Continue with question 144.

#### Question 144-146: Bone Marrow

Indicate whether flow cytometry detected disease in a bone marrow at any time during the reporting period. If **yes**, report the date the sample was collected and the percent disease detected (i.e., percent leukemic blasts) in questions 145 and 146, respectively. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Report **no** for question 144 and go to question 148 in either of the following cases:


- all flow cytometry assessments performed on the bone marrow were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the bone marrow during the reporting period.

If multiple flow cytometry assessments performed on bone marrow were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

#### Questions 147: Was disease detected?

Indicate if the bone marrow flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with relapse, select **yes**. Continue with question 148.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select **no**. Continue with question 148.

#### Question 148: Was disease detected via cytogenetic testing (karyotyping or FISH)?

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the recipient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the recipient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic testing detected the recipient’s primary disease at any time during the reporting period, report **Yes** and go to question 149.

If all cytogenetic testing was negative for evidence of the recipient’s primary disease during the current reporting period, report **No** and go to question 167.

Report **Unknown** for question 148 and go to question 167 in any of the following cases:


- cytogenetic testing was not performed during the reporting period; or
- cytogenetic testing was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether cytogenetic testing was performed during the reporting period.

#### Question 149: Were cytogenetic abnormalities identified via FISH?

Indicate whether FISH studies detected disease at any time during the reporting period. If FISH detected disease, select **Yes** go to question 150.

Report **No** for question 149 and go to question 158 in any of the following cases:


- FISH testing was not performed during the reporting period; or
- FISH testing was done but abnormalities were not detected; or
- FISH testing was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- It cannot be determined whether FISH testing was performed during the reporting period.

#### Questions 150-151: Sample source

Indicate if the sample was from **bone marrow** or **peripheral blood** and report the date the sample was collected in question 151. If multiple sources were used to test FISH, the most preferred sample is the bone marrow.

If multiple FISH assessments were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 152-155: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 152, then continue with question 153.

Report the number of abnormalities detected by FISH in question 153. After indicating the number of abnormalities in question 153, select all abnormalities detected in questions 154-155.

If an abnormality is detected, but not listed as an option in question 154, select* other abnormality* and specify the abnormality in question 155. If multiple “other abnormalities” were detected, report “see attachment” in question 155 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 156: Was this considered a disease relapse?

Indicate if the FISH results were considered consistent with disease relapse. Criteria for FISH relapse are established by clinical judgment. If the recipient has abnormalities detected by FISH that the physician considers to be consistent with relapse, select **yes**. Continue with question 157.

If the recipient has residual disease by FISH that the physician does not consider to be consistent with relapse, select **no**. Continue with question 157.

#### Question 157: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if the FISH report is attached to support the cytogenetic findings reported in questions 152-155. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 158: Were cytogenetic abnormalities identified via karyotyping?

Indicate whether karyotyping studies detected abnormalities at any time during the reporting period. If karyotyping detected disease, select **Yes** go to question 159.

Report **No** for question 158 and go to question 167 in any of the following cases:


- karyotyping was not performed during the reporting period; or
- karyotyping was performed but not abnormalities were detected; or
- karyotyping was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether karyotyping was performed during the reporting period.

#### Questions 159-160: Sample source

Indicate if the sample was from **bone marrow** or **peripheral blood** and report the date the sample was collected in question 160. If multiple sources were used for karyotyping analysis, the preferred sample is the bone marrow.

If multiple karyotyping assessments were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 161-164: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 161, then continue with question 162.

Report the number of abnormalities detected by karyotyping in question 162. After indicating the number of abnormalities in question 162, select all abnormalities detected in questions 163-164.

If an abnormality is detected, but not listed as an option in question 163, select **other abnormality** and specify the abnormality in question 164. If multiple “other abnormalities” were detected, report “see attachment” in question 164 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 165: Was this considered a disease relapse?

Indicate if the karyotyping results were considered consistent with disease relapse. Criteria for karyotype relapse are established by clinical judgment. If the recipient has abnormalities detected by karyotyping that the physician considers to be consistent with relapse, select **Yes.** Continue with question 166.

If the recipient has residual disease by karyotyping that the physician does not consider to be consistent with relapse, select **No**. Continue with question 166.

#### Question 166: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if the karyotyping report is attached to support the cytogenetic findings reported in questions 161-164. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Questions 167-168: Was disease detected via bone marrow examination?

If a bone marrow biopsy detected disease during the reporting period, report **Yes** for question 167 and report the date of the positive assessment in question 168. Continue with question 169.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If multiple bone marrow biopsies detected disease, report the date of the earliest positive assessment performed during the reporting period.

If bone marrow biopsies did not detect disease at any time during the reporting period, report **No**.

If it is unknown if any bone marrow biopsies were done, report **Unknown** and go to question 174.

#### Questions 169-170: Blasts in the bone marrow

Indicate wither the percentage of blasts in the bone marrow was **known** or **unknown**. If **known** report the percentage documented on the laboratory report in question 170. If **unknown** continue with question 174.

#### Question 171: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This is evident in MDS diseases such as chronic idiopathic myelofibrosis. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is **known** or **unknown**. If the myelofibrosis grade is documented in the pathology report or stated in a physician note, select **known**, continue with question 172.

If the myelofibrosis grade is not documented, select **unknown**, continue with question 173.

#### Question 172: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist.

Select **MF-0** if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select **MF-1** if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select **MF-2** if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with focal bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select **MF-3** if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 173: Was this considered a disease relapse?

Indicate if the bone marrow biopsy results were considered a disease relapse. If the bone marrow biopsy was consistent with relapse, select **yes**. Continue with question 174.

If the recipient has residual myelofibrosis that the physician does not consider to be consistent with relapse, select **no**. Continue with question 174.

#### Questions 174-175: Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma)

Indicate if the recipient had extramedullary disease indicative of AML during the reporting period. An example of extramedullary disease would be a myeloid sarcoma. Indicate **yes** if extramedullary disease indicative of AML was present and report the date of assessment in question 175. Indicate **no** if extramedullary disease indicative of AML was not present during the reporting period and continue with question 178.

If multiple assessments detected extramedullary disease indicative of AML during the reporting period, report the date of the earliest positive assessment performed during the reporting period.

#### Questions 176-177: Specify site(s) of disease (check all that apply)

Select each site where extramedullary disease indicative of AML was detected on the date reported in question 175. If extramedullary disease indicative of AML was detected at a site not specified in question 176, report **other site** and specify all other sites where extramedullary disease indicative of AML in question 177.

#### Questions 178-180: Was disease detected by other assessment?

Indicate if disease was detected by any other assessment during the reporting period. Indicate **yes** if disease was detected by other assessment during the reporting period, report the date of assessment in question 179, and specify the name of the other assessment in question 180. Indicate **no** if disease was not detected by any other during the reporting period and continue with question 182.

#### Question 181: Was this considered a disease relapse?

Indicate if the result of the other disease assessment was considered a disease relapse. Criteria for disease relapse are established by clinical judgment. If the recipient has another disease assessment that the physician considers to be consistent with relapse, select **yes**. Continue with question 182.

#### Question 182: Was intervention given for minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML since the date of the last report?

Indicate if the recipient received treatment post-infusion for minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML since the date of last report. See question 183 for definitions each of these indications for treatment.

#### Question 183: Specify reason for which intervention was given

Select all indications for which treatment was administered during the reporting period. See below for definitions of each indication.

**Minimal Residual Disease**: Recipient is in hematologic CR, but has evidence of disease by more sensitive assessments including molecular, flow cytometry or cytogenetic methods.

**Persistent Disease**: The recipient was in primary induction failure or relapse at the time of infusion and has not achieved a hematologic CR post-infusion.

**Relapsed Disease**: The recipient was in CR at the time of infusion or the recipient achieved a CR post-infusion. In either case, treatment is administered for a relapse which occurred post-infusion.

**Decreased / Loss of Chimerism**: If the recipient’s chimerism decreased or was lost during the reporting period, treatment is administered to recover the donor chimerism. In other words, the donor portion of the chimerism was decreasing or lost completely (i.e., 0%).

**Progression to AML**: If an examination demonstrated ≥20% blasts in the blood or bone marrow during the reporting period, this is a progression to AML and treatment would be administered in order to treat this progression.

#### Question 184: Systemic therapy

Systemic therapy includes chemotherapy, immunotherapy, or targeted therapies delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein or given orally. Do not report subsequent HCT / cellular therapies in questions 184-193. If the recipient received systemic therapy during the reporting period to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, report **yes**. If not, report **no**.

#### Questions 185-186: Date therapy was first started

If the recipient started systemic therapy during the reporting period to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, report “Known” for question 185 and indicate the date started in question 186. If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the recipient started therapy in a prior reporting period to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, and continued the therapy into the current reporting period, report *Previously reported *and go to question 187.

For recipients who start and stop therapy multiple times post-infusion, first determine whether the recipient stopped therapy for at least 30 days. If not, consider the therapy continuous. Only report a new therapy start date if all three of the below conditions are met.


- The recipient stopped all therapy given for treatment; and
- The recipient restarted therapy for treatment during the current reporting period; and
- Therapy was restarted at least 30 days after the therapy stop date.

#### Questions 187-188: Date therapy stopped

Indicate if therapy stop date is **Known** or **Unknown**. If the therapy is being given in cycles, report the date the recipient started the last cycle for this line of therapy in question 188. Otherwise, report the final administration date for the therapy being reported.

If the recipient is still receiving this treatment at the end of the reporting period, report **not applicable, still receiving therapy**.

If the stop date is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 189-190: Reason therapy stopped

If the systemic therapy was stopped during the reporting period, indicate the reason in question 189. If the reason therapy stopped isn’t listed in question 189, select **other** and report the other reason therapy stopped in question 190.

#### Question 191-193: Specify systemic therapy given for maintenance: (check all that apply)

Report the drug(s) given as part of this line of therapy. If multiple lines of therapy were given during the reporting period, they must be reported separately.

If the recipient received a JAK1 or JAK2 inhibitor not listed, select **other JAK1 or JAK2 inhibitor** and report the agent in question 192.

If the recipient received a systemic therapy which is not listed, select **other systemic therapy** and report the agent in question 193. Report the generic name of the agent, not the name brand.

#### Question 194-195: Supportive treatment

Supportive treatment refers to therapy given to prevent, control, or relieve complications and side effects and to improve the recipient’s comfort. These therapies include treatment with growth factors (EPO, G-CSF, GM-CSF, etc.).

If the recipient received supportive treatment, report **yes** and select all supportive treatment given. If the recipient did not receive supportive treatment, report **no**.

#### Question 196: Cellular Therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells).

Report **yes** if the recipient received cellular therapy as part of the line of therapy being reported. If not, report **no**.

#### Question 197: Subsequent HCT

If the recipient received a subsequent HCT to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, report **yes**. If not, report **no**.

If a subsequent HCT was performed during the reporting period, ensure this was reported on the Post-infusion Data (2100 or 4100) forms as well. Reporting a subsequent HCT given to treat the recipient’s primary disease will prompt a new Pre-TED (2400) form to come due in FormsNet3SM.

#### Question 198: Accelerated withdrawal of immunosuppression in response to disease assessment

Immunosuppressive medications may be tapered or entirely withdrawn in order to promote a graft vs leukemia effect in the setting of relapsed, progressive, or persistent disease. If immunosuppression is reduced or stopped during the reporting period in order to treat disease, report **yes**. If not, report **no**.

#### Question 199-200: Blinded randomized trial

Indicate whether treatment was administered as part of a blinded randomized trial. Consult the physician overseeing treatment if it is not clear whether the therapy is being given as part of a blinded randomized trial. If **yes**, report the clinicaltrials.gov number.

If the clinical trial number (NCT number) is not clearly documented, it can be looked up using the Find a Study feature on www.clinicaltrials.gov.

If the recipient is participating in a clinical trial that is not registered with clinicaltrials.gov, but is registered elsewhere, leave question 200 blank and override the validation error using the code “Unable to answer.” Also, attach documentation which displays the clinical trial number and corresponding registry to the form in FormsNet3SM. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 201-202: Other therapy

Indicate if the recipient received any other therapy (not already reported in questions 184-200) given for minimal residual disease, persistent disease, relapsed disease, decreased / loss of chimerism, or progression to AML. Do not report supportive therapies (e.g., transfusions, growth factors) or a subsequent HCT in questions 201-202, as they should already have been reported above. If **yes**, specify all other therapies given.

Copy and complete questions 183-202 to report therapy given for additional indications (e.g. MRD, relapse, persistent disease).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q105 | 4/9/2024 | Modify | Question 105-202 blue box updated: Questions 105 – 202 are intended to capture information only for recipients who relapse / progress, have persistent or minimal residual disease in this reporting period. If disease was not detected by the method of assessment, report No. If disease was detected by the method of assessment, the earliest instance in which disease was detected in |
Updated for clarification |
| Q105 – 202 | 5/6/2022 | Add | Clarification added above question 105 (blue note box and instructional text) to report the first assessment showing evidence of disease: Questions 105 – 202 are intended to capture the earliest instance of disease detection by each method of assessment performed during the reporting period. If multiple tests by a particular method have demonstrated evidence of disease during the reporting period, report the date / result of the earliest positive assessment(s) performed during the reporting period.For each method of assessment, report “Yes” if that method detected the recipient’s MPN (or markers of MPN) during the reporting period. If testing by a particular method (e.g., molecular makers, cytogenetic, flow cytometry, etc.) was done, but did not shown evidence of disease during the reporting period, report “No” for that method. If testing for splenomegaly, hepatomegaly, driver mutations, molecular or cytogenetic markers / abnormalities, or disease detected via bone marrow was not done during the reporting period or it is not known whether testing was performed, report “Unknown” for those methods. If testing by flow cytometry or for disease detected extramedullary or by other assessment was not done during the reporting period or it is not known whether testing was performed, report “No” for those methods. |
Added for clarification |
| Q117 | 4/9/2024 | Modify | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: Testing for driver mutations may be performed by different methods including next generation sequencing (NGS), polymerase chain reaction (PCR), microarray, and fluorescence in situ hybridization (FISH). If testing by any / all of these methods was performed, to assess JAK2, CALR, MPL and CSF3R, and at least one of the driver mutations were detected (i.e. positive for disease), report Yes for question 117 and continue with question 118. If testing was completed during the reporting period but did not show evidence of disease, report No. If testing was not done during the reporting period or it is unknown whether testing was completed, report Unknown. no or unknown respectively and go to question 130. |
Incorrect instructions |
| Q130 | 4/9/2024 | Modify | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. FISH testing for molecular markers should not be reported here. Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD). If any molecular testing for molecular markers was performed and disease was detected during the reporting period, report Yes and go to question 131. If molecular testing for molecular markers was Unknown |
Incorrect instructions |
| Q131 | 4/9/2024 | Modify | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: If a positive molecular marker was identified, select Yes and continue with question 132. If there were no molecular markers identified-, or it is unknown whether molecular markers were identified,- select no unknown respectively, |
Incorrect instructions |
| Q132 | 4/12/2024 | Add | Instructions clarified on which assessment date to report: Report the date the sample was collected for molecular testing. If disease was detected multiple times by this method of assessment in the reporting period, report the first assessment which detected disease. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, Guidelines for Completing Forms |
Added for clarification |
| Q139 | 4/9/2024 | Modify | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing. If disease was detected via flow cytometry, select Yes and continue with question 140. If flow cytometry was done but disease was not detected or it is unknown if flow cytometry was done, select No and continue with question 148. |
Incorrect instructions |
| Q149 | 4/9/2024 | Add | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: Indicate whether FISH studies detected disease at any time during the reporting period. If FISH detected disease, select Yes go to question 150. Report No for question 149 and go to question 158 in any of the following cases:
|
Incorrect instructions |
| Q158 | 4/9/2024 | Add | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: Indicate whether karyotyping studies detected abnormalities at any time during the reporting period. If karyotyping detected disease, select Yes go to question 159. Report no for question 158 and go to question 167 in any of the following cases:
|
Incorrect instructions |
| Q167 | 4/9/2024 | Add | Instructions updated to clarify these questions should only be reported if disease was detected by this assessment: If a bone marrow biopsy detected disease during the reporting period, report Yes for question 167 and report the date of the positive assessment in question 168. Continue with question 169. If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions,
No. no orunknown |
Incorrect instructions |
| Q173 | 9/21/2022 | Modify | Instructions updated: Indicate if the |
Original instructions incorrect |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)