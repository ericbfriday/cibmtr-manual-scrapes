#### Question 1: What was the date of diagnosis of Neuroblastoma?

Neuroblastoma is typically diagnosed by histopathologic findings from tumor tissue samples or a bone marrow biopsy. Tumor marker analyses can provide diagnostic assistance. The date of diagnosis should be the date when the biopsy of tumor mass, metastatic site, or bone marrow was obtained. If the diagnosis was determined at an outside facility and no documentation of the laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the exact pathological diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 2 – 31: Specify the site(s) of primary tumor(s) at diagnosis

Indicate **Yes** or **No** if the primary tumor was identified at diagnosis for each site listed in questions 2-31 (i.e. adrenal gland, bone, bone marrow, etc.). If the site(s) was identified, select **Yes** and report the number of tumors present. If the site is not listed in questions 2-27, indicate **Yes** for “Other site” in question 28, report the number of tumors present at diagnosis and specify the location of the “other site.”

If the location of primary tumor(s) is unknown, select **No** for the sites listed in questions 2-30, and report **Yes** for question 31.

#### Question 32: Were metastases present at diagnosis?

Metastases can develop when cancer cells break away from the main tumor and enter the bloodstream or lymphatic system. Indicate **Yes** or **No** if metastases were present at diagnosis.

If it is not known if metastases were present at diagnosis, report **Unknown**. This option should be used sparingly and only when no diagnostic information is available.

#### Questions 33 – 47: Specify the site(s) of metastases

For each site listed in questions 33-46, specify if the site of metastatic neuroblastoma present at diagnosis. If metastatic disease was present at a site not listed in questions 33-45, report **Yes** for “Other site” and specify the site in question 47.

#### Questions 48 – 52:Specify radiographic tests used to evaluate the disease status at diagnosis

Radiologic assessments are imaging techniques used to assess disease at diagnosis, typically for lymphomas or solid tumors. A multimodal imaging approach is often taken when evaluating neuroblastoma. CT, MRI, scintigraphy, and skeletal surveys are commonly used. Indicate **Yes** or **No** if any of the listed radiologic tests were performed to evaluate the disease status at diagnosis.

See below for definitions and examples of each method of assessment:


**CT scan**: Uses computer processing to turn numerous x-rays taken from many different angles into cross-sectional images; these scans can be useful for identifying abnormal structural features or pathologically enlarged organs or tissues.**Magnetic resonance imagining (MRI)**: Magnetic resonance imaging (MRI) is an imaging technique used to form pictures of the anatomy and the physiological processes of the body.**I-meta-iodobenzylguanidine scan (MIBG)**: Uses radioactive tracers for imaging +/- tissue destruction. These scans are specific to andrenergic tissues, which are those nervous system tissues involved in epinephrine and norepinephrine production and reception.**Skeletal survey**: Or “bone survey”, is comprised of a series of x-rays taken to examine all the bones in the body.**Technetium scan**: Technetium (Tc-99m) is an isotope commonly used as a tracer in imaging scans to detect how certain parts of the body are functioning. Tc-99m scans are often used to detect a wide range of conditions such as: tumors, heart disease, thyroid abnormalities and kidney conditions.

#### Question 53: Were any biopsies performed at diagnosis?

Indicate **Yes** or **No** if any biopsies were performed at diagnosis or prior to the first treatment for neuroblastoma. If biopsies were not performed or it is not known if one was performed, select **No** and continue with question 62.

#### Questions 54 – 58: Specify the biopsy site(s) positive for neuroblastoma

For questions 54-58 indicate whether each biopsy site was positive for neuroblastoma. If the biopsy site was positive for neuroblastoma indicate **Yes**. If a biopsy site was tested and negative for neuroblastoma or the site was not biopsied, indicate **No** and continue with the next question.

If a biopsy was positive for neuroblastoma at a site not listed, indicate **Yes** for “Other site” and specify the site in question 58.

#### Question 59: Specify the histologic findings by Shimada classification

The Shimada classification divides tumors into stroma-rich and stroma-poor categories according to their organizational pattern. Stroma refers to Schwann cells associated with neuroblastoma cells.

Indicate if the positive biopsy(ies) specified in questions 54-58 are **Stroma-rich** (percentage of tumor stroma ≥ 50%) or **Stroma-poor** (percentage of tumor stroma < 50%). This information is likely to be found in a histopathology report from a tissue biopsy; however, if the Shimada classification is unclear, seek physician clarification.

If the histologic findings by the Shimada classification are not known, select **Not classified / unknown** and continue with question 62.

#### Question 60: Specify histology

Specify the histology of the stroma-rich biopsy as either **Nodular** or **Well differentiated / intermixed**. This classification is based on the morphology of the immature elements and might be included in a histopathology report. However, clinician clarification may be necessary.

#### Question 61: Specify histology

Specify if histology of the stroma-poor biopsy is considered **Favorable** or **Unfavorable**. This classification is typically based on the patient’s age at diagnosis, degree of maturation, and the mitosis-karyorrhexis index (count of cells undergoing mitosis or karyorrhexis) of the neuroblastic cells. This information might be included in a histopathology report; however, clinician input may be necessary if the histology is not documented within the biopsy report.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)