The Leukodystrophies Post-Infusion Data Form is one of the Comprehensive Report Forms. This form captures Leukodystrophies post-HCT data for the reporting period.

This form must be completed for all recipients whose primary disease is reported on the Pre-TED Disease Classification (2402) Form as a leukodystrophy and specified as one of the following:

- Krabbe Disease (globoid cell leukodystrophy)
- Metachromatic leukodystrophy (MLD)
- Adrenoleukodystrophy (ALD)
- Hereditary diffuse leukoencephalopathy with spheroids (HDLS)

The Post-Infusion Leukodystrophies (2137) Form must be completed in conjunction with each Post-Infusion Follow-up (2100) Form. This form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100; between day 100 and the six-month date of contact for six-month follow-up; and between the date of contact for the six-month follow-up and the date of contact for the one-year follow-up, etc.).

Links to sections of the manual:

[Q1 – 5: Leukodystrophies Post-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-5-leukodystrophies-post-infusion-data)

[Q6 – 53: Clinical Status Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q6-52-clinical-status-post-infusion)

[Q54 – 61: Clinical Status Prior to Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q54-61-disease-modifying-therapies)

[Q62: Marrow Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q72-marrow-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/6/2025 |
|

[2137: Leukodystrophies Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2137-leukodystrophies-post-infusion)*This section is only completed for*~~gene therapy~~ Skysona® infusions.[2137: Leukodystrophies Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2137-leukodystrophies-post-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)