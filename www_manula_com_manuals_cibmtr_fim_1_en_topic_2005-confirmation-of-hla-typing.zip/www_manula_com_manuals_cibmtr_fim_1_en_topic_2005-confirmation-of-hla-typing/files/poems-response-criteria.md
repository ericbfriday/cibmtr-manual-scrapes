#### General Reporting Guidelines

- Use the POEMS response criteria when determining the disease status for POEMS.
- Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.

### Hematologic Response

#### Complete Response (CR)

Requires **all** of the following:


- Serum and urine negative for monoclonal proteins by immunofixation
- Plasma cells in marrow < 5%

CR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy.

The method of the two consecutive assessments may be any of the biochemical tests (urine / serum testing) listed in the disease status criteria available in the manual. Though it is preferable the biochemical confirmatory testing include both urine & serum, this disease status does not required two consecutive assessments by each method.

#### Very Good Partial Response (VGPR)

**One or more** of the following must be present:


- Serum M-protein detectable by immunofixation, but not on electrophoresis; or
- A ≥ 90% reduction in the serum M-protein as long as the serum M-protein was ≥ 0.5 g/dL at baseline

VGPR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy.

#### Partial Response (PR)

- A ≥ 50% reduction in the serum M-protein as long as the serum M-protein was ≥ 1.0 g/dL at baseline

PR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy

#### No Response (NR)

- Does not meet the criteria for CR, VGPR, PR, or progressive disease.

NR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy.

#### Progressive Disease (PD)

- Requires a 25% increase from the lowest M-spike achieved with an absolute increase of > 0.5 g/dL

PD requires two consecutive assessments (by the same method) made at any time before classification as disease progression, and/or the start of any new therapy.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/12/2024 | POEMS Response Criteria | Add | Urine Immunofixation and Electrophoresis blue box added for clarification: Urine Immunofixation and Electrophoresis: The sample for the urine immunofixation and electrophoresis criteria must be a 24-hour urine and not a random urine. |
| 5/18/2022 | POEMS Response Criteria | Remove | POEMS Partial Response Criteria update to be more concise as the first bullet point was the same criteria for VGPR:
|
| 10/2/2020 | POEMS Response Criteria | Add | POEMS Response Criteria section of the Forms Instructions Manual released. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)