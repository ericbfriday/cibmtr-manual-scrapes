The Hemophagocytic Lymphohistiocytosis Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures HLH-specific Pre-HCT data such as the disease assessment, clinical and laboratory features at diagnosis, history of infection, pre-transplant therapy, and clinical and laboratory studies prior to the start of the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “histiocytic disorders” and question 635 as “hemophagocytic lymphohistiocytosis (HLH).”

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype and **this baseline disease insert was not completed for the previous transplant** (e.g., patient was on TED track for the prior HCT or prior HCT was autologous with no consent), select “no” and begin at question 1.

If this is a report of a second or subsequent transplant for a **different disease** (e.g., patient was previously transplanted for a disease other than HLH), select “no” and begin at question 1.

If this is a report of a second or subsequent transplant for the **same disease and this baseline disease insert has previously been completed**, select “yes” and continue with question 108.

[Q1-22: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-q22-disease-assessment-at-diagnosis)

[Q23-47: Clinical Features and Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q23-47-clinical-features-and-laboratory-studies-at-diagnosis)

[Q48-58: Disease Assessment Between Diagnosis and the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q48-58-disease-assessment-between-diagnosis-and-the-start-of-the-preparative-regimen)

[Q59-74: History of Infection at Any Time Prior to the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q59-74-history-of-infection-at-any-time-prior-to-the-preparative-regimen)

[Q75-107: Pre-HCT Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q75-107-pre-hct-therapy)

[Q108-127: Clinical Features and Laboratory Studies At Last Evaluation Prior to the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q108-127-clinical-features-and-laboratory-studies-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/7/2020 | Comprehensive Disease-Specific Manuals | Add | Clarification added to explain how to report lines of therapy for subsequent infusions: Lines of Therapy and Subsequent InfusionsIf this is a subsequent infusion and a 2039 was completed for the previous infusion, lines of therapy do not need to be reported in duplication on the subsequent 2039. Please report from post previous infusion to time of preparative regimen / infusion for the current infusion. If a 2039 was not previously completed, all lines of therapy from diagnosis to the current preparative regimen / infusion must be completed. |
| 2/24/17 | Comprehensive Disease-Specific Manuals | Modify | Updated explanations of triggers for disease inserts to refer to the primary disease reported on the Pre-TED Disease Classification Form (Form 2402) instead of the Pre-TED Form (Form 2400) |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)