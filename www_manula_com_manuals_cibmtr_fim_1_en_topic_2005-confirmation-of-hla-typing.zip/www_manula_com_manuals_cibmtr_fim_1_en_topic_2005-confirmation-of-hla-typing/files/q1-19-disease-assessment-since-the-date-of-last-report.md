#### Question 1: Did the recipient have lymphoma at the time of HCT?

XLP is associated with a higher incidence of lymphoma, which may be secondary to EBV infection; however, not all lymphomas in the setting of XLP exhibit EBV clonality. There is speculation that lymphoma risk is increased secondary to aberrant invariant natural killer T-cell (iNKT), NK, and T-cell cytotoxic function. The majority of lymphomas seen in XLP patients are T-cell lymphomas.

Specify if the patient had lymphoma at the time of transplant. If “yes,” continue with question 3; if “no,” continue with question 2.

#### Question 2: Did the recipient develop lymphoma or have persistent disease since the date of last report?

Indicate if the patient developed lymphoma during the reporting period or had persistent lymphoma carrying over from a previous reporting period. If “yes,” continue with question 3. If “no,” continue with question 4.

#### Question 3: Specify current status of lymphoma

Report the status of the patient’s lymphoma at last assessment during the reporting period. Disease response criteria are defined in Table 1 below.

**Table 1. Lymphoma Disease Response Definitions**


| Disease Response | Definition |
|---|---|
| Complete Remission (CR) | Complete disappearance of all known disease for ≥ 4 weeks |
| Partial Remission (PR) | ≥ 50% reduction in greatest diameter of all sites of known disease and no new sites of disease |
| Stable Disease (SD) | <50% reduction in greatest diameter of all sites of known disease |
| Progressive Disease (PD) | Increase in size of known disease or new sites of disease |
| Not Assessed | No assessment of patient’s disease during reporting period; this would indicate an absence of radiology or physical examination |
| Unknown | Disease assessment was performed but is insufficient to determine disease status or results of evaluation(s) unknown or it is unknown if evaluations were performed |

#### Question 4: Did colitis persist or develop since the date of the last report?

Colitis refers to inflammation of the large intestine, often manifesting as diarrhea, abdominal pain and bloating, and melena (black “tarry” feces) or hematochezia (passage of fresh blood in feces).

Specify if the patient had colitis develop during the reporting period or persist from a previous reporting period. If “yes,” continue with question 5. If “no” or “unknown,” continue with question 7.

#### Question 5: What is the status of colitis?

Specify if colitis was active at the last assessment during the reporting period.

#### Question 6: Was the recipient receiving therapy for colitis?

Indicate if the patient received treatment for colitis at any time during the reporting period.

#### Question 7: Did vasculitis persist or develop since the date of the last report?

Vasculitis refers to inflammation of the vasculature (blood vessels), including both veins and arteries. Vasculitis may impact blood vessels of any size, from capillaries and arterioles to the great truncal vessels. It is typically caused by autoimmunity. If “yes,” continue with question 8. If “no” or “unknown,” continue with question 18.

#### Question 8: Central nervous system

CNS vasculitis refers to inflammation of the vasculature of the brain and/or spinal cord.

Specify if the patient had CNS vasculitis develop during the reporting period or persist from a previous reporting period. If “yes,” continue with question 9. If “no,” continue with question 11.

#### Question 9: What is the status of the CNS vasculitis?

Specify if CNS vasculitis was active at the last assessment during the reporting period.

#### Question 10: Was the recipient receiving therapy for CNS vasculitis?

Indicate if the patient received treatment for CNS vasculitis at any time during the reporting period.

#### Question 11: Pulmonary system

Pulmonary vasculitis involves inflammation of pulmonary vasculature. This can range from the great vessels, such as the pulmonary arteries, to the small alveolar capillaries.

Specify if the patient had pulmonary vasculitis develop during the reporting period or persist from a previous reporting period. If “yes,” continue with question 12. If “no,” continue with question 14.

#### Question 12: What is the status of the pulmonary vasculitis?

Specify if pulmonary vasculitis was active at the last assessment during the reporting period.

#### Question 13: Was the recipient receiving therapy for pulmonary vasculitis?

Indicate if the patient received treatment for pulmonary vasculitis at any time during the reporting period.

#### Questions 14-15: Other vasculitis involvement

Indicate if the patient had other vasculitis involvement. Specify involvement in question 15.

#### Question 16: What is the status of other vasculitis?

Specify if other vasculitis was active at the last assessment during the reporting period.

#### Question 17: Was the recipient receiving therapy for other vasculitis?

Indicate if the patient received treatment for other vasculitis at any time during the reporting period.

#### Question 18: Did the recipient have hemophagocytic lymphohistiocytosis (HLH) prior to transplant or did it present since the date of last report?

HLH is an abnormal proliferation of macrophages and histiocytes that leads to the phagocytosis of healthy circulating blood cells.

Indicate if the patient had HLH prior to transplant or developed HLH during the reporting period. If “yes,” continue with question 19. If “no,” continue with question 20.

If the recipient had HLH in the previous reporting period, but there was no evidence of HLH during the current reporting period, select “no.”

#### Question 19: Specify the status of the HLH disease since the date of last report

Specify if HLH was active or inactive (quiescent) at the last assessment during the reporting period.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)