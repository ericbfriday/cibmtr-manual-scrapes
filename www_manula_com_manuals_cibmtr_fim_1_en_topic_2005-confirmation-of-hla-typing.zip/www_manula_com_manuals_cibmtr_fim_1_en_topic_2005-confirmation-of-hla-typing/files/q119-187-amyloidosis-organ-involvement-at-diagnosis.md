#### Questions 61 – 62: Site(s) of tissue with pathologic diagnosis of amyloidosis (check all that apply)

Abdominal fat is the most common initial biopsy site when amyloidosis is suspected but other tissue sources may be examined. Most tissue samples are taken by needle aspiration and stained with Congo red dye. Samples that are positive have their normal architecture disrupted by amyloid deposits, which appear red under microscopy due to Congo red stain. Under polarized light microscopy, amyloid deposits stained with Congo red appear green (birefringence). Indicate which tissue biopsies were performed at diagnosis (or prior to the first therapy) confirming a pathologic diagnosis of amyloidosis. If the tissue source analyzed is not listed, indicate **Other** and report the other tissue site in question 62.

#### Question 63: Was amyloid subtyping performed?

Correct identification of the amyloidosis-causing protein is critical for proper clinical management and disease prognosis. The most common methods of determining amyloid subtype are immunohistochemistry, mass spectrometry, or immunofluorescence. Indicate **Yes** if amyloid subtyping was performed at diagnosis of amyloidosis or prior to the start of first therapy. If subtyping analysis was not performed, report **No** and continue with question 67.

#### Questions 64 – 66: Indicate amyloid subtype

Specify the results as determined by amyloid subtyping and indicate the testing method utilized.

If a different method was used (e.g., laser microdissection of Congo red-positive deposits followed by liquid chromatography) report **Other** in question 65 and specify the method used in question 66.

#### Question 67: Was a cardiac imaging procedure performed?

Cardiographic imaging may show amyloid infiltration in heart tissue. Cardiac MRI, echocardiogram, sometimes referred to as an echo, (do not report an ECG or EKG, which refer to electrocardiogram)], or Multiple Gate Acquisition (MUGA) scans may be performed to assess heart involvement. Indicate if cardiographic imaging was performed at diagnosis or prior to the first therapy. If a cardiac imaging procedure was not performed, select **No** and continue with question 79.

#### Question 68: Was a cardiac MRI done?

Cardiac MRI may be used to differentiate amyloid involvement from other cardiopathologies. Indicate **Yes** or **No** if a cardiac MRI was performed at diagnosis or prior to the first therapy. If **No**, continue with question 71.

#### Question 69: Specify cardiac MRI results

Characteristics of amyloid involvement in cardiac tissue include impaired ventricular systolic function, thickened valves, increased atrial septal thickness and left ventricular mass, pleural and pericardial effusions, and subendocardial hyperenhancement. 1 Indicate if the results of cardiac MRI were

**Normal**,

**Abnormal**, or

**Unknown**.

1 Penugonda N. Cardiac MRI in infiltrative disorders: A concise review. Curr Cardiol Rev. 2010;6(2):134-136.

#### Question 70: Was documentation submitted to the CIBMTR (e.g., MRI report)?

Indicate if a copy of the cardiac MRI report is attached to support the data reported in questions 68-69. Attaching a copy of the report may prevent additional queries. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/SystemApplications/FormsNet3/Documents/FN3%20Guide%20090920.pdf) .

#### Question 71: Was the left ventricular ejection fraction measured?

The left ventricular ejection fraction (LVEF) is a percentage that represents the volume of blood pumped from the left ventricle into the aorta (also known as stroke volume) compared to the volume of blood in the ventricle just prior to the heart contraction (also known as end diastolic volume). Indicate **Yes** or **No** if the left ventricular ejection fraction (LVEF) was measured. If **No**, continue with question 74.

#### Question 72: Specify the left ventricular ejection fraction

Indicate the left ventricular ejection fraction at diagnosis or prior to the first therapy. Most imaging reports will report the LVEF. If the LVEF is not explicitly documented it should be determined by dividing the stroke volume (SV, the volume of blood pumped into the aorta from the left ventricle) by the end diastolic volume (EDV, the volume of blood in the left ventricle just prior to contraction) of the left ventricle . For example, if the stroke volume was 75 ml and the end diastolic volume was 150ml, the ejection fraction would be 50%.

If the recipient had multiple assessments using different methods, report the most recent assessment prior to the initiation of treatment.

#### Question 73: Specify the method used to determine the left ventricular ejection fraction

Indicate the method used to determine the LVEF value.

#### Question 74: Was diastolic dysfunction present?

Diastole is the period in which chambers of the heart fill with blood. Diastolic dysfunction may be characterized by the difficulty of the ventricles to expand and contract appropriately due to stiffening of the heart walls by amyloid deposits. Indicate **Yes** or **No** if diastolic dysfunction was present. If this information is not known, select **Unknown**.

#### Questions 75 – 76: Specify the intraventricular septal wall thickness measured by echocardiogram

The heart is divided into the right and left sides by the septum. The area between the left and right ventricles is the intraventricular septum. Indicate if the intraventricular septal thickness is **Known** or **Unknown**. If **Known**, based on evaluation by echocardiogram, indicate the thickness of the intraventricular septal wall. If **Unknown**, or not measured by echocardiogram, continue with question 77.

#### Questions 77 – 78: Specify left ventricular (LV) strain percentage

A strain pattern, as determined by electrocardiography, is a well-recognized marker of hypertrophy of the left ventricular (LVH) and is characterized by ST depression and T wave inversion on a resting ECG / EKG. The LV strain percentage is typically a negative percentage. The normal range for the LV global longitudinal strain (LV GLS) is -15.9% to -22.1%.

Indicate if the left ventricular strain percentage is **Known** or **Unknown**. If **Known**, based on evaluation by electrocardiogram, indicate the strain percentage. If **Unknown**, or not measured by electrocardiogram, continue with question 79.

#### Questions 79 – 80: Were any serum cardiac biomarkers assessed?

Assessment of cardiac biomarkers helps determine if injury to cardiac tissue has occurred. Cardiac biomarkers include brain natriuretic peptide (BNP), N-terminal prohormone brain natriuretic peptide (NT-proBNP), troponin I, troponin T, and high-sensitivity troponin T. Indicate **Yes** or **No** if serum cardiac biomarkers were assessed at diagnosis or prior to first therapy. If **Yes**, report the date. If **No** or **Unknown**, continue with question 96.

#### Questions 81 – 83: Brain natriuretic peptide (BNP)

Indicate **Yes** or **No** if the BNP was assessed at the time of amyloidosis diagnosis. If **Yes**, report the value (in pg/mL) and specify the upper limit of normal. If **No**, continue with question 84.

#### Questions 84 – 86: N-terminal prohormone brain natriuretic peptide (NT-proBNP)

Indicate **Yes** or **No** if the NT-proBNP was assessed at the time of amyloidosis diagnosis. If **Yes**, report the value (in pg/mL) and specify the upper limit of normal. If **No**, continue with question 87.

#### Questions 87 – 89: Troponin I

Indicate **Yes** or **No** if the Troponin T was assessed at the time of amyloidosis diagnosis. If **Yes**, report the value (in µg/L) and specify the upper limit of normal. If **No**, continue with question 93.

#### Questions 90 – 92: Troponin T

Indicate if the Troponin T was assessed at the time of amyloidosis diagnosis. If “yes,” report the value (in µg/L) in question 91 and continue with question 92. If “no,” continue with question 93.

#### Questions 93 – 95: High sensitivity troponin T

Indicate **Yes** or **No** if the high-sensitivity troponin T was assessed at the time of amyloidosis diagnosis. If **Yes**, report the value (in ng/L) and specify the upper limit of normal. If **No**, continue with question 96.

#### Questions 96 – 97: Was a 6-minute walk test performed?

A 6-minute walk test is used to assess total distance walked within 6 minutes to determine aerobic capacity and endurance. Indicate if a 6-minute walk test was performed at diagnosis or prior to the first therapy. If **Yes**, report the total distance walked and specify the unit of measure. If **No**, continue with question 98.

#### Question 98: Specify the recipient’s New York Heart Association functional classification of heart failure: (Symptoms may include dyspnea, chest pain, fatigue, and palpitations; activity level should be assessed with consideration for patient’s age group)

Indicate the recipient’s [New York Heart Association functional classification](https://www.cibmtr.org/manuals/fim/1/en/topic/new-york-heart-association-function-classification) at diagnosis or prior to the first therapy using the following guidelines:


**Class I**– Able to perform ordinary activities without symptoms; no limitation of physical activity**Class II**– Ordinary physical activity produces symptoms; slight limitation of physical activity**Class III**– Less-than-ordinary physical activity produces symptoms; moderate limitation of physical activity**Class IV**– Symptoms present even at rest; severe limitation of physical activity

If the recipient’s NYHA functional classification it not known, select **Unknown**.

#### Questions 99 – 101: Recipient blood pressure (at diagnosis)

Indicate if the recipient’s blood pressure was **Known** or **Unknown** at diagnosis of amyloidosis. If **Known**, report the recipient’s blood pressure and specify the body position in which the measure was taken. If testing was performed multiple times prior to the start of treatment, report the last test before the start of therapy.

If the recipient’s blood pressure was not known at diagnosis, select **Unknown** and continue with 102.

#### Question 102: Did the recipient develop pericardial effusion?

Indicate **Yes** or **No** if the recipient developed pericardial effusion.

#### Question 103: Was hepatomegaly present on radiographic imaging (liver span > 15 cm) or on examination (liver edge palpable > 3 cm below right costal margin)?

At the time of diagnosis or prior to first therapy, indicate if the liver spanned more than 15 cm (by radiographic imaging) or the edge of the liver was palpable more than 3 cm (by physical examination). If hepatomegaly was present, select **Yes**. Indicate **No** or **Unknown** if hepatomegaly was not present or it was not possible to determine the presence or absence of hepatomegaly.

#### Questions 104 – 106: Specify the level of serum alkaline phosphatase

Indicate whether the alkaline phosphatase (ALP) level at the time of amyloidosis diagnosis or prior to first treatment is **Known** or **Unknown**. If **Known**, report the laboratory value, unit of measure, and specify the upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 107.

#### Question 107: Was there clinical suspicion of gastrointestinal (GI) involvement?

GI involvement by amyloidosis is usually proven by biopsy; however, clinical symptoms of gastrointestinal involvement may include esophageal reflux, constipation, nausea and abdominal pain, diarrhea, weight loss, or early satiety (fullness). 2 Indicate

**Yes**or

**No**if there was any clinical suspicion of GI involvement at diagnosis or prior to the first therapy. If there was not any clinical suspicion of GI involvement at diagnosis or it is not known, select

**No**or

**Unknown**and continue with question 109.

2 Cowan AJ, Skinner M, Seldin DC, Berk JL, Lichtenstein DR, O’Hara CJ, Doros G, Sanchorawala V. Amyloidosis of the gastrointestinal tract: A 13-year, single-center, referral experience. Haematologica. 2013;98(1):141-146.

#### Question 108: Specify the site(s) of GI involvement (check all that apply)

Symptoms of GI involvement may include, but are not limited to, esophageal reflux, nausea, abdominal pain, constipation, diarrhea, or weight loss. Indicate all sites with clinical suspicion of GI involvement. Select all sites that apply and continue with question 109.

#### Question 109: Was a sensory / motor exam performed?

Indicate **Yes** or **No** if a sensory / motor exam was performed. This exam evaluates the neurological status of the recipient and consists of assessing the recipient’s body positioning, involuntary movements, muscle tone, muscle strength, ability to sense pain and light touch, position sense (proprioception), stereognosia (ability to discern an object with eyes closed, such as a coin), graphesthesia (ability to identify number of letter drawn on skin with eyes closed), and extinction (ability to discern multiple simultaneous stimuli). 3 If a sensory / motor exam was not performed or it not known if one was performed, select

**No**or

**Unknown**and continue with question 111.

3 NYU School of Medicine; Russell S, Triola M. The Precise Neurological Exam. available at: http://informatics.med.nyu.edu/modules/pub/neurosurgery/ Accessibility verified April 7, 2013.

#### Question 110: Specify the exam results

Indicate the results of the sensory / motor exam as **Normal** or **Abnormal**. If the recipient’s sensory / motor exam was within normal limits, select **Normal**. If it is clinically documented that the sensory/motor exam showed “intact” results, these should be interpreted as **Normal**. If the recipient displayed neurologic impairment, select **Abnormal**.

#### Questions 111 – 112: Did the recipient display any other evidence of peripheral nerve involvement for amyloidosis?

Indicate if the recipient displayed any other evidence of peripheral nerve involvement (other than displayed on sensory / motor examination and nerve biopsy). If Yes, specify the other evidence in question 112. If **No**, continue with question 113.

Examples of other peripheral nerve involvement for amyloidosis include (but are not limited to): carpal tunnel syndrome, painful paresthesias in the legs, etc.

#### Question 113: Did the recipient display symptomatic orthostatic hypotension (not attributable to medications or volume depletion)?

Orthostatic hypotension is a decrease in blood pressure (systolic by 20 mmHg or diastolic by 10 mmHg) within 3 minutes of standing from a sitting or lying down position. Symptoms include “dizziness, lightheadedness, blurred vision, weakness, fatigue, nausea, palpitation and headache.” 4 Indicate if the recipient had evidence of orthostatic hypotension at diagnosis, or prior to first therapy, that was not attributable to medications or volume depletion.

4 Lanier JB, Mote MB, Clay EC. Evaluation and management of orthostatic hypotension. Am Fam Physician. 2011;84(5):527-536.

#### Questions 114 – 115: Did the recipient display any other evidence of autonomic neuropathy (e.g., pseudo-obstruction or intractable diarrhea)?

Indicate if the recipient had any other evidence of autonomic neuropathy, such as pseudo-obstruction or intractable diarrhea, at the time of diagnosis or prior to first therapy. If **Yes**, specify the other evidence. If **No**, continue with question 116.

Pseudo-obstruction is a condition in which food does not pass through the intestines as if the intestines were blocked; however, rather than a blockage, it is caused by nerve damage within the intestinal tract.

Intractable diarrhea is diarrhea that cannot be stopped by medication.

#### Question 116: Did the recipient display any other clinical involvement?

Indicate if the recipient displayed any other clinical manifestations at the time of diagnosis or prior to first therapy. Review the preceding sections starting from question 67 and ensure that any manifestations reported here do not already have a specific place for reporting. If the recipient displayed clinical involvement not already reported elsewhere, select **Yes**. If **No**, continue with question 119.

#### Questions 117 – 118: Specify the evidence of other organ involvement (check all that apply)

For each option, indicate if there was evidence of other organ involvement. If there was other organ involvement not listed in this section, select **Other organ involvement** in and specify the other organ in question 118.

Examples may include:


- Arthropathy is a disease of the joints. An example of a common arthropathy in patients with amyloidosis is carpal tunnel-like symptoms.
- Amyloid deposits may be found in the lung, impairing their function. Examples of lung involvement may be alveolar-septal disease, nodular disease, intra- and extra-thoracic adenopathy, pleural disease, and diaphragm deposition.
[5](#fn174892832668596b3190d1e-5) - Soft tissue involvement, other than those already listed, may include glandular involvement (such as submandibular glands).
- Any additional organ involvement, other than those already listed, may be reported in this section as
**Other organ involvement**. The other organ involved will then be specified in question 118.

5 Berk JL, O’Regan A, Skinner M. Pulmonary and tracheobronchial amyloidosis. Semin Respir Crit Care Med. 2002;23(2):155-65.

#### Questions 119 – 121: Was Factor X measured?

Factor X is a protein within the blood that is critical in coagulation and clotting processes. Indicate **Yes** or **No** if Factor X was measured at the diagnosis of amyloidosis or prior to the start of first therapy. If **Yes**, report the Factor X percentage, indicate the type of Factor X measurement that was utilized to determine this percentage, and if the recipient was actively taking Warfarin (Coumadin) at the time of Factor X analysis.

If Factor X was not measured at the amyloidosis diagnosis, select **No** and continue with question 123.

#### Questions 123 – 124: Uric acid at diagnosis

Elevated levels of uric acid are often due to decreased kidney function where uric acid elimination is being done inefficiently. Indicate whether the uric acid at diagnosis of amyloidosis was **Known** or **Unknown**. If **Known**, report the value documented on the laboratory report. If **Unknown**, continue with question 125.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)