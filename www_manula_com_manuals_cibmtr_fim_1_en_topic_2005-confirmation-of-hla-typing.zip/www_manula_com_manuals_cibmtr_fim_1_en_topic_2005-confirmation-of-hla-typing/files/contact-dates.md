This section is intended to provide general information about reporting contact dates for infusions (transplant, cellular therapy, and gene therapy).

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspxwebpage).

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/2024 |
|

[Reporting Instructions Overview: Contact Dates – Subsequent Infusions and Contact Dates](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/subsequent-infusions-and-contact-dates)*The recipient had a subsequent auto transplant for graft failure and death occurred in the same reporting period. The recipient has their first transplant on 3/1/2023 and a subsequent auto transplant for the indication of graft failure/insufficient hematopoietic recovery on 4/15/2023 and death occurred on 5/20/2023. Report the Day 100 contact date as the date of death, 5/20/2023.*[Reporting Instructions Overview: Contact Dates – Subsequent Infusions and Contact Dates](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/subsequent-infusions-and-contact-dates)**Subsequent Cell Therapy and Death**: For a subsequent cellular therapy, if the Cellular Therapy Essential Data Pre-Infusion (4000) is requested via CIBMTR Center Support to be made “NRQ”, the death and subsequent infusion can be reported on the same form.[Reporting Instructions Overview: Contact Dates – Subsequent Infusions and Contact Dates](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/subsequent-infusions-and-contact-dates)*The recipient had a subsequent non-genetically modified cellular therapy and death occurred in the same reporting period. The recipient has their first transplant on 1/21/23 and a non-genetically modified cellular therapy infusion on 2/15/23. Death occurred on 3/1/23. Report the Day 100 contact date as the date of death, 3/1/23*
Last modified:
Apr 21, 2025

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)