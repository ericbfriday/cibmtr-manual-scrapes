#### Complete Response (CR)

Complete response requires all of the following:


- Disappearance/resolution of primary tumor
- No evidence of metastatic sites
- Catecholamines normal

#### Very Good Partial Remission (VGPR)

Very good partial remission requires all of the following:


- Primary tumor decreased by 90-99%
- No evidence of metastatic sites
- Catecholamines normal
- Residual 99Tc bone changes allowed

#### Partial Response (PR)

Partial response requires all of the following:


- Primary tumor decreased by > 50%
- All measurable metastatic sites decreased by > 50%
- Number of positive bone sites decreased by > 50%
- No more than 1 positive bone marrow site allowed, 1 positive marrow aspirate or biopsy allowed if this represents a decrease from the number of positive sites at diagnosis.

#### Minimal Response (MR)

Minimal response requires all of the following:


- No new lesions
- > 50% reduction of any measurable lesion (primary or metastases) with < 50% reduction in any other; < 25% increase in any existing lesion.

#### No Response (NR)

Includes no new lesions with less than < 50% reduction but < 25% increase in any existing lesion.

#### Progressive Disease (PD) (after Very Good Partial Remission, Partial Response, Minimal Response or No response), Relapsed Disease (after Complete Response)

Progression or relapse requires at least one of the following:


- Any new lesions
- Increase of any measurable lesion by > 25%
- Previous negative marrow positive for tumor.

| Date | Manual Section | Add/ Remove/Modify | Description |
|---|---|---|---|
| 1/25/2021 | Neuroblastoma Response Criteria | Add | Version 1 of the Neuroblastoma Response Criteria section of the Forms Instructions Manual released. |

Last modified:
Feb 01, 2021

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)