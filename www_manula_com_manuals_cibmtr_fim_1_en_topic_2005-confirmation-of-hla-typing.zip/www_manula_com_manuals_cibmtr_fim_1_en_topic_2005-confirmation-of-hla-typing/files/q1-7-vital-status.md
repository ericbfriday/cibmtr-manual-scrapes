The date of actual contact with the recipient to determine medical status for this follow-up report is based on a medical evaluation conducted by a clinician with responsibility for the recipient’s care. Report the date of the medical evaluation performed closest to the designated time period of the form (e.g., Day+100, 6 months, or annual follow-up visit). Time windows are provided to guide selection of dates for reporting purposes. Recipients are not always seen within the time windows used for reporting follow-up dates, and some discretion is therefore required when determining which date to report. If the recipient is not seen within the time windows, report the date closest to the date of contact within reason.

If the Post-HCT Follow-Up Form reports a subsequent infusion (transplant or cellular therapy), report the date of latest follow-up as the day prior to the start of the preparative regimen / systemic therapy. If no preparative regimen or conditioning / systemic therapy was given, report the day prior to infusion as the date of contact.

**Question 1: Date of actual contact with the recipient to determine the medical status for this follow-up report**

Enter the date of actual contact with recipient to determine medical status for this follow-up report. Acceptable evaluations include those from the transplant center, referring physician, or other physician currently assuming responsibility for the recipient’s care. Please capture a physician evaluation that falls within the appropriate range, if possible, rather than other types of patient contact that may be closer to the actual time point. If an evaluation was not performed at Day+100, at 6 months, or on the HCT anniversary, choose the date of the visit closest to the actual time point.

If the recipient has not been seen by a clinician during the reporting period but the survival status is known, complete the [Survival Tool](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/survival-form-status?q=survival+tool) referenced in the CIBMTR Data Management Guide.

In general, the date of contact should be reported as close to the 100-day, 6 month, or annual anniversary to transplant as possible. Report the date of actual contact with the recipient to evaluate medical status for the reporting period. In the absence of contact with a clinician, other types of contact may include a documented phone call with the recipient, a laboratory evaluation, or any other documented recipient interaction on the date reported. If there was no contact on the exact time point, choose the date of contact closest to the actual time point. Below, the guidelines show an ideal approximate range for reporting each post-transplant time point:

| Time Point | Approximate Range |
|---|---|
| 100 days | +/- 15 days (Day 85-115) |
| 6 months | +/- 30 days (Day 150-210) |
| 1 year | + 60 days (Day 366 – 425) |
| Annual reporting 2+ years | +/- 30 days (Months 23-25, 35-37, etc.) |

Recipients are not always seen within the approximate ranges and some discretion is required when determining the date of contact to report. In that case, report the date closest to the date of contact within reason. The examples below assume that efforts were undertaken to retrieve outside medical records from the primary care provider, but source documentation was available.

**Example 1.** *The 100-day date of contact doesn’t fall within the ideal approximate range.*

The autologous recipient was transplanted on 1/1/13 and is seen regularly until 3/1/13. After that, the recipient was referred home and not seen again until 7/1/13 for a restaging exam and 7/5/13 for a meeting to discuss the results.

What to report:

100 Day Date of Contact: 3/1/13 (Since there was no contact closer to the ideal date of 4/11/13, this date is acceptable)

6 Month Date of Contact: 7/5/13 (note the latest disease assessment would likely be reported as 7/1/13)

**Example 2.** *The 100-day date of contact doesn’t fall within the ideal approximate range and the recipient wasn’t seen again until 1-year post-HCT.*

The autologous recipient was transplanted on 1/1/12 and is seen regularly until 3/1/12. After that, the recipient was referred home and not seen again until 1/1/13 for a restaging exam and 1/4/13 for a meeting to discuss the results.

What to report:

100 Day Date of Contact: 3/1/13 (Since there was no contact closer to the ideal date of 4/11/13, this date is acceptable)

6 Month Form: Indicate the recipient is lost to follow-up in FormsNet3

1 Year Date of Contact: 1/4/13 (note the latest disease assessment would likely be reported as 1/1/13)

Additional Information


- A date of contact should never be used multiple times for the same recipient’s forms.
- For example, 6/1/13 should not be reported for both the 6 month and 1-year form. Instead, determine the best possible date of contact for each reporting period; if there is not a suitable date of contact for a reporting period, this may indicate that the recipient was lost to follow-up.

- If the recipient has a disease evaluation just after the ideal date of contact, capturing that data on the form may be beneficial.
- For example, if the recipient’s 90 day restaging exam was delayed until day 115 and the physician had contact with the recipient on day 117, the restaging exams can be reported as the latest disease assessment and day 117 would be the ideal date of contact, even though it is just slightly after the ideal approximate range for the date of contact.


**Date of Contact & Death**

In the case of recipient death, the date of death should be reported as the date of contact regardless of the time until the ideal date of contact. The date of death should be reported no matter where the death took place (inpatient at the transplant facility, at an outside hospital, in a hospice setting, or within the recipient’s home).

If the death occurred at an outside location and records of death are not available, the dictated date of death within a physician note may be reported. If the progress notes detailing the circumstances of death are available, request these records. These records are useful for completing required follow-up data fields and the cause of death data fields on this form. If the exact date of death is not known, use the processed described for reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Example 3.** *The recipient has died before their six-month anniversary.*

The recipient is transplanted on 1/1/20, was seen regularly through the first 100 days. They had restaging exams on 4/4/20 and was seen on 4/8/20, and then died on 5/13/20 in the hospital emergency room.

What to report:

100 Day Date of Contact: 4/8/20 (note the latest disease assessment would likely be reported as 4/4/20)

6 Month Date of Contact: 5/13/20 (though the death does not occur within the ideal approximate range for 6 months)

**Example 4.** *The recipient has died after their six-month anniversary.*

The recipient is transplanted on 1/1/13, was seen regularly through the first 100 days. They had restaging exams on 4/22/13 and was seen on 4/23/13. Based on findings in the restaging exam, the recipient was admitted for additional treatment. The disease was found to be refractory on a 6/25/13 restaging exam, and the recipient was discharged to hospice on 7/8/13. The hospital was notified via telephone that the recipient died on 7/16/13.

What to report:

100 Day Date of Contact: 4/23/13 (note the latest disease assessment would likely be reported as 4/22/13)

6 Month Date of Contact: 7/16/13 (note the latest disease assessment would likely be reported as 6/25/13)

**Date of Contact & Subsequent Infusion**

If the recipient has a subsequent infusion (HCT or cellular therapy), report the date of contact as the day before the preparative regimen / systemic therapy begins for the subsequent infusion. If no preparative regimen / systemic therapy is given, report the date of contact as the day before the subsequent infusion. In these cases, actual contact on that day is **not** required, and the day prior to the initiation of the preparative regimen (or infusion, if no preparative regimen / systemic therapy) should be reported. This allows every day to be covered by a reporting period but prevents overlap between transplant events.

**Example 5.** *The recipient had a 2nd transplant with a preparative regimen.*

The recipient has their first transplant on 1/1/13 and a planned second transplant on 2/1/13. The recipient was admitted on and received their first dose of chemotherapy for the preparative regimen for HCT #2 on 1/28/13.

What to report:

100 Day Date of Contact: 1/27/13 (regardless of actual contact on that date)

**Example 6.** *The recipient had a subsequent transplant without a preparative regimen.*

Following their first transplant on 1/1/13, a recipient with SCID required a subsequent allogeneic transplant due to poor graft function. The recipient has remained inpatient following the first transplant. The physician planned the second transplant for 5/31/13 and proceeded without a preparative regimen.

What to report:

100 Day Date of Contact: 4/11/13 (+/- 15 days)

6 Month Date of Contact: 5/30/13

**Example 7.** *The recipient had a subsequent auto transplant for graft failure.*

The recipient has their first auto transplant on 3/1/23 and a subsequent auto transplant for the indication of graft failure/insufficient hematopoietic recovery on 4/15/23.

What to report:

100 Day Date of Contact: The date of contact reported will be appropriate to the reporting period since a new Pre-TED (2400) / Disease Classification (2402) is not required for auto rescues.

**Example 8.** *The recipient had a subsequent genetically modified cellular therapy with lymphodepleting therapy administered prior to infusion.*

The recipient has their first transplant on 2/1/15 and a genetically modified (e.g. CAR-T) cellular therapy infusion on 3/1/15. The recipient was admitted on and received their first dose of lymphodepleting therapy 2/28/15.

What to report:

100 Day Date of Contact: 2/27/15 (regardless of actual contact on that date). Both HCT and cellular therapy forms will be completed but all applicable HCT follow-up forms will be reset to the new event date (i.e., Forms 4100+2100). See [How Forms Come Due](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/how-forms-2004-2005-2006-come-due) in the Data Management Manual for more information on combined follow up.

**Example 9.** *The recipient had a subsequent non-genetically modified cellular therapy.*

The recipient has their first transplant on 1/21/15 and a non-genetically modified (e.g. DLI) cellular therapy infusion on 2/15/15. There was no lymphodepleting therapy administered.

What to report:

100 Day Date of Contact: The date of contact reported will be appropriate to the reporting period. Combined follow up will not be applied, a single F4100 is required, then HCT reporting continues.

**Example 10.** *The recipient had a subsequent Donor Lymphocyte Infusion (DLI).*

The recipient has their first transplant on 1/21/2022 and receives a DLI on 2/27/2022. There was no lymphodepleting therapy administered prior to the DLI.

What to report:

100 Day Date of Contact: The date of contact reported will be appropriate to the reporting period. Do not complete the follow up form early. Combined follow up will not be applied, a single F2199 is required for each DLI in the reporting period, then HCT reporting continues.

**1-Year Date of Contact**

When reporting the date of contact for the 1-year reporting period, if the recipient is alive, report a contact date after Day 365. The date of contact should not be reported prior to Day 366 for the 1-year reporting period. This ensures the recipient is included in the numerator for the transplant center’s Center Specific Analysis (CSA).

**Example 11.** *A recipient is evaluated before and after Day 365 but not on Day 365.*

The recipient had an allogeneic transplant on 1/5/13 and is seen regularly until 6/20/13. After that, the recipient was referred home and not seen again until 1/1/14 for a restaging exam and again on 1/15/14 to review the results. Day 365 is 1/5/14.

What to report:

1-Year Date of Contact: 1/15/14 (since this date is ≥ Day 365)

**Example 12.** *A recipient is evaluated before and after Day 365 but not on Day 365.*

The recipient is transplanted on 2/28/19 and seen regularly until 8/28/19. The next visit is on 2/20/20 for blood work and the lab results are phoned to the recipient on 2/21/20. The recipient was not evaluated again until 4/1/20. Day 365 is 2/28/20.

What to report:

1-Year Date of Contact: 4/1/20

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Question 2: Specify the recipient’s survival status at the date of last contact.**

Indicate the survival status of the recipient on the date of actual contact for follow-up evaluation. If the recipient has died, answers to subsequent questions should reflect the recipient’s clinical status between the date of last report and their death. The center must also complete a Recipient Death Data (2900) Form.

**Question 3: Did the recipient receive a subsequent infusion?**

Indicate if the recipient received a subsequent infusion during the reporting period. Subsequent infusions include transplant, cellular therapy, gene therapy, DLI, and ‘boost’ (autologous or allogeneic).

For more information on infusion types, review [Appendix D: How to Distinguish Infusion Types](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

**Question 4: Did the recipient receive a subsequent HCT?**

Indicate whether the recipient received a second (or third, etc.) hematopoietic stem cell infusion. Hematopoietic stem cells are defined as mobilized peripheral blood stem cells, bone marrow, or cord blood. The source of the hematopoietic stem cells may be allogeneic unrelated, allogeneic related, or autologous. For more information on how to distinguish infusion types (example: HCT versus DCI), see [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

If the recipient has received a subsequent HCT since the date of the last report, ensure the date of actual contact reported in question 1 is the date immediately prior to the start of the preparative regimen for the subsequent HCT. If no preparative regimen was given, report the date prior to infusion.

**Questions 5: Has the recipient received a cellular therapy? (e.g., CAR-T, DCI)**

Indicate whether the recipient received a cellular therapy for any reason within the reporting period. The most common type of post-HCT cellular therapy are donor cellular infusions (DCI) and donor lymphocyte infusions (DLI). These infusions are not intended to promote hematopoiesis. If the recipient received additional cells due to engraftment issues, or if they received an infusion of unmanipulated CD34+ cellular product (stimulated peripheral blood stem cells, bone marrow, or cord blood), report as a subsequent HCT rather than a cellular therapy. For more information on how to distinguish infusion types (example: HCT versus DCI), see [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

A DCI is a form of cellular therapy that uses cells from the original donor and is commonly used to create a graft-versus-leukemia / tumor (GVL / GVT) effect. The recipient does not receive a preparative regimen prior to receiving the donor cells because the purpose of a DCI is to activate the immune system rather than repopulate the marrow. The recipient may, however, be given therapy prior to the infusion for the purpose of disease control. The types of cells used in a DCI include, but are not limited to lymphocytes, unstimulated peripheral blood mononuclear cells, dendritic cells, and / or mesenchymal cells.

Other forms of cellular therapy may include cytotoxic T-lymphocytes (CTLC) to treat infections or chimeric antigen receptor T-cells (CAR T-cells) to treat persistent, progressive, or recurrent disease.

**Question 6: Was this infusion a donor lymphocyte infusion (DLI)?**

As previously mentioned, donor lymphocyte infusions (DLI) are considered a type of cellular therapy. These infusions are not intended to promote hematopoiesis. If the recipient received additional cells due to engraftment issues, or if they received an infusion of unmanipulated CD34+ cellular product (stimulated peripheral blood stem cells, bone marrow, or cord blood), report as a subsequent HCT rather than a cellular therapy. For more information on how to distinguish infusion types (example: HCT versus DCI), see [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

Indicate if the infusion was a donor lymphocyte infusion (DLI). An infusion is donor lymphocyte infusion when all the following criteria are met:

- The intent of the infusion is something other than to restore hematopoiesis
- The infusion must be post-HCT, often by the same donor as the HCT
- Indication is suboptimal donor chimerism, immune reconstitution, GVHD treatment, prevent or treat disease release (as reported on the Pre-TED (2400) Form)
- Composition of cells are un-manipulated lymphocytes

If the infusion meets the above definition of DLI, select **Yes**.

If the infusion does not meet DLI criteria, select **No**.

**Question 7: Number of DLIs in this reporting period**

Report the number of Donor Lymphocyte Infusions (DLI) the recipient received in the reporting period. This question is used to make the correct number of Donor Lymphocyte Infusion (2199) Form(s) come due.

**Question 8: Are any of the products, associated with the course of cellular therapy, genetically modified?**

Genetically modified products include any product that was manipulated to alter its gene expression through the insertion of different genes or editing of genes. An example of a genetically modified product is the manipulation of T-lymphocytes to express Chimeric Antigen Receptors (CAR T-cells) directed towards specific tumor targets (antigens). Donor Lymphocyte infusions are typically not genetically modified.

If more than one product is infused, indicate **Yes** if any of the products are genetically modified. This question is used to determine the follow up schedule of the cellular therapy.

**Question 9: Date of cellular therapy**

Report the date of cellular therapy infusion. If multiple infusions were received in the reporting period, report the earliest. If infusions are continuing from a previous instance of a course of cellular therapy, only report in the period during which the first infusion was received. This question is used to make the Pre-CTED (4000) form come due and is not answered for DLIs.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q1 | 1/26/2024 | Add | Example 7 added: Example 7. The recipient had a subsequent auto transplant for graft failure: The recipient has their first auto transplant on 3/1/23 and a subsequent auto transplant for the indication of graft failure/insufficient hematopoietic recovery on 4/15/23. What to report: 100 Day Date of Contact: The date of contact reported will be appropriate to the reporting period since a new Pre-TED (2400) / Disease Classification (2402) is not required for auto rescues. |
Added for clarification |
| Q1 | 12/19/2023 | Modify | Instructions update to clarify the contact date for the 1Y reporting period must be greater than day 365: Reporting the 1-Year Date of Contact: If this form is being completed for the 1-year reporting period, ensure the reported contact date is > 1-Year Date of Contact instructions below for additional information. |
Incorrect instructions |
| Q3 | 7/26/2204 | Delete | Subsequent Infusion blue note box removed |
Question enabled with the Summer 2024 Quarterly Release |
| Q4 | 7/26/2024 | Add | Subsequent HCT and Cellular Therapy red warning box added above Q4: Subsequent HCT and Cellular Therapy: The following questions are disabled as of July 26, 2024: Did the recipient receive a subsequent HCT?, Has the recipient received a cellular therapy?, Was this infusion a donor lymphocyte infusion (DLI)?, Number of DLIs in this reporting period, Are any of the products, associated with the course of cellular therapy, genetically modified?, Date of cellular therapy; and will be removed with the next revision of this form. All subsequent infusions are reported in the question above Did the recipient receive a subsequent infusion? |
Question enabled with the Summer 2024 Quarterly Release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)