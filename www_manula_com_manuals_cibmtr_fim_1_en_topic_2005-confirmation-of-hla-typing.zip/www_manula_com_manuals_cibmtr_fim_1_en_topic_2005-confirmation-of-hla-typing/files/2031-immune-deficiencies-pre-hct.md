The Immune Deficiency Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures ID-specific pre-HCT data such as: disease assessment at diagnosis, laboratory studies at diagnosis, clinical features assessed between diagnosis and the start of the preparative regimen, and pre-HCT therapy.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as Disorders of the Immune System and specified as:


- Adenosine deaminase (ADA) deficiency / severe combined immunodeficiency (SCID)
- Absence of T and B cells SCID
- Absence of T, normal B cell SCID
- Omenn syndrome
- Reticular dysgensis
- Bare lymphocyte syndrome
- Other SCID
- SCID, not otherwise specified
- Ataxia telangiectasia
- HIV infection
- DiGeorge anomaly
- Common variable immunodeficiency
- Leukocyte adhesion deficiencies, including GP180, CD-18, LFA, and WBC adhesion deficiencies
- Kostmann agranulocytosis (congenital neutropenia)
- Neutrophil actin deficiency
- Cartilage-hair hypoplasia
- CD40 ligand deficiency
- Other Immunodeficiencies
- Immune deficiency, not otherwise specific

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype, and this baseline disease insert has not been completed for the previous transplant (e.g., patient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), begin at question 1. If this is a report of a second or subsequent transplant for a different disease (e.g., patient was previously transplanted for a disease other than ID), begin at question 1.

If this is a report of a second or subsequent transplant for the same disease and this baseline disease insert has previously been completed, check the indicator box and continue with question 116.

[Q1-8: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/idq1-8-disease-assessment-at-diagnosis)[Q9-50: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-50-laboratory-studies-at-diagnosis)[Q51-115: Clinical Features Assessed Between Diagnosis and the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q51-115-clinical-features-assessed-between-diagnosis-and-the-start-of-the-preparative-regimen)[Q116-191: Pre-HCT Therapy for Immune Deficiency](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q116-191-pre-hct-therapy-for-immune-deficiency)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/2024 |
|

[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)*Specify the lymphocyte function assessment performed at the time of diagnosis; if multiple studies were performed prior to the institution of therapy, report the*~~latest values prior to any first treatment for ID.~~ values closest to the diagnosis date.[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)*Specify the antibody response assessment performed at the time of diagnosis; if multiple studies were performed prior to the initiation of therapy (including IVIG), report the*~~latest values prior to any first treatment for ID~~ values closest to the diagnosis date.[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)*Specify the lymphocyte analyses performed at the time of diagnosis; if multiple studies were performed prior to the initiation of therapy, report the*~~latest values prior to any first treatment for ID~~ values closest to the diagnosis date.[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)*Specify the following quantitative immunoglobulins measured at the time of diagnosis; if multiple studies were performed prior to the initiation of therapy, report the*~~latest values prior to any first treatment of the immune deficiency~~ values closest to the diagnosis date.[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)[question 33](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-50-laboratory-studies-at-diagnosis#33): If CD56+ cells were not tested, centers may report CD16+ results in these data fields.[2031: ID Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)[question 32](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-50-laboratory-studies-at-diagnosis#q32):If CD20+ cells were not tested, centers may report CD19+ results in these data fields.

[2031/2131: Immune Deficiencies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-2131-immune-deficiencies-id)**Published new manual for**[2031](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)&[2131](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)Pre- and Post-HCT Immune Deficiencies Data
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)