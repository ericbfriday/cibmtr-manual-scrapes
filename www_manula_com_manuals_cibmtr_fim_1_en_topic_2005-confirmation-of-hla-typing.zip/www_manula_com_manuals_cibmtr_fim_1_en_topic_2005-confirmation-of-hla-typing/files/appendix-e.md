The intention of this appendix is to define the term **product** and provide several examples of infusions using single and multiple products. This appendix will also provide direction with regard to reporting product infusion on the CIBMTR Infusion Form 2006.

**The Infusion Form 2006 must be submitted for each product.** In order for a Form 2006 to become due in the FormsNet3SM application, each product must be reported as a separate instance (including any supplemental cells given prior to clinical day 0) on the Pre-TED Form 2400. If the patient received multiple products of the same type (e.g. multiple PBSC products), the transplant center must contact CIBMTR Center Support to request an additional Form 2006 in FormsNet3SM. Additionally, whenever multiple products are reported on the Comprehensive Report Forms, the transplant center must also contact CIBMTR Center Support to request additional Form 2006s in FormsNet3SM.

## Single Product vs. Multiple Products


**Single Product:** For the purposes of this manual, the CIBMTR defines a single product (i.e. stem cell product) as **cells collected from a single donor using the same mobilization cycle and collection method regardless of the number of collection days.**

**If a single product is infused, then complete a single (i.e. one) Form 2006**. For more information, see Example 1 and Table 1 below.

**Example 1 – Multiple Bags:** A GCSF-stimulated donor had two PBSC collections on subsequent days. The products collected over the two days were divided into four bags. Although the product is contained in multiple bags, this collection is considered a single product, as there was no change in mobilization technique or collection method. Therefore, one Form 2006 should be submitted.

**Example 2 – Change in Mobilization:** A GCSF-stimulated donor had a PBSC collection, but the cell count was poor. Plerixafor (Mozobil) was added as part of the mobilization and the donor was recollected the following day. As the change in mobilization occurred during the same mobilization cycle, these collections are considered a single product. Therefore, a single Form 2006 should be completed.

**Multiple Products:** For the purposes of this manual, the CIBMTR defines multiple products as cells collected using more than one donor, mobilization technique, and/or collection method.

**If a multiple products are infused, then multiple (i.e. two or more) Form 2006s must be completed.** For more information, see Examples 2-5 and Table 1 below.

**Example 3 – Double Cord Blood Units:** A recipient receives an infusion of two cord blood units. Two Form 2006s must be submitted as each cord blood unit is from a different donor.

**Example 4 – Multiple Collection Methods:** A GCSF-stimulated donor had a PBSC collection and the product was cryopreserved. One month later, the donor had a marrow collection and both products were infused at the time of transplant. Each collection is considered a separate product because different collection methods were used. Two Form 2006s must be submitted as these products were collected using two different methods.

**Example 5 – Re-Mobilization:** A GCSF-stimulated donor had a PBSC collection, but cell count was poor. No further collections were attempted and a week later the donor was re-mobilized with GCSF and a second PBSC collection was performed. Each collection is considered a separate product due to the re-mobilization of the recipient.

**Table 1. Single Product vs. Multiple Products**

| Definition | Number of Form 2006s Required: |
|---|---|
Single ProductAll of the following criteria must be met: • Single donor/cell source • Single mobilization event (collection) • Single collection method |
One |
Multiple Products One or more of the following criteria must be met: • Multiple donors/cell sources • Multiple mobilization events (collections) • Multiple collection methods |
Multiple – one to represent each donor/cell source, mobilization method, and/or collection method |

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for any of the appendices, please reference the retired appendix on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/8/21 | Appendix E: Definition of a Product | Modify | Graphic below the “Single Product vs Multiple Products” was added and examples 1 – 5 were update. |
| 6/30/17 | Appendix E: Definition of a Product | Modify | Appendix P: Definition of a Product has been renamed as Appendix E: Definition of a Product. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)