#### Question 29-42: Laboratory studies at diagnosis

These questions are intended to determine liver function at the time of VOD/SOS diagnosis. Report testing performed on the date of diagnosis. If testing was not performed on the date of diagnosis, report the closest assessment performed prior to diagnosis.

For each laboratory study, report “known” if testing was performed at the time of diagnosis and indicate the result as well as the date testing was performed. Report “unknown” if testing was not performed or the results are not available.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)