#### Question 1: What was the date of diagnosis?

Juvenile myelomonocytic leukemia (JMML) is characterized by multiple clinical and laboratory features, rather than distinct pathological characteristics. As such, the date of diagnosis should be the date of the last assessment used to establish a diagnosis of JMML.

#### Table 1. Diagnostic Criteria for JMML

| Category | Criteria |
|---|---|
Category 1 All Category 1 criteria plus additional Category 2 or Category 3 criteria are required to establish a diagnosis of JMML. |
|
Category 2 All Category 1 traits plus at least one Category 2 trait can establish a diagnosis of JMML. |
|
Category 3All Category 1 traits plus at least two Category 3 traits can establish a diangosis of JMML in the absence of any Category 2 traits. |
|

In order to establish a diagnosis of JMML, all of the category 1 criteria must be met. In addition, the patient must meet at least *one* category 2 criterion or at least *two* category 3 criteria. Report the date of sample collection for the last required assessment used to establish the diagnosis for JMML.

**Example**: Patient has absolute peripheral monocytosis of 3.2 × 109/L with palpable splenomegaly. On April 19, 2007, patient has a bone marrow biopsy and aspirate that show 2% blasts. On May 12, 2007, a peripheral blood sample is drawn and sent for BCR/ABL and PTPN11 molecular studies. On May 27, 2007, the lab results come back showing no BCR/ABL gene fusion but the presence of a PTPN11 gene mutation. The physician meets with the family to explain the diagnosis of Juvenile Myelomonocytic Leukemia (JMML) on June 7, 2007.

The reported date of diagnosis would be ** May 12, 2007**.

#### Specify whether the recipient expressed the following clinical features at diagnosis:

For questions 2-6, report the patient’s status at diagnosis or prior to first therapy. Include supportive measures such as leukapheresis and 13-cis-retinoic acid as first therapy for the purposes of establishing clinical features at diagnosis.

#### Question 2: Adenopathy

Indicate if the patient had clinical adenopathy at diagnosis or prior to first therapy. Adenopathy refers to enlargement of lymph nodes and may be established by physical examination or imaging.

#### Question 3: Hepatomegaly

Indicate if the patient had palpable hepatomegaly at diagnosis or prior to first therapy. Hepatomegaly refers to enlargement of the liver and should be established on physical exam; hepatomegaly is defined as the liver edge being palpable more than three centimeters below the right costal margin. Hepatomegaly may be confirmed by imaging.

#### Question 4: Neurofibromatosis

Indicate if the patient had neurofibromatosis of any type at diagnosis or prior to first therapy. Neurofibromatosis refers to the abnormal proliferation of neural crest cells that form tumors. The most common type of neurofibromatosis is type 1, also known as von Recklinghausen disease, which is an autosomal dominant genetic disorder characterized by neurofibromas, skeletal abnormalities, café au lait spots, Lisch nodules, freckling in the axilla or groin, and/or optic nerve glioma.

#### Question 5: Skin involvement

Indicate if the patient had skin involvement at diagnosis or prior to first therapy. Skin involvement may clinically be characterized by edematous or erythematous lesions, or generalized rash. Do not report petechiae or pallor as skin involvement.

#### Question 6: Splenomegaly

Indicate if the patient had palpable splenomegaly at diagnosis or prior to first therapy. Splenomegaly refers to enlargement of the spleen and should be established on physical exam; splenomegaly is defined as the spleen being palpable more than three centimeters below the left costal margin. Splenomegaly may be confirmed by imaging.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)