Chronic lymphocytic leukemia (CLL) is a cancer of the B lymphocytes. B lymphocytes are white blood cells that develop in the bone marrow and circulate throughout the blood to fight infection. In CLL, lymphocytes with damaged DNA proliferate within the blood, accumulating in the bone marrow, lymph nodes, and organs. The damaged lymphocytes do not fight infections as well as healthy lymphocytes. Symptoms of CLL are generally caused by the replacement of healthy blood cells (including red blood cells and white blood cells) with leukemic cells in the bone marrow and lymph nodes. Symptoms include frequent infections, fever, fatigue, splenomegaly, night sweats, etc.

Small lymphocytic lymphoma (SLL) describes the condition in which abnormal lymphocytes with the same morphology and immunophenotype as CLL present primarily in the lymph nodes.

Hairy cell leukemia is similar to CLL, but the lymphocytes have a distinct “hairy” appearance under the microscope.

Prolymphocytic leukemias are identified by the presence of abnormal prolymphocytes, the precursor to lymphocytes. These leukemias are more aggressive and are split into two subtypes: B-cell prolymphocytic leukemia and T-cell prolymphocytic leukemia.

[CLL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-response-criteria)

[2013: CLL Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2013-cll-pre-hct)

[2113: CLL Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-post-hct)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)