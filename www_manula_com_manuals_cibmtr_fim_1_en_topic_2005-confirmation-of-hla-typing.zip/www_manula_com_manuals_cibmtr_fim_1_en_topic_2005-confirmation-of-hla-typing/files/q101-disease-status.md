#### Question 148: What is the status of sickle cell disease at the time of this report, or at the time of death?

Report the status of the recipient’s sickle cell disease based on the Hb S and clinical symptoms at the time of evaluation, or death, for this reporting period. The term “clinical symptoms” refers to the clinical complications captured above (i.e., vaso-occlusive pain, acute chest syndrome, avascular necrosis, etc.). See below for additional details regarding the available disease status options:

**Hb electrophoresis (Hb S) ≤ 50% and clinical symptoms described are absent:**The Hb S value at the time of evaluation for the current reporting period is ≤ 50% (reported above), the clinical symptoms are absent, and the recipient is not receiving disease modifying agents.**Hb S > 50% and clinical symptoms described are absent:**The Hb S value at the time of evaluation for the current reporting period is > 50% (reported above), the clinical symptoms are absent, and the recipient is not receiving disease modifying agents.**Hb S > 50% and clinical symptoms described are present:**The Hb S value at the time of evaluation for the current reporting period is > 50% (reported above), the clinical symptoms are present, and the recipient is not receiving disease modifying agents.**Recipient is receiving disease modifying therapy:**Select this disease response option if the recipient is still receiving disease modifying agents on the date of contact for the current reporting period, regardless of if improvement was observed in Hb S values.

If therapy was discontinued prior to the contact date and Hb S was not re-assessed, report the disease status as either **Hb S > 50% and clinical symptoms described are absent** or **Hb S > 50% and clinical symptoms described are present** based on the absence or presence of clinical symptoms.

If the Hb S is ≤ 50% but clinical symptoms are present, leave the data field blank, override the FormsNet3SM error with “unable to answer,” and explain the Hb S is ≤ 50%; however, clinical symptoms are present in the comment section.

If it is unclear whether clinical symptoms are still present at the time of evaluation for the current reporting period, confirm with the attending physician.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)