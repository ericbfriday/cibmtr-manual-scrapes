This form must be completed for each product infused for Gene Therapy recipients. The Gene Therapy Product (2003) Form is designed to capture product specific information for all infusions given to a recipient as a course of gene therapy. The form captures product identifiers, collection, processing/manipulation, and analysis details, as well as infusion detail.

A separate form should be completed for a single product. Examples of single products include:


- PBSC collected from a single mobilization event (a mobilization event is the planned administration of growth factors or systemic therapy designed to enhance stem cell collection), even when collected over several days, is considered one product.
- multiple mobilizations, and possibly multiple manufacturing steps, required for the final product intended for infusion. The number of mobilizations will be reported on the form

For more information see [ Appendix D – How To Distinguish Infusion Types](https://www.cibmtr.org/manuals/fim/1/en/topic/appendix-d) and

[.](https://www.cibmtr.org/manuals/fim/1/en/topic/appendix-e)

**Appendix E – Definition of a Product**Links to Sections of Form:

[Q1 – 6: Product Identification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-5)

[Q7 – 15 : Product Collection](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q6-12-product-collection)

[Q16 – 32: Product Processing / Manipulation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q13-29-product-processing-manipulation)

[Q33 – 71: Product Analysis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q30-68-product-analysis-all-products)

[Q72 – 81: Product Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q69-75-product-infusion)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the ** Retired Forms Manuals** of the CIBMTR Forms Instruction Manual is intended to be a resource for completing the Gene Therapy Product Form.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/2025 |
|

[2003: Gene Therapy Product](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4006)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)