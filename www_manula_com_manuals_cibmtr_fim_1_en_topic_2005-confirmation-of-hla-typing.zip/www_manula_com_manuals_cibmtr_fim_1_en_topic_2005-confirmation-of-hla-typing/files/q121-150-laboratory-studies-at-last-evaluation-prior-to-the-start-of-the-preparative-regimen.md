These questions are intended to determine the status of the recipient prior to the preparative regimen. Testing may be performed multiple times within the pre-transplant workup period (approximately 30 days) prior to the start of the preparative regimen; report the most recent laboratory value. Laboratory values obtained on the first day of the preparative regimen may be reported as long as the sample was drawn before any radiation or systemic therapy was administered.

#### Questions 121-122: Absolute lymphocyte count

Indicate whether the lymphocyte count was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 122. If “unknown,” continue with question 123.

#### Questions 123-124: Bone marrow aspirate (examined for histologic involvement)

Indicate whether the extent of histologic involvement in the bone marrow aspirate was “known” or “unknown” immediately prior to the start of the preparative regimen. If bone marrow aspirate was not examined, report “not applicable.” If “known,” report the extent of aspirate histologic involvement in question 124. If “unknown” or “not applicable,” continue with question 125.

#### Questions 125-126: Bone marrow biopsy (examined for histologic involvement)

Indicate whether the extent of histologic involvement in the bone marrow biopsy was “known” or “unknown” immediately prior to the start of the preparative regimen. If bone marrow biopsy was not examined, report “not applicable.” If “known,” report the extent of biopsy histologic involvement in question 126. If “unknown” or “not applicable,” continue with question 127.

#### Questions 127-128: Serum ß2 macroglobulin

Indicate whether ß2 microglobulin was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 128. If “unknown,” continue with question 129.

#### Questions 129-130: Relative serum viscosity

Hyperviscosity syndrome is a common manifestation of WM and LPL. Indicate if relative serum viscosity was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory value in question 130. If “unknown,” continue with question 131.

#### Questions 131-132: Serum monoclonal protein (M-spike) (only from electrophoresis)

Indicate whether serum monoclonal protein quantification from electrophoresis was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory value and unit of measure in question 132. If serum electrophoresis was done and did not show monoclonal protein, report “0.” If “unknown,” continue with question 133.

#### Questions 133-134: Urinary monoclonal protein (M-spike)

Indicate whether 24-hour urine monoclonal protein quantification from electrophoresis was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory value in question 134. If urine electrophoresis was done and did not show monoclonal protein, report “0.” If “unknown,” continue with question 135.

#### Question 135: Cold agglutinins

Cold agglutinin disease is a common manifestation of WM and LPL. Cold agglutinins are autoantibodies that bind to the red blood cells, manifesting as autoimmune hemolytic anemia. Indicate if cold agglutinins were “positive” or “negative” immediately prior to the start of the preparative regimen. If cold agglutinins were not tested or it is unknown if cold agglutinins were tested, report “unknown.”

#### Question 136: Cryoglobulin

Cryoglobulins are immunoglobulins that aggregate as a gel at temperatures below 37°C. Cryoglobulins may be mixed immunoglobulins or a single component; the majority of cryoglobulin in WM or LPL patients will be mixed IgM-IgG. Indicate if cryoglobulin was “present” or “absent” immediately prior to the start of the preparative regimen. If cryoglobulin was not tested or it is unknown if cryoglobulin was tested, report “unknown.”

#### Questions 137-139: IgG

Indicate whether IgG level was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory value and unit of measure in question 138; report the laboratory upper limit of normal value and unit of measure in question 139. If “unknown,” continue with question 140.

#### Questions 140-142: IgA

Indicate whether IgA level was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory value and unit of measure in question 141; report the laboratory upper limit of normal value and unit of measure in question 142. If “unknown,” continue with question 143.

#### Questions 143-145: IgM

Indicate whether IgM level was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the laboratory value and unit of measure in question 144; report the laboratory upper limit of normal value and unit of measure in question 145. If “unknown,” continue with question 146.

#### Question 146: Were cytogenetics tested (conventional or FISH)?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality that reflects the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) and fluorescence *in situ* hybridization (FISH) testing. For more information about cytogenetic testing and terminology, see [Appendix C](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Indicate if cytogenetic studies were obtained immediately prior to the start of the preparative regimen.

If cytogenetic studies were obtained, check “yes” and continue with question 147.

If cytogenetic studies were not obtained or it is unknown if chromosome studies were performed, indicate “no” or “unknown” and continue with question 151.

#### Question 147: Results of tests

If cytogenetic studies identified abnormalities (any karyotype other than 46XX or 46XY), indicate “abnormalities identified” and continue with question 148.

If cytogenetic studies yielded no evaluable metaphases or there were no abnormalities identified, indicate this and continue with question 151.

#### Question 148-150: Specify abnormalities

Deletion of the long arm of chromosome 6 is the most common structural abnormality in WM and LPL. However, other structural and numeric abnormalities have been noted.

If question 147 indicates that abnormalities were identified immediately prior to the start of the preparative regimen, questions 148-149 must be answered as “yes” or “no.” Do not leave either response blank. If the patient had any abnormality other than del(6q), select “yes” for “other abnormality,” and specify in question 150.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)