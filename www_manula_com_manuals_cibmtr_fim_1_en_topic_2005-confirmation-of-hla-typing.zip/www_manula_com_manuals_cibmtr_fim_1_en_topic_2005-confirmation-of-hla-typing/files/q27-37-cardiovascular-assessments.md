#### Figure 1: Echogcardiogram

#### Questions 25 – 27: Was left ventricular ejection fraction (LVEF) or left ventricular shortening fraction reported?

The left ventricular ejection fraction (LVEF) is a percentage that represents the volume of blood pumped from the left ventricle into the aorta (also known as stroke volume) compared to the volume of blood in the ventricle just prior to the heart contraction (also known as end diastolic volume). The left ventricular shortening fraction is the percentage change in cavity dimensions of the left ventricle with systolic contraction. The LVEF and left ventricular shortening fraction are assessed via an echocardiogram. Refer to Figure 1 above for an example of an echocardiogram report.

Report **Yes** if either LVEF or left ventricular shortening fraction was assessed at any time prior to start of the preparative regimen / infusion and provide the percentage(s). If the LVEF and left ventricular shortening fraction were assessed, report the results of both. If the LVEF or left ventricular shortening fraction were assessed multiple times prior to the start of the preparative regimen / infusion, report the most recent value(s).

Report **No** if the LVEF and left ventricular shortening fraction were not assessed.

#### Questions 28 – 29: Is there evidence of pulmonary hypertension?

Pulmonary hypertension (PH) refers to elevated pulmonary arterial pressure and is diagnosed either by an echocardiogram or right heart catheterization. PH can be due to a primary elevation of pressure in the pulmonary arterial system alone (pulmonary arterial hypertension), or secondary to elevations of pressure in the pulmonary venous and pulmonary capillary systems (pulmonary venous hypertension; post-capillary PH).

Indicate **Yes** if the recipient had evidence of PH at any time between diagnosis and the start of the preparative regimen and indicate which method was used to diagnose PH. Report **No** if the recipient did not have evidence of PH at any time between diagnosis and the start of the preparative regimen.

#### Question 30: Is a copy of the echocardiogram report attached?

Indicate whether the echocardiogram report is attached to this form. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Questions 31 – 32: Cardiac iron T2 imaging (found on MRI results)

Cardiac T2* mapping is a noninvasive MRI method that is used to identify myocardial iron accumulation in several iron storage diseases. If **Known**, report the unit of measure from the MRI results in m/sec.

#### Questions 33 – 34: Was brain natriuretic peptide (BNP) assessed?

Brain natriuretic peptide (BNP) is a hormone secreted by cardiac ventricle cells in response to increased ventricular blood volume. BNP is typically measured using various immunoassay techniques. Confirm with the attending physician on where to locate immunoassay results measuring BNP, if available.

Indicate if the BNP was assessed at any time between diagnosis and the start of the preparative regimen. If **Yes**, report the value as documented on the laboratory report (in pg / mL). If BNP was assessed multiple times, report the results of the most recent test. If BNP was not assessed or if no information is available to determine if BNP was tested, report **No** or **Unknown**, respectively.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)