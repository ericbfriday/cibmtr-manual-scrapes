#### Question 33: Specify the timepoint in the product preparation phase that the product was analyzed

Report the time in the product preparation phase the product was analyzed. A maximum of three timepoints may be reported. Each timepoint can only be reported once.

**Fresh manipulated product:**Assessment of a*fresh manipulated*product. This will usually be performed at the manufacturing / processing site**Prior to cryopreservation of manipulated product plus additives:**Assessment of a*fresh manipulated*product, plus additives. This will usually be performed at the manufacturing / processing site**Post-thaw of cryopreserved manipulated product:**Assessment of the cryopreserved, manipulated product after thawing. This will usually be performed at the transplant center prior to infusion of the product

#### Question 34: Date of product analysis

Report the date (YYYY-MM-DD) when the product was analyzed for each timepoint reported. The date of product analysis is not necessarily the date of the product infusion.

#### Question 35: Total volume of product plus additives

Enter the total volume of the product plus additives in the bag(s) for the reported timepoint. Report the volume in milliliters (mL), one decimal place is allowed.

#### Questions 36 – 37: CD34+ cells

Indicate if the CD34+ cells were quantified at the reported timepoint. If **Done**, report the absolute number of CD34+ cells for the specified timepoint. Do not report cells per kilogram. If the CD34+ cells were not quantified for the specific timepoint, select **Not done** and continue with *Other cell type*.

#### Questions 38 – 39: Viability of CD34+ cells

If the viability of the CD34+ cells was quantified, select **Done** and report the percentage of viable cells. If the viability was **Not done**, continue with *Other cell type*.

Select **Unknown** if there is no documentation to confirm if viability was performed.

If the laboratory assay only measures CD34+ viable cells, report the number of viable CD34+ cells above, select **Done** for the *Viability of CD34+ cells*, and report a viability of **100%**.

#### Questions 40 – 41: Method of testing CD34+ cell viability

Indicate the method of testing viability

**Flow cytometry based:**7-AAD (7-aminoactinomycin D) and propidium iodide are compounds that can stain dead cells but will not cross the membrane of living cells. Cytometric techniques are used to calculate the percentage of viable cells in a sample.**Trypan blue:**a technique where the dead cells become stained when in contact with the compound, but living cells remain impermeable to the dye. Cells are counted under a microscope to determine the percentage of viable cells in a sample.**Other method:**If the cell viability was tested using a different method, select this option and specify the method.

#### Questions 42 – 43: Other cell type

Indicate if an **Other** cell type was quantified at the reported timepoint. If **Done**, report the total number of “other” cell types tested. The maximum number of cell types that can be reported is four. The number of cell types reported will enable the appropriate number of instances in FormsNet3SM.

If no “other” cell types were quantified at the reported timepoint, select **Not done** and continue with Product Infusion

#### Questions 42 – 67: Specify other cell types

For each cell type, a separate instance will be enabled. Specify the “other” cell type quantified at the reported timepoint and report the absolute number of cells. Do not report cells per kilogram.

Additionally, indicate if the viability of the “other” cell(s) was quantified. If **Done**, report the viability percent of cells and specify the method of testing for viability. For commercial products, the viability will be performed at the manufacturing site and this information may or may not be reported to the transplant center.

**Flow cytometry based**: 7-AAD (7-aminoactinomycin D) and Propidium iodide are compounds that can stain dead cells but will not cross the membrane of living cells. Cytometric techniques are used to calculate the percentage of viable cells in a sample.**Trypan blue**: a technique where the dead cells become stained when in contact with the compound, but living cells remain impermeable to the dye. Cells are counted under a microscope to determine the percentage of viable cells in a sample.**Other method**: If the cell viability was tested using a different method, select this option and specify the method.

Select **Unknown** if there is no documentation to confirm if viability was performed.

A vector copy number (VCN) is the number of vector copies per diploid genome. This information may be available from a clinical study protocol or information that comes with the product. Indicate if the VCN of the infused product is **Known** or **Unknown**. If **Known**, report the VCN.

#### Questions 70 – 71: Percentage of gene edited cells in the infused product

When a product is genetically modified by gene editing, the percentage of gene edited cells maybe be known. This information may be available from a clinical study protocol or information that comes with the product. Indicate if the percentage of gene edited cells in the infused product is **Known** or **Unknown**. If **Known**, report the percentage of gene edited cells.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)