#### Question 13: Specify the spleen size

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam. If there are multiple measurements, report the most recent value.

If the spleen size was not assessed by a physical exam in the current reporting period, leave the data field blank and override the FormsNetSM error.

#### Question 14: Specify the spleen size

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI). If there are multiple measurements, report the most recent value.

If imaging to assess the spleen size was not completed in the current reporting period, leave the data field blank and override the FormsNet3SM error.

#### Question 15: Specify the spleen volume

**This question is optional.**

The spleen volume can be calculated using the spleen measurements obtained from a CT / MRI and the standard prolate ellipsoid formula.

Specify the spleen volume in the current reporting period, as documented by the physician. If the spleen volume is not documented, seek physician clarification. Data managers should not calculate the spleen volume. If there are multiple scans, report the spleen volume using the most recent scan prior to the initiation of hypertransfusion.

If a scan was not completed in the reporting period or the physician determines the spleen volume cannot be calculated, leave the data field blank.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)