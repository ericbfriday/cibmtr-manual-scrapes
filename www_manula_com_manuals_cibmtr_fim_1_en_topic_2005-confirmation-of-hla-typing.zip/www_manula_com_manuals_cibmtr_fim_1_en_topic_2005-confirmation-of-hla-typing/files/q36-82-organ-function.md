#### Questions 36 – 82: Organ Function

This section of the form compliments the organ function section of the Post-HCT Follow Up Data Form, F2100.

**Hypersensitivity**

Clinically significant hypersensitivity reactions, including anaphylaxis, have occurred following administration of TEPADINA. Hypersensitivity may include shortness of breath, hypotension, dizziness, and possibly syncope.


- Grade 1: systemic intervention not indicated
- Grade 2: oral intervention indicated
- Grade 3: Bronchospasm; hospitalization indicated for clinical sequelae; intravenous intervention indicated
- Grade 4: life-threatening consequences; urgent intervention indicated

**Infertility**

Described as fertility impairment, ovarian functions impairment, or spermatogenesis impairment.

**Pulmonary arterial hypertension (PAH)**

High blood pressure in the arteries of the lungs. PAH occurs when the very small arteries throughout the lungs narrow in diameter, which increases the resistance to blood flow through the lungs.

**Erythematous rash / toxic skin reaction**

Symptoms-

Erythematous rash: abnormal redness and inflation of the skin

Flushing: sudden redness of the skin

Photosensitivity: A disorder characterized by an increase in sensitivity of the skin to light

Stevens-Johnson syndrome / Toxic epidermal necrolysis: a severe allergic drug reaction


- Painful Blistering of the skin and mucous membrane involvement. Typical symptoms for both diseases include peeling skin, fever, body aches, a flat red rash, and blisters and sores on the mucous membranes.
- Ocular involvement includes severe conjunctivitis, iritis, palpebral edema, conjunctival and corneal blisters and erosions, and corneal perforation.
- Stevens-Johnson syndrome causes only small areas of peeling skin (affecting less than 10% of the body).
- Toxic epidermal necrolysis causes large areas of peeling skin (affecting over 30% of the body).

**Grade 3-4 elevation of AST, ALT, and/or bilirubin**

AST (Aspartate aminotransferase increased): A finding based on laboratory test results that indicate an increase in the level of aspartate aminotransferase (AST or SGOT) in a blood specimen.


- Grade 3: >5.0 – 20.0 x ULN if baseline was normal; >5.0 – 20.0 x baseline if baseline was abnormal
- Grade 4: >20.0 x ULN if baseline was normal; >20.0 x baseline if baseline was abnormal

ALT (Alanine aminotransferase increased): A finding based on laboratory test results that indicate an increase in the level of alanine aminotransferase (ALT or SGPT) in the blood specimen.


- Grade 3: >5.0 – 20.0 x ULN if baseline was normal; >5.0 – 20.0 x baseline if baseline was abnormal
- Grade 4: >20.0 x ULN if baseline was normal; >20.0 x baseline if baseline was abnormal

Bilirubin (Blood bilirubin increased): A finding based on laboratory test results that indicate an abnormally high level of bilirubin in the blood. Excess bilirubin is associated with jaundice.


- Grade 3: >3.0 – 10.0 x ULN if baseline was normal; >3.0 – 10.0 x baseline if baseline was abnormal
- Grade 4: >10.0 x ULN if baseline was normal; >10.0 x baseline if baseline was abnormal

**Leukoencephalopathy**: A disorder characterized by diffuse reactive astrocytosis with multiple areas of necrotic foci without inflammation.

**Other neurological toxicity**: F2100 captures CNS hemorrhage, encephalopathy (non-infectious), neuropathy, seizures, and stroke. The intent of this question to capture other neurological impairments outside of those options.

**Confusion / delirium**:


- Confusion: A disorder characterized by a lack of clear and orderly thought and behavior.
- Delirium: A disorder characterized by the acute and sudden development of confusion, illusions, movement changes, inattentiveness, agitation, and hallucinations. Usually, it is a reversible condition.

**Hallucination**: A disorder characterized by a false sensory perception in the absence of an external stimulus.

Hemorrhage: severe bleeding, other than cerebral, diffuse alveolar or CNS hemorrhage (captured on 2100).

**Cerebral hemorrhage**:

A disorder characterized by bleeding of the brain.

Date of onset: for each impairment / disorder, report the date the disorder / impairment was first documented by a physician or other health care provider in the progress note or chart.

**In the transplant physician’s judgement, was the disorder / impairment a direct result of the Tepadina administration?**

For each impairment / disorder, indicate if the medical director believes the disorder / impairment to be directly related to the infusion of the drug.

**Was this disorder / impairment a serious event?**

An event is serious if one of the following applies:


- Death (the event is the cause of death);
- Life-threatening (i.e., immediate risk of death);
- In-patient hospitalization or prolongation of existing hospitalization;
- Persistent or significant disability / incapacity;
- Congenital anomaly / birth defect;
- Important medical events

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)