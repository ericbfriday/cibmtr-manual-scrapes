#### Questions 1 & 2: Tepadina® stop date

Indicate if Tepadina® stop date is “Known” or “Unknown” in question 1. Start date is reported on F2400 in the conditioning regimen section. Report the final administration date of Tepadina® in question 2. If the stop date is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy stopped is “Unknown,” go to question 3.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Dec 22, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)