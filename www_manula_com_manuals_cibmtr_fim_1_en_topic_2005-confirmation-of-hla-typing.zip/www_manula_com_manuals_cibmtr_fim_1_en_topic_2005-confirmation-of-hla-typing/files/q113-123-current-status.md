#### Question 113-115: Recipient weight (most recent)

Report “known” if the recipient’s weight was evaluated during the reporting period. If known, report the most recent weight documented during the reporting period and the date the measurement was taken. If the recipient’s weight was not evaluated during the reporting period, report “unknown” and continue with question 116.

#### Question 116-118: Total serum bilirubin

Report “known” if total serum bilirubin was evaluated during the reporting period. If known, report the most recent testing performed during the reporting period and the date of the sample was taken. If total serum bilirubin was not evaluated during the reporting period, report “unknown” and continue with question 119.

#### Question 119-121: Serum creatinine

Report “known” if serum creatinine was evaluated during the reporting period. If known, report the most recent testing performed during the reporting period and the date the sample was taken. If serum creatinine was not evaluated during the reporting period, report “unknown” and continue with question 122.

#### Question 122-123: Specify the oxygen requirements: (at date of last contact)

Report the amount of oxygen support required on the date of contact.

If reporting “other oxygen requirement,” specify the type of oxygen support administered in question 123.

#### Question 124-125: Did VOD / SOS resolve?

Indicate whether VOD/SOS resolved during the current reporting period. The guidelines for determining whether a complete resolution was achieved are available in the instructions for [question 56](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q43-98-therapy#Q56-57) . If VOD/SOS symptoms resolved, continue with question 125. If VOD/SOS did not resolve during the reporting period, continue with question 146.

If VOD/SOS symptoms resolved and then returned less than 30 days later, report “no” for question 124 and continue with question 146.

If VOD/SOS resolved and recurred during the current reporting period, report “Yes” for question 124 and continue with question 125. For reporting purposes, recurrence of VOD/SOS is defined as a subsequent clinical diagnosis after demonstrating a complete resolution of all symptoms.

#### Question 126-127: Did VOD / SOS symptoms recur?

If a subsequent VOD/SOS clinical diagnosis was made following a complete resolution, report “yes” and continue with question 127. Otherwise, report “no” and continue with question 146.

#### Question 128-134: VOD / SOS symptoms at recurrence

Report “yes” for any symptoms documented at the time of recurrence.


**Increased bilirubin**: ≥2.0 mg/dL (34 µmol/L)**Ascites**: Accumulation of fluid in the space between the lining of the abdomen and the abdominal organs (peritoneal cavity).**Weight gain**: Greater than 2% increase in the recipient’s weight compared to their weight prior to the onset of symptoms.**Hepatomegaly**: Abnormal enlargement of liver.**Right upper quadrant pain**: One of the clinical features that may be associated with the onset of VOD/SOS.

#### Question 135-145: Was therapy given for recurrent VOD / SOS?

Report “yes,” if any treatment was given for the recurrence of VOD/SOS. If “yes,” specify any treatment given during the reporting period in questions 136-145. If “no,” continue with question 146.

If the recipient received a therapy other than the drugs listed, report “yes” for “other drug” and specify the treatment(s) in question 145.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)