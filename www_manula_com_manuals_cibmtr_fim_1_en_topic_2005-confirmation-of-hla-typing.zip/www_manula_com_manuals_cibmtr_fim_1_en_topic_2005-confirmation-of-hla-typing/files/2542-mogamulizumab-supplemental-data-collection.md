The Mogamulizumab Supplemental Data Collection Form (Form 2542) is designed to support a retrospective and prospective, multicenter, observational registry of patients treated with mogamulizumab alone or in combination, within one year prior to allogeneic hematopoietic cell transplantation (allo HCT) or treated with mogamulizumab, alone or combination, within 18 months after HCT.

The Mogamulizumab Supplemental Data Collection Form will come due for all recipients enrolled on the study irrespective of Mogamulizumab administration status. This includes recipients on the Case arm, those who received Mogamulizumab one year prior to or 18 months post allo HCT and recipients on the Control arm, those who satisfy the study eligibility criteria except Mogamulizumab administration. The 2400 and 2402 will confirm eligibility, this includes event date, age at event, disease subtype, and type of infusion. Once eligibility is confirmed, the 2500 and 2542 will come due for all recipients.

The 2118 will capture if Mogamulizumab was used post-transplant at 100 days, 6 months, 12 months and 2 years post-transplant. If the use of Mogamulizumab post-transplant is indicated on any 2118, the 2542 will become due.

Links to Pages of Mogamulizumab Supplemental Data Collection Section of Forms Instruction Manual

[Q1 – 3: Complications of Interest](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-3-complications-of-interest)

[Q4 – 12: Post-Infusion Critical Illness](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q4-9-post-infusion-critical-illness)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals webpage](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx).

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/26/2024 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)