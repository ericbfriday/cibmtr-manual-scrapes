#### Complete Response (CR)[1](#fn35457993868596aa9868a4-1)

[1](#fn35457993868596aa9868a4-1)

All of the following:


- No evidence of lymphadenopathy
[2](#fn35457993868596aa9868a4-2) - No organomegaly
- Neutrophils ≥ 1.5 × 10
9/L - Platelets > 100 × 10
9/L - Hemoglobin > 11 g/dL
- Lymphocytes < 4 × 10
9/L - Bone marrow < 30% lymphocytes
- Absence of constitutional symptoms (including weight loss, fever, and night sweats)

1 Hallek, M., Cheson, B. D., Catovsky, D., Caligaris-Cappio, F., Dighiero, G., Döhner, H., … & Kipps, T. J. (2008). Guidelines for the diagnosis and treatment of chronic lymphocytic leukemia: a report from the International Workshop on Chronic Lymphocytic Leukemia updating the National Cancer Institute–Working Group 1996 guidelines. *Blood*, 111(12), 5446-5456.

2 Absence of significant lymphadenopathy (e.g., lymph nodes > 1.5 cm in diameter) by physical examination. In clinical trials, a CT scan of the abdomen, pelvis, and thorax is desirable if previously abnormal. Lymph nodes should not be larger than 1.5 cm in diameter.

#### Partial Response (PR)

All of the following, if applicable:


- ≥ 50% decrease in peripheral blood lymphocyte count from pretreatment value
- ≥ 50% reduction in lymphadenopathy if present pretreatment
- ≥ 50% reduction in liver and/or spleen size if enlarged pretreatment

In addition, one or more of the following:


- Neutrophils ≥ 1.5 ×10
9/L or 50% improvement over baseline - Platelets > 100 ×10
9/L or 50% improvement over baseline - Hemoglobin > 11 g/dL or 50% improvement over baseline

#### Stable Disease (SD)

No change (not complete response, partial response, or progressive disease)

#### Progressive Disease (Prog)

One or more of the following:


- ≥ 50% increase in the sum of the products of ≥ 2 lymph nodes (≥ 1 lymph node must be ≥ 2 cm) or new nodes
- ≥ 50% increase in liver or spleen size, or new hepatomegaly or splenomegaly
- ≥ 50% increase in absolute lymphocyte count to ≥ 5 ×10
9/L - Transformation to a more aggressive histology

*Report relapse from CR using this response indicator.*

#### Untreated

No chemotherapy given in the six months prior to the HCT

#### Not Assessed

No evaluation performed

Source: Cheson BD, Bennett JM, Greever M, Kay N, Keating MJ, O’Brien S, Rai KR. National Cancer Institute-Sponsored Working Group guidelines for chronic lymphocytic leukemia: revised guidelines for diagnosis and treatment. *Blood* 1996 87(12):4990-7.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2013.CLL%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/23/17 | CLL Response Criteria | Remove | Removed criteria for Nodular Partial Remission as this disease status is no longer captured on the forms. |
| 3/5/15 | CLL Response Criteria | Add | The disease status criteria for CLL, formerly available in the Pre-TED section of the Forms Instruction Manual, has been moved to a new section of the manual titled CLL Response Criteria. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)