# Q108-127: Clinical Features and Laboratory Studies At Last Evaluation Prior to the Start of the Preparative Regimen

#### Question 108: Anemia (Hgb < 9 g/dL):

Indicate if the recipient had anemia at the last evaluation prior to the start of the preparative regimen. Anemia is defined as hemoglobin less than 9 g/dL. Select “yes,” “no,” or “unknown.”

#### Question 109: Degranulation assay of NK cells (as defined by local laboratory):

Degranulation in natural killer (NK) cells is the process by which NK cells release granules containing chemicals (perforin and granzymes) that are used to destroy targeted cells. In some subtypes of FHL (FHL3, 4, and 5), degranulation of NK cells is absent or abnormally low. A granule release assay (GRA) can be used to assess the degranulation indirectly by measuring the expression of CD107a on the cell surface following stimulation. This expression is only detectable when the granules fuse with the cell membrane, thus the absence of CD107a by GRA would indicate a defect in some part of NK degranulation. Indicate if the results of degranulation assay of NK cells were “normal,” “abnormal,” or “unknown” at the last evaluation prior to the start of the preparative regimen.

#### Question 110: Fever (> 38.5° C or > 101.3° F for > 7 days):

Indicate if the recipient had fever at the last evaluation prior to the start of the preparative regimen. Fever is defined as a temperature above 38.5° C (101.3° F) for more than 7 days. Select “yes,” “no,” or “unknown.”

#### Question 111: Hepatomegaly (liver edge palpable > 3 cm below right costal margin):

Indicate if the recipient had hepatomegaly (enlargement of the liver) at the last evaluation prior to the start of the preparative regimen. Hepatomegaly is defined by the palpability of the liver edge 3 cm or more below the right costal margin. Indicate “yes,” “no,” or “unknown.”

#### Questions 112-113: Serum ferritin:

Indicate if the serum ferritin level was known at the last evaluation prior to the start of the preparative regimen. If “known,” indicate the value in question 113. If “unknown,” continue with question 114.

#### Questions 114-115: Triglycerides:

Indicate if the triglyceride level was known at the last evaluation prior to the start of the preparative regimen. If “known,” indicate the value in question 115. If “unknown,” continue with question 116.

#### Questions 116-117: Fibrinogen antigen assay (factor I; fibrinogen activity; functional fibrinogen; fibrinogen antigen):

Fibrinogen levels may be low in those with HLH. Indicate if a fibrinogen antigen assay (factor 1; fibrinogen activity; functional fibrinogen; fibrinogen antigen) level was known at the last evaluation prior to the start of the preparative regimen. If “known,” indicate the value (and corresponding unit) in question 117. If “unknown,” continue with question 118.

#### Question 118: NK cell function:

NK cell function is measured by a cytotoxicity assay.

NK cell function (cytotoxicity) may be absent or reduced in those with HLH. Indicate the NK cell function at the last evaluation prior to the start of the preparative regimen. Select “absent (≤ 10% lower limit of normal),” “decreased (11-50% lower limit of normal),” “normal,” or “unknown.”

#### Question 119: Neutropenia (ANC < 1.0 × 109/L):

Indicate if the recipient was neutropenic at the last evaluation prior to the start of the preparative regimen. Neutropenia is defined as an absolute neutrophil count (ANC) less than 1.0 × 109/L. Indicate “yes,” “no,” or “unknown.”

#### Question 120: Soluble interleukin-2 receptor alpha chain (sCD25) (as defined by local laboratory):

The presence of soluble interleukin-2 receptors (soluble IL-2R, sCD25) in the plasma indicates the activation of T cells. Elevated soluble IL-2R is indicative of prolonged T-cell activation, indicating a protracted immune response. Levels of soluble IL-2R differ based on age, so using age-based reference ranges is helpful to identify abnormal results. 1 Indicate the soluble IL-2R alpha chain level at diagnosis or prior to the start of therapy for HLH. The results of the test should be reported as defined by the local laboratory. Indicate if the soluble IL-2R alpha chain level was “normal,” “elevated,” or “unknown.”

1 Zhang K, Filipovich AH, Johnson J, et al. Hemophagocytic Lymphohistiocytosis, Familial. 2006 Mar 22 [Updated 2013 Jan 17]. In: Pagon RA, Adam MP, Bird TD, et al., editors. GeneReviews™ [Internet]. Seattle (WA): University of Washington, Seattle; 1993-2013.Accessed at: [http://www.ncbi.nlm.nih.gov/books/NBK1444/](http://www.ncbi.nlm.nih.gov/books/NBK1444/) on October 3, 2013.

#### Question 121: Splenomegaly (spleen palpable > 3 cm below left costal margin):

Indicate if the recipient had splenomegaly (enlargement of the spleen) at the last evaluation prior to the start of the preparative regimen. Splenomegaly is defined by the palpability of the spleen edge 3 cm or more below the left costal margin. Indicate “yes,” “no,” or “unknown.”

#### Question 122: Thrombocytopenia (platelets < 100 × 109/L):

Indicate if the recipient was thrombocytopenic at the last evaluation prior to the start of the preparative regimen. Thrombocytopenia is defined as a platelet count less than 100 × 109/L. Indicate “yes,” “no,” or “unknown.”

#### Question 123: Neopterin level:

The measurement of neopterin in the CSF is useful to determine immune system activity. Indicate the neopterin level in the cerebrospinal fluid (CSF) at the last evaluation prior to the start of the preparative regimen. Indicate “normal” or “elevated.” If an assessment of neopterin levels in the CSF was not done at the last evaluation prior to the start of the preparative regimen, select “not done.”

#### Question 124: Protein:

Indicate the protein level in the cerebrospinal fluid (CSF) at the last evaluation prior to the start of the preparative regimen. Indicate “normal” or “elevated.” If an assessment of protein levels in the CSF was not done at the last evaluation prior to the start of the preparative regimen, select “not done.”

#### Question 125: WBC count:

Indicate the WBC count in the cerebrospinal fluid (CSF) at the last evaluation prior to the start of the preparative regimen. Indicate “normal” if there were less than or equal to 5 cells/μL in the CSF. Indicate “elevated” if there were greater than 5 cells/μL in the CSF. If an assessment of WBC count in the CSF was not done at the last evaluation prior to the start of the preparative regimen, select “not done.”

#### Question 126: Were central nervous system (CNS) abnormalities found on computed tomography (CT or CAT) or magnetic resonance imaging (MRI) scans?

Indicate if radiology (CT, CAT, and/or MRI) detected any abnormalities in the central nervous system (brain and spinal cord) at the time of assessment prior to the preparative regimen. CNS abnormalities may include lesions, leptomeningeal enhancements, or edema.

If CNS abnormalities were detected on radiological examination, select “yes” and continue with question 127. If no CNS abnormalities were detected on radiological examination, select “no” and continue with the signature lines. If it is unknown if abnormalities were present or if no CT/CAT/MRIs were performed, select “unknown” and continue with the signature lines.

#### Question 127: Specify date scan was performed:

Enter the date the radiological assessment was performed.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)