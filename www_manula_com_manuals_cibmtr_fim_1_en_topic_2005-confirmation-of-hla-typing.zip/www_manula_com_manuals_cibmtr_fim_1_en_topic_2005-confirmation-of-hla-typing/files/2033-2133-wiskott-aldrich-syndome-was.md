Wiskott-Aldrich syndrome (WAS) is a rare X-linked recessive immunodeficiency affecting 1 to 10 of every 1 million male newborns. It is characterized by microthrombocytopenia and defective lymphocyte function. The decreased numbers and reduced size of platelets (microthrombocytopenia) in the blood often result in bruising, bloody diarrhea, and potentially severe internal bleeding. Defective lymphocyte function can manifest with recurrent infections such as otitis media and pneumonia, autoimmune disorders, and malignancies.[1](#fn79656694468596a887ff24-1)

The WAS gene encodes the WASp protein which has important roles in hematopoietic cellular function. Patients with Wiskott-Aldrich syndrome contain a WAS gene variant and altered WASp expression leading to a range of clinical presentations. A WAS scoring system was developed to categorize WAS-associated symptoms into three distinct groups (X-linked Neutropenia, X-linked Thrombocytopenia, and Classic WAS). See table below. Patients with microthrombocytopenia and only mild, transient eczema or minor infections are classified with X-linked thrombocytopenia (XLT). Those with treatment-resistant eczema and recurrent infections, or an autoimmune disease or malignancy receive the WAS classification. The spectrum of clinical manifestations underscores the complex role of WASp in cellular function.[2](#fn79656694468596a887ff24-2)[3](#fn79656694468596a887ff24-3)[4](#fn79656694468596a887ff24-4)

**Table: Scoring System to Define Clinical Phenotypes Associated with WAS mutations**

[5](#fn79656694468596a887ff24-5)

XLN |
iXLT |
XLT |
Classic WAS |
||||
|---|---|---|---|---|---|---|---|
| Score | 0 | <1 | 1 | 2 | 3 | 4 | 5 |
Thrombocytopenia |
- | Intermittent | Present | Present | Present | Present | Present |
Small Platelets |
- | Present | Present | Present | Present | Present | Present |
Eczema |
- | - | - | Mild, transient | Persistent but therapy-responsive | Difficult to control | Any: Absent to difficult to control |
Immunodeficiency |
Absent or mild | - | Absent or mild | Mild | Present | Present | Absent, Mild, or Present |
Infections |
Absent or mild | - | - | Mild, infrequent without sequelae | Recurrent, requiring antibiotics and IVIG prophylaxis | Score 3 OR severe, life-threatening | Any: Absent to severe, life-threatening |
Autoimmunity and/or Malignancy |
- | - | - | - | - | - | Present |
Congenital Neutropenia |
Present | - | - | - | - | - | - |
Myelodysplasia |
Possible myelodysplasia | - | - | - | - | - | - |

XLN: X-linked Neutropenia, iXLT: Intermittent X-linked Thrombocytopenia, XLT: X-linked Thrombocytopenia, WAS: Wiskott-Aldrich Syndrome

1 Ozsahin H, Cavazzana-Calvo M, Notarangelo L, et al. Long-term outcome following hematopoietic stem-cell transplantation in Wiskott-Aldrich syndrome: collaborative study of the European Society for Immunodeficiencies and European Group for Blood and Marrow Transplantation. Blood, 2008;111(1):439-45.

2 Bosticardo M, Marangoni F, Aiuti A, et al. Recent advances in understanding the pathophysiology of Wiskott-Aldrich syndrome. Blood, 2009;113(25):6288-96.

3 Puck J and Candotti F. Lessons from the Wiskott-Aldrich Syndrome. New England Journal of Medicine, 2006;355(17):1759-61.

4 Notarangelo LD, Miao CH, Ochs HD. Wiskott-Aldrich Syndrome. Current Opinion in Hematology, 2008; 15:30-36.

5 Adapted from: Albert, M. H., Notarangelo, L. D., & Ochs, H. D. (2011). Clinical spectrum, pathophysiology and treatment of the Wiskott–Aldrich syndrome. Current opinion in hematology, 18(1), 42-48.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)