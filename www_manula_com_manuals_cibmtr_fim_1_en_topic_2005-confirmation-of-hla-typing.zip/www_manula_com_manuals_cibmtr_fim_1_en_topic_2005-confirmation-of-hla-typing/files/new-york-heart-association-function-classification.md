#### Class I

Able to perform ordinary activities without symptoms; no limitation of physical activity

#### Class II

Ordinary physical activity produces symptoms; slight limitation of physical activity

#### Class III

Less-than-ordinary physical activity produces symptoms; moderate limitation of physical activity

#### Class IV

Symptoms present even at rest; severe limitation of physical activity

Last modified:
Mar 03, 2015

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)