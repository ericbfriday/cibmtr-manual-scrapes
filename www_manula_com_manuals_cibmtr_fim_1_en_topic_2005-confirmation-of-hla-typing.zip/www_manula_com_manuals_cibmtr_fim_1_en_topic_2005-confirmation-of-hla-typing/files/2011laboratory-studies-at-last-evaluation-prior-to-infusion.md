# Q64-91: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion

All values reported in questions 64-91 must reflect the most recent testing prior to the start of the preparative regimen (or infusion if no preparative regimen was given. Do not report testing performed during a line of therapy reported in questions 20-68. If testing was not performed near the start of the start of the preparative regimen / infusion (within approximately 30 days) and after the most recent line of therapy (if applicable), the center should report “Unknown” for that value.

#### Question 64-66: WBC

Indicate whether the white blood count (WBC) in the peripheral blood is “Known” or “Unknown” at the last evaluation prior to the start of the preparative regimen / infusion. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If the WBC at the last evaluation prior to the start of the preparative regimen / infusion is not known, report “Unknown” and go to question 67.

#### Question 67-69: Blasts in blood

Indicate whether the percent blasts in the peripheral blood is “Known” or “Unknown” at the last evaluation prior to the start of the preparative regimen / infusion. This may be determined by an automated differential, a manual count, or flow cytometry. Testing by any of these methods may be reported in questions 67-69. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If the percent blasts in blood at the last evaluation prior to the start of the preparative regimen / infusion is not known, report “Unknown” and go to question 70.

If a differential was performed and there were no blasts present in the peripheral blood, the lab report may not display a column for blasts. In this case, it can be assumed no blasts are present and ‘0’ should be reported.

#### Question 70-72: Blasts in bone marrow

Indicate whether the percent blasts in the bone marrow is “Known” or “Unknown” at the last evaluation prior to the start of the preparative regimen / infusion. The percent blast may be assessed by manual differential or flow cytometry. **If available, report the manual differential performed on the bone marrow aspirate sample.** If a manual differential was not performed on an aspirate sample, other methods / sample types may be reported (such as flow cytometry on an aspirate sample, or testing on a core biopsy) may be reported.

If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If the percent blasts in bone marrow at the last evaluation prior to the start of the preparative regimen / infusion is not known, report “Unknown” and go to question 73.

#### Question 73: Was flow cytometry performed?

Indicate whether flow cytometry (immunophenotyping) was performed on the blood and / or bone marrow at the last evaluation prior to the start of the preparative regimen / infusion. If “Yes,” go to question 74. Report “No” and continue with question 82 if flow cytometry was not performed on the blood and / or bone marrow at the last evaluation prior to the start of the preparative regimen / infusion.

Report “Unknown” and continue with question 82 if there is no information to determine if flow cytometry was performed or not performed at the last evaluation prior to the start of the preparative regimen / infusion.

#### Question 74-77: Flow cytometry testing on blood

Indicate whether flow cytometry was performed on the blood at the last evaluation prior to the start of the preparative regimen / infusion. If “Yes,” report the date the sample was collected and whether disease was detected in questions 75 and 76 respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 77. Otherwise, go to question 78.

If flow cytometry was not performed on the blood at the last evaluation prior to the start of the preparative regimen / infusion, report “No” for question 74 and go to question 78.

#### Question 78-81: Flow cytometry testing on bone marrow

Indicate whether flow cytometry was performed on the bone marrow at the last evaluation prior to the start of the preparative regimen / infusion. If “Yes,” report the date the sample was collected and whether disease was detected in questions 79 and 80 respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 81. Otherwise, go to question 82.

If flow cytometry was not performed on the bone marrow at the last evaluation prior to the start of the preparative regimen / infusion, report “No” for question 78 and go to question 82.

#### Question 82-91: Was extramedullary disease present?

Refer to the instructions for [questions 10-19](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2011laboratory-studies-at-diagnosis#extrafor) a description of extramedullary disease. If the recipient had extramedullary disease at the last evaluation prior to the start of the preparative regimen / infusion, report “Yes” for question 82 and report all extramedullary sites of involvement in questions 83-91. If the recipient did not have any extramedullary disease at this time point or it is not known whether extramedullary disease is present, report “No” or “Unknown” respectively for question 82 and submit the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q67 – 69 | 8/12/2022 | Add | Indicate whether the percent blasts in the peripheral blood is “Known” or “Unknown” at the last evaluation prior to the start of the preparative regimen / infusion. This may be determined by an automated differential, a manual count, or flow cytometry. Testing by any of these methods may be reported in questions 67-69. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in
|
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)