Complete a “Line of Therapy” section for each line of therapy administered during the current reporting period. If multiple lines of therapy were administered, copy and complete questions 19-56 for each line of therapy.

#### Question 18: Was therapy given since the date of the last report for reasons other than relapse or progressive disease? (Include any maintenance and consolidation therapy)

Indicate if the recipient received treatment for WM/LPL during the current reporting period for any reason other than relapsed or persistent disease, e.g., maintenance or consolidation therapy. If the patient received therapy for reasons other than relapsed or persistent disease, check “yes” and continue with question 19. If the patient did not receive therapy, or only received therapy for relapsed or persistent disease, check “no” and continue with question 57.

#### Question 19: Systemic therapy

Systemic therapy refers to a delivery mechanism where a therapeutic agent is delivered orally or intravenously, enters the bloodstream, and is distributed throughout the body.

Indicate “yes” if the patient received systemic therapy and continue with question 20. If the patient did not receive systemic therapy, indicate “no” and continue with question 48.

#### Questions 20-21: Date therapy started

Indicate “known” if the therapy start date is documented, and specify the start date in question 21. If the date is unknown, indicate this and continue with question 22.

#### Questions 22-23: Number of cycles

Indicate if the number of cycles is “known” or “unknown.” If known, report the number of cycles the recipient received during the reporting period for the line of therapy reported in question 23. If the therapy is not given in cycles or the number of cycles is not known, select “unknown” and continue with question 24.

#### Questions 24-47: Specify systemic therapy agents

Systemic therapy agents and treatment regimens vary based on disease, prognosis, and protocol. Drugs may be administered in an inpatient or outpatient setting, and treatment may consist of one or multiple drugs. Additionally, drugs may be administered on a single day, over consecutive days, or continuously.

Indicate “yes” or “no” for each therapeutic agent listed. Do not leave any response blank. If the recipient received an agent that is not listed, check “yes” for “other systemic therapy” and specify the treatment in question 47.

#### Question 48: Radiation therapy

Radiation therapy uses high-energy, ionizing radiation to kill malignant cells. Much like non-targeted systemic therapy, radiation therapy does not specifically target malignant cells and does have significant side effects. For that reason, high-dose radiation often targets a limited field.

Indicate if the recipient received radiation treatment for WM or LPL during the current reporting period. If “yes,” continue with question 49. If “no,” continue with question 53.

#### Question 49: Date therapy started

Specify the first date of radiation administration. If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 50-52: Specify radiation site(s)

Specify radiation site(s). If question 48 is answered “yes,” at least one site of radiation therapy must be specified in questions 50-52.

#### Question 53: Best response to line of therapy

Indicate the patient’s best response to this line of therapy. **See WM Response Criteria for disease status definitions.**

#### Question 54: Date assessed

Enter the date the best response to the line of therapy was established. Report the date of the pathological (e.g., bone marrow biopsy), radiological (e.g., CT), or biochemical (e.g., SPEP) evaluation. Enter the date the sample was collected for examination for pathological and/or laboratory evaluation, or enter the date the imaging took place for radiologic assessment. If no pathological, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically assessed the recipient’s response.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 55: Did disease relapse/progress following this line of therapy?

Relapse is the recurrence of disease after CR. WM or LPL relapse is demonstrated by reappearance of disease characteristics, including IgM paraprotein, lymphadenopathy and/or organomegaly, and bone marrow histologic involvement.

WM or LPL progression criteria are specified in Table 2 above. Indicate if relapse or progression occurred following the line of therapy being reported. If question 53 is answered “progressive disease,” question 55 must be “yes.”

#### Question 56: Date of relapse/progression

Enter the date of the assessment that identified relapse or progression following the line of therapy and *continue with question 59*. Enter the date the sample was collected for pathological and laboratory evaluation or enter the date the imaging took place. If the physician determined evidence of relapse during an office visit, report the date of assessment.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 57: Has disease relapsed or progressed since the date of last report?

Relapse is the recurrence of disease after CR. WM or LPL relapse is demonstrated by reappearance of disease characteristics, including IgM paraprotein, lymphadenopathy and/or organomegaly, and bone marrow histologic involvement.

WM or LPL progression criteria are specified in Table 2 above. Indicate if relapse or progression occurred at any time during the reporting period.

#### Question 58: Date of relapse/progression

Enter the date of the assessment that identified relapse or progression during the reporting period. Enter the date the sample was collected for pathological and laboratory evaluation or enter the date the imaging took place. If the physician determined evidence of relapse during an office visit, report the date of assessment.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)