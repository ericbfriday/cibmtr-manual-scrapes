Welcome to the CIBMTR Forms Instruction Manual. The Table of Contents on the left side of the screen is for navigational purposes; if you are on a mobile device you may find the Table on Contents on the top of the page.

[General Instructions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-instructions) provides useful general background information for successfully completing forms.

[2804/2814: CRID Assignment and Indication](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2804-2814-crid-assignment-and-indication) provides explanatory text used to generate a CIBMTR Research ID (CRID) and report the indication.

[Transplant Essential Data (TED) Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/transplant-essential-data-ted-manuals) provides explanatory text for each question found on the TED forms.

[Comprehensive Baseline & Follow-up Forms Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/follow-up-forms-manuals) provides explanatory text for each question on the Baseline, Follow-up, IDMs, HLA, and Infusion forms.

[Comprehensive Disease Specific Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/none) provides explanatory text and additional information for disease indications requiring CIBMTR reporting.

[Cellular Therapy Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cellular-therapy) provides explanatory text for completing pre-infusion, infusion, and post-infusion forms

[Infection & Miscellaneous Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/miscellaneous-manuals) provides explanatory text for manuals such as the Hepatitis Serology, VOD / SOS, and Myelofibrosis CMS Study forms.

[Appendices](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendices) provide additional information beyond the scope of the other manuals.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 11/29/2021 |
|

[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100q15-16)[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100q175-179)[Cellular Therapy Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cellular-therapy)**REMS reporting**: infusions can be reported without research consent if the center is utilizing CIBMTR to support their REMS reporting needs in meeting the requirements for the commercially available CAR-T products.[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100q175-179)[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000q253-311)[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100q175-179)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)