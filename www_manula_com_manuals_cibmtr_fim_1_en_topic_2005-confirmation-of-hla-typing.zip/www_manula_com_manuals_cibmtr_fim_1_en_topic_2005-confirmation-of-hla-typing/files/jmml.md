Juvenile Myelomonocytic Leukemia (JMML) is a cancer of the white blood cells. It is characterized by overproduction of myelocytes and monocytes; this chronic proliferation of myelocytes and monocytes in the bone marrow prevents the formation of healthy red blood cells, white blood cells, and/or platelets. Since JMML is characterized both by dysregulation and excessive proliferation of the bone marrow, it is classified as a mixed myelodysplastic-myeloproliferative disorder. The pathologic features of JMML are believed to primarily be the result of a clonal abnormality leading to activation of Ras signaling; this inappropriate activation of Ras leads to over-proliferation of certain cell types. Approximately 75% of all JMML patients carry one of three mutually exclusive mutations associated with inappropriate Ras activation: direct *RAS* mutations; *NF1* -inactivating mutations; or protein tyrosine phosphatase, non-receptor type 11 (*PTPN11*) mutations.[1](#fn161671716068596baf95a9a-1)

Clinically, JMML presents as hepatosplenomegaly with or without lymphadenopathy, pallor, fever, and rash. Due to the broad differential diagnosis associated with this presentation, a diagnosis of JMML may require a very extensive workup. JMML most commonly affects children less than six years of age, with most patients diagnosed at less than two years of age. It comprises less than 2% of all childhood leukemias, and has historically carried a grim prognosis, with less than 10% survival with a chemotherapy-only approach. 1 With HCT, survival approaches 50%.


[2](#fn161671716068596baf95a9a-2)1 National Cancer Institute. Childhood Acute Myeloid Leukemia/Other Myeloid Malignancies Treatment (PDQ®), Health Professionals handout. Accessed at: [http://www.cancer.gov/cancertopics/pdq/treatment/childAML/HealthProfessional](http://www.cancer.gov/cancertopics/pdq/treatment/childAML/HealthProfessional)

Accessibility verified August 8, 2013.

2 Locatelli F, Nollke P, Zecca M, et al. Hematopoietic stem cell transplantation (HSCT) in children with juvenile myelomonocytic leukemia (JMML): results of the EWOG-MDS/EBMT trial. *Blood*. 2004;105(1):410-419.

[JMML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/jmml-response-criteria)

[2015: JMML Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-jmml-pre-hct)

[2115: JMML Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2115-jmml-post-hct)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)