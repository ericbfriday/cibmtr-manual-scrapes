#### Questions 20 – 21: Were pulmonary function tests (PFT) performed? (If PFT tests were conducted we ask that you attach the most recent report)

Indicate if pulmonary function tests (PFTs) were performed prior to the start of the preparative regimen / infusion. If pulmonary function tests were performed, report **Yes** and specify if the PFT report is attached. If multiple PFTs were performed, attach the most recent report. Attaching PFT reports will prevent future requests to submit additional data for research studies.

If pulmonary function tests were not performed between diagnosis and the start of the preparative regimen / infusion, select **No**.

For instructions on how to attach documents in FormsNet3[SM], refer to the [Training Guide](http://www.cibmtr.org/DataManagement/Training/OnlineTraining/Pages/default.aspx).

#### Question 22: For children unable to perform a PFT, was oxygen saturation on room air > 95%?

Indicate if oxygen saturation on room air was > 95%. If oxygen saturation is > 95%, report **Yes**. If the oxygen saturation on room air was ≤ 95%, report **No**. If oxygen saturation was assessed multiple times, report the most recent assessment.

If oxygen saturation was not assessed, report **Not done**. This question is only applicable for children ≤ 5 years of age.

#### Questions 23 – 24: Was a 6-minute walk test performed?

A 6-minute walk test is used to assess total distance walked within 6 minutes to determine aerobic capacity and endurance. Indicate if a 6-minute walk test was performed at any time between diagnosis and the start of the preparative regimen / infusion. If **Yes**, report the total distance walked and specify the unit of measure.

If a 6-minute walk test was not performed or if the recipient is unable to walk or cannot perform the 6-minute walk test due to their current clinical status, report **No**.

If multiple walk tests were performed prior to the start of the preparative regimen / infusion, report the results of the most recent assessment.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)