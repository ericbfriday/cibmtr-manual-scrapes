The Elivaldogene Autotemcel (Skysona®) Pre-Infusion Supplemental Data Collection (2546) Form must be completed for recipients who are enrolled onto CIBMTR study CS20-51. This is a post-marketing prospective, multicenter, observational, long-term safety and effectiveness registry study of recipients with cerebral adrenoleukodystrophy treated with Elivaldogene Autotemcel (Skysona®).

The Pre-Transplant Essential Data (2400) Form will confirm study eligibility, this includes event date and gene therapy product infused. Once eligibility is confirmed, the Elivaldogene Autotemcel Pre-Infusion (2546) Form will come due for all recipients with the Recipient Baseline (2000), Gene Therapy Product (2003) and Leukodystrophies Pre-Infusion Data (2037) Forms.

Links to Sections of Form:

[Q1-4 Leukodystrophy Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-4-leukodystrophy-diagnosis)

[Q5-6: Clinical Status Prior to Mobilization](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q5-6-clinical-status-prior-to-mobilization)

[Q7-8: Clinical Status Prior to Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q7-8-clinical-status-prior-to-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, you can reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 9/27/2024 | Elivaldogene Autotemcel (Skysona®) Pre-Infusion Supplemental Data | Add | Version 1 of the Elivaldogene Autotemcel (Skysona®) Pre-Infusion Supplemental Data section of the Forms Instruction Manual released. Version 1 corresponds to revision 1 of the Form 2546. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)