The Hepatitis Serology Post-HCT Data, Form 2147, will come due when the following IDMs are reported as “positive” on the Form 2000, Recipient Baseline Data:


- Hepatitis B surface antigen
- Hepatitis B core antibody
- Hepatitis B DNA
- Hepatitis C antibody
- Hepatitis C NAT

This form will *also* come due when a recipient’s post-transplant Hepatitis B and/or Hepatitis C viral infection is reported on the post-transplant follow-up forms for recipients on the comprehensive report form (CRF) track.

Links to Sections


[Q1-9: Serological Evidence of Hepatitis Exposure / Infection – Recipient](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-9-serological-evidence-of-hepatitis-exposure-infection-recipient)[Q10-17: Serological Evidence of Hepatitis Exposure / Infection – Donor](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q10-17-serological-evidence-of-hepatitis-exposure-infection-donor)[Q18-37: Antiviral Therapy for Hepatitis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q18-37-antiviral-therapy-for-hepatitis)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/3/2021 |
|

~~Hepatitis B surface Antigen~~~~Hepatitis B core Antibody~~~~Hepatitis C Antibody~~

[2047/2147: Hepatitis Serology](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2047-2147-hepatitis-serology)**Published new manual for**[2047](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2047-hepatitis-serology-pre-hct)&[2147](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2147-hepatitis-serology-post-hct)Hepatitis Serology.
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)