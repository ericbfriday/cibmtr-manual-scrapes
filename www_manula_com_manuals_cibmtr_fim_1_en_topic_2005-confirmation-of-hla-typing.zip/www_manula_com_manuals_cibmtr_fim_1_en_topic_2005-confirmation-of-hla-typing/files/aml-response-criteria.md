**Example 1:**A recipient who transformed from MDS to AML received AML induction therapy. A bone marrow biopsy was performed post-induction and showed remission; however, there was still evidence of dysplasia present. The recipient did not receive additional therapy and went to transplant. In this scenario, the pre-transplant disease status may be reported as “CR” if all AML criteria are met in addition to having 0% blasts in the peripheral blood.**Example 2:**A recipient who transformed from primary myelofibrosis to AML achieved remission following induction therapy and went to transplant. During the Day 100 reporting period, a bone marrow biopsy was performed and myelofibrosis was present. In this case, the post-transplant disease status may still be reported as “CR” if all AML criteria are met in addition to having 0% blasts in the peripheral blood.

#### Complete Remission (CR)

Hematologic complete remission is defined as meeting all of the following response criteria:


- < 5% blasts in the bone marrow
- No blasts with Auer rods
- No extramedullary disease (e.g., CNS, soft tissue disease)
- Neutrophils ≥ 1,000/µL
- Platelets ≥ 100,000/µL
- Transfusion independent

Alternative post-transplant CR criteria are accepted in the setting of **pediatric** AML when the center does *not* routinely perform bone marrow biopsies post-transplant and the patient was in CR pre-transplant. These criteria are not used for pre-transplant AML disease status. The criteria are as follows:


- Complete donor chimerism (≥ 95% donor chimerism without recipient cells detected)
- No extramedullary disease (e.g., CNS, soft tissue disease)
- Neutrophils ≥ 1,000/µL
- Platelets ≥ 100,000/µL
- Transfusion independent (a minimum of eight weeks without platelet or red blood cell transfusion)

Include recipients who are MRD positive or where the MRD status is unknown. MRD assessments include cytogenetic, flow cytometry, and molecular methods.

Include recipients meeting the above CR criteria regardless of how many courses of therapy were required to achieve CR.

The number of this complete remission can be determined by using the following guidelines:


- 1st CR: no prior relapse
- 2nd CR: one prior relapse
- 3rd or higher: two or more prior relapses

#### Complete Remission with Incomplete Hematologic Recovery (CRi)

Hematologic complete remission with incomplete hematologic recovery is defined as meeting all of the following response criteria:


- < 5% blasts in the bone marrow
- No blasts with Auer rods
- No extramedullary disease (e.g., CNS, soft tissue disease)
- Transfusion independent (a minimum of eight weeks without platelet or red blood cell transfusion) (Please note, if the physician documents transfusion dependence related to treatment and not the patient’s underlying AML, CR should be reported)

#### Primary Induction Failure (PIF)

The patient received treatment for AML but **never achieved CR or CRi at anytime**. PIF is not limited by the number of unsuccessful treatments; this disease status only applies to recipients who have *never been in CR or CRi*.

#### Relapse (REL)

Relapse is defined as the recurrence of disease after CR, meeting one or more of the following criteria:


- ≥ 5% blasts in the marrow or peripheral blood
- Extramedullary disease
- Disease presence determined by a physician upon clinical assessment

The number of this relapse can be determined by using the following guidelines:


- 1st relapse: one prior CR
- 2nd relapse: two prior CRs
- 3rd or higher: three or more CRs

Do not include a partial response (PR) when determining number of relapse. Recipients who achieve a PR to treatment should be classified as either PIF or relapse; PR in AML is generally of short duration and is unlikely to predict clinical benefit.

#### No Treatment

The recipient was diagnosed with acute leukemia and never received therapeutic agents; include patients who have received only supportive therapy, including growth factors and/or blood transfusions.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

Reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage for the historical manual change history.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

**Relapse Criteria**: The Disease presence determined by a physician upon clinical assessment criteria is not if there is**only**disease detected by MRD or other methods of assessment (i.e., molecular, cytogenetics, flow cytometry). In order to report relapse, disease must be detected by clinical / hematologic assessments.[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)**Example 1:**A recipient who transformed from MDS to AML received AML induction therapy. A bone marrow biopsy was performed post-induction and showed remission; however, there was still evidence of dysplasia present. The recipient did not receive additional therapy and went to transplant. In this scenario, the pre-transplant disease status may be reported as “CR” if all AML criteria are met in addition to having 0 % blasts in the peripheral blood.**Example 2:**A recipient who transformed from primary myelofibrosis to AML achieved remission following induction therapy and went to transplant. During the Day 100 reporting period, a bone marrow biopsy was performed and myelofibrosis was present. In this case, the post-transplant disease status may still be reported as “CR” if all AML criteria are met in addition to having 0 % blasts in the peripheral blood.

[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)*Include recipients who are MRD positive or where the MRD status is unknown. MRD assessments includes*~~with persistent~~ cytogenetic, flow cytometry, and molecular methods.[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)*Transfusion independent (a minimum of eight weeks without platelet or red blood cell transfusion) (Please note, if the physician documents transfusion dependence related to treatment and not to the patient’s underlying AML, CR-i- should be reported*[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)*Transfusion independent (a minimum of eight weeks without platelet or red blood cell transfusion)*[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)**Complete Remission***Hematologic complete remission is defined as meeting all of the following response criteria*~~for at least four weeks~~:*< 5% blasts in the bone marrow**No blasts with Auer rods*~~Normal maturation of all cellular components in the bone marrow~~*No extramedullary disease (e.g., CNS, soft tissue disease)**Neutrophils ≥ 1,000/µL**Platelets ≥ 100,000/µL**Transfusion independent*

**Complete Remission with Incomplete Hematologic Recovery (CRi)**

*Hematologic complete remission with incomplete hematologic recovery is defined as meeting all of the following response criteria*~~for at least four weeks~~:*< 5% blasts in the bone marrow**No blasts with Auer rods*~~Normal maturation of all cellular components in the bone marrow~~*No extramedullary disease (e.g., CNS, soft tissue disease)**Transfusion independence (Please note, if the physician documents transfusion dependence related to treatment and not the patient’s underlying AML, CRi can be reported)*

[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)*For recipients with MDS / MPN / MF that transformed to AML*blue information box that this instruction also applies to recipients with AML with MDS related changes along with examples 1 and 2:*Historically, for recipients who had residual MDS / MPN / MF following treatment for AML, the AML disease status was reported as either PIF or relapse (i.e., the recipient cannot be in an AML CR if there is evidence of MDS / MPN / MF at the time of assessment). However, this instruction was removed in May 2020 and an AML CR may be reported if there is residual MDS / MPN / MF as long as there are < 5% blasts in the bone marrow as well as 0% blasts in the peripheral blood. This instruction also applies to recipients whose primary disease for transplant is “AML with MDS related changes”**Example 1: A recipient who transformed from MDS to AML received AML induction therapy. A bone marrow biopsy was performed post-induction and showed remission; however, there was still evidence of dysplasia present. The recipient did not receive additional therapy and went to transplant. In this scenario, the pre-transplant disease status may be reported as “CR.”*

Example 2: A recipient who transformed from primary myelofibrosis to AML achieved remission following induction therapy and went to transplant. During the Day 100 reporting period, a bone marrow biopsy was performed, and myelofibrosis was present. In this case, the post-transplant disease status may still be reported as “CR.”Example 2: A recipient who transformed from primary myelofibrosis to AML achieved remission following induction therapy and went to transplant. During the Day 100 reporting period, a bone marrow biopsy was performed, and myelofibrosis was present. In this case, the post-transplant disease status may still be reported as “CR.”

[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)**For recipients with MDS / MPN / MF that transformed to AML**Historically, for recipients who had residual MDS / MPN / MF following treatment for AML, the AML disease status was reported as either PIF or relapse (i.e., the recipient cannot be in an AML CR if there is evidence of MDS / MPN / MF at the time of assessment). However, this instruction was removed in May 2020 and an AML CR may be reported if there is residual MDS / MPN / MF as long as there are < 5% blasts in the bone marrow as well as 0% blasts in the peripheral blood.[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)*Transfusion independent (Please note, if the physician documents transfusion dependence related to treatment and not the patient’s underlying AML, CRi can be reported)*
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)