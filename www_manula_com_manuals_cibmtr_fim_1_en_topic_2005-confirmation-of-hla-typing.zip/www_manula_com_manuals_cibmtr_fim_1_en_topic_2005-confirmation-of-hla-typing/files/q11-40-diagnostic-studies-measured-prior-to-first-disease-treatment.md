**Report findings at diagnosis of the primary disease for infusion. All values reported must reflect testing performed prior to the start of treatment of the primary disease for which the HCT / cellular therapy is being performed.** If multiple studies were performed prior to the start of therapy, report the assessment closest to the diagnosis date of the primary disease for infusion. If the recipient’s MPN transformed, report the studies from the original diagnosis.

#### Question 11: Date CBC with differential drawn

Report the date the sample was collected for testing and continue with question 12. If multiple studies were performed prior to the start of therapy, report the assessment closest to the diagnosis date of the primary disease for infusion.

#### Question 12-13: Neutrophils

Indicate whether the neutrophil percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the value documented on the laboratory report in question 13. If “unknown,” continue with question 14.

#### Questions 14-15: Bands

Indicate whether the band percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 15. If “unknown,” continue with question 16.

#### Questions 16-17: Metamyelocytes

Indicate whether the percentage of metamyelocytes in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 17. If “unknown,” continue with question 18.

#### Question 18-19: Myelocytes

Indicate whether the myelocyte percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 19. If “unknown,” continue with question 20.

#### Questions 20-21: Lymphocytes

Indicate whether the lymphocyte percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 21. If “unknown,” continue with question 22.

#### Questions 22-23: Monocytes

Indicate whether the monocyte percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 23. If “unknown,” continue with question 24.

#### Questions 24-25: Basophils

Indicate whether the basophils percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 25. If “unknown,” continue with question 26.

#### Questions 26-27: Eosinophil

Indicate whether the eosinophil percentage in the blood was “known” or “unknown” at the time of MPN diagnosis. If “known,” report the percentage documented on the laboratory report in question 27. If “unknown,” continue with question 28.

#### Questions 28-29: Was a bone marrow examination performed?

Indicate if a bone marrow examination was performed at the time of MPN diagnosis. If “yes,” indicate the date the sample was collected in question 29. If “no” or “unknown,” continue with question 33.

#### Question 30: Cellularity

Cellularity describes the percentage of bone marrow occupied by hematopoietic cells compared to other tissues, such as adipose (fat) cells. In MPN, the percentage of hematopoietic cells is likely increased (hypercellular) due to proliferation of immature cells. In other cases, the cellularity may be normal (normocellular) or decreased (hypocellular). This distinction is made on the pathology report of a bone marrow examination.

Indicate whether the bone marrow examination revealed “decreased (hypocellular),” “normal (normocellular),” or “increased (hypercellular)” cellularity at diagnosis or prior to the first treatment. If a biopsy was not obtained or if the degree of cellularity is not addressed in the report, select “unknown.”

#### Question 31: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This is evident in MPN diseases. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented on the pathology report or stated in a physician note, select “known,” continue with question 32.

If the myelofibrosis grade is not documented, select “unknown,” continue with question 33.

#### Question 32: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal BM.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with local bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 33: Were molecular tests for molecular markers performed (e.g., PCR) (please do not include driver mutations JAK2, CALR, MPL, and CSF3R as previously captured on the Disease Classification F2402)

Molecular assessment involves testing blood or bone marrow for the presence of known molecular markers associated with the recipient’s disease. Molecular assessments are the most sensitive test for genetic abnormalities and involve amplifying regions of cellular DNA by polymerase chain reaction (PCR), typically using RNA to generate complementary DNA through reverse transcription (RT-PCR). The amplified DNA fragments are compared to a control, providing a method of quantifying log increase of genetic mutation transcripts. Each log increase is a 10-fold increase of gene transcript compared to control. Molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

Indicate if molecular tests for molecular markers (excluding driver mutations previously captured on the Disease Classification F2402) were obtained at the time the recipient was diagnosed with MPN or prior to the start of treatment.

If molecular tests for molecular markers (excluding driver mutations previously captured on the Disease Classification F2402) were obtained, select “yes” and continue with question 34.

If molecular tests for molecular markers (excluding driver mutations previously captured on the Pre-TED Disease Classification (2402) form were not obtained or it is unknown if tests were performed, indicate “no” or “unknown” and continue with question 41.

#### Question 34: Indicate if a positive molecular marker(s) was identified

Indicate if positive molecular marker(s) was identified at the time of MPN diagnosis or prior to the start of treatment.

If a positive molecular marker was identified, select “yes” and continue with question 35.

If there were no molecular markers identified, select “no” and continue with question 41.

#### Question 35: Date sample collected

Report the date the sample was collected for molecular testing. If multiple studies were performed prior to the start of therapy, report the last assessment prior to the start of treatment.

#### Questions 36-37: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 38. If a positive marker is detected, but not listed as an option, select “Other molecular marker” and specify the positive molecular marker in question 37.

#### Questions 38-39: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

Figure 1. Molecular disease assessment with amino acid changes documented (highlighted in yellow).


For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 38 indicate if the amino acid change is “known” or “unknown” for the positive molecular marker reported in questions 36-37. If known, report the amino acid change in question 39. If unknown, continue with question 40.

Copy questions 36-39 to report more than one positive molecular marker.

#### Question 40: Was documentation submitted to the CIBMTR?

Indicate if the molecular report(s) is attached to support the molecular findings reported in questions 43-46. For further instructions on how to attach documents in FormsNet3]SM[, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 11 | 4/21/2023 | Modify | Clarified the instructions for the labs at diagnosis should reflect the labs closest to the date of diagnosis. | To ensure more consistent reporting, all labs for the “at diagnosis” timepoint were clarified to reflect the values obtained closest to the date of diagnosis, prior to the start of any therapy. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)