#### Question 14-17: Select all known hematologic labs (check all that apply).

These questions are intended to capture any hematologic labs within 60 days prior to the start of the preparative regimen.

**Erythroferrone (ERFE):**The main erythroid regulator of hepcidin, the homeostatic hormone controlling plasma iron levels and total body iron**Growth/differentiation factor (GDF15):**Member of the transforming growth factor-β superfamily, participates in processes associated with myeloma development and its end-organ complications.**Nucleated RBC (erythroblast):**Premature erythrocyte precursors that reside in the bone marrow of humans of all ages as an element of erythropoiesis.

If none of the labs listed above were completed within 60 days prior to the start of the preparative regimen, select **None**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Sep 30, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)