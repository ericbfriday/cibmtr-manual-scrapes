#### Question 27: What was the initial therapy? (after diagnosis)

Recipients will receive either neoadjuvant therapy (radiation or systemic therapy (chemotherapy)), or surgery at the time of diagnosis. Neoadjuvant therapy is given to a recipient before surgery to help shrink a tumor or stop disease spread to optimize the main treatment’s success rate and, if possible, make it less invasive. Regardless of the therapy type, it is important to document what the type was and when it started.

Indicate if the initial (*first*) therapy after diagnosis was **Radiation therapy**, **Surgery**, or **Systemic therapy**.

#### Question 28: Date initial therapy started

Report the date the initial therapy started.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 29: Date of primary surgical intervention

Report the date of primary surgical intervention. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Question 30: Disease status following primary surgical intervention

Residual tumor may be found in the area of primary tumor and its regional lymph nodes and/or at distant sites.

The primary surgical intervention may be the initial therapy reported above or performed after initial neoadjuvant therapy. Regardless of when the primary surgical intervention was performed, report the disease status following primary surgical intervention:

• R0: no residual tumor

• R1: microscopic residual tumor

• R2: macroscopic residual tumor

#### Question 31: Necrosis (osteosarcoma)

Report the percentage of necrosis following primary surgical intervention.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)