Acute Myelogenous Leukemia (AML) is a cancer of the white blood cells. It is characterized by the rapid proliferation of abnormal, immature myelocytes, known as myeloblasts, in the bone marrow. This accumulation of blasts in the marrow prevents the formation of healthy red blood cells, white blood cells, and/or platelets. Normal myeloblasts develop into neutrophils, basophils, and eosinophils, which are all white blood cells that fight infection. In AML, the leukemic myeloblasts do not fully develop and are unable to fight infection. The symptoms of AML result from a drop in red blood cell, platelet, and normal white blood cell counts caused by the replacement of normal bone marrow with leukemic cells.

Certain prognostic indicators are associated with poorer outcomes. These include advanced age (50+ years of age), AML arising from MDS or secondary/therapy-related AML, and certain genetic mutations that are described in greater detail later in this manual.

[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)

[2010: AML Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2010)

[2110: AML Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)