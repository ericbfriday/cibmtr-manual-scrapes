#### Question 140: Was GVHD prophylaxis planned?

After allogeneic HCT, specific immunosuppressive therapy may be administered to prevent GVHD or to immunosuppress the host marrow, thereby promoting engraftment of the donor stem cells. Most transplant centers have specific GVHD prophylaxis protocols and graft rejection protocols. **Planned** agents a recipient receives as a result of these protocols should be included in this section. This answer does not have to match what is reported on the Post-Infusion Follow-Up (2100) Form.

Indicate if GVHD prophylaxis was planned at the time of transplant. If GVHD prophylaxis was not planned at the time of transplant, check **No**.

#### Questions 141 – 142: Specify drugs / intervention (check all that apply)

The prophylactic drug options listed on the form are intended to be administered in a **systemic or oral form**. If the recipient received one of the listed drugs in a topical form, select the “other agent” option and specify the drug.

The Pre-TED Form lists the generic chemotherapy drug names. The following website provides the trade names under which generic drugs are manufactured: [http://www.rxlist.com/script/main/hp.asp](http://www.rxlist.com/script/main/hp.asp)

If GVHD prophylaxis is used for a syngeneic (monozygotic or identical twin) or autologous HCT, attach a copy of the source document using the attachment feature in FormsNet3SM.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)