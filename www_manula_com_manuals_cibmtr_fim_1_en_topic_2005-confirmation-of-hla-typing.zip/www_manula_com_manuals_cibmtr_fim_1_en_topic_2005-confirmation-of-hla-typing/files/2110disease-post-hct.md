Questions 51-88 are intended to capture the earliest instance of disease detection by each method of assessment performed during the reporting period. For each method of assessment, report “Yes” if that method detected the recipient’s AML (or markers of AML) during the reporting period. If testing by a particular method (e.g., molecular makers, cytogenetic, flow cytometry, etc.) was done, but did not shown evidence of disease during the reporting period, report “No” for that method. If testing for molecular or cytogenetic markers / abnormalities was not done during the reporting period or it is not known whether testing was performed, report “Unknown” for those methods (question 51 and 70). If testing by flow cytometry, clinical / hematologic assessment, or other assessment was not done during the reporting period or it is not known whether testing was performed, report “No” for those methods (questions 63, 80, and 87).

If multiple tests by a particular method have demonstrated evidence of disease during the reporting period, report the date / result of the earliest positive assessment(s) performed during the reporting period.

#### Question 51-52: Were tests for molecular markers performed and positive for disease (e.g. PCR, NGS)?

See [question 4](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#mol) for a description of molecular testing. If any testing for molecular markers detected the recipient’s primary disease during the reporting period, report “Yes” for question 51 and report the date the sample was collected in question 52. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms.](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms)

If molecular marker testing did not detect disease at any time during the reporting period, report “No” for question 51 and go to question 63.

If molecular marker testing was not performed during the reporting period, report “Unknown” go to question 63. If it is not known whether testing for molecular markers was performed during the reporting period, or the test results are not known, report “Unknown” and go to question 63.

#### Question 52-61: Specify results

For each molecular marker in questions 53-62, report whether testing was “Positive,” “Negative,” or “Not done.” If tests identified a molecular marker other than those listed in questions 53-60, report the result in question 61 and specify the marker in question 62. If multiple “Other molecular markers” were tested at the time of best response, report one instance (i.e., copy) of question 61-62 for each “Other molecular marker” tested. If greater than 3 “Other molecular marker[s]” are tested, do the following:


- report one instance of question 61-62; and
- report “Positive” if any of the “Other molecular marker[s]” were positive, otherwise, report “Negative;” and
- report “see attachment” in question 62; and
- attach any / all reports documenting the results of testing for “Other molecular marker[s].”

If CEBPA is reported as “Positive” (question 53) question 54 must be completed. If the lab report does not specify whether the detected marker was biallelic / homozygous or monoallelic / heterozygous, confirm with the laboratory whether this information can be determined prior to reporting “Unknown.”

#### Question 63: Was the disease detected via flow cytometry?

See [question 15](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#flow) for a description of flow cytometry. If flow cytometry detected the recipient’s primary disease at any time during the reporting period, report “Yes” and go to question 64. Report “No” and go to question 70 in either of the following cases:


- all flow cytometry assessments performed on the blood and marrow were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the blood or bone marrow during the reporting period.

#### Question 64-66: Flow cytometry testing on blood

Indicate whether flow cytometry detected disease in a blood sample at any time during the reporting period. If “Yes,” report the date the sample was collected and the percent disease detected (i.e., percent leukemic blasts) in questions 65 and 66 respectively. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). Report “No” for question 64 and go to question 67 in either of the following cases:


- all flow cytometry assessments performed on the blood were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the blood during the reporting period.

If multiple flow cytometry assessments performed on blood samples were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

#### Question 67-69: Flow cytometry testing on bone marrow

Indicate whether flow cytometry detected disease in a bone marrow sample at any time during the reporting period. If “Yes,” report the date the sample was collected and the percent disease detected (i.e., percent leukemic blasts) in questions 68 and 69 respectively. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). Report “No” for question 67 and go to question 70 in either of the following cases:


- all flow cytometry assessments performed on the marrow were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the marrow during the reporting period.

If multiple flow cytometry assessments performed on bone marrow samples were positive for disease, report the date and results of the earliest positive assessment performed during the reporting period.

#### Question 70: Was disease detected by cytogenetic testing (karyotyping or FISH)?

Refer to [question 24](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#cyto) for a description of cytogenetic studies. If cytogenetic testing detected the recipient’s primary disease at any time during the reporting period, report “Yes” and go to question 71. If all cytogenetic testing was negative for evidence of the recipient’s primary disease during the current reporting period, report “No” and go to question 79. Report “Unknown” for question 70 and go to question 79 in any of the following cases:


- cytogenetic testing was not performed during the reporting period; or
- cytogenetic testing was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether cytogenetic testing was performed during the reporting period.

#### Question 71-72: Were cytogenetic abnormalities identified via FISH?

Indicate whether FISH studies detected disease at any time during the reporting period. If “Yes,” report the date the sample was collected in question 72 and go to question 73. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). Report “No” for question 71 and go to question 75 in any of the following cases:


- FISH testing was not performed during the reporting period; or
- FISH testing was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether FISH testing was performed during the reporting period.

If multiple FISH assessments were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

#### Question 73-74: Specify cytogenetic abnormalities (FISH)

Select all clonal cytogenetic abnormalities detected by FISH on the date reported in question 72. If an abnormality is detected, but not listed as an option in question 73, select “Other abnormality” and specify the abnormality in question 74. If multiple “Other abnormalities” were detected by FISH at the time of best response, report “see attachment” in question 74 and attach a copy of the FISH report. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 75-76: Were cytogenetic abnormalities identified via karyotyping?

Indicate whether karyotyping studies detected disease at any time during the reporting period. If “Yes,” report the date the sample was collected in question 76 and go to question 77. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). Report “No” for question 75 and go to question 79 if:


- karyotyping was not performed during the reporting period; or
- karyotyping was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether karyotyping was performed during the reporting period.

If multiple karotypes were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

#### Question 77-78: Specify cytogenetic abnormalities (karyoptying)

Select all clonal cytogenetic abnormalities detected by karyotyping on the date reported in question 76. If an abnormality is detected, but not listed as an option in question 77, select “Other abnormality” and specify the abnormality in question 78. If multiple “Other abnormalities” were detected by karyotyping at the time of best response, report “see attachment” in question 74 and attach a copy of the karyotype report. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 79: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the reported cytogenetic findings in question 70-78. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 80-81: Was disease detected by clinical / hematologic assessment?

Clinical / hematologic assessments include, but are not limited to, biopsies, imaging assessments, complete blood counts, and physical exams. If clinical / hematologic testing detected disease during the reporting period, report “Yes” for question 81 and report the date of the positive assessment in question 81. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If multiple clinical / hematologic assessments detected disease, report the date of the earliest positive assessment performed during the reporting period.

#### Question 82-86: Specify Sites of Disease

Report “Yes” for each site where disease was detected by clinical / hematologic methods on the date reported in question 81. If clinical / hematologic assessments detected disease at a site not specified in questions 82-86, report “Yes” for question 85 and specify all other sites where disease was detected on the date reported in question 81.

Report “No” if a site:


- was not tested during the reporting period; or
- was tested during the reporting period, but disease was not detected.

#### Question 87-89: Was the disease status assessed by other assessment?

Indicate whether the recipient’s primary disease was assessed by any method other than those included in questions 51-86 during the reporting period. If “Yes,” report the date assessed and specify the type of assessment in questions 88 and 89 respectively. If the exact date of assessment is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If AML was not assessed by any methods other than those included in questions 51-86, report “No” for question 87 and go to question 90.

#### Question 90: Was intervention given for relapsed disease or progressive disease, or minimal residual disease? (since the date of last report)

Indicate if the recipient received treatment post-infusion for minimal residual disease, persistent disease, or relapse since the date of last report. If “Yes,” go to question 90. If “No,” go to question 103. See question 91 for definitions each of these indications for treatment.

#### Question 91: Specify reason for which intervention was given

Select all indications for which treatment was administered during the reporting period. See below for definitions of each indication.

**Minimal Residual Disease:** Recipient is in hematologic CR, but has evidence of disease by more sensitive assessments including molecular, flow cytometry or cytogenetic methods.

**Persistent Disease:** The recipient was in primary induction failure or relapse at the time of infusion and has not achieved a hematologic CR post-infusion.

**Relapsed Disease:** The recipient was in CR at the time of infusion or the recipient achieved a CR post-infusion. In either case, treatment is administered for a relapse which occurred post-infusion.

#### Question 92: Central nervous system irradiation

See [question 42](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110post-infusion-therapy#CNS) for a description of central nervous system (CNS) irradiation. If the recipient received CNS irradiation to treat minimal residual disease, persistent disease, or relapse during the reporting period, report “Yes.” If not, report “No.”

#### Question 93: Intrathecal Therapy

Intrathecal therapy is chemotherapy administered to the CNS via a lumbar puncture. It may be given to treat or prevent leukemic blasts in the cerebrospinal fluid or other CNS tissues. If intrathecal therapy was given as part of treatment for minimal residual disease, persistent disease, or relapse, report “Yes.” If not, report “No.”

#### Question 94: Systemic therapy

See [question 43](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110post-infusion-therapy#sys) for a description of systemic therapy. Do not report total body irradiation or subsequent HCT / cellular therapies in questions 94-98. If the recipient received systemic therapy during the reporting period for minimal residual disease, persistent disease, or relapse, report “Yes” and go to question 95. If not, report “No” and go to question 98.

#### Question 95-96: Date therapy was first started post-HCT / post-infusion

If the recipient started systemic therapy for minimal residual disease, persistent disease, or relapse during the reporting period, report “Known” for question 95 and indicate the date started in question 96. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the recipient started therapy for minimal residual disease, persistent disease, or relapse in a prior reporting period and continued the therapy into the current reporting period, report “Previously reported” and go to question 97.

For recipients who start and stop therapy multiple times post-infusion, first determine whether the recipient stopped therapy for at least 30 days. If not, consider the therapy continuous. Only report a new therapy start date if all three of the below conditions are met

- The recipient stopped all therapy given for minimal residual disease, persistent disease, or relapse during a prior reporting period; and
- The recipient restarted therapy for minimal residual disease, persistent disease, or relapse during the current reporting period; and
- Therapy was restarted at least 30 days after the therapy stop date.

#### Question 97-98: Specify systemic therapy given

Select all systemic therapy (see [question 43](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110post-infusion-therapy#sys) for definition) given for minimal residual disease, persistent disease, or relapse during the reporting period. If a therapy is given, but not listed as an option in question 97, select “Other systemic therapy” and specify the drug in question 98.

#### Question 99: Cellular therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells).

Report “Yes” if the recipient received cellular therapy as treatment for minimal residual disease, persistent disease, or relapse during the reporting period. If not, report “No.”

#### Question 100: Subsequent HCT

Indicate whether the recipient received a HCT since the date of the last report (or since infusion if completing this is the 100 day follow-up form). Hematopoietic stem cells (HSC) are defined as mobilized peripheral blood stem cells, bone marrow, or cord blood. The source of HSC may be allogeneic unrelated, allogeneic related, or autologous. For more information on how to distinguish infusion types (example: HCT versus DCI), [see Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

#### Question 101: Accelerated withdrawal of immunosuppression

Immunosuppressive medications may be tapered or entirely withdrawn in order to promote a graft vs leukemia effect in the setting of relapsed, progressive, or persistent disease. For reporting purposes, accelerated withdrawal is defined as any decrease in immunosuppression to promote graft versus leukemia effect.

If the recipient undergoes an accelerated withdrawal immunosuppression during the reporting period in order to treat disease, report “yes.” If not, report “no.”

#### Question 102-103: Other therapy

Indicate if the recipient received any other treatment for minimal residual disease, persistent disease, or relapse during the reporting period. If “Yes,” specify the type of treatment administered in question 103. If “No,” go to question 104.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)