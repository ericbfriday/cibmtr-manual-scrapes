#### Question 2: Specify the solid tumor sub-disease (ICD10 code)

Specify the solid tumor sub-disease based on the ICD-10 code. ICD-10 (International Classification of Diseases, Tenth Revision) is a system for coding medical conditions, symptoms, and procedures. Physicians use ICD-10 codes to classify and code diagnoses, symptoms, and procedures for claims processing.

Synovial sarcoma and myxoid round cell sarcoma subtypes are listed under Malignant neoplasm of other connective and soft tissue (C49.X). Bone sarcoma subtypes are listed under Malignant neoplasm of bone and articular cartilage of limbs (C40.X) and Malignant neoplasm of bone and articular cartilage of other and unspecified site (C41.X and C40.X)

#### Question 3: Two largest dimensions of target lesion:

The target lesion refers to a specific, measurable area that is chosen by the physician to monitor and assess the effectiveness of treatment.

Report the two largest dimensions of the target lesion, in centimeters, at diagnosis. This will be documented in the imaging report (e.g. CT, MRI, etc.). If the mass is given in three dimensions (for example: 3 cm x 5 cm x 4 cm), report the longest two dimensions.

#### Questions 4-6: Were metastases present?

Metastases can develop when cancer cells break away from the main tumor and enter the bloodstream or lymphatic system. This will be documented in a note, problem list, or the imaging report.

If metastases were present at diagnosis, select **Yes** specify the location(s) of metastases. Specify the location if **Other location** is selected.

#### Question 7: Were cytogenetics tested? (FISH or Karyotype)

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the disease cells.

Indicate whether cytogenetic studies were obtained at diagnosis. If cytogenetic studies were obtained at diagnosis, select **Yes**. If cytogenetic studies were not obtained at this time point or it is not known whether chromosome studies were performed, indicate **No** or **Unknown**, respectively.

#### Questions 8-9: Were cytogenetics tested via FISH?

If FISH studies were performed at diagnosis, report **Yes** and indicate whether or not abnormalities were identified. If FISH studies were not performed at diagnosis, FISH samples were inadequate, or it is not known if performed, report **No**.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Questions 10-12: Specify cytogenetic abnormalities identified via FISH

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable.

Select all abnormalities identified via FISH at diagnosis.

If an abnormality is detected but not listed as an option in, select **Other abnormality** and specify. If multiple other abnormalities were detected, report “see attached report” attach the final report(s) for any other abnormality detected. For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Questions 13-14: Were cytogenetics tested via karyotyping?

If karyotyping was performed at diagnosis, report **Yes** and indicate whether abnormalities were detected. If karyotyping performed, but there wasn’t any evaluable metaphase, report, **No evaluable metaphases**. If karyotyping was not performed at this time point or it is unknown, indicate **No**.

#### Question 15-17: Specify cytogenetic abnormalities

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string if applicable. Refer to [Appendix C, Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c) for more information on how to report using the ISCN functionality.

If an abnormality is detected but not listed as an option, select **Other abnormality** and specify the abnormality. If multiple other abnormalities were detected, report “see attached report” and attach the final report(s) for any other abnormality detected. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Question 18: Were molecular markers performed? (PCR, NGS)

Molecular assessment involves testing blood or bone marrow for the presence of known molecular markers associated with the recipient’s disease. Molecular assessments are the most sensitive test for genetic abnormalities and involve amplifying regions of cellular DNA by polymerase chain reaction (PCR), typically using RNA to generate complementary DNA through reverse transcription (RT-PCR). The amplified DNA fragments are compared to a control, providing a method of quantifying log increase of genetic mutation transcripts. Each log increase is a 10-fold increase of gene transcript compared to control. Molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing.

Indicate **Yes** or **No** if tests for molecular markers were performed at diagnosis.

#### Questions 19-20: Specify the positive molecular markers

Specify the positive molecular marker. If a positive marker is detected, but not listed as an option, select **Other molecular marker** and specify.

If molecular markers were not identified, select **None**.

#### Questions 21-22: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported.

For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](https://varnomen.hgvs.org/recommendations/protein/).

Indicate if the amino acid change is **Known** or **Unknown** for the positive molecular marker reported in this instance. If **Known**, report the amino acid change.

#### Question 23: Grade / Differentiation

Grade/differentiation is a standardized way of measuring how developed and organized cancer cells are in a tissue or organ. A pathologist studies a biopsy sample to determine the grade, which is based on how abnormal the cells look. The grade indicates how aggressive the cancer is and how likely it is to grow and spread:

• Grade I: Well differentiated (low grade)

• Grade II: Moderately differentiated (intermediate grade)

• Grade III: Poorly differentiated (high grade)

• Grade IV: Undifferentiated (high grade)

• Unknown

Report the grade/differentiation at diagnosis. Grading can be found the path report.

Source: [https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis/tumor-grade](https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis/tumor-grade)

#### Question 24: Solid tumor – (T) tumor

**(T) tumor**is used to describe the size of the primary tumor and its’ invasion into adjacent tissues. T-values are assessed differently based on the involved anatomic structures. A number after the T (such as T1, T2, T3, or T4) might describe the tumor size and/or amount of spread into nearby structures. The higher the T number, the larger the tumor and/or the more it has grown into nearby tissues.

- TX means there’s no information about the primary tumor, or it can’t be measured.
- T0 means there is no evidence of a primary tumor (it cannot be found).
- T1-T4 is used to identify the size and extension of the tumor, with progressive enlargement and invasiveness from T1 to T4.

Report the classification of the (T) tumor at diagnosis.

#### Question 25: Solid tumor – (N) lymph node

**(N) lymph node**is used to describe regional lymph node involvement of the tumor. Lymph nodes function as biological filters, as fluid from body tissues is absorbed into lymphatic capillaries and flows to the lymph nodes.

- NX means there’s no information about the nearby lymph nodes, or they can’t be assessed
- N0 indicates no regional nodal spread
- N1-N3 indicates some degree of nodal spread, with a progressively distal spread from N1 to N3

Report the classification of the (N) lymph node at diagnosis.

#### Question 26: Solid Tumor – (M) metastasis

**(M) metastasis**is used to identify the presence of distant metastases of the primary tumor.

- M0 means that no distant cancer spread has been found.
- M1 means that the cancer has been found to have spread to distant organs or tissues.

Report the classification of the (M) metastases at diagnosis.

1 Rosen RD, Sapra A. TNM Classification. [Updated 2023 Feb 13]. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2025 Jan-. Available from: https://www.ncbi.nlm.nih.gov/books/NBK553187/

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)