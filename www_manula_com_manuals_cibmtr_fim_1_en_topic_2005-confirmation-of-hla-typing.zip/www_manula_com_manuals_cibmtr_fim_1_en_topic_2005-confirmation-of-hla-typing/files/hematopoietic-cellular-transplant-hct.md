#### Question 22: Is a subsequent HCT planned as part of the overall treatment protocol (not as a reaction to post-HCT disease assessment) (For autologous HCTs only)

If, at the time of the current HCT, a second (tandem transplant) or subsequent HCT is planned according to the protocol, check **Yes** even if the recipient does not receive the planned subsequent HCT. The word “planned” should not be interpreted as: if the recipient relapses, then the “plan” is to perform a subsequent HCT.

#### Question 23: Specify subsequent HCT planned

Indicate whether the planned subsequent HCT is **Autologous** or **Allogeneic**.

#### Question 24: Has the recipient ever had a prior HCT?

Include all HCTs in the recipient’s history, even if the transplants were not performed at your center. The intent is to capture the full picture of the recipient’s treatment / transplant history.

If the recipient never had a prior HCT, report **No**.

#### Question 25: Specify the number of prior HCTs

Enter the number of prior HCTs for the recipient. An HCT event is defined as an infusion of mobilized peripheral blood stem cells (PBSC), bone marrow, or cord blood. For more information on how to distinguish infusion types [example: HCT versus donor cellular infusion (DCI)], see [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

For recipients who have received a previous HCT (prior to the HCT for which this form is being completed), the following are examples of how to calculate the number of prior HCTs.

**Example 1:** A recipient was previously transplanted under a protocol that included an infusion of cells over multiple days: day 0, day +1 and day +2. This series of infusions is considered one HCT event (as opposed to three HCT events) and should be counted as *HCT Event #1*.

After receiving the infusion, the recipient had relapse of disease. The recipient is scheduled to receive a subsequent HCT including a preparative regimen. This HCT is *HCT Event #2*. One prior HCT should be reported.

**Example 2:** A recipient previously received an allogeneic HCT (*HCT Event #1*). Then, due to delayed neutrophil recovery, the recipient received additional cryopreserved allogeneic mobilized PBSC from the original donor, without a preparative regimen (i.e., “boost” – *HCT Event #2*).

After receiving the boost, the recipient had relapse of disease. The recipient is scheduled to receive a subsequent allogeneic HCT with preparative regimen (HCT Event #3). Two prior HCTs should be reported.

**Example 3:** A recipient previously received an autologous HCT (*HCT Event #1*). Then due to delayed neutrophil recovery, the recipient received additional cryopreserved autologous cells without a preparative regimen (i.e., “boost” which is not counted as an HCT event because the intent of the autologous infusion is to treat the graft failure).

The boost is successful, but a few years later the recipient develops a new malignancy. The recipient is scheduled to receive a subsequent autologous HCT with preparative regimen (*HCT Event #2*). One prior HCT should be reported.

#### Question 26: Were all prior HCTs reported to the CIBMTR?

This should include any / all HCTs not performed at your center. If the recipient is a transfer patient, you will be able to see all past HCT dates in the Recipient Information Grid in FormsNet3SM. Contact CIBMTR Customer Support if there are questions.

If **Yes** or **Unknown**, continue with *Reason for current HCT*.

#### Question 27: Date of prior HCT

Report the date (YYYY-MM-DD) of the prior HCT being reported in this instance. If the exact date is unknown and must be estimated, check the **Date estimated** box.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 28: Was the prior HCT performed at a different institution?

Indicate if the prior HCT being reported in this instance was performed at another institution. If the prior HCT was not performed at a different institution, select **No**.

#### Question 29: Specify the institution that performed the HCT

Report the name, city, state, and country of the institution where the recipient’s prior HCT being reported in this instance was performed. These data are used to identify and link the recipient’s existence in the database and, if necessary, obtain data from the other institution where the previous infusion was administered

#### Question 30: What was the HPC source for the prior HCT? (check all that apply)

Report the cell source(s) for the prior HCT being reported in this instance.

An **Autologous** product has cells collected from the recipient for his / her own use.

An unrelated donor (**Allogeneic, unrelated**) is a donor who shares no known ancestry with the recipients. Include adoptive parents / children or stepparents / children.

A related donor (**Allogeneic, related**) is a blood-related relative. This includes monozygotic (identical twins), non-monozygotic (dizygotic, fraternal, non-identical) twins, siblings, parents, aunts, uncles, children, cousins, half-sibling, etc.

#### Questions 31 – 35: Reason for current HCT

Indicate the reason for the current HCT (check only one). If this was a subsequent transplant, verify that this answer is consistent with the reason for the subsequent transplant reported on the previous series of report forms.

**Graft failure / insufficient hematopoietic recovery:**Additional stem cells are required because there wasn’t any ANC recovery following HCT (primary graft failure), the hematopoietic recovery indefinitely declined after the initial hematopoietic recovery (secondary graft failure), or hematopoietic recovery was deemed insufficient or too slow for survival following previous high-dose therapy and HCT. If the reason is graft failure after initial recovery or insufficient hematopoietic recovery, also report the date of graft failure / rejection.- If autologous cells are infused for this reason, this is considered an autologous rescue; in this case, reporting will continue under the prior HCT date and a new Pre-TED form is not required.
- If allogeneic cells are infused, this would be considered a subsequent HCT, and a new Pre-TED is required, and reporting would start over.

**Persistent primary disease:**Additional stem cells are required because of the persistent presence of disease pre- and post-transplant (i.e., complete remission was never achieved following the previous transplant).**Recurrent primary disease:**Additional stem cells are required because of relapse primary disease (i.e., complete remission was achieved pre- or post-transplant, but the disease relapsed following the previous transplant). If the reason is recurrent primary disease, continue with*Date of relapse*and report the relapse date. If multiple relapses have occurred since the previous infusion, report the date of the most recent relapse.**Planned subsequent HCT, per protocol:**Additional stem cells are given as defined by the protocol for a subsequent transplant/infusion. This includes all planned subsequent transplants (including triple or quadruple transplants). This transplant is not based upon recovery, disease status, or any other assessment.**New malignancy (including PTLD and EBV lymphoma):**Additional stem cells are required because the recipient has developed a new malignancy. This does not include a transformation or progression of the original malignancy for which the recipient was transplanted. If the reason is a new malignancy, continue with*Date of secondary malignancy*and report the diagnosis date of the new malignancy. In addition, attach a copy of the pathology report using the “Add Attachment” feature in FormsNet3SM. Ensure that the date of diagnosis for the new malignancy matches the date of diagnosis for the new malignancy reported on the previous transplant’s appropriate follow-up form.**Insufficient chimerism:**In the case of a stable, mixed donor chimerism, the infusion of additional cells (usually lymphocytes and not mobilized stem cells) is typically classified as a DCI. Verify with the transplant physician that the cells given should be reported as a subsequent transplant and that stable, mixed chimerism is the reason for the transplant. However, in the case of declining chimerism – when the percentage of donor cells is sequentially decreasing on several studies, indicating possible impending graft failure – additional stem cells are required. Usually, the donor chimerism has fallen below 30-50%.**Other:**If additional stem cells are given for a reason other than the options listed, select**Other**and specify in*Specify other reason*.

#### Question 36: Has the recipient ever had a prior cellular therapy? (do not include DLIs)

Include all cellular therapy infusions, except DLIs, in the recipient’s history, even if the infusions were not performed at your center. The intent is to capture the full picture of the recipient’s treatment history.

#### Question 37: Were all prior cellular therapies reported to the CIBMTR?

This should include all cellular therapy infusions (except for DLIs) not performed at your center. If the recipient is a transfer patient, you will be able to see all past infusion dates in the Recipient Information Grid in FormsNet3SM. Contact the CIBMTR Customer Support if there are questions.

If **Yes**, all prior cellular therapies were reported to the CIBMTR or **Unknown**, continue with the Donor Information section.

#### Question 38: Date of the prior cellular therapy

Report the date (YYYY-MM-DD) of the prior cellular therapy being reported in this instance.

For information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 39: Was the cellular therapy performed at a different institution?

Indicate if the prior cellular therapy being reported in this instance was performed at another institution. If the prior cellular therapy was not performed at a different institution, select **No**.

#### Question 40: Specify the institution that performed the cellular therapy

Report the name, city, state, and country of the institution where the recipient’s prior cellular therapy being reported in this instance was performed. These data are used to identify and link the recipient’s existence in the database and, if necessary, obtain data from the other institution where the previous treatment was administered.

#### Question 41: Specify the source(s) for the prior cellular therapy (check all that apply)

Indicate the cell source(s) for the prior cellular therapy being reported in this instance. If the product is “off the self” or a “third party donor” product obtained from pharmaceutical companies or other corporate entities, donor type should still be identified.

An **Autologous** product has cells collected from the recipient for his / her own use.

An unrelated donor (**Allogeneic, unrelated**) is a donor who shares no known ancestry with the recipient. Include adoptive parents / children or stepparents / children.

A related donor (**Allogeneic, related**) is a blood-related relative. This includes monozygotic (identical twins), non-monozygotic (dizygotic, fraternal, non-identical) twins, siblings, parents, aunts, uncles, children, cousins, half-siblings, etc.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q31 – 35 | 7/19/2023 | Modify | Updated instructions on what relapse date to report when the reason for subsequent HCT is recurrent primary disease: Recurrent primary disease: Additional stem cells are required because of relapse primary disease (i.e., complete remission was achieved pre- or post-transplant, but the disease relapsed following the previous transplant). If the reason is recurrent primary disease, continue with Date of relapse and report the relapse date. If multiple relapses have occurred since the previous infusion, report the date of the most recent relapse. |
Updated for consistency / accuracy |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)