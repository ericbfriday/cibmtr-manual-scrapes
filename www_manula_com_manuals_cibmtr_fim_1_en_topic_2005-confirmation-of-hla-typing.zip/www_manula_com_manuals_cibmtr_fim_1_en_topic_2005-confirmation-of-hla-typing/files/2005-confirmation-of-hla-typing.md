For transplants using an NMDP donor or cord blood unit, the donor’s HLA typing is reported on NMDP Form 22 (Confirmation of Donor HLA Typing) and the recipient’s HLA typing is reported on NMDP Form 117 (Final Recipient HLA Typing).

In all other situations, the Confirmation of HLA Typing form (Form 2005) is used to report HLA typing for both the donor and recipient on the Transplant Essential Data (TED) and comprehensive report form (CRF) tracks. This includes:

- Non-NMDP unrelated donor
- Non-NMDP unrelated cord blood unit
- Related cord blood unit
- HLA matched related donor
- HLA mismatched related donor
- Recipient of any of the donor types listed above
- Recipient of HLA identical

A separate Form 2005 should be completed for each non-NMDP donor, recipient, or cord blood unit; however, only the recipient form is required for syngeneic transplants and HLA identical siblings. Typing on the donor / CBU must be reported when meeting any of the descriptions above.

If the recipient is receiving a subsequent HCT from the same donor and HLA Typing Forms have already been completed for the first HCT, the center does not need to complete a second set of HLA Typing Forms for the subsequent infusion. However, if a recipient is receiving a subsequent HCT from a different donor fitting one of the descriptions above, the HLA Typing Form must be completed for the new donor.

The human immune system recognizes and defends against threats from outside the body. An important component of the immune system is the **human leukocyte antigen (HLA)** genes. These genes produce proteins, some of which are expressed on the surface of cells. These surface proteins allow cells to recognize self from non-self. Cells with matching proteins are recognized as self and passed over. However, when the proteins do not match between cells, one cell is identified as non-self, and an immune reaction is triggered to destroy it.

If the HLA of a donor and a recipient do not match closely, the immune response could result in the recipient’s body attacking the transplanted cells (resulting in graft failure), or the transplanted cells attacking the recipient’s body (graft-versus-host disease).

HLA genes are divided into three classes. The two classes that are important in matching donors and recipients are class I (HLA-A, B, C) and class II (includes HLA-DR, DQ). All HLA genes are encoded on an area of chromosome six known as the Major Histocompatibility Complex (MHC).

Finding a good donor-recipient HLA match can be difficult because HLA is highly polymorphic, or variable. It can be completely unique to an individual. Since DNA is inherited from parents, the likelihood of a complete match is greater between full biological siblings than two unrelated individuals. Each individual has two copies of chromosome six (one from each parent). This means that each parent will be a haploidentical (half) match. A full sibling will have a 25% chance of being an identical HLA match, a 25% chance of being completely non-identical, and a 50% chance of being a haploidentical match.


**Figure 1. Example of Single HLA-A Locus Inheritance**

| HLA-A Heredity | Biological Mother |
|
|---|---|---|
Biological Father |
HLA-A*01 |
HLA-A*03 |
HLA-A*02 |
01, 02 | 03, 02 |
HLA-A*24 |
01, 24 | 03, 24 |

The nomenclature (naming system) of HLA is an ever-evolving field, with an international committee dedicated to maintaining standards for identifying the genes and their allele sequences. Allele names consist of 3 to 5 parts, depending on what is known about that individual allele.

#### Figure 2. HLA Nomenclature[1](#fn94271907068596bcaee516-1)

[1](#fn94271907068596bcaee516-1)

1 Anthony Nolan Research Institute. (2010). *HLA Nomenclature*. Web. 04 April 2013. [http://hla.alleles.org/nomenclature/naming.html](http://hla.alleles.org/nomenclature/naming.html)

The HLA prefix will precede the specific HLA locus (gene), which will be separated from allele-specific information by an asterisk. The first field will refer to a broad group of alleles (otherwise known as the “allele family”); this designation will be separated from the next field by a colon. The second field will refer to the specific allele, which yields a specific HLA protein. Third and fourth fields may be specified, but are considered less important since they represent differences at a DNA level, rather than at a level of protein expression, due to a synonymous coding region (exon) or substitution in the non-coding region of the gene (intron). The name may be followed by a letter, which can alter the meaning of the preceding nomenclature. For example, the letter “N” signifies a null allele that does not test serologically.

DNA testing is done at low, intermediate, or high resolution.

Low-resolution testing is equivalent to serologic testing that identifies the allele group as represented by the first field of an HLA name (e.g., HLA-A*02).

Intermediate-resolution testing is molecular testing that may have remaining ambiguities. It reports allele groups that may contain 2 to 100 or more alleles. The nomenclature for these ambiguities is not internationally standardized; it is defined by the reporting lab or organization. NMDP reports frequently include letter sets that refer to possible genotypes within an allele group. Other laboratories may list all possible genotypes (e.g., DRB1*01:01 or 01:02, DRB1*01:01/01:02), where each specified allele is possible at a single locus.

High-resolution testing, or testing at the molecular level, provides further information about the gene itself, including what specific proteins will be expressed by the cells and even differences in sequence that do not impact protein expression. For cellular transplant, matching at the high resolution level is critically important.

#### Complete this form specifying the recipient or donor HLA *at the level it was typed*.

For a glossary of terms used in this section of the manual, see [Appendix B](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-b-glossary-of-terms).

Links to Sections of the Form:

[Q1: Donor/Cord Blood Unit Identification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-12-donor-cord-blood-unit-identification)

[Q2-24: HLA Typing by DNA Technology](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q13-35-hla-typing-by-dna-technology)

[Q25-30: Antigens Defined by DNA Technology](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q36-41-antigens-defined-by-serologic-typing)

[Q31-47: Optional Antigen Reporting](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q42-58-optional-antigen-reporting)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2005.Confirmation%20of%20HLA%20Typing%20%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

*Non-NMDP unrelated donor**Non-NMDP unrelated cord blood unit**Related cord blood unit**HLA matched related donor**HLA mismatched related donor**Recipient of any of the donor types listed above*~~Match siblings/syngeneic recipients and donors participating in the Related HCT Specimen Repository~~Recipient of HLA identical

[2005: Confirmation of HLA Typing](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2005-confirmation-of-hla-typing)*A separate Form 2005 should be completed for each non-NMDP donor, recipient, or cord blood unit; however, only the recipient form is required for syngeneic transplants and HLA identical siblings.*~~Both maternal and paternal typing should be submitted, if available, for all mismatched related donor transplants on the CRF track. Additionally, cord blood maternal typing should be submitted, if available, for all unrelated cord blood transplants on the CRF track. Maternal typing is requested in addition to, and not in place of, typing performed on the donor / CBU.~~ Typing on the donor / CBU must be reported when meeting any of the descriptions above.[2005: Confirmation of HLA Typing](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2005-confirmation-of-hla-typing)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)