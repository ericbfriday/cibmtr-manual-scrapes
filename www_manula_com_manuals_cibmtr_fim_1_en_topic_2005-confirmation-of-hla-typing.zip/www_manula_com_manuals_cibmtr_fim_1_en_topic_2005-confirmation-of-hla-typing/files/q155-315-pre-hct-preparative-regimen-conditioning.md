#### Question 120: Height at initiation of pre-HCT preparative regimen

Report the recipient’s height just prior to the start of the preparative regimen. The intent of this question is to determine the height used when calculating preparative regimen drug doses. This height is usually documented on the transplant orders (for radiation and/or systemic therapy) or admitting orders.

Even if the recipient does not receive a preparative regimen, the height is still required.

#### Question 121: Actual weight at initiation of pre-HCT preparative regimen

Report the recipient’s body weight just prior to the start of the preparative regimen as documented on the transplant (for radiation and/or systemic therapy) or admitting orders. The intent of this question is to report the weight used to calculate the preparative regimen drug doses. This weight may also be the same weight reported on the Recipient Baseline (2000) Form, if applicable. Report weight to the nearest tenth of a kilogram or pound. Do not report adjusted body weight, lean body weight, or ideal body weight.

Even if the recipient does not receive a preparative regimen, the weight is still required.

#### Question 122: Was a pre-HCT preparative regimen prescribed?

Recipients are generally transplanted under a specific protocol that defines the radiation and/or systemic therapy the recipient is intended to receive as a preparative regimen. This protocol, which may be either a research protocol or standard of care protocol, should be referred to when completing this section.

However, there are instances when a preparative regimen is not given. Examples may include, but are not limited to:


- Primary diagnosis of an immune deficiency.
- Subsequent allogeneic HCT due to loss of, or poor, neutrophil engraftment.

If a preparative regimen is prescribed per protocol, check **Yes**. If a preparative regimen is not prescribed, check **No**.

For more information regarding the recipient’s preparative regimen, consult a transplant physician or contact CIBMTR Center Support.

#### Question 123: Classify the recipient’s prescribed preparative regimen

Myeloablative pre-transplant conditioning destroys bone marrow cells using high-dose radiation and/or systemic therapy. It is used to eliminate the recipient’s immune system and to leave space in the bone marrow niche for the donated cells. A myeloablative regimen is sometimes used for recipients with non-malignant diseases who require HCT for marrow reconstitution (i.e., immunodeficiencies) or to produce a complete donor chimerism.

Non-myeloablative stem cell transplant (**NMA** or **NST**) and reduced-intensity conditioning (**RIC**) preparative regimens generally use lower doses of radiation and/or systemic therapy to prevent graft rejection and to suppress the recipient’s hematopoietic immune system, but not eliminate it completely. Non-myeloablative protocols rely on the immune cells of the donor to destroy the disease (called graft versus tumor or GVT effect), and typically produces mixed chimerism. NST is a common treatment option for recipients who are older or who have other health problems, as the lower radiation and/or systemic therapy doses are easier for the recipient to tolerate.

In general, RIC includes any regimen that does not meet the criteria for either myeloablative or non-myeloablative regimens.

The determination of the intent of the regimen should be based on the center’s protocol or the opinion of the physician overseeing the care of the recipient. However, if the intent is not specified, the regimen intensity may be reported based on the CIBMTR operational guidelines below.

**Table 1. Examples of Myeloablative, Reduced Intensity, and Non-Myeloablative Regimens**

| Myeloablative Regimens | Reduced Intensity and Non-Myeloablative Regimens |
|---|---|
| • TBI > 500 cGy (single) or > 800 cGy (fractionated) • Cyclophosphamide + TBI (> 500 cGy (single) or > 800 cGy (fractionated)) • Cyclophosphamide + Etoposide + TBI (> 500 cGy (single) or > 800 cGy (fractionated)) • Busulfan > 7.2 mg/kg IV or >9.0mg/kg orally • Busulfan >300 mg/m2 IV or >375 mg/m 2 orally• Busulfan (> 7.2 mg/kg IV or >9.0mg/kg orally) + Cyclophosphamide • Busulfan (>7.2 mg/kg IV or >9.0 mg/kg orally) + Melphalan >150 mg/m 2• Melphalan >150 mg/m 2• Thiotepa ≥ 10 mg/kg • Treosulfan > 30,000 mg/m 2 or > 30 g/m2 |
• TBI ≤ 500 cGy (single) or ≤ 800 cGy (fractionated) • ATG + Cyclophosphamide • BEAM (Carmustine [BCNU], Etoposide, Cytarabine [Ara-C], Melphalan) • Busulfan ≤ 7.2 mg/kg IV or ≤ 9.0mg/kg orally • Busulfan ≤ 300 mg/m 2 IV or ≤ 375 mg/m2 orally• Melphalan ≤ 150 mg/m 2• Fludarabine + Cytarabine • Fludarabine + Cyclophosphamide • Fludarabine + TBI ≤ 500 cGy (single) or ≤ 800 cGy (fractionated) • Thiotepa < 10 mg/kg • Treosulfan ≤ 30,000 mg/m 2 or ≤ 30 g/m2• Etoposide + Cyclophosphamide |

Indicate whether the intent of the preparative regimen was **Myeloablative** (to produce marrow ablation or pancytopenia), **Non-myeloablative**, or **Reduced intensity**.

#### Question 124: Was irradiation planned as part of the pre-HCT preparative regimen?

If irradiation is planned as part of the preparative regimen, check **Yes**. If irradiation is not planned, check **No**.

Irradiation performed as previous treatment should not be reported in this section. Report irradiation performed as previous treatment on the appropriate Disease Specific Form. Additionally, “radiation boosts,” often given to smaller sites that may have residual malignant cells or to areas that were shielded (i.e., chest wall or lung), should not be reported in this section. Report irradiation boosts administered on the applicable Recipient Baseline Data (2000) Form.

#### Question 125: What was the prescribed radiation field?

Indicate if the planned irradiation was to **Total body**, **Total body by intensity-modulated radiation therapy (IMRT)**, **Total lymphoid or nodal regions**, or **Thoracoabdominal region**.

#### Question 126: Total prescribed dose

Enter the total dose of radiation prescribed. If radiation was prescribed as a single dose, the amount of radiation delivered in the single dose constitutes the total dose. If the radiation was prescribed in fractionated doses, multiply the dose per fraction by the total number of fractions to determine the total dose. Enter the total dose of radiation in either grays (Gy) or centigrays (cGy).

**Example:**

Radiation Order: TBI, 200 cGy/day for three days (3 doses)

Total dose: 200 cGy x 3 doses = 600 cGy

Report “Total Dose” as: 600 cGy

#### Question 127: Date started

Enter the date the single dose or first fraction of radiation was administered.

#### Question 128: Was the radiation fractionated?

Radiation is either delivered as a single dose or in several treatments (fractions). Radiation is fractionated to increase the loss of diseased cells, as they do not recover as quickly as disease-free cells.

Indicate if the radiation was fractionated. If the radiation was not fractionated, check **No**.

#### Question 129: Total number of fractions

Enter the total number of fractions (treatments) of radiation that were administered. The recipient may receive more than one fraction per day (hyperfractionation).

The total number of fractions multiplied by the dose per fraction must be equal to the total dose reported above.

#### Questions 130 – 131: Drug

The form lists each drug by the generic name. The following website provides the trade names under which generic drugs are manufactured: [http://www.rxlist.com/script/main/hp.asp](http://www.rxlist.com/script/main/hp.asp).

The **Other drug** category should be used only if the drug is not one of the listed options. If an “other” drug is prescribed, list the name of the drug. Include any intrathecal drugs the recipient received for prophylaxis or treatment of CNS disease within 21 days prior to the start of the preparative regimen. Do not report additional sites of radiation (e.g., cranial boost) in the “other” drug category. If the recipient is assigned to the Comprehensive Report Forms by the form selection algorithm, the additional sites of radiation will be reported on the Recipient Baseline Form (Form 2000). If the recipient is assigned to TED Forms by the form track selection algorithm, the additional sites of radiation will not be reported.

If the Pre-TED is being completed for a subsequent HCT, do not report therapy that was given to treat the recipient’s disease (between the previous and current planned HCTs) in the preparative regimen section.

If there is a change to the chemotherapy preparative regimen (e.g., from busulfan + fludarabine to melphalan + fludarabine) after the Form 2400 has been submitted, return to the Pre-TED (2400) form and make this correction directly in FormsNet3SM to ensure that the chemotherapy reported reflects the actual chemotherapy regimen given.

#### Question 132: Total prescribed dose

Report the ** total dose** of each drug as

**prescribed**in the preparative regimen section of the HCT protocol.

**Do not report the prescribed**. Report the drug doses to the nearest tenth. For paper submission, do not modify the number of boxes or include decimal values. The pharmacy record or Medication Administration Record (MAR) should be used for determining the date the drug was started.

*daily*doseReport the dose units as either “mg/m2,” “mg/kg,” “AUC (mg x h/L),” “AUC (µmol x min/L),” or “CSS (ng/mL).” If the total prescribed dose is reported in a unit other than those listed, convert the dose to the appropriate unit. See the example below or consult with a transplant pharmacist for the appropriate conversion. If drug doses cannot be converted to the unit listed (e.g., Campath), leave the unit field blank, override the error (using “unable to answer”), and attach a copy of the source document to the Pre-TED using the attachment feature in FormsNet3.

Pharmacokinetic testing can be used to determine whether the drug concentration in the bloodstream is appropriate to the dose given. This reflects the speed of absorption and elimination of the drug. These tests are usually performed using the first dose of systemic therapy, or a test dose, where multiple samples are drawn at specific time points following the first dose. The samples are sent to a laboratory that performs the testing to determine the drug concentration. If carboplatin was prescribed, indicate if pharmacokinetic testing was performed to determine the preparative regimen dosing. If it is not known whether or not this testing was performed, consult a transplant physician.

A common example of this situation occurs in the use of busulfan. When pharmacokinetic (pK) testing is performed, the ordered busulfan dose can be calculated from either the *AUC dose* or *daily AUC*. If an *AUC dose* is documented, this can be multiplied by the number of ordered doses in order to calculate the ordered busulfan dose. When a *daily AUC* is documented, this can be multiplied by the number of days in order to calculate the ordered busulfan dose. See the example below for more information.

**Example – Calculating the ordered dose of Busulfan using AUC dose:** The AUC dose in the example below is 2842 uMol x Min, which was prescribed for a total of 5 doses. The total ordered dose of Busulfan in this scenario should be reported as 14,210 uMol x Min.

In some cases, a “test dose” of the drug is given before the actual preparative regimen is started, and this dose is used for acquiring drug levels that are used to adjust the dose that will be used in the preparative regimen. In other situations, the first dose of the drug is given in the usual fashion as part of the preparative regimen. After this first dose, serum drug levels are drawn and sent to a reference lab. The drug is continued at the starting dose until the lab results are reported and adjustment is made to later doses.

When a drug is used for the preparative regimen where pharmacokinetics will be tested, it is important to distinguish whether the testing will be done with a “test dose” before beginning the preparative regimen or using the first dose of the preparative regimen. The reporting of the dosing for the CIBMTR forms depends upon this distinction. This helps distinguish whether the dose is part of the therapeutic regimen, or not.

- A test dose was given
**> 24 hours**prior to the intended therapeutic dosing.**Example:**A patient with AML underwent allogeneic HCT from a sibling; busulfan and cyclophosphamide were used as the preparative regimen. The patient presented to clinic 9 days before the HCT, where a dose of busulfan at 0.5 mg/kg was given intravenously. Blood samples were drawn for the next 6 hours, after which the patient left the clinic. His samples were sent to a lab, results were returned the next day, and an adjusted dose of busulfan was calculated. He returned to the hospital 6 days before HCT, and began to receive busulfan at the adjusted dose intravenously for 4 days, followed by cyclophosphamide, and proceeded to receive his cells. Since he received 0.5 mg/kg as a “test dose,” this would not be reported in his total preparative regimen dose.

If a test dose was given, where the dose was distinct from the therapeutic dosing preparative regimen (often 1-2 or more days prior to the initiation of regular dosing), the following should be reported:- On the Pre-TED (2400) form, the total prescribed dose per protocol would NOT include the test dose.
- On the Baseline (2000) form, the start date of the chemotherapy agent should be reported as the date the first therapeutic dose was administered. The actual dose received would NOT include the test dose.


- The first dose of therapeutic dosing is used for monitoring.
**Example:**A patient with MDS received an allogeneic HCT from an unrelated donor; busulfan and fludarabine were used as the preparative regimen. She was admitted to the hospital 7 days before her HCT, and received a dose of busulfan at 0.8 mg/kg IV at 6:00 AM. Serum samples were drawn every 30 minutes until the next dose of Busulfan at 0.8 mg/kg IV was given at 12:00 noon. Her blood was sent to a reference lab, and she continued to receive busulfan every 6 hours. On day -6, the lab called with her drug levels, and it was determined that the current dose was correct. No adjustment was made, and she completed all 16 doses of busulfan. Since the dose of busulfan (0.8 mg/kg) that was used for drug testing was ALSO her first dose of the preparative regimen, it should be included in the amount of drug that was given for preparative regimen. The total prescribed dose per protocol should be reported as “13 mg/kg.” (0.8 mg/kg x 16 doses = 12.8 mg/kg rounded to 13 mg/kg).

If the first dose of the preparative regimen was used to determine pharmacokinetics, the following should be reported:- On the Pre-TED (2400) form, the total prescribed dose per protocol would include the dose used for monitoring.
- On the Baseline (2000) form, the start date of the chemotherapy agent should be reported as the date the first dose was administered. The actual dose received would include the dose used for monitoring.



Test doses must be reported consistently at your center. Since most centers follow a consistent approach to pharmacokinetic testing, it should be straightforward for the center to adopt a consistent approach to the reporting of test doses.

#### Question 133: Date started

Enter the date when the first dose of the preparative regimen drug was administered. The pharmacy record or Medication Administration Record (MAR) should be used for determining the date the drug was started.

#### Question 134: Specify administration (busulfan only)

Report the busulfan administration route as either **Oral**, **IV**, or **Both**.

**Section Updates:**

Report the recipient’s actual body weight just prior to the start of the preparative regimen. The intent of this question is to report the actual weight at the time the preparative regimen starts (which may be different than the weight used to determine preparative regimen doses). This weight is usually documented on the transplant orders (for radiation and/or systemic therapy) or admitting orders. Report weight to the nearest tenth of a kilogram or pound. Do not report adjusted body weight, lean body weight, or ideal body weight.

Even if the recipient does not receive a preparative regimen, the weight is still required.

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q120 | 2/15/2023 | Remove | Instructions for reporting the height prior to prep were updated: Report the recipient’s height just prior to the start of the preparative regimen. The intent of this question is to determine the height used when calculating preparative regimen drug doses. This height is usually documented on the transplant orders (for radiation and/or systemic therapy) or admitting orders. |
Due to change in form revision |
| Q121 | 4/19/2024 | Remove | Instructions reporting weight prior to prep updated: Report the recipient’s body weight just prior to the start of the preparative regimen as documented on the transplant (for radiation and/or systemic therapy) or admitting orders. The intent of this question is to report the weight used to calculate the preparative regimen drug doses. This weight may also be the same weight reported on the Recipient Baseline (2000) Form, if applicable. Report weight to the nearest tenth of a kilogram or pound. Do not report adjusted body weight, lean body weight, or ideal body weight. Even if the recipient does not receive a preparative regimen, the weight is still required. |
Sentenced incorrectly removed |
| Q121 | 4/15/2024 | Remove | Instructions reporting weight prior to prep updated: Report the recipient’s body weight just prior to the start of the preparative regimen as documented on the transplant (for radiation and/or systemic therapy) or admitting orders. The intent of this question is to report the weight used to calculate the preparative regimen drug doses. This weight may also be the same weight reported on the Recipient Baseline (2000) Form, if applicable. Report weight to the nearest tenth of a kilogram or pound. |
Sentenced missed when instructions were updated on 4/3/2024 |
| Q121 | 4/3/2024 | Modify | Instructions for reporting the weight prior to prep were updated: Report the recipient’s |
Incorrect instructions |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)