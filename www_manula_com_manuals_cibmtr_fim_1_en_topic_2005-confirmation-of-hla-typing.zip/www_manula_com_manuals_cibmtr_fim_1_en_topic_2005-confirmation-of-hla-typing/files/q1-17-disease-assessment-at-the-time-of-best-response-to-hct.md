#### Question 1: Compared to the disease status prior to the preparative regimen, what was the best response to HCT since the date of last report? (Include response to any therapy given for post-HCT maintenance or consolidation, but exclude any therapy given for relapsed, persistent, or progressive disease)

Any specified therapy administered post-HCT to prolong remission or for minimal residual disease is considered part of the HCT and should be included when assessing the recipient’s response to transplant. Treatment given post-HCT for relapsed or persistent disease is not considered part of the HCT and should be excluded when assessing the response to HCT. If treatment was given post-HCT for relapsed or persistent disease, assess the patient’s best response prior to the start of therapy. If therapy was only given for reasons other than relapsed or persistent disease, assess the patient’s best response throughout the entire duration of the reporting period.

If the recipient was in remission at the start of the preparative regimen, indicate “continued complete remission” and continue with question 2.

If the recipient was not in remission at the start of the preparative regimen, indicate their best response to transplant and continue with question 2. If the recipient did not have their disease evaluated by any method of assessment, including physical examination, report “not assessed” and continue with question 18.

**See WM Response Criteria for disease status definitions.**

#### Question 2: Was the date of best response previously reported?

If the patient achieved their best response to transplant in the current reporting period, indicate “no” and continue with question 3.

If the recipient achieved their best response to transplant during a previous reporting period, indicate “yes” and continue with question 18.

#### Question 3: Date assessed

Report the date of the assessment that established the best disease response to transplant. Enter the date the sample was collected for pathological and laboratory evaluation.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 4-5: Absolute lymphocyte count

Indicate whether the lymphocyte count was “known” or “unknown” at the time of best response to transplant. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 5. If “unknown,” continue with question 6.

#### Questions 6-8: IgM

Indicate whether the IgM level was “known” or “unknown” at the time of best response to transplant. If “known,” report the laboratory value and unit of measure in question 7; report the laboratory upper limit of normal value and unit of measure in question 8. If “unknown,” continue with question 9.

#### Questions 9-10: Serum monoclonal protein (M-spike) (only from electrophoresis)

Indicate whether serum monoclonal protein quantification from electrophoresis was “known” or “unknown” at the time of best response to transplant. If “known,” report the laboratory value and unit of measure in question 10. If serum electrophoresis was done and did not show monoclonal protein, report “0.” If “unknown,” continue with question 11.

#### Questions 11-12: Urinary monoclonal protein (M-spike)

Indicate whether 24-hour urine monoclonal protein quantification from electrophoresis was “known” or “unknown” at the time of best response to transplant. If “known,” report the laboratory value and unit of measure in question 12. If urine electrophoresis was done and did not show monoclonal protein, report “0.” If “unknown,” continue with question 13.

#### Questions 13-14: Bone marrow aspirate (examined for histologic involvement)

Indicate whether the extent of histologic involvement in the bone marrow aspirate was “known” or “unknown” at the time of best response to transplant. If bone marrow aspirate was not examined, report “not applicable.” If “known,” report the extent of aspirate histologic involvement in question 14. If “unknown” or “not applicable,” continue with question 15.

#### Questions 15-16: Bone marrow biopsy (examined for histologic involvement)

Indicate whether the extent of histologic involvement in the bone marrow biopsy was “known” or “unknown” at the time of best response to transplant. If bone marrow biopsy was not examined, report “not applicable.” If “known,” report the extent of biopsy histologic involvement in question 16. If “unknown” or “not applicable,” continue with question 17.

#### Question 17: Specify the type of histological involvement in marrow

WM and LPL are often characterized by histologic involvement of the bone marrow. However, there are variations in the type of involvement:[1](#fn135970793068596c0fb20bf-1)

*Lymphoplasmacytoid*: This variant is primarily defined by small lymphocytes with some plasmacytoid lymphocytes and rare mature plasma cells. Lymphoplasmacytoid cells (plasmacytoid lymphocytes) are mononuclear cells with dark, irregular nuclei. They are slightly larger than a small lymphocyte. Additionally, mitotic and large cells are rare.*Lymphoplasmacytic*: In this variant, the involved cells are a mix of small lymphocytes, plasmacytoid lymphocytes, and mature plasma cells. Mitotic and large cells are rare.*Polymorphous*: This variant can resemble either lymphoplasmacytoid or lymphoplasmacytic variants, but mitotic and large cells are more common. Large cells are still less common than in large cell lymphomas.

Specify the type of histologic involvement as indicated by the pathology report or transplant physician. Report “unknown” if the bone marrow was not examined, there was no bone marrow involvement, or if the type of histologic involvement cannot be specified.

1 Ioachim HL, Medeiros LJ. (2009) *Lymph Node Pathology*, *4th edition*. Philadelphia, PA: Lippincott Williams & Wilkins.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)