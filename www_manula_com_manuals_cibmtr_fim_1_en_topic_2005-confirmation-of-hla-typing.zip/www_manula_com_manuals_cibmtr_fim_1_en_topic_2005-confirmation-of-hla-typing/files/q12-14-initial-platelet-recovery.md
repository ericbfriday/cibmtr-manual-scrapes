*Optional for Non-U.S. Centers*

The following questions refer to **initial** platelet recovery following the HCT for which this form is being completed. All dates should reflect **no platelet transfusions administered for seven consecutive days.** Report the date of the first of three consecutive laboratory values ≥ 20 × 109/L obtained on different days, as shown in the [Reporting Platelet Recovery example](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q12-14-initial-platelet-recovery#Plat) below. Note that platelet recovery may take place well after the recipient has returned to the referring physician for care. It is essential that information and laboratory values be obtained from the referring physician.

Transfusions temporarily increase blood cell counts. When the data is later used for analysis, it is important to be able to distinguish between a recipient whose own body was creating the cells and a recipient who required transfusions to support the counts.

The following example illustrates the procedure to follow for reporting platelet recovery.

**Reporting Platelet Recovery**

Transfusion |
|||||||||||
|---|---|---|---|---|---|---|---|---|---|---|---|
Day |
0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
Platelet Count |
10,000 | 35,000 | 30,000 | 25,000 | 10,000 | 15,000 | 19,000 | 23,000 | 25,000 | 40,000 | 50,000 |
Date |
1/1/2008 | 1/2/2008 | 1/3/2008 | 1/4/2008 | 1/5/2008 | 1/6/2008 | 1/7/2008 | 1/8/2008 | 1/9/2008 | 1/10/2008 | 1/11/2008 |
1st of 3 |

Report **1/8/08** as date platelet count ≥ 20 × 109/L

#### Question 7: Was an initial platelet count ≥ 20 × 109/L achieved?

Indicate whether or not there was evidence of initial platelet recovery following this HCT.

Check only one response:

- Select
**Yes**if platelet count ≥ 20 × 109/ L was achieved and sustained for 3 consecutive laboratory values, obtained on different days without platelet transfusions administered in the previous 7 days - Select
**No**if platelet count was not ≥ 20 × 109/ L or if platelet transfusions were administered in the previous 7 days. - Check
**Not applicable**, if the recipient’s platelets never dropped below 20 × 109/L at any time post-HCT and a platelet transfusion was never required. If the recipient’s platelet count drops below 20 × 109/L and/or the recipient received a platelet transfusion even once, do not use this option. This option is only applicable in the 100-day reporting period. - Check
**Previously reported**if this is the six-month or annual follow-up, and initial platelet recovery has already been reported on a previous form.

#### Question 8: Date platelet ≥ 20 × 109/L

Enter the **first** date of three consecutive laboratory values obtained on different days where the platelet count was ≥ 20 × 109/L. Ensure that no platelet transfusions were administered for seven days immediately preceding this date. Include day seven, as shown in the [Reporting Platelet Recovery example](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q12-14-initial-platelet-recovery#Plat) above, when determining the recovery date.

If three laboratory values were not obtained on consecutive days, but a sequential rise of ≥ 20 × 109/L is demonstrated, follow the examples below when determining an estimated date.

**Reporting Scenarios:**

**A.** The recipient is being seen in the outpatient clinic and receives a platelet transfusion on January 1. The platelet count is 22 × 109/L on January 2, 24 × 109/L on January 3, and 28 × 109/L on January 4. The recipient does not come into the clinic for evaluation until one month later. The recipient has not received any more platelet transfusions and the platelet count is well above 20 × 109/L. Report January 8 (day seven post-platelet transfusion) for the date of platelet recovery.

**B.** The recipient is being seen in the outpatient clinic and receives a platelet transfusion on January 1. The platelet count is ≥ 20 × 109/L on January 2, January 3, and January 4. The recipient is then discharged back to their primary care physician. The transplant center receives a follow-up note from the primary care physician that states “recipient recovered their platelets in January of 2011.” Report an estimated date of recovery using the guidelines available in General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)