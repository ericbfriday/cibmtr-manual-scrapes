#### Question 1: What was the best response to HCT or cellular therapy since the date of the last report? (Include response to any therapy given for post-HCT / post-infusion maintenance or consolidation, but exclude any therapy given for relapsed, persistent or progressive disease.)

The intent of this question is to determine the best overall response to HCT or cellular therapy. This is assessed in each reporting period. For any recipients in complete remission (CR) or complete remission with incomplete hematologic recovery (CRi) at the time of infusion, report “Continued Complete Remission” for question 1 and go to question 41.

When evaluating the best response, determine the disease status within the reporting period using the international working group criteria provided in the in AML Response Criteria section of the Forms Instructions Manual. Compare this response to all previous post-infusion reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status. See question 2 to indicate that this disease status was previously reported.

Include response to any post-infusion treatment planned as of Day 0. If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR or as preemptive therapy for recipients with minimal residual disease, consider this “planned therapy,” even if this was not documented prior to the transplant. * Do not include response any treatment for relapse, progression, or persistent disease.* If a recipient started treatment for relapse, progression, or persistent disease, report the best response prior to the initiation of treatment (even if this was confirmed in a prior reporting period).

**Best Response to HCT Reporting Scenarios:**

**A.** A recipient in complete remission at the time of infusion has a disease relapse detected on their first bone marrow biopsy post-HCT. They do not achieve a sustained recovery of their absolute neutrophil count by day 100.

*100 Day Follow-Up Form:*

**Question 1:** Report “Continued complete remission.” This option should be used for all recipients in CR at the time of infusion regardless of post-infusion disease assessments.

**B.** A recipient in primary induction failure at the time of infusion achieves a CRi on 6/1/2016. Their platelets are persistently low through their day 100 contact date (6/15/2016); however, they do rise / remain above 100 × 109/L beginning 6/30/2016 at which time the recipient’s disease status was CR.

*100 Day Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “No.” The date of best response has not been previously reported. Never report “Yes” for question 2 on the day 100 follow-up form.

**Question 3:** Report 6/1/2016 as indicated in the report scenario.

*Six Month Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “Yes.” The date of best response was previously reported on the 100 day follow-up form.

**Question 3:** Leave blank. This question will not be answered when question 2 has been answered “Yes.”

**C.** A recipient in primary induction failure at the time of infusion achieves a CR during the 100 day reporting period on 5/1/2014. The recipient has a disease relapse during the 6 month reporting period and their disease status remains “Relapse” on the 6 month date of contact despite multiple treatments.

*100 Day Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “No.” The date of best response has not been previously reported. Never report “Yes” for question 2 on the day 100 follow-up form.

**Question 3:** Report 5/1/2014 as indicated in the report scenario.

*Six Month Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “Yes.” The date of best response was previously reported on the 100 day follow-up form.

**Question 3:** Leave blank. This question will not be answered when question 2 has been answered “Yes.”

*Note, once a CR / CRi is achieved post-infusion, the best response will always be reported as CR for question 1. Changes to disease status after CR / CRi is achieved are not reported in question 1.*

#### Question 2: Was the date of best response previously reported?

If the best response to HCT / cellular therapy was first documented during the current reporting period, report “no” and go to question 3. If the best response was achieved during a previous reporting period (and therefore reported on a previous AML Post-Infusion Data Form), report “Yes” and go to question 41.

Do not report “Yes” if completing this form for the 100 day reporting period.

#### Question 3: Date assessed

Report the date the best response to HCT / cellular therapy was established. This should be the earliest date when all international working group criteria for the response reported in question 1 were met. Report the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear). If no pathologic, radiographic, or laboratory assessments were performed to establish the best response, report the office visit in which the physician clinically evaluated the response.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms.](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms)

## Disease Assessments at Time of Best Response

For reporting purposes, the definition of “at the time of best response” depends on the reporting period. See Disease Assessment Time Windows below. Only consider assessments with samples collected within the time window which corresponds to the follow-up form being completed. If assessments were performed during the reporting period, but the samples were not collected within the indicated time window, consider them “Not done” when completing questions 4-40.

#### Table 1. Disease Assessment Time Windows

| Follow-Up Form | Approximate Time Window |
|---|---|
| 100 Day | + / – 15 days of date of best response (Question 3) |
| 6 Month | + / – 15 days of date of best response (Question 3) |
| Annual | + / – 30 days of date of best response (Question 3) |

#### Question 4: Were tests for molecular markers performed (e.g. PCR, NGS)?

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If testing for molecular markers was performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#DzA)), report “Yes” and go to question 5.

If molecular marker testing was not performed at the time of best response or it is unknown if testing was done, report “No” or “Unknown” respectively and go to question 15.

#### Question 5-14: Specify results

For each molecular marker in questions 5-14, report whether testing was “Positive,” “Negative,” or “Not done.” If tests identified a molecular marker other than those listed in questions 5-12, report the result in question 13 and specify the marker in question 14.

If multiple “Other molecular marker[s]” were tested at the time of best response, report one instance (i.e., copy) of question 13-14 for each “Other molecular marker” tested. If greater than 3 “Other molecular marker[s]” were tested, do the following:


- report one instance of question 13-14; and
- report “Positive” if any of the “Other molecular marker[s]” were positive, otherwise, report “Negative;” and
- report “see attachment” in question 14; and
- attach any / all reports documenting the results of testing for “Other molecular marker[s].”

If CEBPA is reported as “Positive” (question 5) question 6 must be completed. If the lab report does not specify whether the detected marker was biallelic / homozygous or monoallelic / heterozygous, confirm with the laboratory whether this information can be determined prior to reporting “Unknown.”

#### Question 15: Was the disease status assessed via flow cytometry?

Flow cytometry (immunophenotyping) is a technique that can be performed on blood, bone marrow, or tissue preparations where cell surface markers can be detected on cellular material. Only testing performed on the blood or bone marrow may be reported in questions 15-23.

If flow cytometry was performed at the time of best response (see Table 1), report “Yes” and go to question 16.

If flow cytometry was not performed at the time of best response, report “no” and go to question 24.

#### Question 16-19: Flow cytometry testing on blood

Indicate whether flow cytometry was performed on peripheral blood at the time of best response (refer to [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#DzA)). If “Yes,” report the date the sample was collected and whether disease was detected in questions 17 and 18 respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 19. Otherwise, go to question 20.

If flow cytometry was not performed on the blood at the time of best response, report “No” for question 16 and go to question 20.

#### Question 20-23: Flow cytometry testing on bone marrow

Indicate whether flow cytometry was performed on bone marrow at the time of best response. If “Yes,” report the date the sample was collected and whether disease was detected in questions 21 and 22 respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 23. Otherwise, go to question 24.

If flow cytometry was not performed on the bone marrow at the time of best response, report “No” for question 20 and go to question 24.

#### Question 24: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality which reflects the recipient’s disease. Testing methods you may see include conventional chromosome analysis (karyotyping) or fluorescence *in situ* hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic (karyotyping or FISH) studies were obtained at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#DzA)) report “Yes” and go to question 24.

If cytogenetic studies were attempted at the time of best response, but there were not adequate cells (metaphases), report “No,” and go to question 36.

If no cytogenetic studies were obtained at the time of best response, indicate “No” and go to question 36.

If it is not known whether any cytogenetic studies were obtained at the time of best response, indicate “Unknown” and go to question 36.

#### Question 25-26: Were cytogenetics tested via FISH?

If FISH studies were performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#DzA)), report “Yes” for question 25 and indicate whether clonal abnormalities were detected in question 26. If FISH studies were not performed, report “No” for question 25 and go to question 30. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Question 27-29: Specify cytogenetic abnormalities (FISH)

Report the number of abnormalities detected by FISH at the time of best response in question 27. After indicating the number of abnormalities in question 27, select all abnormalities detected in questions 28-29.

If a clonal abnormality is detected, but not listed as an option in question 28, select “Other abnormality” and specify the abnormality in question 29. If multiple “Other abnormalities” were detected, report “see attachment” in question 29 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 30-31: Were cytogenetics tested via karyotyping?

If karyotyping was performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#DzA)), report “Yes” for question 30 and indicate whether clonal abnormalities were detected in question 31. If karyotyping was not performed, indicate “No” and go to question 35. Examples of this include: karyotyping was not performed or karyotyping sample was inadequate.

#### Question 32-34: Specify cytogenetic abnormalities (karyotyping)

Report the number of abnormalities detected by karyotyping at the time of best response in question 32. After indicating the number of abnormalities in question 32, select all abnormalities detected in questions 33-34.

If a clonal abnormality is detected, but not listed as an option in question 33, select “Other abnormality” and specify the abnormality in question 34. If multiple “Other abnormalities” were detected, report “see attachment” in question 34 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 35: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported in questions 24-34. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 36-40: Was the disease status assessed by other assessment?

Indicate whether AML was assessed by any method other than those included in questions 4-35 at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#DzA)). If “Yes,” report the date assessed and specify the type of assessment in questions 37 and 38 respectively. Also indicate whether the reported assessment detected disease (question 38) and, if so, whether this was considered a disease relapse (question 40). If the exact date of assessment is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms.](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) If AML was not assessed by any methods other than those included in questions 4-35, report “No” for question 36 and go to question 41.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)