#### General Reporting Guidelines

- At any response level, if some but not all criteria are met, the disease status should be downgraded to next lower level of response.
- The percentage of plasma cells in the bone marrow aspirate and / or biopsy may also be identified on a flow cytometry report. A flow cytometry report may
**NOT**be used to confirm CR (e.g., < 5% plasma cells in the bone marrow). - Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.

#### Stringent Complete Remission (sCR)

Follows criteria for CR as defined below, **plus all of the following**:


- Normal free light chain ratio
- See blue box above regarding Free Light Chain Ratios

- Absence of clonal cells in the bone marrow by immunohistochemistry (confirmation with repeat bone marrow biopsy not needed). (κ/λ ratio ≤ 4:1 or ≥ 1:2 for κ and λ patients, respectively, after counting ≥ 100 plasma cells)

sCR by biochemical testing requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy.

#### Complete Remission (CR)

**Measurable Myeloma**

A treatment response where **all** of the following criteria are met:


- < 5% plasma cells in the bone marrow (confirmation with repeat bone marrow biopsy not needed);
*and* - Absence of extramedullary disease;
*and* - No plasma cells in peripheral blood;
*and* - Negative immunofixation on serum and urine samples.

**Non-Measurable Myeloma**

If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria at time of diagnosis):


- Serum M-protein ≥ 1 g / dL
- Urine M-protein ≥ 200 mg / 24 hours

then a normal serum free light chain (FLC) ratio is required in place of the M-protein criteria (provided the serum FLC assay showed an involved level > 10 mg / dL and an abnormal serum FLC ratio at diagnosis).

CR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy CR requirements

The method of the two consecutive assessments may be any of the biochemical tests (urine/serum testing) listed in the disease status criteria available in the manual. Though it is preferable the biochemical confirmatory testing include both the urine & serum, this disease status does not require two consecutive assessments by each method.

#### Very Good Partial Response (VGPR)

**Measurable Myeloma**

**One or more** of the following criteria must be met:


- Bone marrow plasma cells <5% (confirmation not required)
- No plasma cells in the peripheral blood
- Absence of extramedullary disease
- Serum and urine M-protein detectable by immunofixation but not on electrophoresis
- ≥ 90% reduction in serum M-protein and urine M-protein level < 100 mg / 24 hours.

**Non-Measurable Myeloma**

If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria at time of diagnosis):


- Serum M-protein ≥ 1 g / dL
- Urine M-protein ≥ 200 mg / 24 hours

then a ≥ 90% decrease in the difference between involved and uninvolved free light chain levels is required in place of the M-protein criteria (provided the serum free light chain assay shows involved > 10 mg/dL and the serum free light chain ratio is abnormal).

VGPR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy VGPR requirements.

#### Partial Response (PR)

**Measurable Myeloma**

**One or more** of the following criteria must be met:


- 5% to 25% plasma cells in the bone marrow
- 1% to 5% plasma cells in peripheral blood
- ≥ 50% reduction in the size of extramedullary disease
- ≥ 50% reduction in serum M-protein
- ≥ 90% reduction in 24-hour urinary M-protein and < 200 mg / 24 hours

**Non-Measurable Myeloma**

If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria at time of diagnosis):


- Serum M-protein ≥ 1 g / dL
- Urine M-protein ≥ 200 mg / 24 hours

then a ≥ 50% decrease in the difference between involved and uninvolved free light chain levels is required in place of the M-protein criteria (provided the serum free light chain assay shows involved level > 10 mg/dL and the serum free light chain is abnormal).

PR by biochemical testing requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy.

#### Stable Disease (SD)

Does not meet the criteria for CR, VGPR, PR or PD.

SD requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy SD requirements.

#### Progressive Disease (PD)

**One or more** of the following criteria must be met:


- Increase of ≥ 25% from the lowest response value achieved in:
- Bone marrow plasma cell percentage (in aspirate) or absolute percentage ≥ 10%;
*and / or* - Serum M-component with an absolute increase ≥ 0.5 g / dL (or 5 g / L) (for progressive disease, serum M-component increases of ≥ 1 g / dL are sufficient if the starting M-component is ≥ 5 g / dL);
*and / or* - Urine M-component with an absolute increase ≥ 200 mg / 24 hours;
*and / or*

- Bone marrow plasma cell percentage (in aspirate) or absolute percentage ≥ 10%;
- >5% absolute increase in peripheral blood plasma cells;
*and / or* - Definite development of new bone lesions or extramedullary disease, or definite increase in the size of any existing bone lesions or extramedullary disease;
*and / or* - Development of hypercalcemia (corrected serum calcium > 11.5 mg / dL or 2.65 mmol) that can be attributed solely to the PCL.

PD by biochemical testing requires two consecutive assessments (by the same method) made at any time before classification as disease progression, and / or the start of any new therapy.

#### Relapse from CR

**One or more** of the following criteria must be met:


- Reappearance of serum or urine M-protein by immunofixation or electrophoresis;
*and / or* - Development of ≥ 10% plasma cells in the bone marrow;
*and / or* - Appearance of any other sing of progression such as:
- Development of new soft tissue plasmacytomas or bone lesions (osteoporotic fractures do not constitute progression)
- Hypercalcemia (> 11mg/dL)
- Decrease in hemoglobin of ≥ 2 g/dL not related to therapy or other non-myeloma-related conditions
- Rise in serum creatinine by 2 mg/dL or more from the start of therapy and attributable to myeloma
- Hyperviscosity related to serum paraprotein


Relapse requires two consecutive assessments (by the same method) made at any time before classification as relapse, and/or the start of any new therapy.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/12/2024 | Plasma Cell Leukemia Response Criteria | Add | Urine Immunofixation and Electrophoresis blue box added for clarification: Urine Immunofixation and Electrophoresis: The sample for the urine immunofixation and electrophoresis criteria must be a 24-hour urine and not a random urine. |
| 5/5/2021 | Plasma Cell Leukemia Response Criteria | Add | The following criteria was added for relapse: Appearance of any other sign of progression such as: Development of new soft tissue plasmacytomas or bone lesions (osteoporotic fractures do not constitute progression), Hypercalcemia (> 11mg/dL), Decrease in hemoglobin of ≥ 2 g/dL not related to therapy or other non-myeloma-related conditions, Rise in serum creatinine by 2 mg/dL or more from the start of therapy and attributable to myeloma, Hyperviscosity related to serum paraprotein |
| 5/5/2021 | Plasma Cell Leukemia Response Criteria | Modify | The response criteria for CR, VGPR, and PR were re-formatted and split between measurable and non-measurable disease. |
| 5/5/2021 | Plasma Cell Leukemia Response Criteria | Add | Confirmatory Assessments for PCL red warning box added: Questions often arise about how to report a disease response when the recipient meets all criteria for a disease response at a given timepoint (i.e., pre-infusion, 100-day date of contact, 6 month date of contact, etc.) and the confirmatory assessment is performed within the next timepoint. In this case, the disease response should be reported at the timepoint in which it was first observed (not the timepoint in which it was confirmed). Please note, this may require updating a previously submitted form. Review the examples below for further clarification. |
| 5/5/2021 | Plasma Cell Leukemia Response Criteria | Add | Urine Studies blue note box added: In order to report a Stringent Complete Response (sCR) or Complete Response (CR), urine studies MUST be performed and agree with the international myeloma working group (IMWG) criteria provided above. As long as the negative serum electrophoresis and immunofixation studies have been confirmed, only one set of negative urine studies needs to be documented to report sCR or CR. |
| 4/6/2020 | Plasma Cell Leukemia Response Criteria | Add | Added guidance on Free Light Chain Ratios. |
| 10/14/17 | Plasma Cell Leukemia Response Criteria | Add | Version 1 of the Plasma Cell Leukemia Response Criteria section of the Forms Instructions Manual released. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)