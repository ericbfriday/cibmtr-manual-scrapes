#### Question 32: Does the recipient have hepatomegaly? (≥ 2 cm below costal margin)

Indicate if the recipient had hepatomegaly in the current reporting period. Hepatomegaly may be documented during the physician’s physical assessment of the recipient or by a radiologic assessment and represents an abnormal finding.

If the recipient does not have hepatomegaly or it not known / not documented, report **No** or **Unknown**, respectively and continue with *Was liver iron content (LIC) tested?*

#### Questions 33 – 34: Is liver size known?

Specify if the liver size is known. If **Yes**, report the size of the liver in centimeters, measured below the right costal margin as assessed by the physical exam or radiologic assessment. If there are multiple liver measurements documented, report the most recent measurement.

If the liver size is not documented, report **No**.

#### Questions 35 – 37: Was liver iron content (LIC) tested?

Transfusions for hemolytic diseases may lead to iron build up or accumulation in the liver and other target organs. Liver iron content (LIC) is commonly used to measure total iron storage. Methods of assessment include, but are not limited to, liver biopsy, T2 MRI, FerriScan, and SQUID biomagnetometer.

Indicate if the LIC was assessed during the current reporting period. If **Yes**, report the value, units of measurement, and specify the method of assessment. If the LIC was assessed multiple times, report the most recent results.

#### Questions 38 – 40: Was a liver biopsy performed?

Evaluation of liver tissue may be necessary to determine the extent of the recipient’s disease. Indicate if a liver biopsy was performed during the current reporting period. If a liver biopsy was performed, report **Yes** and specify the date (YYYY-MM-DD) of the most recent liver biopsy if **Known**. This date should reflect the date the sample was collected for analysis.

If the exact date is not known, report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

If a liver biopsy was not performed or if no information is available to determine if a liver biopsy was performed, report **No** and go to *Total serum bilirubin*.

#### Question 41: Was there evidence of liver cirrhosis?

Indicate if there was evidence of cirrhosis from the liver biopsy reported above. If cirrhosis was identified, report **Yes**. If cirrhosis was not identified or no information is available to determine if cirrhosis was present, report **No** or **Unknown**, respectively.

#### Questions 42 – 43: Was there evidence of liver fibrosis?

Indicate if there was evidence of fibrosis from the liver biopsy reported above. If **Yes**, specify the type of fibrosis.

• **Bridging fibrosis:** Bands of fibrous tissue and collagen with span portal spaces / and or centrilobular spaces creating a ‘bridge-like’ appearance

• **Periportal fibrosis:** Fibrous expansion of portal fields with fibrosis extending along the terminal portal veins.

• **Other:** Select this option if fibrosis was present but the type is something other than ‘bridging fibrosis’ or ‘periportal fibrosis.’

• **Unknown**: Select this option the biopsy report indicates fibrosis was present but does not specify the type.

If fibrosis was not identified or no information is available to determine if fibrosis was present, report **No** or **Unknown**, respectively and continue with *Was there evidence of chronic hepatitis?*

#### Question 44: Was there evidence of chronic hepatitis?

Indicate if there was evidence of chronic hepatitis from the liver biopsy reported above. If chronic hepatitis was identified, report **Yes**. If chronic hepatitis was not identified or no information is available to determine if chronic hepatitis was present, report **No** or **Unknown**, respectively.

#### Question 45: Is documentation being attached? (CIBMTR recommends attaching the liver biopsy report)

Indicate if documentation (i.e., liver biopsy) is attached to this form. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 46 – 48: Total serum bilirubin

Bilirubin is a pigment that is formed from the breakdown of hemoglobin in red blood cells. Serum bilirubin is a test of liver function that reflects the ability of the liver to take up, process, and secrete bilirubin. Total bilirubin includes the direct (conjugated) and indirect (unconjugated) bilirubin values. If your laboratory reports direct and indirect separately, add the two together to report the total serum bilirubin.

Indicate if the total serum bilirubin is **Known** for the current reporting period. If **Known**, report the value, units of measurement, and specify the upper limit of normal. If the total serum bilirubin was assessed multiple times during the current reporting period, report the most recent results.

#### Questions 49 – 51: Direct bilirubin

Indicate if the direct (conjugated) bilirubin is **Known** for the current reporting period. If **Known**, report the value, units of measurement, and specify the upper limit of normal. If the direct bilirubin was assessed multiple times during the current reporting period, report the most recent results.

#### Question 52 – 53: AST (SGOT)

Aspartate aminotransferase, or serum glutamic oxalic transaminase, is an enzyme measured in serum or plasma that reflects liver function and liver cell integrity. Elevated levels of AST may indicate liver damage.

If **Known**, report the value and units of measurement. If the AST was assessed multiple times during the current reporting period, report the most recent results.

#### Question 54 – 55: ALT (SGPT)

Alanine aminotransferase, or serum glutamic pyruvic transaminase, is an enzyme measured in the blood that reflects liver function. Elevated levels of ALT indicate liver injury, minor or severe.

If **Known**, report the value and units of measurement. If the ALT was assessed multiple times during the current reporting period, report the most recent results.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)