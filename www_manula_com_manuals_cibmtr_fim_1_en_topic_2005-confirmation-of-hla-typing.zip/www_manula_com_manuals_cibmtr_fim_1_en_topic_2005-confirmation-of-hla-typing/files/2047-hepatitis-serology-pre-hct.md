The Hepatitis Serology Pre-HCT Data, Form 2047, will come due when any of the following IDMs are reported as “positive” on the Form 2000, Recipient Baseline Data:


- Hepatitis B surface antigen
- Hepatitis B core antibody
- Hepatitis B DNA
- Hepatitis C antibody
- Hepatitis C NAT

Links to Sections


[Q1-6: Serological Evidence of Prior Hepatitis Exposure / Infection – Recipient](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-6-serological-evidence-of-prior-hepatitis-exposure-infection-recipient)[Q7-26: History of Antiviral Therapy for Hepatitis – Recipient](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q7-26-history-of-antiviral-therapy-for-hepatitis-recipient)[Q27-34: Serological Evidence of Prior Hepatitis Exposure / Infection – Donor](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q27-34-serological-evidence-of-prior-hepatitis-exposure-infection-donor)[Q35-54: History of Antiviral Therapy for Hepatitis – Donor](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q35-54-history-of-antiviral-therapy-for-hepatitis-donor)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/3/2021 |
|

~~Hepatitis B surface Antigen~~~~Hepatitis B core Antibody~~~~Hepatitis C Antibody~~

[2047/2147: Hepatitis Serology](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2047-2147-hepatitis-serology)**Published new manual for**[2047](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2047-hepatitis-serology-pre-hct)&[2147](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2147-hepatitis-serology-post-hct)Hepatitis Serology.
Last modified:
Mar 03, 2021

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)