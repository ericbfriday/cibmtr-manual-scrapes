The Leukodystrophies Pre-Infusion Data Form is one of the Comprehensive Report Forms. This form captures leukodystrophy specific pre-infusion data such as: disease assessments / laboratory studies at diagnosis, pre-infusion treatment and laboratory studies / clinical status prior to the start of the preparative regimen.

This form must be completed for all recipients whose primary disease is reported on the Pre-TED Disease Classification (2402) Form as a leukodystrophy and specified as one of the following:

- Krabbe Disease (globoid cell leukodystrophy)
- Metachromatic leukodystrophy (MLD)
- Adrenoleukodystrophy (ALD)
- Hereditary diffuse leukoencephalopathy with spheroids (HDLS)

Links to sections of the manual:

[Q1: Subsequent Transplant or Cellular Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-subsequent-transplant-or-cellular-therapies)

[Q2 – 22: Leukodystrophy Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-22-leukodystrophy-diagnosis)

[Q23 – 29: Disease Modifying Therapies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q23-29-disease-modifying-therapies)

[Q30 – 71: Clinical Status Prior to Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q23-63-clinical-status-prior-to-preparative-regimen)

[Q72: Marrow Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q72-marrow-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/6/2025 |
|

[2037: Leukodystrophies Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2037-leukodystrophies-pre-infusion)*This section is only completed for*~~gene therapy~~ Skysona® infusions Report the marrow results at last evaluation prior to the start of the preparative regimen.[2037: Leukodystrophies Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2037-leukodystrophies-pre-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)