#### Complete Remission (CR)

Normalization of WBC and resolution of organomegaly.

#### Partial Remission (PR)

≥ 50% reduction of WBC from maximum pre-treatment value and/or ≥ 50% reduction of organomegaly from pre-treatment maximum

#### Marginal Response (MR)

25-50% reduction of WBC from maximum pre-treatment value and 25-50% reduction of organomegaly from pre-treatment maximum

*or*

≥ 50% reduction of WBC from maximum pre-treatment value and no change in organomegaly

*or*

≥ 50% reduction of organomegaly from pre-treatment maximum and no change in WBC

#### Stable Disease (SD)

≤ 25% reduction of WBC from maximum pre-treatment value and/or ≤ 25% reduction of organomegaly from pre-treatment maximum

#### Progressive Disease (PD)

Increase in WBC and/or organomegaly

#### Relapse

Reappearance of disease characteristics such as leukocytosis, absolute monocytosis, and organomegaly after complete remission (CR)

#### Not assessed

No assessment of leukocytosis or organomegaly was done at any time after therapy. If the patient was not treated, no assessment of leukocytosis or organomegaly was done at any time after diagnosis.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)