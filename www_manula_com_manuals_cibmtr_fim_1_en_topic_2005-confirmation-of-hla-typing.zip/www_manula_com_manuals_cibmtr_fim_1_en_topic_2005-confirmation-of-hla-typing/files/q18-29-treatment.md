#### Question 18: Was the recipient on iron chelation?

Iron chelation therapy is used to prevent or reduce iron overload. Examples include Deferoxamine (Desferal) and Deferasirox (Jadenu, Exjade).

Indicate if the recipient was on iron chelation therapy in the current reporting period. If the recipient did not receive iron chelation therapy in the reporting period or it is not known, report **No** or **Unknown**, respectively, and continue with *Was phlebotomy performed?*

#### Question 19: Was iron chelation previously reported?

Specify if the iron chelation start date was previously reported. If iron chelation was started in prior reporting period and continued into the current, report **Yes** and continue with Is iron chelation ongoing?

The **Yes** option is not applicable for the Day 100 reporting period.

#### Questions 20 – 21: Date started

Indicate if the iron chelation start date is known. If **Known**, report the date (YYYY-MM-DD) when this therapy began.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Questions 22 – 23: Is iron chelation ongoing?

Indicate if the recipient is still receiving iron chelation therapy on the contact date. If **Yes**, continue with Was phlebotomy performed?

If **No**, report the date (YYYY-MM-DD) when the recipient received the last dose of iron chelation in the reporting period.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Question 24: Was phlebotomy performed?

Phlebotomy is a procedure in which blood is removed from the body with the goal of reducing iron overload. Phlebotomy therapy is typically a series of these procedures.

Indicate if phlebotomy was performed in the current reporting period. If phlebotomy was not performed in the reporting period or it is not known if performed, select **No** and continue with *Did the recipient have a splenectomy?*

#### Question 25: Was phlebotomy previously reported?

Specify if the phlebotomy start date was previously reported (i.e., the first phlebotomy of the series was started in a prior reporting period). If **Yes**, continue with *Is phlebotomy ongoing*.

The **Yes** option is not applicable for the Day 100 reporting period.

#### Questions 26 – 27: Date started

Indicate if the phlebotomy start date is known. If **Known**, report the date (YYYY-MM-DD) when this therapy began.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Questions 28 – 29: Is phlebotomy ongoing?

Indicate if phlebotomy is ongoing at the time of the contact date for the current reporting period. If **Yes**, continue with Splenic Assessments.

If **No**, report the date when phlebotomy ended in the reporting period (i.e., the last phlebotomy of the series).

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)