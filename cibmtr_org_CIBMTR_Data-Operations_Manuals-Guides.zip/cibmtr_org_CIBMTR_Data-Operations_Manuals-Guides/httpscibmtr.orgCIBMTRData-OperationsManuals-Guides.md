# https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides

<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides
title: Manuals & Guides
url: https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides
hostname: cibmtr.org
description: As a transplant center administrator or data manager, you play a critical role in advancing hematopoietic cell transplantation through complete, accurate and timely data submission to the CIBMTR. Your efforts are key in supporting the research that has led to increased survival and an enriched quality of life for thousands of patients.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Audit Guide, CIBMTR Reporting Application Guide, Data Management Guide, Forms Instruction Manual, FormsNet Training Guide, Manuals & Guides']
filedate: 2025-06-23
-->

#### Data Management Guide

The Data Management Guide contains information on center participation and data submission to CIBMTR and serves as a resource for individuals seeking guidance about forms due, data quality, and the functions of CIBMTR research data processing.

[View Data Management Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/getting-started)

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership
title: Center Membership
url: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership
hostname: cibmtr.org
description: The CIBMTR has established an extensive clinical database of patient outcomes. Through the submission of timely and accurate data, center administrators and clinical research professionals play a key role in helping the CIBMTR maintain - and grow - this critical database that has led to increased survival for recipients.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Center Membership, managing CIBMTR membership, working with data operations']
filedate: 2025-06-23
-->

CIBMTR has established an extensive clinical database of patient outcomes. Through the submission of timely and accurate data, center administrators and clinical research professionals play a key role in helping CIBMTR maintain - and grow - this critical database that has led to increased survival for recipients.

Learn how CIBMTR network centers interact with the different areas with CIBMTR Data Operations.

See more

Learn how to manage your CIBMTR membership.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Communications
title: Communications
url: https://cibmtr.org/CIBMTR/Data-Operations/Communications
hostname: cibmtr.org
description: CIBMTR Data Operations provides all important updates and announcements in our weekly eBlast communications. The team sends these communications via email each Tuesday to data management professionals at active centers. All eBlasts and any additional memos from the previous year are also posted on this page.
sitename: cibmtr.org
date: 2025-06-16
categories: []
tags: ['Communications, data operations communications, data operations eBlasts, weekly email']
filedate: 2025-06-23
-->

| December 31st, 2024
|
[Data Operations Updates for the Week of 12/30/24 (293)](https://cibmtr.cmail20.com/t/d-e-syhllkk-dhjyuluhhk-r/)
|
- CIBMTR Center Support Closed for New Years Holiday
- Seeking Volunteers for CIBMTR Burden Testing - Transplant Essential Data Collection
- Last Chance to Provide Your Input!
- Register for Introductory Course for New Data Managers
- 2025 Tandem Meetings Registration Now Open!
|
| December 23rd, 2024
|
[Data Operations Updates for the Week of 12/23/24 (292)](https://cibmtr.cmail20.com/t/d-e-sydllid-dhykkijtij-r/)
|
- CIBMTR Center Support Closed for Christmas and New Year Holidays
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- TC Query Report Enhancements
- We Want Your Input for the 2025 Tandem Audit Highlights Presentation!
- Register for Introductory Course for New Data Managers
- 2025 Tandem Meetings Registration Now Open!
|
| December 23rd, 2024
|
[Seeking Volunteers for CIBMTR Burden Testing (291)](https://cibmtr.cmail20.com/t/d-e-swuklk-dhykkicdi-r/)
|
- Seeking Volunteers for CIBMTR Burden Testing - Transplant Essential Data Collection
|
| December 17th, 2024
|
[Data Operations Updates for the Week of 12/16/24 (290)](https://cibmtr.cmail20.com/t/d-e-sskuit-dhvudolu-r/)
|
- We Want Your Input for the 2025 Tandem Audit Highlights Presentation!
- Register for Introductory Course for New Data Managers
- 2024 Center-Specific Survival Analysis Report Now Available on CIBMTR Portal
- Cell Therapy Reporting Guides
- Center Specific Survival Analysis (TCSA) Notification
- 2025 Tandem Meetings Registration Now Open!
|
| December 10th, 2024
|
[Data Operations Updates for the Week of 12/9/24 (289)](https://cibmtr.cmail19.com/t/d-e-svcjk-dhnbdjjd-r/)
|
- Center Specific Survival Analysis (TCSA) Notification
- 2025 Tandem Meetings Registration Now Open!
|
| December 3rd, 2024
|
[Data Operations Updates for the Week of 12/2/24 (288)](https://cibmtr.cmail19.com/t/d-e-satdjd-dhljmuhit-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Corporate Study Expectations
- Last Chance to Register! Cell Therapy and Gene Therapy Forum on December 5th
- Price Increase Soon! 2025 Tandem Meetings Registration Open!
|
| November 26th, 2024
|
[Data Operations Updates for the Week of 11/25/24 (287)](https://cibmtr.cmail19.com/t/d-e-smkydt-ddkhhlutx-r/)
|
- CIBMTR Center Support Closed on November 28th and 29th
- Corporate Study Expectations
- Register Now for Winter Quarterly Release Preview Webinar on December 3rd
- Register Now for Cell Therapy and Gene Therapy Forum on December 5th
- 2025 Tandem Meetings Registration Now Open!
|
| November 19th, 2024
|
[Data Operations Updates for the Week of 11/18/24 (286)](https://cibmtr.cmail19.com/t/d-e-spltdl-ddhubilih-r/)
|
- Register Now for Winter Quarterly Release Preview Webinar on December 3rd
- Update to When Confirmation of HLA Typing (F2005) Comes Due in FN3
- JOB POSTING: Director of Statistical Operations
- International Recipient CPI Notifications
- We Want Your Input!
- Register Now for Cell Therapy and Gene Therapy Forum on December 5th
- 2025 Tandem Meetings Registration Now Open!
|
| November 12th, 2024
|
[Data Operations Updates for the Week of 11/11/24 (285)](https://cibmtr.cmail19.com/t/d-e-sojjhk-dddyijilur-r/)
|
- We Want Your Input!
- Register Now for Cell Therapy and Gene Therapy Forum on December 5th
- 2025 Tandem Meetings Registration Now Open!
|
| November 5th, 2024
|
[Data Operations Updates for the Week of 11/4/24 (284)](https://cibmtr.cmail19.com/t/d-e-slhddkl-ddijdrhuuy-r/)
|
- Consent Status Review - Reconsent Pending
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- 2025 Tandem Meetings Registration Now Open!
|
| October 29th, 2024
|
[Data Operations Updates for the Week of 10/28/24 (283)](https://cibmtr.cmail19.com/t/d-e-slturo-ddtrkkjduy-r/)
|
- Reconsent Pending: Change to Process
- CIBMTR Forms Instruction Manual Updates
- October 2024 Quarterly Release - Important Information
- Center Volumes Data Report (CVDR) Notifications
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
|
| October 21st, 2024
|
[Important Fall Release Information Included - Data Operations Updates for the Week of 10/21/2024 (282)](https://cibmtr.cmail20.com/t/d-e-slyyull-ddjyljptt-r/)
|
- October 2024 Quarterly Release - Important Information
- Center Volumes Data Report (CVDR) Notifications
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
|
| October 17th, 2024
|
[Center Volumes Data Report (CVDR) Notifications (281)](https://cibmtr.cmail19.com/t/d-e-sllhjit-ddeiylhtl-r/)
|
- Center Volumes Data Report (CVDR) Notifications
|
| October 15th, 2024
|
[Data Operations Updates for the Week of 10/14/24 (280)](https://cibmtr.cmail20.com/t/d-e-euuiult-ddeiylhtl-r/)
|
- October 2024 Quarterly Release - Important Information
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
|
| October 8th, 2024
|
[Data Operations Updates for the Week of 10/7/24 (279)](https://cibmtr.cmail20.com/t/d-e-euduhlt-ddxhdlum-r/)
|
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
- Save the Date! Fall Quarterly Release Webinar
|
| October 2nd, 2024
|
[Join us for CRP/DM Track at the 2025 Tandem Meetings!](https://cibmtr.cmail20.com/t/d-e-eutkhtt-ddldwirhu-r/)
|
- 2025 Tandem Meetings Registration Now Open!
|
| October 1st, 2024
|
[Data Operations Updates for the Week of 9/30/24 (277)](https://cibmtr.cmail19.com/t/d-e-eutfiy-ddltlyeji-r/)
|
- International Recipient CPI Notifications
- Save the Date! Fall Quarterly Release Webinar
|
| September 24th, 2024
|
[Data Operations Updates for the Week of 9/23/24 (276)](https://cibmtr.cmail19.com/t/d-e-eurjhtk-diuiliuiur-r/)
|
- Center Volumes Data Report (CVDR) Notifications
- Last Chance to Register for Upcoming IRC Meeting - TED Forms
|
| September 17th, 2024
|
[Data Operations Updates for the Week of 9/16/24 (275)](https://cibmtr.cmail20.com/t/d-e-ekkdrll-dikritiyjl-r/)
|
- US Recipient CPI Notifications
- Center Volumes Data Report (CVDR) Notifications
- LAST CHANCE! Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| September 10th, 2024
|
[Data Operations Updates for the Week of 9/9/24 (274)](https://cibmtr.cmail19.com/t/d-e-ekikldd-didklrtktl-r/)
|
- Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| September 4th, 2024
|
[Center Volumes Data Report (CVDR) Notifications (273)](https://cibmtr.cmail19.com/t/d-e-ekjdua-diihdkdrui-r/)
|
- Center Volumes Data Report (CVDR) Notifications
|
| September 3rd, 2024
|
[Data Operations Updates for the Week of 9/2/24 (272)](https://cibmtr.cmail19.com/t/d-e-ekjqkt-diihdkdrui-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- Register for Upcoming Initial Review Committee (IRC) Meeting - Solid Tumor Forms
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| August 28th, 2024
|
[Center Volumes Data Report (CVDR) Notifications (271)](https://cibmtr.cmail19.com/t/d-e-ekrnjt-diirdhdrkh-r/)
|
- Center Volumes Data Report (CVDR) Notifications
|
| August 27th, 2024
|
[Data Operations Updates for the Week of 8/26/24 (270)](https://cibmtr.cmail19.com/t/d-e-eklddud-diilljnlu-r/)
|
- Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- CIBMTR Portal - Cridical Forms Past Due: Monthly Update
- Register for Upcoming Initial Review Committee (IRC) Meeting - Solid Tumor Forms
- LAST CHANCE TO REGISTER! New Data Manaer Onboarding - September 2024
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| August 20th, 2024
|
[Data Operations Updates for the Week of 8/19/24 (269)](https://cibmtr.cmail20.com/t/d-e-ehkbuk-dityjlhjij-r/)
|
- NEW! Register for Upcoming Initial Review Committee (IRC) Meeting - Solid Tumor Forms
- JOB POSTING: Scientific Director, Infection and Immune Reconstitution Working Committee
- New Data Manager Onboarding - September 2024 Registration Now Open!
- Register Now for Advanced Data Manager Training!
- Training Spotlight: Reporting Disease Assessments
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| August 14th, 2024
|
[Register Now for New Data Manager Onboarding! (268)](https://cibmtr.cmail19.com/t/d-e-ehdqdl-dijriudjdk-r/)
|
- New Data Manager Onboarding - September 2024 Registration Now Open!
|
| August 13th, 2024
|
[Data Operations Updates for the Week of 8/12/24 (267)](https://cibmtr.cmail19.com/t/d-e-ehihijy-dijriudjdk-r/)
|
- Register Now for Fall Quarterly Release Preview Webinar on August 19th
- Register Now for Advanced Data Manager Training!
- Training Spotlight: Reporting Disease Assessments
- New Data Manager Onboarding - September 2024 Registration Now Open!
- Register for Upcoming Initial Review Committee (IRC) Meetings - Transplant Essential Data Forms
|
| August 6th, 2024
|
[Data Operations Updates for the Week of 8/5/24 (266)](https://cibmtr.cmail20.com/t/d-e-ehyhkld-dieyddukl-r/)
|
- Register Now for Fall Quarterly Release Preview Webinar on August 19th
- Consent Status - Please Review List on Portal
- Register Now for Advanced Data Manager Training!
- Training Spotlight: Reporting Disease Assessments
- US Recipient CPI Notifications
- New Data Manager Onboarding - September 2024 Registration Now Open!
- Register for Upcoming Initial Review Committee (IRC) Meetings - Transplant Essential Data Forms
|
| July 30th, 2024
|
[Data Operations Updates for the Week of 7/29/24 (265)](https://cibmtr.cmail19.com/t/d-e-ehlhuyk-dibtkdidu-r/)
|
- July 2024 Quarterly Release - Important Information
- New CIBMTR Forms Instructiona Manual Update Process & Release Updates
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
- Lifileucel (Amtagvi) Reporting Guide Now Available
- Last Call for Input: Advanced Data Manager Training
|
| July 23rd, 2024
|
[Important Summer Release Information Included - CIBMTR Data Operations Updates for the Week of 7/22/24 (264)](https://cibmtr.cmail20.com/t/d-e-edkjlit-dilyiudkkj-r/)
|
- July 2024 Quarterly Release - Important Information!
- New CIBMTR Forms Instruction Manual Update Process & Release Updates
- International Recipient CPI Notifications
- Input Requested: Advanced Data Manager Training
|
| July 17th, 2024
|
[Register for Upcoming Initial Review Committee (IRC) Meetings](https://cibmtr.cmail19.com/t/d-e-eddjtjk-dtutntdui-r/)
|
- Register for Upcoming Initial Review Committee (IRC) Meetings - Transplant Essential Data Forms
|
| July 16, 2024
|
[Data Operations Updates for the Week of 7/15/24 (262)](https://cibmtr.cmail19.com/t/d-e-edihux-dtutntdui-r/)
|
- July 2024 Quarterly Release - Important Information
- CIBMTR User Access Verification Update
- Input Requested: Advanced Data Manager Training
|
| July 9th, 2024
|
[Data Operations Updates for the Week of 7/8/24 (261)](https://cibmtr.cmail19.com/t/d-e-edjjldd-dtkyujkkir-r/)
|
- Semi-Annual User Access Verification for CIBMTR Applications
- Input Requested: Advanced Data Manager Training
- Save the Dates! Upcoming Quarterly Release Informational Webinars
|
| July 2nd, 2024
|
[Data Operations Updates for the Week of 7/1/24 (260)](https://cibmtr.createsend7.com/t/d-e-edluiuk-dthjhuwlr-r/)
|
- CIBMTR Center Support Closed July 4th
- Save the Dates! Upcoming Quarterly Release Informational Webinars
- US Recipient CPI Notifications
- International Recipient CPI Notifications
|
| June 26th, 2024
|
[Center Volumes Data Report (CVDR) Notification (259)](https://cibmtr.cmail20.com/t/d-e-eikuio-dtdiniyhy-r/)
|
|
| June 25th, 2024
|
[Data Operations Updates for the Week of 6/24/24 (258)](https://cibmtr.cmail19.com/t/d-e-eikjhld-dtdjdhxyh-r/)
|
- Reminder: ISCN Functionality Available within FormsNet3
- Updates to the Training & eLearnings Tile on CIBMTR Portal
- Save the Dates! Upcoming Quarterly Release Informational Webinars
|
| June 18th, 2024
|
[Data Operations Updates for the Week of 6/17/24 (257)](https://cibmtr.cmail20.com/t/d-e-eiiwud-dtiityluji-r/)
|
- Orca Products Reporting Guide
- F4100 Hypogammaglobulinemia Update
- Form Reimbursement Fee Schedule Updates
|
| June 11th, 2024
|
[Data Operations Updates for the Week of 6/10/24 (256)](https://cibmtr.cmail19.com/t/d-e-eijlitd-dttdtljduh-r/)
|
- US Recipient CPI Notifications
- International Recipint CPI Notifications
- CT Product Specific Reporting Guide Updates
|
| June 4th, 2024
|
[Data Operations Updates for the Week of 6/3/24 (255)](https://cibmtr.cmail19.com/t/d-e-eiltthl-dtjdlddutl-r/)
|
- Consent Status
- FY2023 Center Specific Audit Summary Reports Available on CIBMTR Portal
|
| May 28th, 2024
|
[Data Operations Updates for the Week of 5/27/24 (254)](https://cibmtr.cmail20.com/t/d-e-ethktiy-dtydjullf-r/)
|
- FY2023 Center Specific Audit Summary Reports Available on CIBMTR Portal
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Last Chance to Register! New Quarterly Release Preview Webinar - May 30th
- Introductory Course for New Data Managers
- Data Quality Focus in May - Best Response on Post-HCT Disease-Specific Forms: MPN F2157
|
| May 21st, 2024
|
[Data Operations Updates for the Week of 5/20/24 (253)](https://cibmtr.cmail20.com/t/d-e-etigky-dtcjukkkt-r/)
|
- CIBMTR Center Support Closed May 27th
- Final Day to Submit Feedback on CLL Forms!
- Save the Date for May 30th: New Quarterly Release Preview Webinar
- Introductory Course for New Data Managers - Registration Open!
- Data Quality Focus in May - Best Response on Post-HCT Disease-Specific Forms: MPN F2157
|
| May 14th, 2024
|
[Data Operations Updates for the Week of 5/13/24 (252)](https://cibmtr.cmail20.com/t/d-e-etyiun-dtlhgyddu-r/)
|
- Feedback Requested for CLL Forms by Tuesday, May 21, 2024
- New Report Added to the CIBMTR Portal: Critical Forms Past Due
- Save the Date for May 30th: New Quarterly Release Preview Webinar
- Data Quality Focus in May - Best Response on Post-HCT Disease-Specific Forms: MPN F2157
- Introductory Course for New Data Managers - Registration Open!
|
| May 7th, 2024
|
[Data Operations Updates for the Week of 5/6/24 (251)](https://cibmtr.cmail19.com/t/d-e-ejuktit-djuhtduruy-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
|
| April 30th, 2024
|
[Data Operations Updates for the Week of 4/29/24 (250)](https://cibmtr.cmail20.com/t/d-e-ejhxhd-djkhtrhyhj-r/)
|
- Notes from Spring (April) 2024 Release
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
|
| April 24th, 2024
|
[Important US Recipient CPI Notification (249)](https://cibmtr.createsend7.com/t/d-e-ejimjt-djhuoxlr-r/)
|
- US Recipient CPI Summary Reports Not Refreshed Today: April 24, 2024
|
| April 23rd, 2024
|
[Data Operations Updates for the Week of 4/22/24 (248)](https://cibmtr.cmail20.com/t/d-e-ejtjdld-djhhtjdldh-r/)
|
- April 2023 Quarterly Release Information
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
- Last Chance to Register! Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| April 16th, 2024
|
[Important Spring Release Information Included - Data Operations Updates for the Week of 4/15/24 (247)](https://cibmtr.cmail20.com/t/d-e-ejridx-djdukdiuht-r/)
|
- April 2024 Quarterly Release Information
- CIBMTR Forms Instruction Manual Updates
- New Cellular Therapy Reporting Guides
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
- Registration Open - Recorded New Data Manager Onboarding
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| April 9th, 2024
|
[Data Operations Updates for the Week of 4/8/24 (246)](https://cibmtr.cmail20.com/t/d-e-eykudtd-djdrddduii-r/)
|
- April 2024 Quarterly Release Information
- Form 2100 Organ Function Instructions
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
- CIBMTR Forms Instruction Manual Updates
- Registration Open! Recorded New Data Manager Onboarding
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| April 2nd, 2024
|
[Data Operations Updates for the Week of 4/1/24 (245)](https://cibmtr.cmail19.com/t/d-e-eydjrjd-djirkltjlk-r/)
|
- Save the Date! Upcoming Quarterly Release Informational Webinar
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| March 26th, 2024
|
[Data Operations Updates for the Week of 3/25/24 (244)](https://cibmtr.cmail19.com/t/d-e-esjlul-djtjdugdt-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
|
| March 19th, 2024
|
[Data Operations Updates for the Week of 3/18/24 (243)](https://cibmtr.cmail20.com/t/d-e-evlldt-djjtutvut-r/)
|
- Registration Open! Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
- Cellular Therapy Product Training and Resources
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
|
| March 14th, 2024
|
[Feedback Requested for CIBMTR TED Forms (242)](https://cibmtr.cmail19.com/t/d-e-eftlhl-djyujyhhui-r/)
|
- Feedback Requested for TED Forms by Thursday, March 28, 2024
|
| March 12th, 2024
|
[Data Operations Updates for the Week of 3/11/24 (241)](https://cibmtr.cmail20.com/t/d-e-eayujy-djydxtijr-r/)
|
- Expanded Medicare Coverage for Allogeneic HCT for MDS
- CIBMTR Forms Instruction Manual Updates
- Cellular Therapy Product Training and Resources
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
|
| March 5th, 2024
|
[Data Operations Updates for the Week of 3/4/24 (240)](https://cibmtr.cmail20.com/t/d-e-emjrtl-djqpmli-r/)
|
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
- US Recipient CPI Reminders
- International Recipient CPI Reminders
|
| February 27th, 2024
|
[Data Operations Updates for the Week of 2/26/24 (239)](https://cibmtr.cmail20.com/t/d-e-enjjit-djlhhhdtjr-r/)
|
- REGISTRATION EXTENDED! March New Data Manager Onboarding
- CIBMTR Forms Instruction Manual Updates
- 2024 Transplant Center Specific Analysis (TCSA)
|
| February 20th, 2024
|
[Data Operations Updates for the Week of 2/19/24 (238)](https://cibmtr.cmail20.com/t/d-e-elktrx-dyukurtjjy-r/)
|
- March New Data Manager Onboarding – REGISTRATION CLOSES NEXT WEEK!
- 2024 Transplant Center Specific Analysis (TCSA)
- CIBMTR Center Support – Delayed Staff Responses February 19 – 23, 2024
- Your Opinion Matters: CIBMTR.org Website
|
| February 13th, 2024
|
[Data Operations Updates for the Week of 2/12/24 (237)](https://cibmtr.cmail20.com/t/d-e-eldkhyk-dyulutlidh-r/)
|
- CIBMTR Center Support - Delayed Staff Responses February 19-23, 2024
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- 2024 Tandem Meetings - Last Chance for Virtual Registration!
- New Data Manager Onboarding - March 2024: Registration Open
- New and Improved Self-Guided Data Manager Onboarding Training
- Your Opinion Matters: CIBMTR.org Website
|
| February 6th, 2024
|
[Data Operations Updates for the Week of 2/5/24 (236)](https://cibmtr.cmail19.com/t/d-e-eltlhty-dykylyjuud-r/)
|
- New Data Manager Onboarding - March 2024: Registration Now Open!
- New and Improved Self-Guided Data Manager Onboarding Training
- Your Opinion Matters: CIBMTR.org Website
- Register for the 2024 Tandem Meetings!
|
| January 30th, 2024
|
[Data Operations Updates for the Week of 1/29/24 (235)](https://cibmtr.cmail19.com/t/d-e-elrclt-dyhyuliyky-r/)
|
- January 2024 Quarterly Release Now Live
- New Data Manager Onboarding - March 2024: Registration Now Open!
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Register for the 2024 Tandem Meetings!
|
| January 25th, 2024
|
[Important Recipient CPI Correction (234)](https://cibmtr.cmail20.com/t/d-e-vuuiddd-dyddojlhd-r/)
|
- US Recipient CPI - Correction
- International Recipient CPI - Correction
|
| January 23rd, 2024
|
[Important Winter Release Information Included - CIBMTR Data Operations Updates for the Week of 1/22/24 (233)](https://cibmtr.cmail19.com/t/d-e-vuktjdd-dydjjhdio-r/)
|
- January 2024 Quarterly Release Information
- 2024 Transplant Center Specific Analysis (TCSA)
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- New Data Manager Onboarding Coming Soon!
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Register for the 2024 Tandem Meetings!
|
| January 16th, 2024
|
[Data Operations Updates for the Week of 1/15/24 (232)](https://cibmtr.cmail19.com/t/d-e-vuikyn-dyiyhiulp-r/)
|
- January 2024 Quarterly Release Information
- New Data Manager Onboarding Coming Soon!
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Register for the 2024 Tandem Meetings!
|
| January 9th, 2024
|
[Data Operations Updates for the Week of 1/8/24 (231)](https://cibmtr.cmail19.com/t/d-e-vujjdid-dytthkjjdl-r/)
|
- CIBMTR Center Support Closed Monday, January 15th
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Save the Date: FormsNet3 ISCN Functionality Training on January 16th!
- Last Chance to Register! Introductory Course for New Data Managers on January 10th
- Register for the 2024 Tandem Meetings!
|
| January 2nd, 2024
|
[Data Operations Updates for the Week of 1/1/24 (230)](https://cibmtr.cmail19.com/t/d-e-vurgik-dyjhdyidir-r/)
|
- Save the Date: FormsNet3 ISCN Functionality Training on January 16th!
- CIBMTR Forms Instruction Manual Updates
- Introductory Course for New Data Managers
- Register for the 2024 Tandem Meetings!
- Recorded New Data Manager Onboarding
|

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Training
title: Training
url: https://cibmtr.org/CIBMTR/Data-Operations/Training
hostname: cibmtr.org
description: The CIBMTR training team provides data management professionals with in-depth information about data submission requirements as well as important field knowledge. To give you the best possible training experience, we have organized all our training materials on the CIBMTR Portal Page under Training & eLearning.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['eLearnings, job aids, New Data Manager Onboarding, Tandem Meetings: Clinical Research Professionals / Data Managers Track, Training, upcoming releases']
filedate: 2025-06-23
-->

CIBMTR's training team provides data management professionals with in-depth information about data submission requirements as well as important field knowledge. To give you the best possible training experience, we have organized all our training materials on the CIBMTR Portal Page under Training & eLearning. Trainings and other support materials include:

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms
title: Protocols & Consent Forms
url: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms
hostname: cibmtr.org
description: The CIBMTR encourages centers to invite transplant recipients and donors to participate in the CIBMTR Research Database and the CIBMTR Biorepository. To participate, centers need to use approved CIBMTR protocols and informed consent documents for the Research Database and the CIBMTR Biorepository. These protocols and informed consent documents must be submitted to each center’s local IRB for review and approval.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Biorepository, IRB, PRO protocol, Protocols & Consent Forms, research database, research sample repository']
filedate: 2025-06-23
-->

## Protocols & Consent Forms

[Main Content]
Please wait while we gather your results.

The CIBMTR Biorepository contains cell and serum samples collected from related and unrelated transplant donors, cord blood units, and recipients.

CIBMTR collects longitudinal or cross-sectional PRO data from recipients of cellular therapies who are also enrolled in the Protocol for a Research Database for Hematopoietic Cell Transplantation, Other Cellular Therapies, and Marrow Toxic Injuries (Research Database protocol).

This database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source, autologous transplants, and other cellular therapies including CART and gene therapies. Data are also collected on unrelated donors.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-System-Applications
title: CIBMTR System Applications
url: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-System-Applications
hostname: cibmtr.org
description: Quickly access CIBMTR System Applications such as FormsNet or the CIBMTR Portal.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Portal, CIBMTR System Applications, FormsNet']
filedate: 2025-06-23
-->

Provides on-demand access to CIBMTR’s suite of center-facing applications.

Access the CIBMTR Portal

Secure clinical research management system for electronic submission of outcomes data to CIBMTR, in compliance with the SCTOD.

Access FormsNet

Resource center, ticket support, FAQ and on-boarding documentation for centers utilizing or interested in using the CIBMTR data automation tools (created as a part of the Data Transformation Initiative).

Access Data Automation Portal

AGNIS® (A Growable Network Information System) is an open-source messaging system specifically designed to exchange transplant and other cellular therapy data using a secure, standards-based system.

Centers can use AGNIS to retrieve and transmit form data, extracted directly from their own institution’s database, directly to the FormsNet application using a secure and authenticated electronic data transmission system.

For information to access AGNIS and training, please click below.

Access the AGNIS Portal

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance
title: Data Operations Compliance
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance
hostname: cibmtr.org
description: Learn more about Data Operations Compliance via the CIBMTR Audit Program, CPI Compliance Program, Corporate Studies, or Data Quality. CIBMTR has established compliance programs to ensure timely and accurate submission of data to the CIBMTR Research Database. This data supports CIBMTR’s goal of promoting collaborative research that increases access and improves outcomes of all cellular therapies.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Audity Program, Corporate Studies, CPI Compliance Program, Data Operations Compliance, Data Quality']
filedate: 2025-06-23
-->

Data Operations Corporate Studies and Registries Research Coordinators ensure high quality clinical data are available for regulatory submissions, safety monitoring, contracted deliverables, and publications. They also serve as a liason to respond to and engage network centers in submitting accurate and timely data to the CIBMTR.

[Learn More](/CIBMTR/Data-Operations/Data-Operations-Compliance/Corporate-Studies)

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources
title: Support & Resources
url: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources
hostname: cibmtr.org
description: The CIBMTR provides member centers with online tools and resources to communicate with us and securely exchange data. These include: CIBMTR Center Support, fee schedule, Center Information Management, CIBMTR System Applications.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Center Information Management, CIBMTR Center Support, CIBMTR System Applications, fee schedule, Support & Resources']
filedate: 2025-06-23
-->

CIBMTR reimburses centers for all completed Comprehensive Report Forms. Reporting of TED-level data is not reimbursed, except for Form 2006 or 2003 when requested for recipients on the TED track. Once a form is designated as “CMP” in the FormsNet application, the center will be reimbursed during the next payout time point. View current rates.

CIBMTR Center Support delivers a transparent, flexible, and service-oriented experience for centers. The ServiceNow platform is a digital workflow that has been customized to meet the needs of the CIBMTR community. View Center Support.

Make updates to Center and staff information and request CIBMTR/NMDP Systems Application Access. View how to manage.

Applications Network Centers submit data to CIBMTR through. View applications.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Collection-Forms
title: Data Collection Forms
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Collection-Forms
hostname: cibmtr.org
description: In order to ensure that the most relevant data are collected, the CIBMTR, in collaboration with the global cellular therapy community, has developed a standard set of data elements to be collected for all transplant recipients.
sitename: cibmtr.org
date: 2020-10-23
categories: []
tags: ['center forms, CIBMTR forms, Data Collection Forms, data forms, Forms Instruction Manual']
filedate: 2025-06-23
-->

In order to ensure that the most relevant data are collected, CIBMTR, in collaboration with the global cellular therapy community, has developed a standard set of data elements to be collected for all transplant recipients.

Results Updated

Showing page 1 of 13

2000R6.pdf

2003R2.pdf

2004R5.pdf

2005R7.pdf

2006R6.pdf

2008R2.pdf

2010R4.pdf

2011R5.pdf

2012R3.pdf

2013-R4.pdf

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/Working-with-Data-Operations
title: Working with Data Operations
url: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/Working-with-Data-Operations
hostname: cibmtr.org
description: Learn how CIBMTR network centers interact with the different areas with CIBMTR Data Operations.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['data managers, new data manager onboarding, support for data managers, Working with Data Operations']
filedate: 2025-06-23
-->

Participating center staff who submit data to the CIBMTR are called data managers. Data managers play an important role as they report all source data for our research.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/Managing-CIBMTR-Membership
title: Managing CIBMTR Membership
url: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/Managing-CIBMTR-Membership
hostname: cibmtr.org
description: Learn how to manage your CIBMTR membership.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CRF centers, deactivating CIBMTR membership, Managing CIBMTR Membership, new center membership, participation levels, reactivating CIBMTR membership, TED only centers, updating CIBMTR membership']
filedate: 2025-06-23
-->

Membership in the CIBMTR offers many advantages to centers, most notably the opportunity to join a large network of physicians and clinical research professionals around the world who share the goal of advancing the science of cellular therapies.

TED-only centers receive all CIBMTR general mailings, including our newsletter and summary slides, and they pay member rates for attending the CIBMTR’s annual meeting.

CRF centers receive all the benefits of TED-only centers; in addition, center members may chair CIBMTR Working Committees, may be members of the Executive Committee, and have voting privileges.

Data submission requirements vary depending on your center’s level of participation. Detailed requirements are explained in the CIBMTR Data Management Guide: Center Participation.

Click here to take the next step!

For more information about new center membership and becoming part of the CIBMTR community, please visit New Center Resources.

If you wish to reactivate your CIBMTR center membership, please complete the CIBMTR Center Reactivation Questionnaire. Completing the questionnaire will start the reactivation process. If you have questions, email: cibmtr-centermaintenance@nmdp.org.

If you wish to:

Please complete the Center Withdrawal or Closure Questionnaire. A ticket will be created for you in CIBMTR Center Support. If you have questions prior to completing the questionnaire, please submit a ticket via CIBMTR Center Support under CIBMTR Center Maintenance > Center Closure/Withdrawal from Participation.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Communications/Communications-Archive
title: Communications Archive
url: https://cibmtr.org/CIBMTR/Data-Operations/Communications/Communications-Archive
hostname: cibmtr.org
sitename: cibmtr.org
date: 2023-12-18
categories: []
tags: ['Communications Archive']
filedate: 2025-06-23
-->

| December 19th, 2023 |
[Data Operations Updates for the Week of 12/18/23 (229)](https://cibmtr.cmail19.com/t/d-e-vkkehd-dyydkdhhjk-r/) |
- CIBMTR Center Support Closed December 25th-26th and January 1st
- Introductory Course for New Data Managers
- Register for the 2024 Tandem Meetings!
|
| December 12th, 2023 |
[Data Operations Updates for the Week of 12/11/23 (228)](https://cibmtr.cmail20.com/t/d-e-vkijuud-dyxllvdi-r/) |
- Introductory Course for New Data Managers
- Thank You for Attending the Cell Therapy and Gene Therapy Forum!
- New Forms With ISCN Functionality
- Register for the 2024 Tandem Meetings!
|
| December 5th, 2023 |
[Data Operations Updates for the Week of 12/4/23 (227)](https://cibmtr.cmail20.com/t/d-e-vkythik-dyljtkhryk-r/) |
- Age of Majority: Retrospective Cases
- New Forms With ISCN Functionality
- US Recipient CPI Reminders
- GVHD Immunosuppressive Agents Data Collection
- CIBMTR Forms Instruction Manual Update
- 2023 Center Volumes Data Report (CVDR)
- This Week: CIBMTR Cell Therapy and Gene Therapy Forum!
- Price Increase Soon - Register for the 2024 Tandem Meetings!
|
| November 28th, 2023 |
[Data Operations Updates for the Week of 11/27/23 (225)](https://cibmtr.cmail19.com/t/d-e-vhkuult-drulditdtk-r/) |
- Save the Date: CIBMTR Cell Therapy and Gene Therapy Forum on December 7th!
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- 2024 Tandem Meetings Registration Open!
|
| November 22nd, 2023 |
[2023 Center Volumes Data Report (CVDR) (224)](https://cibmtr.cmail19.com/t/d-e-vhdftd-drhkukilb-r/) |
- 2023 Center Volumes Data Report (CVDR) Information (Technical Issue)
|
| November 21st, 2023 |
[Data Operations Updates for the Week of 11/20/23 (223)](https://cibmtr.cmail19.com/t/d-e-vhdqiy-drhkkiydiy-r/) |
- Thank You for Attending Advanced Data Manager Training
- CIBMTR Center Support Closed November 23rd and 24th
- Save the Date: CIBMTR Cell Therapy and Gene Therapy Forum on December 7th!
- Recorded New Data Manager Onboarding
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- 2024 Tandem Meetings Registration Now Open!
|
| November 14th, 2023 |
[Data Operations Updates for the Week of 11/13/23 (222)](https://cibmtr.cmail20.com/t/d-e-vhjzjl-drdktityud-r/) |
- Save the Date: CIBMTR Cell Therapy and Gene Therapy Forum on December 7th!
- 2023 Center Volumes Data Report (CVDR)
- Recorded New Data Manager Onboarding
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- 2024 Tandem Meetings Registration Now Open!
|
| November 7th, 2023 |
[Data Operations Updates for the Week of 11/6/23 (221)](https://cibmtr.cmail19.com/t/d-e-vhlcyd-drikdykrki-r/) |
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- Advanced Data Manager Training - Only One Week Left to Register!
- 2024 Tandem Meetings Registration Now Open!
|
| November 1st, 2023 |
[2023 Center Volumes Data Report (CVDR) (220)](https://cibmtr.cmail20.com/t/d-e-vdhujjd-drirjljldt-r/) |
- 2023 Center Volumes Data Report (CVDR) Information
|
| October 31st, 2023 |
[Data Operations Updates for the Week of 10/30/23 (219)](https://cibmtr.cmail20.com/t/d-e-vdhjild-drilljulc-r/) |
- CIBMTR Center Support - Delayed Responses November 2-4, 2023
- October 2023 Quarterly Release Now Live
- CIBMTR Forms Instruction Manual Updates
- Pending Reconsent to the CIBMTR Portal
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- Last Chance to Register for Upcoming New Data Manager Training Course!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- 2024 Tandem Meetings Registration Now Open!
|
| October 24th, 2023 |
[Important Fall Release Information Included - Data Operations Updates for the week of 10/23/23 (218)](https://cibmtr.cmail19.com/t/d-e-vdttlg-drtridkyhi-r/)
|
- October 2023 Quarterly Release Information
- Save the Date! Upcoming Quarterly Release Informational Webinar
- Upcoming Training Opportunity for New Data Managers
- 2024 Tandem Meetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- Data Quality Focus for October - Clean-up on the F2149
|
| October 17th, 2023 |
[Data Operations Updates for the Week of 10/16/23 (217)](https://cibmtr.cmail19.com/t/d-e-vdrlkld-drjjxkrjj-r/) |
- October 2023 Quarterly Release Information
- Upcoming Training Opportunity for New Data Managers
- Save the Date! Upcoming Quarterly Release Informational Webinar
- 2024 Tandem Meetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- Data Quality Focus for October - Clean-up on the F2149
|
| October 10th, 2023 |
[Data Operations Updates for the Week of 10/9/23 (216)](https://cibmtr.cmail20.com/t/d-e-vikiuhk-drethiukh-r/) |
- Save the Date! Upcoming Quarterly Release Informational Webinar
- 2024 Tandem Meetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- Data Quality Focus for October - Clean-up on the F2149
|
| October 3rd, 2023 |
[Data Operations Updates for the Week of 10/2/23 (215)](https://cibmtr.cmail20.com/t/d-e-viiktdy-drlkdkjylt-r/) |
- 2024 Tandem Meeetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus for October - Clean-up on the F2149
- Registration Open! Recorded New Data Manager Onboarding
|
| September 26th, 2023 |
[Data Operations Updates for the Week of 9/25/23 (214)](https://cibmtr.cmail20.com/t/d-e-viyuuhd-dluhndliy-r/) |
- Registration Now Open! Recorded New Data Manager Onboarding
- Form 2402 - ISCN Functionality
- US Recipient CPI Reminders
- 2023 Center Volumes Data Report (CVDR) Now Open
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
|
| September 20th, 2023 |
[2023 Center Volumes Data Report (CVDR) Opening Soon! (213)](https://cibmtr.cmail19.com/t/d-e-vilhtkk-dlkutilre-r/) |
- 2023 Center Volumes Data Report (CVDR)
|
| September 19th, 2023 |
[Data Operations Updates for the Week of 9/18/23 (212)](https://cibmtr.cmail20.com/t/d-e-vilcdt-dlkhtrtjdl-r/) |
- NEW! Recorded New Data Manager Onboarding Registration Opening Soon
- CIBMTR Forms Instruction Manual Updates
- Submissions Closing Soon!
** **Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
|
| September 13th, 2023 |
[Fall 2023 Data Manager Training Opportunities (211)](https://cibmtr.cmail20.com/t/d-e-vthuhx-dlklujiiju-r/) |
- Save the Dates! Fall 2023 Data Manager Training Opportunities
|
| September 12th, 2023 |
[Data Operations Updates for the Week of 9/11/23 (210)](https://cibmtr.cmail19.com/t/d-e-vthjdhl-dlhhdlurhr-r/) |
- Error Correction Forms on the CIBMTR Portal
- Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
|
| September 5th, 2023 |
[Data Operations Updates for the Week of 9/4/23 (209)](https://cibmtr.cmail20.com/t/d-e-vttikx-dldkkkdjlt-r/) |
- UPDATE: Network Outage Has Been Resolved
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
- Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- International Recipient CPI Reminders
|
| August 29th, 2023 |
[Data Operations Updates for the Week of 8/28/23 (208)](https://cibmtr.cmail20.com/t/d-e-vtrkkly-dldryhduhl-r/) |
- Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- CIBMTR Forms Instruction Manual Updates
- CIBMTR Center Support Closed September 4th
- Data Quality Focus for August - Answering the Indicator Question
|
| August 22nd, 2023 |
[Data Operations Updates for the Week of 8/21/23 (207)](https://cibmtr.cmail19.com/t/d-e-vjkdua-dlijhrkjlh-r/) |
- Important Update: Respiratory Virus Post-Infusion Form 2149
- 2023 Center Volumes Data Report (CVDR)
- Data Quality Focus for August - Answering the Indicator Question
|
| August 21st, 2023 |
[US Recipient CPI Update (206)](https://cibmtr.cmail19.com/t/d-e-vjkkilk-dliyilbii-r/) |
- UPDATE: US Recipient CPI - CPI Summary Reports Notification
|
| August 15th, 2023 |
[Data Operations Updates for the Week of 8/14/23 (205)](https://cibmtr.cmail19.com/t/d-e-vjddhdd-dltiauuo-r/) |
- New Data Manager Onboarding - Registration Closing Soon!
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus for August - Answering the Indicator Question
- Upstream CRID - Updates and FAQs
|
| August 8th, 2023 |
[Data Operations Updates for the Week of 8/7/23 (204)](https://cibmtr.cmail20.com/t/d-e-vjtvkt-dljkjdjyq-r/) |
- Data Quality Focus for August - Answering the Indicator Question
- Upstream CRID - Updates and FAQs
- Resolving Queries on CRID Assignment and Consent Tools in FormsNet3
- RCI BMT is now CIBMTR CRO Services
- CIBMTR Monthly Maintenance Reminders
- Input Requested: Advanced Data Manager Training Sessions
- 2023 Center Volumes Data Report (CVDR)
- New Data Manager Onboarding - Registration Now Open!
|
| August 1st, 2023 |
[Data Operations Updates for the Week of 7/31/23 (203)](https://cibmtr.cmail20.com/t/d-e-vjritiy-dlyuctikk-r/) |
- 2023 Center Volumes Data Report (CVDR)
- July 2023 Quarterly Release Now Live
- Reconsent Pending - Important Changes
- Input Requested: Advanced Data Manager Training Sessions
- New Audit Categories Available in CIBMTR Center Support
- US Recipient CPI Reminders
- International CPI Reminders
- New Data Manager Onboarding - Registration Now Open!
|
| July 25th, 2023 |
[Important Summer Release Information Included - Data Operations Updates for the Week of 7/24/23 (202)](https://cibmtr.cmail20.com/t/d-e-vykkudt-dlvydtlhh-r/) |
- July 2023 Quarterly Release Information
- Reconsent Pending - Important Changes!
- CIBMTR Launches New Embargo Process
- CIBMTR Forms Instruction Manual Updates
- FormsNet3 User Access Verification Complete
- Patient Transfer Tool Reminders
- July Data Quality Focus - Thank You!
- New Data Manager Onboarding - Registration Now Open!
|
| July 18th, 2023 |
[Data Operations Updates for the Week of 7/17/23 (201)](https://cibmtr.cmail20.com/t/d-e-vydctl-dlmwuujd-r/) |
- Reconsent Pending - Important Changes!
- July 2023 Quarterly Release Information
- CIBMTR Launches New Embargo Process
- International Recipient CPI Reminders
- July Data Quality Focus - Thank You!
- New Data Manager Onboarding - Registration Now Open!
|
| July 11th, 2023 |
[Data Operations Updates for the Week of 7/10/23 (200)](https://cibmtr.cmail20.com/t/d-e-vslkyd-dllhsjls-r/) |
- New Data Manager Onboarding - September 2023 Registration Opening July 12th!
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Reminder: Upstream CRID Feedback Requested
- Last Chance to Attend: Important CIBMTR Webinars Happening This Week!
|
| July 5th, 2023 |
[Data Operations Updates for the Week of 7/3/2023 (199)](https://cibmtr.cmail19.com/t/d-e-vztild-iuuditjdq-r/) |
- New Data Manager Onboarding - September 2023
- Reminder: Upstream CRID Feedback Request
- Important Upcoming CIBMTR Webinars!
- Important June Monthly Maintenance Update
|
| June 28th, 2023 |
[Upstream CRID Survey (198)](https://cibmtr.cmail19.com/t/d-e-vadhc-iukujydlli-r/) |
- Call to Action: Feedback Request
|
| June 27th, 2023 |
[Data Operations Updates for the Week of 6/26/2023 (197)](https://cibmtr.cmail20.com/t/d-e-valhdt-iukdirtkdh-r/) |
- CIBMTR Center Support Closed July 4th
- Important June Monthly Maintenance Update
- FY2022 Center Specific Audit Summary Reports Available on CIBMTR Portal
- Fee Schedule for Study Supplemental Forms has Moved
- Important Upcoming CIBMTR Webinars!
- Data Quality Focus for June - GVHD Reporting for Allo Transplants
|
| June 20th, 2023 |
[Data Operations Updates for the Week of 6/19/2023 (196)](https://cibmtr.cmail19.com/t/d-e-vmjlut-iuhhtyidp-r/) |
- Important Upcoming CIBMTR Webinars!
- UPDATED - Data Quality Focus for June - GVHD Reporting for Allo Transplants
|
| June 15th, 2023 |
[Important Upcoming CIBMTR Webinars (195)](https://cibmtr.cmail19.com/t/d-e-vpduky-iuhyjyea-r/) |
- Action Required: Important Upcoming CIBMTR Webinars!
|
| June 13th, 2023 |
[Data Operations Updates for the Week of 6/12/2023 (194)](https://cibmtr.cmail19.com/t/d-e-vbkktk-iuduzhyp-r/) |
- Data Quality Focus for June - GVHD Reporting for Allo Transplants
- International Recipient CPI Reminders
- Data Manager Training Opportunities are Expanding!
|
| June 6th, 2023 |
[Data Operations Updates for the Week of 6/5/2023 (193)](https://cibmtr.cmail20.com/t/d-e-vlududl-iuiiwkilt-r/) |
- Data Quality Focus for June - GVHD Reporting for Allo Transplants
- International Recipient CPI Reminders
- Data Manager Training Opportunities are Expanding!
|
| May 31st, 2023 |
[Data Manager Training Opportunities (192)](https://cibmtr.cmail19.com/t/d-e-vlddijy-iutturxky-r/) |
- Data Manager Training Opportunities are Expanding!
|
| May 23rd, 2023 |
[Data Operations Updates for the Week of 5/22/2023 (191)](https://cibmtr.cmail20.com/t/d-e-vljuudd-iujrxitdd-r/) |
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
- Upstream CRID Open Enrollment
|
| May 16th, 2023 |
[Data Operations Updates for the Week of 5/15/2023 (190)](https://cibmtr.cmail19.com/t/d-e-vlluhx-iuckyijc-r/) |
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
- Upstream CRID Open Enrollment
- Data for Request for Information (RFI) - Updated for 2022
|
| May 11th, 2023 |
[Data for Request for Information (RFI) Updated for 2022 (189)](https://cibmtr.cmail19.com/t/d-e-zuiulid-iuolrwlj-r/) |
- Data for Request for Information (RFI) - Updated for 2022
|
| May 9th, 2023 |
[Data Operations Updates for the Week of 5/8/2023 (188)](https://cibmtr.cmail20.com/t/d-e-zuklkyk-iultkhuhtu-r/) |
- CIBMTR Forms Instruction Manual
- Upstream CRID Open Enrollment
- US Recipient CPI Reminders
- Updates to Cellular Therapy Reimbursement
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
|
| May 2nd, 2023 |
[Data Operations Updates for the Week of 5/1/2023 (187)](https://cibmtr.cmail20.com/t/d-e-zuiall-ikujxyddd-r/) |
- Updates to Cellular Therapy Reimbursement
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
- International Recipient CPI Reminders
|
| April 25th, 2023 |
[Data Operations Updates for the Week of 4/24/2023 (186)](https://cibmtr.cmail20.com/t/d-e-zuyptl-ikkryuyhtl-r/) |
- April 2023 Quarterly Release Now Live
- CIBMTR Forms Instruction Manual
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| April 18th, 2023 |
[Important Spring Release Information Included - Data Operations Updates for the Week of 4/17/2023 (185)](https://cibmtr.cmail19.com/t/d-e-zkutkjl-ikhjmlldu-r/) |
- April 2023 Quarterly Release Information
- International Recipient CPI Reminders
- CIBMTR Portal Upgrade Now Live
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| April 11th, 2023 |
[Data Operations Updates for the Week of 4/10/2023 (184)](https://cibmtr.cmail20.com/t/d-e-zkdtkkk-ikdrdljrjy-r/) |
- CIBMTR Portal Upgrade Now Live
- April 2023 Quarterly Release Information
- US Recipient CPI Reminders
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| April 4th, 2023 |
[Data Operations Updates for the Week of 4/3/2023 (183)](https://cibmtr.cmail19.com/t/d-e-zktqtd-ikitdjijkl-r/) |
- CIBMTR Portal Upgrade
- Is a New User Missing the Recipient Tab in FN3?
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| March 28th, 2023 |
[Data Operations Updates for the Week of 3/27/2023 (182)](https://cibmtr.cmail19.com/t/d-e-zkrlrut-ikttkrirtj-r/) |
- Data Quality Focus for April - ANC Recovery
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Career Opportunity with CIBMTR-Milwaukee
|
| March 21st, 2023 |
[Data Operations Updates for the Week of 3/20/2023 (181)](https://cibmtr.cmail20.com/t/d-e-zhklydy-ikjyhijhuj-r/) |
- Removal of 'COVID Impact to HCT' Category from CIBMTR Center Support
- FAQs for Resetting and Deleting Forms
- Career Opportunity with CIBMTR-Milwaukee
|
| March 7th, 2023 |
[Data Operations Updates for the Week of 3/6/2023 (180)](https://cibmtr.cmail19.com/t/d-e-zhyljll-ikbbiljl-r/) |
- Career Opportunity with CIBMTR-Milwaukee
- Data Quality Focus for March - Best Response on F2450
|
| February 28, 2023 |
[Data Operations Updates for the Week of 2/27/2023 (179)](https://cibmtr.cmail19.com/t/d-e-zdkukhd-ihuuijkhlk-r/) |
- Data Quality Focus for March - Best Response on F2450
|
| February 21, 2023 |
[Data Operations Updates for the Week of 2/20/2023 (178)](https://cibmtr.cmail20.com/t/d-e-zdiutlk-ihkhjrlili-r/) |
- 2023 Transplant Center Specific Analysis (TCSA)
|
| February 14, 2023 |
[Data Operations Updates for the week of 2/13/2023 (177)](https://cibmtr.cmail19.com/t/d-e-zdytylk-ihhhttjtuj-r/) |
- CIBMTR Center Support - Delayed Staff Responses February 14 - 17, 2023
- International Recipient CPI Reminders
|
| February 07, 2023 |
[Data Operations Updates for the Week of 2/06/2023 (176)](https://cibmtr.cmail19.com/t/d-e-zdlnuk-ihdydtllw-r/) |
- International Recipient CPI Updates
- 2023 Tandem Meetings - Last Chance for Virtual Registration!
|
| January 31, 2023 |
[Data Operations Updates for the Week of 1/30/2023 (175)](https://cibmtr.cmail19.com/t/d-e-zihadd-ihirhrlydk-r/#toc_item_4) |
- 2023 Transplant Center Specific Analysis (TCSA)
- Outstanding Forms Due Backlog
- January 2023 Quaterly Release Now Live
- 2023 Tandem Meetings - Register Now
|
| January 24, 2023 |
[Data Operations Updates for the Week of 1/23/2023 (174)](https://cibmtr.cmail19.com/t/d-e-zitwik-ihtlddlyiu-r/) |
- Winter 2023 Quarterly Release Information
- Now Accepting 2022 CTA Lists for US Transplants
- New CIBMTR Website
- 2023 Tandem Meetings - Register Now
|
| January 17, 2023 |
[Data Operations Updates for the Week of 1/16/2023 (173)](https://cibmtr.cmail19.com/t/d-e-ziriily-ihjrlihkjj-r/) |
- New CIBMTR Website Now Live!
- Winter 2023 Quarterly Release Information
- US Recipient CPI
- 2023 Tandem Meetings - Register Now
|
| January 16, 2023 |
[New CIBMTR.ORG Website Now Live (172)](https://cibmtr.cmail19.com/t/d-e-zirltdt-ihykqgkh-r/) |
- Known Issue with Forms Instruction Manual Link
|
| January 10, 2023 |
[Data Operations Updates for the Week of 1/09/2023 (171)](https://cibmtr.cmail19.com/t/d-e-ztkhkjt-ihftuiyui-r/) |
- New CIBMTR Website Coming Soon!
- New Data Manager Onboarding Registration
- 2023 Tandem Meetings - Register Now
|

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/Research-Database-Protocol
title: Research Database Protocol
url: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/Research-Database-Protocol
hostname: cibmtr.org
description: When a donor or recipient consents to participate in the Research Database, their data are contained in the CIBMTR’s Research Database and used for research. The database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source and for autologous transplants. Data are also collected on unrelated donors and their donation experiences.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['baseline and outcome data, IRB, Research Database Protocol']
filedate: 2025-06-23
-->

When a donor or recipient consents to participate in the Research Database, their data are contained in the CIBMTR’s Research Database and used for research. The database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source and for autologous transplants. Data are also collected on unrelated donors and their donation experiences.

The primary purpose of the Research Database is to have a comprehensive source of data that can be used to study hematopoietic cell transplantation (HCT).

These data may be used in research to:

Any recipient of an unrelated or related donor or autologous transplant in a CIBMTR-affiliated center may participate in the Research Database. All NMDP donors who have been requested to donate marrow or peripheral blood stem cells for a recipient may also participate. Complete eligibility requirements are outlined in the study protocol.

If the recipient of an allogeneic (related or unrelated) HCT does not consent to the use of his/her data for research, the transplant center will still be required to submit TED–level data on the recipient. In this case, the recipient’s data will only be used for federally required analyses, such as the center-specific analysis mandated by CIBMTR’s contract to operate the Stem Cell Therapeutic Outcomes Database (SCTOD). The recipient’s data will never be included in research studies.

TED-level data is used in research. Therefore, if a transplant center only submits TED-level data to the CIBMTR, the center must still approach all allogeneic HCT recipients for consent to the Research Database. If a recipient consents to the Research Database, their TED-level data will be used in research.

For autologous recipients who do not consent to participate in research, the CIBMTR requests that the transplant center submit TED-level data on the recipient. No additional TED-level forms are required other than the Pre-TED. This information will help ensure the epidemiological integrity of the database and does not require the provision of any significant health information that could identify the recipient, nor will the recipient's data ever be included in research studies.

To be compliant with United States Federal Regulations for human research subject protection, all transplant centers must obtain IRB-approved informed consent from recipients to allow data submitted to the Research Database to be used for research studies, regardless of the level of data the center submits to the CIBMTR. All US transplant centers must have IRB approval for their center for the Research Database Research protocol.

Upon obtaining center IRB approval, the CIBMTR Protocol Coordinator must receive a copy of the center's IRB approval letter, approved protocol, and informed consent documents. These documents should be submitted via email to: DatabaseIRB@nmdp.org.

The CIBMTR tracks the IRB approval for the Research Database at each participating center. The center's IRB approval for this protocol must be current at all times. Failure to have current IRB approval may affect a center's ability to meet CPI requirements for data submission.

International transplant centers must follow their country’s laws and regulations governing human subjects and privacy protection. The transplant center is responsible for obtaining the necessary institutional review and approval for the Research Database.

If the recipient does not consent to participate in the Research Database according to the laws and regulations of their country, the CIBMTR requests that the transplant center submit TED-level data on the allogeneic recipient. For the autologous recipient, no additional TED-level forms are requested other than the Pre-TED. This information will help ensure the epidemiological integrity of the database and does not require the provision of any significant health information that could identify the recipient, nor will the recipient's data ever be included in research studies.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form templates. Your center must have IRB approval for the protocol and consent forms relevant to your center. The protocol must be submitted as written for center IRB approval.

The National Institutes of Health (NIH) has issued a Certificate of Confidentiality for the Research Database. According to NIH Policy, research that is applicable within the scope of the Policy as of 10/01/2017 is deemed to be issued a Certificate through the Policy. Certificates issued in this automatic manner will not be issued as a separate document.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/PRO-Data-Collection-Protocol
title: PRO Data Collection Protocol
url: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/PRO-Data-Collection-Protocol
hostname: cibmtr.org
description: CIBMTR collects longitudinal or cross-sectional PRO data from recipients of cellular therapies who are also enrolled in the Protocol for a Research Database for Hematopoietic Cell Transplantation, Other Cellular Therapies, and Marrow Toxic Injuries (Research Database protocol). The time points for PRO data collection parallel the time points at which treatment centers submit clinical outcomes data from healthcare records, with an additional time point at 30 days post-treatment for cellular therapy patients.
sitename: cibmtr.org
date: 2025-05-20
categories: []
tags: ['patient-reported outcomes, PRO Data Collection Protocol, PRO protocol']
filedate: 2025-06-23
-->

The CIBMTR collects longitudinal or cross-sectional PRO data from recipients of cellular therapies who are also enrolled in the Protocol for a Research Database for Hematopoietic Cell Transplantation, Other Cellular Therapies, and Marrow Toxic Injuries (Research Database protocol). The time points for PRO data collection parallel the time points at which treatment centers submit clinical outcomes data from healthcare records, with an additional time point at 30 days post-treatment for cellular therapy patients. Below are the measures and time points collected for adult HCT and CAR T patients:

The primary purpose of the PRO Protocol is to have a centralized collection of patient-reported symptoms and functioning to supplement traditional outcomes, such as survival or disease relapse, in registration and other studies. These data may be used in research to:

Any recipient of an unrelated or related HCT or CAR T in a CIBMTR-affiliated center may participate in the PRO protocol. Complete eligibility requirements are outlined in the study protocol.

If the recipient of HCT or cellular therapy does not consent to the Research Database protocol, they may still participate in the PRO protocol, but the use of their data will be limited to CIBMTR and NMDP process improvement analyses or study-specific analysis as laid out in the PRO protocol consent form.

The CIBMTR Survey Research Group identifies, approaches, and obtains consent from eligible recipients. Informed consent is documented in the CIBMTR electronic PRO (ePRO) system. The Survey Research Group centrally collects PRO surveys from participating recipients electronically, on paper, or by phone and follows up with non-responders.

PRO data are collected in the ePRO system and then stored in the CIBMTR database where they can be linked to CIBMTR clinical outcomes data.

Presented here are the number of patients enrolled in the CIBMTR PRO Protocol by type and year of infusion, as of May 20, 2025.

111 HCTs not included in the table due to lack of infusion type information in FormsNet3.

Presented here are the number of completed PRO surveys available for analysis by infusion-related time point, infusion type, age at transplant, gender, and indication, as of May 20, 2025.

Number (%) of patients who have survey completed at each time point

110 year 5 surveys not included in the table

The PRO protocol is a single-site CIBMTR protocol. All research activities, including enrollment and data collection, are centrally performed within the CIBMTR. Centers do not need to submit the PRO protocol or consent form to their local IRB for their patients to participate.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form. These are provided for reference only. Centers should not submit these materials for local IRB approval. Centers should not use these materials to consent recipients.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/Biorepository
title: CIBMTR Biorepository
url: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/Biorepository
hostname: cibmtr.org
description: The CIBMTR Biorepository contains cell and serum samples collected from related and unrelated transplant donors, cord blood units, and recipients.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Biorepository, cord blood units, recipient sample, related donors, Research Sample Repository, serum samples, unrelated donors']
filedate: 2025-06-23
-->

The CIBMTR Biorepository contains cell and serum samples collected from related and unrelated transplant donors, cord blood units, and recipients.

The primary objective of the CIBMTR Biorepository is to make these samples available for research studies related to histocompatibility and hematopoietic cell transplantation (HCT).

These data may be used in research to:

The CIBMTR Biorepository includes cell and serum samples from allogeneic related and unrelated donors and recipients. The protocol also allows for the submission of research samples from registered donors with rare tissue types. Complete eligibility requirements are outlined in the study protocol.

To be compliant with United States Federal Regulations for human research subject protection, US transplant centers must obtain IRB-approved informed consent from recipients before submitting samples to the CIBMTR Biorepository .

Although all NMDP centers participate in the CIBMTR Biorepository protocol, only select NMDP centers currently submit related recipient and donor samples. In the future, additional NMDP centers may be invited to submit related recipient and donor samples.

If your center only performs related donor HCT and/or autologous HCT, you will not submit research samples and, therefore, do not need to obtain IRB approval for your center for the CIBMTR Biorepository protocol.

Upon obtaining center IRB approval, the CIBMTR Protocol Coordinator must receive a copy of the center's IRB approval letter, approved protocol, and informed consent documents. These documents should be sent via email to: RepositoryIRB@nmdp.org

The CIBMTR tracks the IRB approval for the CIBMTR Biorepository at each participating center. The center's IRB approval for this protocol must be current at all times. Failure to have current IRB approval may affect your center's ability to meet continuous process improvement (CPI) requirements for sample submission.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form templates. Your center must have IRB approval for the protocol and consent forms relevant to your center. The protocol must be submitted as written for center IRB approval.

The Health Resources and Services Administration (HRSA) has issued a Certificate of Confidentiality for the CIBMTR Biorepository. According to HRSA's Policy, research that is applicable within the scope of the Policy as of December 13, 2016, is deemed to be issued a Certificate through the Policy. Certificates issued automatically will not be given as separate documents.

HRSA's Human Subjects Protection Policy: https://www.hrsa.gov/about/organization/bureaus/opae/human-subjects

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/CPI-Compliance-Program
title: CPI Compliance Program
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/CPI-Compliance-Program
hostname: cibmtr.org
description: The CIBMTR established the Continuous Process Improvement (CPI) Compliance Program to ensure timely and accurate submission of data to the CIBMTR. These data support the CIBMTR’s mission to serve as a collaborative resource of data and experts supporting research in cellular therapy to improve patient outcomes. In addition, CPI supports the CIBMTR's ability to perform benchmarking and to provide accurate population level data. These data also support quality assurance efforts for the programs providing the products, including cord blood banks and apheresis and collection centers.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['continuous process improvement compliance program, CPI Compliance Program']
filedate: 2025-06-23
-->

CIBMTR established the Continuous Process Improvement (CPI) Compliance Program to ensure timely and accurate submission of data to CIBMTR. These data support CIBMTR’s mission to serve as a collaborative resource of data and experts supporting research in cellular therapy to improve patient outcomes. In addition, CPI supports CIBMTR's ability to perform benchmarking and to provide accurate population level data. These data also support quality assurance efforts for the programs providing the products, including cord blood banks and apheresis and collection centers.

For more information on specific requirements, refer to CIBMTR's Data Management Guide.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/Audit-Program
title: Audit Program
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/Audit-Program
hostname: cibmtr.org
description: Ongoing data audits are performed at all CIBMTR participating centers as part of the CIBMTR’s overall data quality assurance program. The audit compares data in source documents maintained at the center with data contained in the CIBMTR outcomes registry. The audits identify errors that otherwise would go undetected by the online validations built into the data entry program.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Audit Program, data audits, quality assurance program']
filedate: 2025-06-23
-->

Ongoing data audits are performed at all CIBMTR participating centers as part of the CIBMTR’s overall data quality assurance program. The audit compares data in source documents maintained at the center with data contained in the CIBMTR outcomes registry. The audits identify errors that otherwise would go undetected by the online validations built into the data entry program.

The overall goal of the ongoing audits is to ensure the quality and accuracy of the research database by:

As part of the on-going data quality program, the CIBMTR conducts data quality audits at regular intervals to ensure the accuracy of data submitted to the CIBMTR’s observational database. CIBMTR Clinical Research Associates serve as auditors. They compare submitted data with source documentation, provide training to data management staff, and identify any systemic data reporting issues at transplant centers qualifying for audit. All data elements on all forms are subject to audit. However, the audit concentrates on “critical” data, i.e., data most likely to be included in a research study. Data elements considered “non-critical” are randomly audited to increase the validity of the audit error rates. Auditors also review consent forms for completeness. See the Before the Audit section in the Audit Guide for more details and strategies for a successful audit.

Additional information about the CIBMTR audit visit can be found in the During the Audit section of the Audit Guide.

Following the audit, the CIBMTR generates a report and may require the center to complete corrective action. The final report will also contain the center’s critical, random, and overall field error rates. Center audit preparation is key to ensuring the logistical success of the audit. More details can be found in the After the Audit section of the Audit Guide.

Each center is audited once in a four-year cycle.

In 2017, FACT and the CIBMTR launched a collaborative program of data auditing, designed to reduce duplicative efforts, enhance quality improvement efforts, and provide support to accredited programs. The essential elements of the collaboration are:

For more information, including a list of frequently asked questions, see the FACT CIBMTR Audit Collaboration Letter.

For more detailed information about the audit process, audit results, a list of General FAQs, and audit contact information, please see the Audit Guide.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/Corporate-Studies
title: Corporate Studies
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/Corporate-Studies
hostname: cibmtr.org
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Corporate Studies']
filedate: 2025-06-23
-->

Skip to Content
Patients
Industry Collaborators
Menu
Research
Propose a Working Committee Study
All Studies
Research Focus Areas
Observational Research / Working Committees
Clinical Trials
Immunobiology Research
Bioinformatics Research
Statistical Methodology Research
Implementation Science
Data Operations
Center Membership
Protocols & Consent Forms
Data Collection Forms
Manuals & Guides
Data Operations Compliance
Training
Communications
Support & Resources
CIBMTR System Applications
Meetings
Tandem Meetings
Tandem Meetings News
Upcoming Meetings
Materials & Archive
Resources
Recipient & Donor Data
Biorepository Inventories
Request BMT CTN Biorepository Inventory Information
Request CIBMTR Biorepository Inventory Information
Publications
Summary Slides & Reports
Publicly Available Datasets
Research Tools & Calculators
Center-Specific Survival Analysis
Related Websites
About CIBMTR
Our Impact
SCTOD
Our Centers
Leadership
Administrative Committees and Task Forces
Administrative Reports
News
Careers
CIBMTR 50th Anniversary
CIBMTR Page Scholars Program
Contact Us
Support CIBMTR
Data Protection & Privacy
Patients
Industry Collaborators
Corporate Studies
CIBMTR
>
Data Operations
>
Data Operations Compliance
>
Corporate Studies
Main Content
Webpage coming soon!

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/Data-Quality
title: Data Quality
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Operations-Compliance/Data-Quality
hostname: cibmtr.org
description: CIBMTR’s data quality efforts are continuous and cyclical. They are under constant refinement to ensure that any new data concerns that arise can be prevented or identified as far upstream as possible. The CIBMTR's clinical data quality team coordinates several aspects of the post-collection data validation processes. This team coordinates requests from various areas of the CIBMTR to participating centers to ensure consistency in messaging and prioritization guidance.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['clinical data quality, data concerns, Data Quality, post-collection data validation process']
filedate: 2025-06-23
-->

CIBMTR’s data quality efforts are continuous and cyclical. They are under constant refinement to ensure that any new data concerns that arise can be prevented or identified as far upstream as possible.

CIBMTR's clinical data quality team coordinates several aspects of the post-collection data validation processes. This team coordinates requests from various areas of CIBMTR to participating centers to ensure consistency in messaging and prioritization guidance.

As new issues are identified, the clinical data quality team evaluates existing resources, including instruction manuals, available training videos, and FormsNet3SM validation, and the team coordinates enhancements to the relevant systems and materials.

FormsNet validation happens in real-time as data are entered. Users are prompted and can resolve errors immediately in the application. Forms will not be considered “complete” by the application until all errors are addressed.

The FormsNet Query Management Tool allows CIBMTR to place a query on a field directly within FormsNet so all system validation happens normally, preventing the user from generating additional errors. This enhances efficiency and protects privacy by reducing manual processes, such as emails and phone calls. The tool also requires action from CIBMTR staff members to “approve” the response before the form can go back to a complete status, ensuring the response truly resolves the data issue.

Resolution of these queries are tracked within the CPI compliance program. Centers must address a target percentage of queries within a trimester to remain in good standing.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Center-Support
title: CIBMTR Center Support
url: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Center-Support
hostname: cibmtr.org
description: Center Support delivers a transparent, flexible, and service-oriented experience for centers. The ServiceNow platform is a digital workflow that has been customized to meet the needs of the CIBMTR community.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Center Support, ServiceNow']
filedate: 2025-06-23
-->

ServiceNow allows Data Operations to:

Submit all data reporting, technical, and procedural questions via CIBMTR Center Support, and your questions will be automatically routed to the appropriate team.

Access CIBMTR Center Support

Contact Angela Hauck, Center Support Services Manager, at ahauck@nmdp.org.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Applications
title: CIBMTR System Applications
url: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Applications
hostname: cibmtr.org
description: Quickly access CIBMTR System Applications such as FormsNet or the CIBMTR Portal.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Portal, CIBMTR System Applications, FormsNet']
filedate: 2025-06-23
-->

Provides on-demand access to CIBMTR’s suite of center-facing applications.

Access the CIBMTR Portal

Secure clinical research management system for electronic submission of outcomes data to CIBMTR, in compliance with the SCTOD.

Access FormsNet

Resource center, ticket support, FAQ and on-boarding documentation for centers utilizing or interested in using the CIBMTR data automation tools (created as a part of the Data Transformation Initiative).

Access Data Automation Portal

AGNIS® (A Growable Network Information System) is an open-source messaging system specifically designed to exchange transplant and other cellular therapy data using a secure, standards-based system.

Centers can use AGNIS to retrieve and transmit form data, extracted directly from their own institution’s database, directly to the FormsNet application using a secure and authenticated electronic data transmission system.

For information to access AGNIS and training, please click below.

Access the AGNIS Portal

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Information-Management
title: CIBMTR Center Information Management
url: https://cibmtr.org/CIBMTR/Data-Operations/Support-Resources/CIBMTR-Information-Management
hostname: cibmtr.org
description: The CIBMTR needs to keep your staff and center information up to date in our database. Having correct information enables access to FormsNet and CIBMTR Portal applications, and it ensures your staff members receive important announcements and training information.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['CIBMTR Center Information Management, updates to center and staff information']
filedate: 2025-06-23
-->

Submit center information changes via CIBMTR Center Support:

Submit staff information changes in the Network Partner Portal

The center's primary data manager or medical director must submit all changes in staff information in the Network Partner Portal:

The primary data manager or medical director must:

Log into the Network Partner Portal to make a new account. Use "Create User" for a brand new person. Use "Modify User" for a user who already has an NMDP account (for example, at a transplant center). If unsure, try "Modify User" and search for the person using their email address.

Center personnel can be added as:

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Data-Collection-Forms/Upcoming-Releases
title: Upcoming Releases
url: https://cibmtr.org/CIBMTR/Data-Operations/Data-Collection-Forms/Upcoming-Releases
hostname: cibmtr.org
description: Upcoming CIBMTR Form releases.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Upcoming Releases']
filedate: 2025-06-23
-->

CIBMTR submitted the OMB 2025 TED Forms Renewal Package (forms 2004 R6, 2005 R8, 3500 R3, 2900 R6, 2006 R7, 2199 R2, 2400 R11, 2402 R10, 2450 R9, 2451 R3 and 2804 R7) to the Health Resources and Services Administration (HRSA) in January 2025 with a scheduled release to centers in the Summer Quarterly FN3 Release on July 25, 2025.

To date, the 60-day and 30-day Federal Register Notices (FRN) have not been posted and the OMB 2025 TED Forms Renewal Package remains under HRSA's review. The OMB TED Forms Package WILL NOT be released in the Summer 2025 Quarterly Release.

For additional information, see the eBlast communication sent out on May 7, 2025.

To view previous FormsNet3 release highlights, additional release educational materials and recordings, navigate to the CIBMTR Portal > Training & eLearning tile > Release Education.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals
title: Retired Forms Manuals
url: https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals
hostname: cibmtr.org
description: The Retired Forms Manuals contain manuals for retired CIBMTR and NMDP forms, Response Criteria documents, and Appendices (for reference purposes only).
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['Appendices, Response Criteria, Retired Forms Manuals']
filedate: 2025-06-23
-->

| 2000 |
[Baseline Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2000r5-10.2020.pdf) |
5.0 |
October 2020 |
| 2000 |
[Baseline Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2000r4-1.2020.pdf) |
4.0 |
January 2020 |
| 2000 |
[Baseline Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2000r4-3.2015.pdf) |
4.0 |
March 2015 |
| 2000 |
[Baseline Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2000r3-10.2013.pdf) |
3.0 |
October 2013 |
| 2003 |
[Gene Therapy Product Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Gene-Therapy-Product-2003-R1V1.pdf) |
1.0 |
July 2024 |
| 2004 |
[Infectious Disease Markers Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2004r5-9.2022.pdf) |
5.0 |
September 2022 |
| 2004 |
[Infectious Disease Markers Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2004r4-1.2020.pdf) |
4.0 |
January 2020 |
| 2004 |
[Infectious Disease Markers Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2004r4-3.2015.pdf) |
4.0 |
March 2015 |
| 2004 |
[Infectious Disease Markers Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2004r3-10.2013.pdf) |
3.0 |
October 2013 |
| 2005 |
[Confirmation of HLA Typing Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2005r7-9.2022.pdf) |
7.0 |
September 2022 |
| 2005 |
[Confirmation of HLA Typing Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2005r6-10.2020.pdf) |
6.0 |
January 2020 |
| 2005 |
[Confirmation of HLA Typing Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2005r5-1.2017.pdf) |
5.0 |
January 2017 |
| 2005 |
[Confirmation of HLA Typing Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2005r4-10.2013.pdf) |
4.0 |
October 2013 |
| 2006 |
[Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2006r5-9.2022.pdf) |
5.0 |
September 2022 |
| 2006 |
[Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2006r4-1.2020.pdf) |
4.0 |
January 2020 |
| 2006 |
[Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2006r4-3.2015.pdf) |
4.0 |
March 2015 |
| 2006 |
[Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2006r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2006 |
[Infusion Form FAQ (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2006r1-2.2010.pdf) |
1.0 |
February 2010 |
| 2010 |
[Acute Myelogenous Leukemia (AML) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2010r3-7.2017.pdf) |
3.0 |
July 2017 |
| 2010 |
[Acute Myelogenous Leukemia (AML) Pre-HSCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2010r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2011 |
[Acute Lymphoblastic Leukemia (ALL) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2011r4-7.2017.pdf) |
4.0 |
July 2017 |
| 2013 |
[Chronic Lymphocytic Leukemia (CLL) Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/CLL-Pre-Infusion-2013_R3V3.pdf) |
3.0 |
October 2024 |
| 2013 |
[Chronic Lymphocytic Leukemia (CLL) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2013r2-3.2015.pdf) |
2.0 |
March 2015 |
| 2014 |
[Myelodysplasia/Myeloproliferative Neoplasms (MDS/MPN) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2014r33-5.2020.pdf) |
3.0 |
May 2020 |
| 2014 |
[Myelodysplasia/Myeloproliferative Neoplasms (MDS/MPN) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2014r2-3.2015.pdf) |
2.0 |
March 2015 |
| 2015 |
[Myelodysplasia/Myeloproliferative Neoplasms (MDS/MPN) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2015r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2016 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2016r3-4.2021.pdf) |
3.0 |
April 2021 |
| 2016 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2016r3-1.2020.pdf) |
3.0 |
January 2020 |
| 2016 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2016r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2016 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2016r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2018 |
[Hodgkin and Non-Hodgkin Lymphoma Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2018r4-1.2019.pdf) |
4.0 |
January 2019 |
| 2018 |
[Hodgkin and Non-Hodgkin Lymphoma Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2018r5-10.2020.pdf) |
5.0 |
October 2020 |
| 2018 |
[Hodgkin and Non-Hodgkin Lymphoma Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2018r3-1.2018.pdf) |
3.0 |
January 2018 |
| 2018 |
[Hodgkin and Non-Hodgkin Lymphoma Pre-HSCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2018r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2019 |
[Waldenstrom's Macroglobulinemia / Lymphoplasmacytic Lymphoma (MAC) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2019r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2028 |
[Aplastic Anemia Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2028r2-10.2020.pdf) |
2.0 |
October 2020 |
| 2028 |
[Aplastic Anemia Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2028r1-3.2015.pdf) |
1.0 |
March 2015 |
| 2030 |
[Sickle Cell Disease Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/SCD-Pre-Infusion-2030_R3V1.pdf) |
3.0 |
October 2024 |
| 2034 |
[X-Linked Lymphoproliferative Syndrome (XLP) Pre-HCT Data Form Instructions](/Files/Data-Operations/Retired-Forms-Manuals/2034r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2037 |
[Leukodystrophies Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Leukodystropy-Pre-Infusion-2037-R3V1.pdf) |
3.0 |
July 2024 |
| 2039 |
[Hemophagocytic Lymphohistiocytosis (HLH) Pre-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2039r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2046 |
[Fungal Infection Pre-Infusion Data (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2046r4-5.2018.pdf) |
4.0 |
May 2018 |
| 2058 |
[Thalassemia Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Thalassemia-Pre-Infusion-2058-R1V1.pdf) |
1.0 |
July 2024 |
| 2100 |
[Post-HCT Follow-Up (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2100r8-10.2023.pdf) |
8.0 |
October 2023 |
| 2100 |
[Post-HCT Follow-Up (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2100r7-9.2022.pdf) |
7.0 |
September 2022 |
| 2100 |
[Post-HCT Follow-Up (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2100r6-7.2021.pdf) |
6.0 |
July 2021 |
| 2100 |
[100 Day Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2100r5-10.2020.pdf) |
5.0 |
October 2020 |
| 2100 |
[100 Day Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2100r4-7.2018.pdf) |
4.0 |
July 2018 |
| 2100 |
[100 Days Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2100r3-1.2017.pdf) |
3.0 |
January 2017 |
| 2110 |
[Acute Myelogeneous Leukemia (AML) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2110r3-7.2017.pdf) |
3.0 |
July 2017 |
| 2110 |
[Acute Myelogenous Leukemia (AML) Post-HSCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2110r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2111 |
[Acute Lymphoblastic Leukemia (ALL) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2111r3-7.2017.pdf) |
3.0 |
July 2017 |
| 2113 |
[Chronic Lymphocytic Leukemia (CLL) Post-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/CLL-Post-Infusion-2113_R3V3pdf.pdf) |
3.0 |
October 2024 |
| 2113 |
[Chronic Lymphocytic Leukemia (CLL) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2013r2-3.2015.pdf) |
2.0 |
March 2015 |
| 2114 |
[Myelodysplasia/Myeloproliferative Neoplasms (MDS/MPN) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2114r3-5.2020.pdf) |
3.0 |
May 2020 |
| 2114 |
[Myelodysplasia/Myeloproliferative Neoplasms (MDS/MPN) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2114r2-3.2015.pdf) |
2.0 |
March 2015 |
| 2115 |
[Juvenile Myelomonocytic Leukemia (JMML) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2115r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2116 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2116r3-4.2021.pdf) |
3.0 |
April 2021 |
| 2116 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2116r3-1.2020.pdf) |
3.0 |
January 2020 |
| 2116 |
[Multiple Myeloma / Plasma Cell Disorders (PCD) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2116r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2116 |
[Multiple Myeloma / Plasma Cell Leukemia Post-HSCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2116r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2118 |
[Hodgkin and Non-Hodgkin Lymphoma Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2118r3-1.2018.pdf) |
3.0 |
January 2018 |
| 2118 |
[Hodgkin and Non-Hodgkin Lymphoma Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2118r2-10.2013.pdf) |
2.0 |
October 2013 |
| 2119 |
[Waldenstrom's Macroglobulinemia / Lymphoplasmacytic Lymphoma (MAC) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2119r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2128 |
[Aplastic Anemia Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2128r2-10.2020.pdf) |
2.0 |
October 2020 |
| 2128 |
[Aplastic Anemia Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2128r1-3.2015.pdf) |
1.0 |
March 2015 |
| 2130 |
[Sickle Cell Disease Post-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/SCD-Post-Infusion-2130_R3V1.pdf) |
3.0 |
October 2024 |
| 2134 |
[X-Linked Lymphoproliferative Syndrome (XLP) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2134r3-3.2015.pdf) |
3.0 |
March 2015 |
| 2137 |
[Leukodystrophies Post-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Leukodystrophy-Post-Infusion-2137-R3V1.pdf) |
3.0 |
July 2024 |
| 2139 |
[Hemophagocytic Lymphohistiocytosis (HLH) Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2139r3.3.2015.pdf) |
3.0 |
March 2015 |
| 2146 |
[Fungal Infection Post-Infusion Data (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2146r3-5.2018.pdf) |
3.0 |
May 2018 |
| 2158 |
[Thalassemia Post-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Thalassemia-Post-Infusion-2158-R1V1.pdf) |
1.0 |
July 2024 |
| 2200 |
[Six Months to Two Years Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2200r3-1.2017.pdf) |
3.0 |
January 2017 |
| 2300 |
[Greater Than Two Years Post-HCT Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2300r3-1.2017.pdf) |
3.0 |
January 2017 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r9-9.2022.pdf) |
9.0 |
September 2022 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r8-10.2021.pdf) |
8.0 |
October 2021 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r7-1.2021.pdf) |
7.0 |
January 2021 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r6-5.2020.pdf) |
6.0 |
May 2020 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r5-1.2020.pdf) |
5.0 |
January 2020 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r4-1.2017.pdf) |
4.0 |
January 2017 |
| 2400 |
[Pre-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2400r3-10.2013.pdf) |
3.0 |
October 2013 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Disease-Classification-2402_R8V8.pdf) |
8.0 |
October 2024 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Disease-Classification-2402_R7_RETIRED.pdf) |
7.0 |
April 2024 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2402r6-9.2022.pdf) |
6.0 |
September 2022 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2402r5-10.2020.pdf) |
5.0 |
October 2020 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2402r4-5.2020.pdf) |
4.0 |
May 2020 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2402r3-1.2020.pdf) |
3.0 |
January 2020 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2402r2-1.2018.pdf) |
2.0 |
January 2018 |
| 2402 |
[Pre-TED Disease Classification Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2402r1-7.2017.pdf) |
1.0 |
July 2017 |
| 2450 |
[Post-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Post-TED-2450-R7-V6.pdf) |
7.0 |
July 2024 |
| 2450 |
[Post-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2450r6-9.2022.pdf) |
6.0 |
September 2022 |
| 2450 |
[Post-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2450r5-10.2021.pdf) |
5.0 |
October 2021 |
| 2450 |
[Post-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2450r4-1.2020.pdf) |
4.0 |
January 2020 |
| 2450 |
[Post-TED Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2450r3-1.2017.pdf) |
3.0 |
January 2017 |
| 2540 |
[Tepadina® Supplemental Data Collection Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2540r1-4.2019.pdf) |
1.0 |
April 2019 |
| 2542 |
[Mogamulizumab Supplemental Data Collection (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2542r1-1.2024.pdf) |
1.0 |
January 2024 |
| 2556 |
[Myelofibrosis Pre-HCT Data](/Files/Data-Operations/Retired-Forms-Manuals/2556r1-5.2020.pdf) |
1.0 |
May 2020 |
| 2557 |
[Myelofibrosis Post-HCT Data](/Files/Data-Operations/Retired-Forms-Manuals/2557r1-5.2020.pdf) |
1.0 |
May 2020 |
| 2800 |
[Log of Appended Documents Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2800r2-3.2015.pdf) |
2.0 |
March 2015 |
| General Instructions Section 11 |
[Log of Appended Documents](/Files/Data-Operations/Retired-Forms-Manuals/Section11-8.2014.pdf) |
N/A |
August 2014 |
| 2804 |
[CIBMTR Recipient ID Assignment Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2804r5-10.2019.pdf) |
5.0 |
October 2019 |
| 2804 |
[CIBMTR Recipient ID Assignment Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2804r4-3.2015.pdf) |
4.0 |
March 2015 |
| 2814 |
[Indictation Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/Inidcation-for-CRID-Assignment-2814-R4-V5.pdf) |
4.0 |
July 2024 |
| 2814 |
[Indication Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2814r2-4.2019.pdf) |
2.0 |
April 2019 |
| 2900 |
[Recipient Death Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2900r4-10.2021.pdf) |
4.0 |
October 2021 |
| 2900 |
[Recipient Death Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2900r3-1.2019.pdf) |
3.0 |
January 2019 |
| 2900 |
[Recipient Death Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2900r2-1.2017.pdf) |
2.0 |
January 2017 |
| 2900 |
[Recipient Death Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/2900r1-3.2015.pdf) |
1.0 |
March 2015 |
| 3500 |
[Subsequent Neoplasms (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/3500r1-7.2021.pdf) |
1.0 |
July 2021 |
| 3501 |
[Pregnancy Form (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/F3501-V1-manual.pdf) |
1.0 |
April 2025 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4000r9-7.2023.pdf) |
9.0 |
July 2023 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/F4000-manual-R8.pdf) |
8.0 |
September 2022 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4000r7-7.2021.pdf) |
7.0 |
July 2021 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4000r6-1.2021.pdf) |
6.0 |
January 2021 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4000r5-1.2020.pdf) |
5.0 |
January 2020 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4000r4-1.2018.pdf) |
4.0 |
January 2018 |
| 4000 |
[Cellular Therapy Essential Data Pre-Infusion Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4000r3-7.2017.pdf) |
3.0 |
July 2017 |
| 4003 |
[Cellular Therapy Product Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4003r5-7.2023.pdf) |
5.0 |
July 2023 |
| 4003 |
[Cellular Therapy Product Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4003r4-2.2022.pdf) |
4.0 |
February 2022 |
| 4003 |
[Cellular Therapy Product Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4003r3-1.2021.pdf) |
3.0 |
January 2021 |
| 4003 |
[Cellular Therapy Product Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4003r2-1.2020.pdf) |
2.0 |
January 2020 |
| 4003 |
[Cellular Therapy Product Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4003r1-1.2019.pdf) |
1.0 |
January 2019 |
| 4006 |
[Cellular Therapy Infusion Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4006r6-7.2023.pdf) |
6.0 |
July 2023 |
| 4006 |
[Cellular Therapy Infusion Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4006r5-2.2022.pdf) |
5.0 |
February 2022 |
| 4006 |
[Cellular Therapy Infusion Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4006r4-1.2021.pdf) |
4.0 |
January 2021 |
| 4006 |
[Cellular Therapy Infusion Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4006r3-1.2020.pdf) |
3.0 |
January 2020 |
| 4006 |
[Cellular Therapy Infusion Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4006r2-1.2018.pdf) |
2.0 |
January 2018 |
| 4006 |
[Cellular Therapy Infusion Data Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4006r1-7.2017.pdf) |
1.0 |
July 2017 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r8-7.2023.pdf) |
8.0 |
July 2023 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r7-2.2022.pdf) |
7.0 |
February 2022 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r6-7.2021.pdf) |
6.0 |
July 2021 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r5-1.2021.pdf) |
5.0 |
January 2021 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r4-1.2020.pdf) |
4.0 |
January 2020 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r3-10.2018.pdf) |
3.0 |
October 2018 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r2-1.2018.pdf) |
2.0 |
January 2018 |
| 4100 |
[Cellular Therapy Essential Data Follow-Up Form Instructions (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/4100r1-7.2017.pdf) |
1.0 |
July 2017 |
| N/A |
Supplemental Report Form Manuals
|
N/A |
September 2013 |
| N/A |
[TED Manual (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/TED-Manual-PDF.pdf) |
N/A |
January 2008 |
| N/A |
[NMDP Forms Instruction Manual (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/NMDP-Forms-Instruction-Manual-PDF.pdf) |
N/A |
December 2007 |
| N/A |
[CIBMTR Data Management Manual (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/CIBMTR-Data-Management-Manual-PDF.pdf) |
N/A |
December 2007 |
| N/A |
[CIBMTR Registration Instruction Manual (PDF)](/Files/Data-Operations/Retired-Forms-Manuals/CIBMTR-Registration-Instruction-Manual-PDF.pdf) |
N/A |
December 2007 |

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/Managing-CIBMTR-Membership/New-Center-Resources
title: New Center Resources
url: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/Managing-CIBMTR-Membership/New-Center-Resources
hostname: cibmtr.org
description: Learn about new center membership and becoming part of the CIBMTR community.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['join CIBMTR, new center membership, New Center Resources']
filedate: 2025-06-23
-->

CIBMTR centers have access to numerous training and resources. These include:

Learn about how CIBMTR System Applications provide options for reporting.

Becoming a CIBMTR center is simple. If you would like to move forward with membership, complete the New Center Questionnaire.

Complete the New Center Questionnaire

Email cibmtr-centermaintenance@nmdp.org if you have any questions about the CIBMTR center membership process.

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/SCTOD-Requirements
title: SCTOD Requirements
url: https://cibmtr.org/CIBMTR/Data-Operations/Center-Membership/SCTOD-Requirements
hostname: cibmtr.org
description: The Stem Cell Therapeutic and Research Act of 2005 requires US transplant centers to submit outcomes data on all allogeneic transplants, both related and unrelated, when either the donor or the recipient resides in the United States (US), or if the collection or infusion takes place in a US center. The contract to manage this outcomes database, named the Stem Cell Therapeutic Outcomes Database (SCTOD), was awarded to CIBMTR in 2006.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['allogeneic transplants, required data, SCTOD Requirements']
filedate: 2025-06-23
-->

The Stem Cell Therapeutic and Research Act of 2005 requires US transplant centers to submit outcomes data on all allogeneic transplants, both related and unrelated, when either the donor or the recipient resides in the United States (US), or if the collection or infusion takes place in a US center. The contract to manage this outcomes database, named the Stem Cell Therapeutic Outcomes Database (SCTOD), was awarded to CIBMTR in 2006.

SCTOD reporting requirements vary depending on a center’s location, the origin of the transplanted graft, and the type of transplant performed: Recipient data are considered part of the SCTOD if they meet one of the following criteria:

Recipient data are not considered part of the SCTOD if they meet one of the following criteria:

Two important initiatives undertaken by CIBMTR to help transplant centers meet SCTOD data collection and submission requirements include:

---
<!--
URL: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/Observational-Database-Protocol
title: Research Database Protocol
url: https://cibmtr.org/CIBMTR/Data-Operations/Protocols-Consent-Forms/Observational-Database-Protocol
hostname: cibmtr.org
description: When a donor or recipient consents to participate in the Research Database, their data are contained in the CIBMTR’s Research Database and used for research. The database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source and for autologous transplants. Data are also collected on unrelated donors and their donation experiences.
sitename: cibmtr.org
date: 2025-01-01
categories: []
tags: ['baseline and outcome data, IRB, Research Database Protocol']
filedate: 2025-06-23
-->

When a donor or recipient consents to participate in the Research Database, their data are contained in the CIBMTR’s Research Database and used for research. The database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source and for autologous transplants. Data are also collected on unrelated donors and their donation experiences.

The primary purpose of the Research Database is to have a comprehensive source of data that can be used to study hematopoietic cell transplantation (HCT).

These data may be used in research to:

Any recipient of an unrelated or related donor or autologous transplant in a CIBMTR-affiliated center may participate in the Research Database. All NMDP donors who have been requested to donate marrow or peripheral blood stem cells for a recipient may also participate. Complete eligibility requirements are outlined in the study protocol.

If the recipient of an allogeneic (related or unrelated) HCT does not consent to the use of his/her data for research, the transplant center will still be required to submit TED–level data on the recipient. In this case, the recipient’s data will only be used for federally required analyses, such as the center-specific analysis mandated by CIBMTR’s contract to operate the Stem Cell Therapeutic Outcomes Database (SCTOD). The recipient’s data will never be included in research studies.

TED-level data is used in research. Therefore, if a transplant center only submits TED-level data to the CIBMTR, the center must still approach all allogeneic HCT recipients for consent to the Research Database. If a recipient consents to the Research Database, their TED-level data will be used in research.

For autologous recipients who do not consent to participate in research, the CIBMTR requests that the transplant center submit TED-level data on the recipient. No additional TED-level forms are required other than the Pre-TED. This information will help ensure the epidemiological integrity of the database and does not require the provision of any significant health information that could identify the recipient, nor will the recipient's data ever be included in research studies.

To be compliant with United States Federal Regulations for human research subject protection, all transplant centers must obtain IRB-approved informed consent from recipients to allow data submitted to the Research Database to be used for research studies, regardless of the level of data the center submits to the CIBMTR. All US transplant centers must have IRB approval for their center for the Research Database Research protocol.

Upon obtaining center IRB approval, the CIBMTR Protocol Coordinator must receive a copy of the center's IRB approval letter, approved protocol, and informed consent documents. These documents should be submitted via email to: DatabaseIRB@nmdp.org.

The CIBMTR tracks the IRB approval for the Research Database at each participating center. The center's IRB approval for this protocol must be current at all times. Failure to have current IRB approval may affect a center's ability to meet CPI requirements for data submission.

International transplant centers must follow their country’s laws and regulations governing human subjects and privacy protection. The transplant center is responsible for obtaining the necessary institutional review and approval for the Research Database.

If the recipient does not consent to participate in the Research Database according to the laws and regulations of their country, the CIBMTR requests that the transplant center submit TED-level data on the allogeneic recipient. For the autologous recipient, no additional TED-level forms are requested other than the Pre-TED. This information will help ensure the epidemiological integrity of the database and does not require the provision of any significant health information that could identify the recipient, nor will the recipient's data ever be included in research studies.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form templates. Your center must have IRB approval for the protocol and consent forms relevant to your center. The protocol must be submitted as written for center IRB approval.

The National Institutes of Health (NIH) has issued a Certificate of Confidentiality for the Research Database. According to NIH Policy, research that is applicable within the scope of the Policy as of 10/01/2017 is deemed to be issued a Certificate through the Policy. Certificates issued in this automatic manner will not be issued as a separate document.

---