# Protocols & Consent Forms

[Main Content]
Please wait while we gather your results.

The CIBMTR Biorepository contains cell and serum samples collected from related and unrelated transplant donors, cord blood units, and recipients.

CIBMTR collects longitudinal or cross-sectional PRO data from recipients of cellular therapies who are also enrolled in the Protocol for a Research Database for Hematopoietic Cell Transplantation, Other Cellular Therapies, and Marrow Toxic Injuries (Research Database protocol).

This database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source, autologous transplants, and other cellular therapies including CART and gene therapies. Data are also collected on unrelated donors.