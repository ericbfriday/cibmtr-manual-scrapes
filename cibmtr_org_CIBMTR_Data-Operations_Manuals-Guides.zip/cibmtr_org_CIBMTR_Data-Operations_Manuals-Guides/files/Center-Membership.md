CIBMTR has established an extensive clinical database of patient outcomes. Through the submission of timely and accurate data, center administrators and clinical research professionals play a key role in helping CIBMTR maintain - and grow - this critical database that has led to increased survival for recipients.


Learn how CIBMTR network centers interact with the different areas with CIBMTR Data Operations.

See more

Learn how to manage your CIBMTR membership.