When a donor or recipient consents to participate in the Research Database, their data are contained in the CIBMTR’s Research Database and used for research. The database includes recipient baseline and outcome data for related and unrelated allogeneic transplants from any cell source and for autologous transplants. Data are also collected on unrelated donors and their donation experiences.

The primary purpose of the Research Database is to have a comprehensive source of data that can be used to study hematopoietic cell transplantation (HCT).

These data may be used in research to:

Any recipient of an unrelated or related donor or autologous transplant in a CIBMTR-affiliated center may participate in the Research Database. All NMDP donors who have been requested to donate marrow or peripheral blood stem cells for a recipient may also participate. Complete eligibility requirements are outlined in the study protocol.

If the recipient of an allogeneic (related or unrelated) HCT does not consent to the use of his/her data for research, the transplant center will still be required to submit TED–level data on the recipient. In this case, the recipient’s data will only be used for federally required analyses, such as the center-specific analysis mandated by CIBMTR’s contract to operate the Stem Cell Therapeutic Outcomes Database (SCTOD). The recipient’s data will never be included in research studies.

TED-level data is used in research. Therefore, if a transplant center only submits TED-level data to the CIBMTR, the center must still approach all allogeneic HCT recipients for consent to the Research Database. If a recipient consents to the Research Database, their TED-level data will be used in research.

For autologous recipients who do not consent to participate in research, the CIBMTR requests that the transplant center submit TED-level data on the recipient. No additional TED-level forms are required other than the Pre-TED. This information will help ensure the epidemiological integrity of the database and does not require the provision of any significant health information that could identify the recipient, nor will the recipient's data ever be included in research studies.

To be compliant with United States Federal Regulations for human research subject protection, all transplant centers must obtain IRB-approved informed consent from recipients to allow data submitted to the Research Database to be used for research studies, regardless of the level of data the center submits to the CIBMTR. All US transplant centers must have IRB approval for their center for the Research Database Research protocol.

Upon obtaining center IRB approval, the CIBMTR Protocol Coordinator must receive a copy of the center's IRB approval letter, approved protocol, and informed consent documents. These documents should be submitted via email to: DatabaseIRB@nmdp.org.

The CIBMTR tracks the IRB approval for the Research Database at each participating center. The center's IRB approval for this protocol must be current at all times. Failure to have current IRB approval may affect a center's ability to meet CPI requirements for data submission.

International transplant centers must follow their country’s laws and regulations governing human subjects and privacy protection. The transplant center is responsible for obtaining the necessary institutional review and approval for the Research Database.

If the recipient does not consent to participate in the Research Database according to the laws and regulations of their country, the CIBMTR requests that the transplant center submit TED-level data on the allogeneic recipient. For the autologous recipient, no additional TED-level forms are requested other than the Pre-TED. This information will help ensure the epidemiological integrity of the database and does not require the provision of any significant health information that could identify the recipient, nor will the recipient's data ever be included in research studies.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form templates. Your center must have IRB approval for the protocol and consent forms relevant to your center. The protocol must be submitted as written for center IRB approval.

The National Institutes of Health (NIH) has issued a Certificate of Confidentiality for the Research Database. According to NIH Policy, research that is applicable within the scope of the Policy as of 10/01/2017 is deemed to be issued a Certificate through the Policy. Certificates issued in this automatic manner will not be issued as a separate document.