The CIBMTR collects longitudinal or cross-sectional PRO data from recipients of cellular therapies who are also enrolled in the Protocol for a Research Database for Hematopoietic Cell Transplantation, Other Cellular Therapies, and Marrow Toxic Injuries (Research Database protocol). The time points for PRO data collection parallel the time points at which treatment centers submit clinical outcomes data from healthcare records, with an additional time point at 30 days post-treatment for cellular therapy patients. Below are the measures and time points collected for adult HCT and CAR T patients:

The primary purpose of the PRO Protocol is to have a centralized collection of patient-reported symptoms and functioning to supplement traditional outcomes, such as survival or disease relapse, in registration and other studies. These data may be used in research to:

Any recipient of an unrelated or related HCT or CAR T in a CIBMTR-affiliated center may participate in the PRO protocol. Complete eligibility requirements are outlined in the study protocol.

If the recipient of HCT or cellular therapy does not consent to the Research Database protocol, they may still participate in the PRO protocol, but the use of their data will be limited to CIBMTR and NMDP process improvement analyses or study-specific analysis as laid out in the PRO protocol consent form.

The CIBMTR Survey Research Group identifies, approaches, and obtains consent from eligible recipients. Informed consent is documented in the CIBMTR electronic PRO (ePRO) system. The Survey Research Group centrally collects PRO surveys from participating recipients electronically, on paper, or by phone and follows up with non-responders.

PRO data are collected in the ePRO system and then stored in the CIBMTR database where they can be linked to CIBMTR clinical outcomes data.

Presented here are the number of patients enrolled in the CIBMTR PRO Protocol by type and year of infusion, as of May 20, 2025.

111 HCTs not included in the table due to lack of infusion type information in FormsNet3.

Presented here are the number of completed PRO surveys available for analysis by infusion-related time point, infusion type, age at transplant, gender, and indication, as of May 20, 2025.

Number (%) of patients who have survey completed at each time point

110 year 5 surveys not included in the table

The PRO protocol is a single-site CIBMTR protocol. All research activities, including enrollment and data collection, are centrally performed within the CIBMTR. Centers do not need to submit the PRO protocol or consent form to their local IRB for their patients to participate.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form. These are provided for reference only. Centers should not submit these materials for local IRB approval. Centers should not use these materials to consent recipients.