The CIBMTR Biorepository contains cell and serum samples collected from related and unrelated transplant donors, cord blood units, and recipients.

The primary objective of the CIBMTR Biorepository is to make these samples available for research studies related to histocompatibility and hematopoietic cell transplantation (HCT).

These data may be used in research to:

The CIBMTR Biorepository includes cell and serum samples from allogeneic related and unrelated donors and recipients. The protocol also allows for the submission of research samples from registered donors with rare tissue types. Complete eligibility requirements are outlined in the study protocol.

To be compliant with United States Federal Regulations for human research subject protection, US transplant centers must obtain IRB-approved informed consent from recipients before submitting samples to the CIBMTR Biorepository .

Although all NMDP centers participate in the CIBMTR Biorepository protocol, only select NMDP centers currently submit related recipient and donor samples. In the future, additional NMDP centers may be invited to submit related recipient and donor samples.

If your center only performs related donor HCT and/or autologous HCT, you will not submit research samples and, therefore, do not need to obtain IRB approval for your center for the CIBMTR Biorepository protocol.

Upon obtaining center IRB approval, the CIBMTR Protocol Coordinator must receive a copy of the center's IRB approval letter, approved protocol, and informed consent documents. These documents should be sent via email to: RepositoryIRB@nmdp.org

The CIBMTR tracks the IRB approval for the CIBMTR Biorepository at each participating center. The center's IRB approval for this protocol must be current at all times. Failure to have current IRB approval may affect your center's ability to meet continuous process improvement (CPI) requirements for sample submission.

The CIBMTR, through the NMDP IRB, has approved the following protocol and consent form templates. Your center must have IRB approval for the protocol and consent forms relevant to your center. The protocol must be submitted as written for center IRB approval.

The Health Resources and Services Administration (HRSA) has issued a Certificate of Confidentiality for the CIBMTR Biorepository. According to HRSA's Policy, research that is applicable within the scope of the Policy as of December 13, 2016, is deemed to be issued a Certificate through the Policy. Certificates issued automatically will not be given as separate documents.

HRSA's Human Subjects Protection Policy: https://www.hrsa.gov/about/organization/bureaus/opae/human-subjects