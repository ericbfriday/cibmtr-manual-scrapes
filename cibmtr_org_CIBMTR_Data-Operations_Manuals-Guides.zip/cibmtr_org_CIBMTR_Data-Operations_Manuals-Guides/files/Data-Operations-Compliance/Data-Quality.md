CIBMTR’s data quality efforts are continuous and cyclical. They are under constant refinement to ensure that any new data concerns that arise can be prevented or identified as far upstream as possible.

CIBMTR's clinical data quality team coordinates several aspects of the post-collection data validation processes. This team coordinates requests from various areas of CIBMTR to participating centers to ensure consistency in messaging and prioritization guidance.

As new issues are identified, the clinical data quality team evaluates existing resources, including instruction manuals, available training videos, and FormsNet3SM validation, and the team coordinates enhancements to the relevant systems and materials.

FormsNet validation happens in real-time as data are entered. Users are prompted and can resolve errors immediately in the application. Forms will not be considered “complete” by the application until all errors are addressed.

The FormsNet Query Management Tool allows CIBMTR to place a query on a field directly within FormsNet so all system validation happens normally, preventing the user from generating additional errors. This enhances efficiency and protects privacy by reducing manual processes, such as emails and phone calls. The tool also requires action from CIBMTR staff members to “approve” the response before the form can go back to a complete status, ensuring the response truly resolves the data issue.

Resolution of these queries are tracked within the CPI compliance program. Centers must address a target percentage of queries within a trimester to remain in good standing.