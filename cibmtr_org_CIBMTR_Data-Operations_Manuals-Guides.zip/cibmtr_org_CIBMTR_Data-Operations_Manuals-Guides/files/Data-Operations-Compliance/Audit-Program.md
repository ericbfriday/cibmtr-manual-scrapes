Ongoing data audits are performed at all CIBMTR participating centers as part of the CIBMTR’s overall data quality assurance program. The audit compares data in source documents maintained at the center with data contained in the CIBMTR outcomes registry. The audits identify errors that otherwise would go undetected by the online validations built into the data entry program.

The overall goal of the ongoing audits is to ensure the quality and accuracy of the research database by:

As part of the on-going data quality program, the CIBMTR conducts data quality audits at regular intervals to ensure the accuracy of data submitted to the CIBMTR’s observational database. CIBMTR Clinical Research Associates serve as auditors. They compare submitted data with source documentation, provide training to data management staff, and identify any systemic data reporting issues at transplant centers qualifying for audit. All data elements on all forms are subject to audit. However, the audit concentrates on “critical” data, i.e., data most likely to be included in a research study. Data elements considered “non-critical” are randomly audited to increase the validity of the audit error rates. Auditors also review consent forms for completeness. See the Before the Audit section in the Audit Guide for more details and strategies for a successful audit.

Additional information about the CIBMTR audit visit can be found in the During the Audit section of the Audit Guide.

Following the audit, the CIBMTR generates a report and may require the center to complete corrective action. The final report will also contain the center’s critical, random, and overall field error rates. Center audit preparation is key to ensuring the logistical success of the audit. More details can be found in the After the Audit section of the Audit Guide.

Each center is audited once in a four-year cycle.

In 2017, FACT and the CIBMTR launched a collaborative program of data auditing, designed to reduce duplicative efforts, enhance quality improvement efforts, and provide support to accredited programs. The essential elements of the collaboration are:

For more information, including a list of frequently asked questions, see the FACT CIBMTR Audit Collaboration Letter.

For more detailed information about the audit process, audit results, a list of General FAQs, and audit contact information, please see the Audit Guide.