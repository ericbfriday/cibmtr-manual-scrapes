| December 19th, 2023 |
[Data Operations Updates for the Week of 12/18/23 (229)](https://cibmtr.cmail19.com/t/d-e-vkkehd-dyydkdhhjk-r/) |
- CIBMTR Center Support Closed December 25th-26th and January 1st
- Introductory Course for New Data Managers
- Register for the 2024 Tandem Meetings!
|
| December 12th, 2023 |
[Data Operations Updates for the Week of 12/11/23 (228)](https://cibmtr.cmail20.com/t/d-e-vkijuud-dyxllvdi-r/) |
- Introductory Course for New Data Managers
- Thank You for Attending the Cell Therapy and Gene Therapy Forum!
- New Forms With ISCN Functionality
- Register for the 2024 Tandem Meetings!
|
| December 5th, 2023 |
[Data Operations Updates for the Week of 12/4/23 (227)](https://cibmtr.cmail20.com/t/d-e-vkythik-dyljtkhryk-r/) |
- Age of Majority: Retrospective Cases
- New Forms With ISCN Functionality
- US Recipient CPI Reminders
- GVHD Immunosuppressive Agents Data Collection
- CIBMTR Forms Instruction Manual Update
- 2023 Center Volumes Data Report (CVDR)
- This Week: CIBMTR Cell Therapy and Gene Therapy Forum!
- Price Increase Soon - Register for the 2024 Tandem Meetings!
|
| November 28th, 2023 |
[Data Operations Updates for the Week of 11/27/23 (225)](https://cibmtr.cmail19.com/t/d-e-vhkuult-drulditdtk-r/) |
- Save the Date: CIBMTR Cell Therapy and Gene Therapy Forum on December 7th!
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- 2024 Tandem Meetings Registration Open!
|
| November 22nd, 2023 |
[2023 Center Volumes Data Report (CVDR) (224)](https://cibmtr.cmail19.com/t/d-e-vhdftd-drhkukilb-r/) |
- 2023 Center Volumes Data Report (CVDR) Information (Technical Issue)
|
| November 21st, 2023 |
[Data Operations Updates for the Week of 11/20/23 (223)](https://cibmtr.cmail19.com/t/d-e-vhdqiy-drhkkiydiy-r/) |
- Thank You for Attending Advanced Data Manager Training
- CIBMTR Center Support Closed November 23rd and 24th
- Save the Date: CIBMTR Cell Therapy and Gene Therapy Forum on December 7th!
- Recorded New Data Manager Onboarding
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- 2024 Tandem Meetings Registration Now Open!
|
| November 14th, 2023 |
[Data Operations Updates for the Week of 11/13/23 (222)](https://cibmtr.cmail20.com/t/d-e-vhjzjl-drdktityud-r/) |
- Save the Date: CIBMTR Cell Therapy and Gene Therapy Forum on December 7th!
- 2023 Center Volumes Data Report (CVDR)
- Recorded New Data Manager Onboarding
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- 2024 Tandem Meetings Registration Now Open!
|
| November 7th, 2023 |
[Data Operations Updates for the Week of 11/6/23 (221)](https://cibmtr.cmail19.com/t/d-e-vhlcyd-drikdykrki-r/) |
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- Advanced Data Manager Training - Only One Week Left to Register!
- 2024 Tandem Meetings Registration Now Open!
|
| November 1st, 2023 |
[2023 Center Volumes Data Report (CVDR) (220)](https://cibmtr.cmail20.com/t/d-e-vdhujjd-drirjljldt-r/) |
- 2023 Center Volumes Data Report (CVDR) Information
|
| October 31st, 2023 |
[Data Operations Updates for the Week of 10/30/23 (219)](https://cibmtr.cmail20.com/t/d-e-vdhjild-drilljulc-r/) |
- CIBMTR Center Support - Delayed Responses November 2-4, 2023
- October 2023 Quarterly Release Now Live
- CIBMTR Forms Instruction Manual Updates
- Pending Reconsent to the CIBMTR Portal
- Data Quality Focus in November - Best Response on AML Post-Infusion Form 2110
- Last Chance to Register for Upcoming New Data Manager Training Course!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- 2024 Tandem Meetings Registration Now Open!
|
| October 24th, 2023 |
[Important Fall Release Information Included - Data Operations Updates for the week of 10/23/23 (218)](https://cibmtr.cmail19.com/t/d-e-vdttlg-drtridkyhi-r/)
|
- October 2023 Quarterly Release Information
- Save the Date! Upcoming Quarterly Release Informational Webinar
- Upcoming Training Opportunity for New Data Managers
- 2024 Tandem Meetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- Data Quality Focus for October - Clean-up on the F2149
|
| October 17th, 2023 |
[Data Operations Updates for the Week of 10/16/23 (217)](https://cibmtr.cmail19.com/t/d-e-vdrlkld-drjjxkrjj-r/) |
- October 2023 Quarterly Release Information
- Upcoming Training Opportunity for New Data Managers
- Save the Date! Upcoming Quarterly Release Informational Webinar
- 2024 Tandem Meetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- Data Quality Focus for October - Clean-up on the F2149
|
| October 10th, 2023 |
[Data Operations Updates for the Week of 10/9/23 (216)](https://cibmtr.cmail20.com/t/d-e-vikiuhk-drethiukh-r/) |
- Save the Date! Upcoming Quarterly Release Informational Webinar
- 2024 Tandem Meetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- Data Quality Focus for October - Clean-up on the F2149
|
| October 3rd, 2023 |
[Data Operations Updates for the Week of 10/2/23 (215)](https://cibmtr.cmail20.com/t/d-e-viiktdy-drlkdkjylt-r/) |
- 2024 Tandem Meeetings Registration Now Open!
- Advanced Data Manager Training Coming in November - Reporting Lines of Therapy
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus for October - Clean-up on the F2149
- Registration Open! Recorded New Data Manager Onboarding
|
| September 26th, 2023 |
[Data Operations Updates for the Week of 9/25/23 (214)](https://cibmtr.cmail20.com/t/d-e-viyuuhd-dluhndliy-r/) |
- Registration Now Open! Recorded New Data Manager Onboarding
- Form 2402 - ISCN Functionality
- US Recipient CPI Reminders
- 2023 Center Volumes Data Report (CVDR) Now Open
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
|
| September 20th, 2023 |
[2023 Center Volumes Data Report (CVDR) Opening Soon! (213)](https://cibmtr.cmail19.com/t/d-e-vilhtkk-dlkutilre-r/) |
- 2023 Center Volumes Data Report (CVDR)
|
| September 19th, 2023 |
[Data Operations Updates for the Week of 9/18/23 (212)](https://cibmtr.cmail20.com/t/d-e-vilcdt-dlkhtrtjdl-r/) |
- NEW! Recorded New Data Manager Onboarding Registration Opening Soon
- CIBMTR Forms Instruction Manual Updates
- Submissions Closing Soon!
** **Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
|
| September 13th, 2023 |
[Fall 2023 Data Manager Training Opportunities (211)](https://cibmtr.cmail20.com/t/d-e-vthuhx-dlklujiiju-r/) |
- Save the Dates! Fall 2023 Data Manager Training Opportunities
|
| September 12th, 2023 |
[Data Operations Updates for the Week of 9/11/23 (210)](https://cibmtr.cmail19.com/t/d-e-vthjdhl-dlhhdlurhr-r/) |
- Error Correction Forms on the CIBMTR Portal
- Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
|
| September 5th, 2023 |
[Data Operations Updates for the Week of 9/4/23 (209)](https://cibmtr.cmail20.com/t/d-e-vttikx-dldkkkdjlt-r/) |
- UPDATE: Network Outage Has Been Resolved
- Data Quality Focus for September - ANC and Platelet Recovery Date Missing
- Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- International Recipient CPI Reminders
|
| August 29th, 2023 |
[Data Operations Updates for the Week of 8/28/23 (208)](https://cibmtr.cmail20.com/t/d-e-vtrkkly-dldryhduhl-r/) |
- Seeking Data Managers for Best Practices Panel at the 2024 Tandem Meetings
- CIBMTR Forms Instruction Manual Updates
- CIBMTR Center Support Closed September 4th
- Data Quality Focus for August - Answering the Indicator Question
|
| August 22nd, 2023 |
[Data Operations Updates for the Week of 8/21/23 (207)](https://cibmtr.cmail19.com/t/d-e-vjkdua-dlijhrkjlh-r/) |
- Important Update: Respiratory Virus Post-Infusion Form 2149
- 2023 Center Volumes Data Report (CVDR)
- Data Quality Focus for August - Answering the Indicator Question
|
| August 21st, 2023 |
[US Recipient CPI Update (206)](https://cibmtr.cmail19.com/t/d-e-vjkkilk-dliyilbii-r/) |
- UPDATE: US Recipient CPI - CPI Summary Reports Notification
|
| August 15th, 2023 |
[Data Operations Updates for the Week of 8/14/23 (205)](https://cibmtr.cmail19.com/t/d-e-vjddhdd-dltiauuo-r/) |
- New Data Manager Onboarding - Registration Closing Soon!
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus for August - Answering the Indicator Question
- Upstream CRID - Updates and FAQs
|
| August 8th, 2023 |
[Data Operations Updates for the Week of 8/7/23 (204)](https://cibmtr.cmail20.com/t/d-e-vjtvkt-dljkjdjyq-r/) |
- Data Quality Focus for August - Answering the Indicator Question
- Upstream CRID - Updates and FAQs
- Resolving Queries on CRID Assignment and Consent Tools in FormsNet3
- RCI BMT is now CIBMTR CRO Services
- CIBMTR Monthly Maintenance Reminders
- Input Requested: Advanced Data Manager Training Sessions
- 2023 Center Volumes Data Report (CVDR)
- New Data Manager Onboarding - Registration Now Open!
|
| August 1st, 2023 |
[Data Operations Updates for the Week of 7/31/23 (203)](https://cibmtr.cmail20.com/t/d-e-vjritiy-dlyuctikk-r/) |
- 2023 Center Volumes Data Report (CVDR)
- July 2023 Quarterly Release Now Live
- Reconsent Pending - Important Changes
- Input Requested: Advanced Data Manager Training Sessions
- New Audit Categories Available in CIBMTR Center Support
- US Recipient CPI Reminders
- International CPI Reminders
- New Data Manager Onboarding - Registration Now Open!
|
| July 25th, 2023 |
[Important Summer Release Information Included - Data Operations Updates for the Week of 7/24/23 (202)](https://cibmtr.cmail20.com/t/d-e-vykkudt-dlvydtlhh-r/) |
- July 2023 Quarterly Release Information
- Reconsent Pending - Important Changes!
- CIBMTR Launches New Embargo Process
- CIBMTR Forms Instruction Manual Updates
- FormsNet3 User Access Verification Complete
- Patient Transfer Tool Reminders
- July Data Quality Focus - Thank You!
- New Data Manager Onboarding - Registration Now Open!
|
| July 18th, 2023 |
[Data Operations Updates for the Week of 7/17/23 (201)](https://cibmtr.cmail20.com/t/d-e-vydctl-dlmwuujd-r/) |
- Reconsent Pending - Important Changes!
- July 2023 Quarterly Release Information
- CIBMTR Launches New Embargo Process
- International Recipient CPI Reminders
- July Data Quality Focus - Thank You!
- New Data Manager Onboarding - Registration Now Open!
|
| July 11th, 2023 |
[Data Operations Updates for the Week of 7/10/23 (200)](https://cibmtr.cmail20.com/t/d-e-vslkyd-dllhsjls-r/) |
- New Data Manager Onboarding - September 2023 Registration Opening July 12th!
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Reminder: Upstream CRID Feedback Requested
- Last Chance to Attend: Important CIBMTR Webinars Happening This Week!
|
| July 5th, 2023 |
[Data Operations Updates for the Week of 7/3/2023 (199)](https://cibmtr.cmail19.com/t/d-e-vztild-iuuditjdq-r/) |
- New Data Manager Onboarding - September 2023
- Reminder: Upstream CRID Feedback Request
- Important Upcoming CIBMTR Webinars!
- Important June Monthly Maintenance Update
|
| June 28th, 2023 |
[Upstream CRID Survey (198)](https://cibmtr.cmail19.com/t/d-e-vadhc-iukujydlli-r/) |
- Call to Action: Feedback Request
|
| June 27th, 2023 |
[Data Operations Updates for the Week of 6/26/2023 (197)](https://cibmtr.cmail20.com/t/d-e-valhdt-iukdirtkdh-r/) |
- CIBMTR Center Support Closed July 4th
- Important June Monthly Maintenance Update
- FY2022 Center Specific Audit Summary Reports Available on CIBMTR Portal
- Fee Schedule for Study Supplemental Forms has Moved
- Important Upcoming CIBMTR Webinars!
- Data Quality Focus for June - GVHD Reporting for Allo Transplants
|
| June 20th, 2023 |
[Data Operations Updates for the Week of 6/19/2023 (196)](https://cibmtr.cmail19.com/t/d-e-vmjlut-iuhhtyidp-r/) |
- Important Upcoming CIBMTR Webinars!
- UPDATED - Data Quality Focus for June - GVHD Reporting for Allo Transplants
|
| June 15th, 2023 |
[Important Upcoming CIBMTR Webinars (195)](https://cibmtr.cmail19.com/t/d-e-vpduky-iuhyjyea-r/) |
- Action Required: Important Upcoming CIBMTR Webinars!
|
| June 13th, 2023 |
[Data Operations Updates for the Week of 6/12/2023 (194)](https://cibmtr.cmail19.com/t/d-e-vbkktk-iuduzhyp-r/) |
- Data Quality Focus for June - GVHD Reporting for Allo Transplants
- International Recipient CPI Reminders
- Data Manager Training Opportunities are Expanding!
|
| June 6th, 2023 |
[Data Operations Updates for the Week of 6/5/2023 (193)](https://cibmtr.cmail20.com/t/d-e-vlududl-iuiiwkilt-r/) |
- Data Quality Focus for June - GVHD Reporting for Allo Transplants
- International Recipient CPI Reminders
- Data Manager Training Opportunities are Expanding!
|
| May 31st, 2023 |
[Data Manager Training Opportunities (192)](https://cibmtr.cmail19.com/t/d-e-vlddijy-iutturxky-r/) |
- Data Manager Training Opportunities are Expanding!
|
| May 23rd, 2023 |
[Data Operations Updates for the Week of 5/22/2023 (191)](https://cibmtr.cmail20.com/t/d-e-vljuudd-iujrxitdd-r/) |
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
- Upstream CRID Open Enrollment
|
| May 16th, 2023 |
[Data Operations Updates for the Week of 5/15/2023 (190)](https://cibmtr.cmail19.com/t/d-e-vlluhx-iuckyijc-r/) |
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
- Upstream CRID Open Enrollment
- Data for Request for Information (RFI) - Updated for 2022
|
| May 11th, 2023 |
[Data for Request for Information (RFI) Updated for 2022 (189)](https://cibmtr.cmail19.com/t/d-e-zuiulid-iuolrwlj-r/) |
- Data for Request for Information (RFI) - Updated for 2022
|
| May 9th, 2023 |
[Data Operations Updates for the Week of 5/8/2023 (188)](https://cibmtr.cmail20.com/t/d-e-zuklkyk-iultkhuhtu-r/) |
- CIBMTR Forms Instruction Manual
- Upstream CRID Open Enrollment
- US Recipient CPI Reminders
- Updates to Cellular Therapy Reimbursement
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
|
| May 2nd, 2023 |
[Data Operations Updates for the Week of 5/1/2023 (187)](https://cibmtr.cmail20.com/t/d-e-zuiall-ikujxyddd-r/) |
- Updates to Cellular Therapy Reimbursement
- Data Quality Focus for May - CMP Form Status & Platelet Recovery
- International Recipient CPI Reminders
|
| April 25th, 2023 |
[Data Operations Updates for the Week of 4/24/2023 (186)](https://cibmtr.cmail20.com/t/d-e-zuyptl-ikkryuyhtl-r/) |
- April 2023 Quarterly Release Now Live
- CIBMTR Forms Instruction Manual
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| April 18th, 2023 |
[Important Spring Release Information Included - Data Operations Updates for the Week of 4/17/2023 (185)](https://cibmtr.cmail19.com/t/d-e-zkutkjl-ikhjmlldu-r/) |
- April 2023 Quarterly Release Information
- International Recipient CPI Reminders
- CIBMTR Portal Upgrade Now Live
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| April 11th, 2023 |
[Data Operations Updates for the Week of 4/10/2023 (184)](https://cibmtr.cmail20.com/t/d-e-zkdtkkk-ikdrdljrjy-r/) |
- CIBMTR Portal Upgrade Now Live
- April 2023 Quarterly Release Information
- US Recipient CPI Reminders
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| April 4th, 2023 |
[Data Operations Updates for the Week of 4/3/2023 (183)](https://cibmtr.cmail19.com/t/d-e-zktqtd-ikitdjijkl-r/) |
- CIBMTR Portal Upgrade
- Is a New User Missing the Recipient Tab in FN3?
- Data Quality Focus for April - ANC Recovery
- Career Opportunity with CIBMTR-Milwaukee
|
| March 28th, 2023 |
[Data Operations Updates for the Week of 3/27/2023 (182)](https://cibmtr.cmail19.com/t/d-e-zkrlrut-ikttkrirtj-r/) |
- Data Quality Focus for April - ANC Recovery
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Career Opportunity with CIBMTR-Milwaukee
|
| March 21st, 2023 |
[Data Operations Updates for the Week of 3/20/2023 (181)](https://cibmtr.cmail20.com/t/d-e-zhklydy-ikjyhijhuj-r/) |
- Removal of 'COVID Impact to HCT' Category from CIBMTR Center Support
- FAQs for Resetting and Deleting Forms
- Career Opportunity with CIBMTR-Milwaukee
|
| March 7th, 2023 |
[Data Operations Updates for the Week of 3/6/2023 (180)](https://cibmtr.cmail19.com/t/d-e-zhyljll-ikbbiljl-r/) |
- Career Opportunity with CIBMTR-Milwaukee
- Data Quality Focus for March - Best Response on F2450
|
| February 28, 2023 |
[Data Operations Updates for the Week of 2/27/2023 (179)](https://cibmtr.cmail19.com/t/d-e-zdkukhd-ihuuijkhlk-r/) |
- Data Quality Focus for March - Best Response on F2450
|
| February 21, 2023 |
[Data Operations Updates for the Week of 2/20/2023 (178)](https://cibmtr.cmail20.com/t/d-e-zdiutlk-ihkhjrlili-r/) |
- 2023 Transplant Center Specific Analysis (TCSA)
|
| February 14, 2023 |
[Data Operations Updates for the week of 2/13/2023 (177)](https://cibmtr.cmail19.com/t/d-e-zdytylk-ihhhttjtuj-r/) |
- CIBMTR Center Support - Delayed Staff Responses February 14 - 17, 2023
- International Recipient CPI Reminders
|
| February 07, 2023 |
[Data Operations Updates for the Week of 2/06/2023 (176)](https://cibmtr.cmail19.com/t/d-e-zdlnuk-ihdydtllw-r/) |
- International Recipient CPI Updates
- 2023 Tandem Meetings - Last Chance for Virtual Registration!
|
| January 31, 2023 |
[Data Operations Updates for the Week of 1/30/2023 (175)](https://cibmtr.cmail19.com/t/d-e-zihadd-ihirhrlydk-r/#toc_item_4) |
- 2023 Transplant Center Specific Analysis (TCSA)
- Outstanding Forms Due Backlog
- January 2023 Quaterly Release Now Live
- 2023 Tandem Meetings - Register Now
|
| January 24, 2023 |
[Data Operations Updates for the Week of 1/23/2023 (174)](https://cibmtr.cmail19.com/t/d-e-zitwik-ihtlddlyiu-r/) |
- Winter 2023 Quarterly Release Information
- Now Accepting 2022 CTA Lists for US Transplants
- New CIBMTR Website
- 2023 Tandem Meetings - Register Now
|
| January 17, 2023 |
[Data Operations Updates for the Week of 1/16/2023 (173)](https://cibmtr.cmail19.com/t/d-e-ziriily-ihjrlihkjj-r/) |
- New CIBMTR Website Now Live!
- Winter 2023 Quarterly Release Information
- US Recipient CPI
- 2023 Tandem Meetings - Register Now
|
| January 16, 2023 |
[New CIBMTR.ORG Website Now Live (172)](https://cibmtr.cmail19.com/t/d-e-zirltdt-ihykqgkh-r/) |
- Known Issue with Forms Instruction Manual Link
|
| January 10, 2023 |
[Data Operations Updates for the Week of 1/09/2023 (171)](https://cibmtr.cmail19.com/t/d-e-ztkhkjt-ihftuiyui-r/) |
- New CIBMTR Website Coming Soon!
- New Data Manager Onboarding Registration
- 2023 Tandem Meetings - Register Now
|