| December 31st, 2024
|
[Data Operations Updates for the Week of 12/30/24 (293)](https://cibmtr.cmail20.com/t/d-e-syhllkk-dhjyuluhhk-r/)
|
- CIBMTR Center Support Closed for New Years Holiday
- Seeking Volunteers for CIBMTR Burden Testing - Transplant Essential Data Collection
- Last Chance to Provide Your Input!
- Register for Introductory Course for New Data Managers
- 2025 Tandem Meetings Registration Now Open!
|
| December 23rd, 2024
|
[Data Operations Updates for the Week of 12/23/24 (292)](https://cibmtr.cmail20.com/t/d-e-sydllid-dhykkijtij-r/)
|
- CIBMTR Center Support Closed for Christmas and New Year Holidays
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- TC Query Report Enhancements
- We Want Your Input for the 2025 Tandem Audit Highlights Presentation!
- Register for Introductory Course for New Data Managers
- 2025 Tandem Meetings Registration Now Open!
|
| December 23rd, 2024
|
[Seeking Volunteers for CIBMTR Burden Testing (291)](https://cibmtr.cmail20.com/t/d-e-swuklk-dhykkicdi-r/)
|
- Seeking Volunteers for CIBMTR Burden Testing - Transplant Essential Data Collection
|
| December 17th, 2024
|
[Data Operations Updates for the Week of 12/16/24 (290)](https://cibmtr.cmail20.com/t/d-e-sskuit-dhvudolu-r/)
|
- We Want Your Input for the 2025 Tandem Audit Highlights Presentation!
- Register for Introductory Course for New Data Managers
- 2024 Center-Specific Survival Analysis Report Now Available on CIBMTR Portal
- Cell Therapy Reporting Guides
- Center Specific Survival Analysis (TCSA) Notification
- 2025 Tandem Meetings Registration Now Open!
|
| December 10th, 2024
|
[Data Operations Updates for the Week of 12/9/24 (289)](https://cibmtr.cmail19.com/t/d-e-svcjk-dhnbdjjd-r/)
|
- Center Specific Survival Analysis (TCSA) Notification
- 2025 Tandem Meetings Registration Now Open!
|
| December 3rd, 2024
|
[Data Operations Updates for the Week of 12/2/24 (288)](https://cibmtr.cmail19.com/t/d-e-satdjd-dhljmuhit-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Corporate Study Expectations
- Last Chance to Register! Cell Therapy and Gene Therapy Forum on December 5th
- Price Increase Soon! 2025 Tandem Meetings Registration Open!
|
| November 26th, 2024
|
[Data Operations Updates for the Week of 11/25/24 (287)](https://cibmtr.cmail19.com/t/d-e-smkydt-ddkhhlutx-r/)
|
- CIBMTR Center Support Closed on November 28th and 29th
- Corporate Study Expectations
- Register Now for Winter Quarterly Release Preview Webinar on December 3rd
- Register Now for Cell Therapy and Gene Therapy Forum on December 5th
- 2025 Tandem Meetings Registration Now Open!
|
| November 19th, 2024
|
[Data Operations Updates for the Week of 11/18/24 (286)](https://cibmtr.cmail19.com/t/d-e-spltdl-ddhubilih-r/)
|
- Register Now for Winter Quarterly Release Preview Webinar on December 3rd
- Update to When Confirmation of HLA Typing (F2005) Comes Due in FN3
- JOB POSTING: Director of Statistical Operations
- International Recipient CPI Notifications
- We Want Your Input!
- Register Now for Cell Therapy and Gene Therapy Forum on December 5th
- 2025 Tandem Meetings Registration Now Open!
|
| November 12th, 2024
|
[Data Operations Updates for the Week of 11/11/24 (285)](https://cibmtr.cmail19.com/t/d-e-sojjhk-dddyijilur-r/)
|
- We Want Your Input!
- Register Now for Cell Therapy and Gene Therapy Forum on December 5th
- 2025 Tandem Meetings Registration Now Open!
|
| November 5th, 2024
|
[Data Operations Updates for the Week of 11/4/24 (284)](https://cibmtr.cmail19.com/t/d-e-slhddkl-ddijdrhuuy-r/)
|
- Consent Status Review - Reconsent Pending
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- 2025 Tandem Meetings Registration Now Open!
|
| October 29th, 2024
|
[Data Operations Updates for the Week of 10/28/24 (283)](https://cibmtr.cmail19.com/t/d-e-slturo-ddtrkkjduy-r/)
|
- Reconsent Pending: Change to Process
- CIBMTR Forms Instruction Manual Updates
- October 2024 Quarterly Release - Important Information
- Center Volumes Data Report (CVDR) Notifications
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
|
| October 21st, 2024
|
[Important Fall Release Information Included - Data Operations Updates for the Week of 10/21/2024 (282)](https://cibmtr.cmail20.com/t/d-e-slyyull-ddjyljptt-r/)
|
- October 2024 Quarterly Release - Important Information
- Center Volumes Data Report (CVDR) Notifications
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
|
| October 17th, 2024
|
[Center Volumes Data Report (CVDR) Notifications (281)](https://cibmtr.cmail19.com/t/d-e-sllhjit-ddeiylhtl-r/)
|
- Center Volumes Data Report (CVDR) Notifications
|
| October 15th, 2024
|
[Data Operations Updates for the Week of 10/14/24 (280)](https://cibmtr.cmail20.com/t/d-e-euuiult-ddeiylhtl-r/)
|
- October 2024 Quarterly Release - Important Information
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
|
| October 8th, 2024
|
[Data Operations Updates for the Week of 10/7/24 (279)](https://cibmtr.cmail20.com/t/d-e-euduhlt-ddxhdlum-r/)
|
- Upcoming Data Manager Training Opportunities
- 2025 Tandem Meetings Registration Now Open!
- Save the Date! Fall Quarterly Release Webinar
|
| October 2nd, 2024
|
[Join us for CRP/DM Track at the 2025 Tandem Meetings!](https://cibmtr.cmail20.com/t/d-e-eutkhtt-ddldwirhu-r/)
|
- 2025 Tandem Meetings Registration Now Open!
|
| October 1st, 2024
|
[Data Operations Updates for the Week of 9/30/24 (277)](https://cibmtr.cmail19.com/t/d-e-eutfiy-ddltlyeji-r/)
|
- International Recipient CPI Notifications
- Save the Date! Fall Quarterly Release Webinar
|
| September 24th, 2024
|
[Data Operations Updates for the Week of 9/23/24 (276)](https://cibmtr.cmail19.com/t/d-e-eurjhtk-diuiliuiur-r/)
|
- Center Volumes Data Report (CVDR) Notifications
- Last Chance to Register for Upcoming IRC Meeting - TED Forms
|
| September 17th, 2024
|
[Data Operations Updates for the Week of 9/16/24 (275)](https://cibmtr.cmail20.com/t/d-e-ekkdrll-dikritiyjl-r/)
|
- US Recipient CPI Notifications
- Center Volumes Data Report (CVDR) Notifications
- LAST CHANCE! Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| September 10th, 2024
|
[Data Operations Updates for the Week of 9/9/24 (274)](https://cibmtr.cmail19.com/t/d-e-ekikldd-didklrtktl-r/)
|
- Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| September 4th, 2024
|
[Center Volumes Data Report (CVDR) Notifications (273)](https://cibmtr.cmail19.com/t/d-e-ekjdua-diihdkdrui-r/)
|
- Center Volumes Data Report (CVDR) Notifications
|
| September 3rd, 2024
|
[Data Operations Updates for the Week of 9/2/24 (272)](https://cibmtr.cmail19.com/t/d-e-ekjqkt-diihdkdrui-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- Register for Upcoming Initial Review Committee (IRC) Meeting - Solid Tumor Forms
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| August 28th, 2024
|
[Center Volumes Data Report (CVDR) Notifications (271)](https://cibmtr.cmail19.com/t/d-e-ekrnjt-diirdhdrkh-r/)
|
- Center Volumes Data Report (CVDR) Notifications
|
| August 27th, 2024
|
[Data Operations Updates for the Week of 8/26/24 (270)](https://cibmtr.cmail19.com/t/d-e-eklddud-diilljnlu-r/)
|
- Seeking Data Managers for Center Idea Sharing Sessions at the 2025 Tandem Meetings
- CIBMTR Portal - Cridical Forms Past Due: Monthly Update
- Register for Upcoming Initial Review Committee (IRC) Meeting - Solid Tumor Forms
- LAST CHANCE TO REGISTER! New Data Manaer Onboarding - September 2024
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| August 20th, 2024
|
[Data Operations Updates for the Week of 8/19/24 (269)](https://cibmtr.cmail20.com/t/d-e-ehkbuk-dityjlhjij-r/)
|
- NEW! Register for Upcoming Initial Review Committee (IRC) Meeting - Solid Tumor Forms
- JOB POSTING: Scientific Director, Infection and Immune Reconstitution Working Committee
- New Data Manager Onboarding - September 2024 Registration Now Open!
- Register Now for Advanced Data Manager Training!
- Training Spotlight: Reporting Disease Assessments
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
|
| August 14th, 2024
|
[Register Now for New Data Manager Onboarding! (268)](https://cibmtr.cmail19.com/t/d-e-ehdqdl-dijriudjdk-r/)
|
- New Data Manager Onboarding - September 2024 Registration Now Open!
|
| August 13th, 2024
|
[Data Operations Updates for the Week of 8/12/24 (267)](https://cibmtr.cmail19.com/t/d-e-ehihijy-dijriudjdk-r/)
|
- Register Now for Fall Quarterly Release Preview Webinar on August 19th
- Register Now for Advanced Data Manager Training!
- Training Spotlight: Reporting Disease Assessments
- New Data Manager Onboarding - September 2024 Registration Now Open!
- Register for Upcoming Initial Review Committee (IRC) Meetings - Transplant Essential Data Forms
|
| August 6th, 2024
|
[Data Operations Updates for the Week of 8/5/24 (266)](https://cibmtr.cmail20.com/t/d-e-ehyhkld-dieyddukl-r/)
|
- Register Now for Fall Quarterly Release Preview Webinar on August 19th
- Consent Status - Please Review List on Portal
- Register Now for Advanced Data Manager Training!
- Training Spotlight: Reporting Disease Assessments
- US Recipient CPI Notifications
- New Data Manager Onboarding - September 2024 Registration Now Open!
- Register for Upcoming Initial Review Committee (IRC) Meetings - Transplant Essential Data Forms
|
| July 30th, 2024
|
[Data Operations Updates for the Week of 7/29/24 (265)](https://cibmtr.cmail19.com/t/d-e-ehlhuyk-dibtkdidu-r/)
|
- July 2024 Quarterly Release - Important Information
- New CIBMTR Forms Instructiona Manual Update Process & Release Updates
- Register for Upcoming Initial Review Committee (IRC) Meetings - TED Forms
- Lifileucel (Amtagvi) Reporting Guide Now Available
- Last Call for Input: Advanced Data Manager Training
|
| July 23rd, 2024
|
[Important Summer Release Information Included - CIBMTR Data Operations Updates for the Week of 7/22/24 (264)](https://cibmtr.cmail20.com/t/d-e-edkjlit-dilyiudkkj-r/)
|
- July 2024 Quarterly Release - Important Information!
- New CIBMTR Forms Instruction Manual Update Process & Release Updates
- International Recipient CPI Notifications
- Input Requested: Advanced Data Manager Training
|
| July 17th, 2024
|
[Register for Upcoming Initial Review Committee (IRC) Meetings](https://cibmtr.cmail19.com/t/d-e-eddjtjk-dtutntdui-r/)
|
- Register for Upcoming Initial Review Committee (IRC) Meetings - Transplant Essential Data Forms
|
| July 16, 2024
|
[Data Operations Updates for the Week of 7/15/24 (262)](https://cibmtr.cmail19.com/t/d-e-edihux-dtutntdui-r/)
|
- July 2024 Quarterly Release - Important Information
- CIBMTR User Access Verification Update
- Input Requested: Advanced Data Manager Training
|
| July 9th, 2024
|
[Data Operations Updates for the Week of 7/8/24 (261)](https://cibmtr.cmail19.com/t/d-e-edjjldd-dtkyujkkir-r/)
|
- Semi-Annual User Access Verification for CIBMTR Applications
- Input Requested: Advanced Data Manager Training
- Save the Dates! Upcoming Quarterly Release Informational Webinars
|
| July 2nd, 2024
|
[Data Operations Updates for the Week of 7/1/24 (260)](https://cibmtr.createsend7.com/t/d-e-edluiuk-dthjhuwlr-r/)
|
- CIBMTR Center Support Closed July 4th
- Save the Dates! Upcoming Quarterly Release Informational Webinars
- US Recipient CPI Notifications
- International Recipient CPI Notifications
|
| June 26th, 2024
|
[Center Volumes Data Report (CVDR) Notification (259)](https://cibmtr.cmail20.com/t/d-e-eikuio-dtdiniyhy-r/)
|
|
| June 25th, 2024
|
[Data Operations Updates for the Week of 6/24/24 (258)](https://cibmtr.cmail19.com/t/d-e-eikjhld-dtdjdhxyh-r/)
|
- Reminder: ISCN Functionality Available within FormsNet3
- Updates to the Training & eLearnings Tile on CIBMTR Portal
- Save the Dates! Upcoming Quarterly Release Informational Webinars
|
| June 18th, 2024
|
[Data Operations Updates for the Week of 6/17/24 (257)](https://cibmtr.cmail20.com/t/d-e-eiiwud-dtiityluji-r/)
|
- Orca Products Reporting Guide
- F4100 Hypogammaglobulinemia Update
- Form Reimbursement Fee Schedule Updates
|
| June 11th, 2024
|
[Data Operations Updates for the Week of 6/10/24 (256)](https://cibmtr.cmail19.com/t/d-e-eijlitd-dttdtljduh-r/)
|
- US Recipient CPI Notifications
- International Recipint CPI Notifications
- CT Product Specific Reporting Guide Updates
|
| June 4th, 2024
|
[Data Operations Updates for the Week of 6/3/24 (255)](https://cibmtr.cmail19.com/t/d-e-eiltthl-dtjdlddutl-r/)
|
- Consent Status
- FY2023 Center Specific Audit Summary Reports Available on CIBMTR Portal
|
| May 28th, 2024
|
[Data Operations Updates for the Week of 5/27/24 (254)](https://cibmtr.cmail20.com/t/d-e-ethktiy-dtydjullf-r/)
|
- FY2023 Center Specific Audit Summary Reports Available on CIBMTR Portal
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Last Chance to Register! New Quarterly Release Preview Webinar - May 30th
- Introductory Course for New Data Managers
- Data Quality Focus in May - Best Response on Post-HCT Disease-Specific Forms: MPN F2157
|
| May 21st, 2024
|
[Data Operations Updates for the Week of 5/20/24 (253)](https://cibmtr.cmail20.com/t/d-e-etigky-dtcjukkkt-r/)
|
- CIBMTR Center Support Closed May 27th
- Final Day to Submit Feedback on CLL Forms!
- Save the Date for May 30th: New Quarterly Release Preview Webinar
- Introductory Course for New Data Managers - Registration Open!
- Data Quality Focus in May - Best Response on Post-HCT Disease-Specific Forms: MPN F2157
|
| May 14th, 2024
|
[Data Operations Updates for the Week of 5/13/24 (252)](https://cibmtr.cmail20.com/t/d-e-etyiun-dtlhgyddu-r/)
|
- Feedback Requested for CLL Forms by Tuesday, May 21, 2024
- New Report Added to the CIBMTR Portal: Critical Forms Past Due
- Save the Date for May 30th: New Quarterly Release Preview Webinar
- Data Quality Focus in May - Best Response on Post-HCT Disease-Specific Forms: MPN F2157
- Introductory Course for New Data Managers - Registration Open!
|
| May 7th, 2024
|
[Data Operations Updates for the Week of 5/6/24 (251)](https://cibmtr.cmail19.com/t/d-e-ejuktit-djuhtduruy-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
|
| April 30th, 2024
|
[Data Operations Updates for the Week of 4/29/24 (250)](https://cibmtr.cmail20.com/t/d-e-ejhxhd-djkhtrhyhj-r/)
|
- Notes from Spring (April) 2024 Release
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
|
| April 24th, 2024
|
[Important US Recipient CPI Notification (249)](https://cibmtr.createsend7.com/t/d-e-ejimjt-djhuoxlr-r/)
|
- US Recipient CPI Summary Reports Not Refreshed Today: April 24, 2024
|
| April 23rd, 2024
|
[Data Operations Updates for the Week of 4/22/24 (248)](https://cibmtr.cmail20.com/t/d-e-ejtjdld-djhhtjdldh-r/)
|
- April 2023 Quarterly Release Information
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
- Last Chance to Register! Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| April 16th, 2024
|
[Important Spring Release Information Included - Data Operations Updates for the Week of 4/15/24 (247)](https://cibmtr.cmail20.com/t/d-e-ejridx-djdukdiuht-r/)
|
- April 2024 Quarterly Release Information
- CIBMTR Forms Instruction Manual Updates
- New Cellular Therapy Reporting Guides
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
- Registration Open - Recorded New Data Manager Onboarding
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| April 9th, 2024
|
[Data Operations Updates for the Week of 4/8/24 (246)](https://cibmtr.cmail20.com/t/d-e-eykudtd-djdrddduii-r/)
|
- April 2024 Quarterly Release Information
- Form 2100 Organ Function Instructions
- Data Quality Focus in April - Best Response on Post-HCT Disease-Specific Forms: Lymphoma F2118
- CIBMTR Forms Instruction Manual Updates
- Registration Open! Recorded New Data Manager Onboarding
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| April 2nd, 2024
|
[Data Operations Updates for the Week of 4/1/24 (245)](https://cibmtr.cmail19.com/t/d-e-eydjrjd-djirkltjlk-r/)
|
- Save the Date! Upcoming Quarterly Release Informational Webinar
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
|
| March 26th, 2024
|
[Data Operations Updates for the Week of 3/25/24 (244)](https://cibmtr.cmail19.com/t/d-e-esjlul-djtjdugdt-r/)
|
- US Recipient CPI Notifications
- International Recipient CPI Notifications
- Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
|
| March 19th, 2024
|
[Data Operations Updates for the Week of 3/18/24 (243)](https://cibmtr.cmail20.com/t/d-e-evlldt-djjtutvut-r/)
|
- Registration Open! Advanced Data Manager Training - Data Back to Centers on CIBMTR Portal
- Cellular Therapy Product Training and Resources
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
|
| March 14th, 2024
|
[Feedback Requested for CIBMTR TED Forms (242)](https://cibmtr.cmail19.com/t/d-e-eftlhl-djyujyhhui-r/)
|
- Feedback Requested for TED Forms by Thursday, March 28, 2024
|
| March 12th, 2024
|
[Data Operations Updates for the Week of 3/11/24 (241)](https://cibmtr.cmail20.com/t/d-e-eayujy-djydxtijr-r/)
|
- Expanded Medicare Coverage for Allogeneic HCT for MDS
- CIBMTR Forms Instruction Manual Updates
- Cellular Therapy Product Training and Resources
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
|
| March 5th, 2024
|
[Data Operations Updates for the Week of 3/4/24 (240)](https://cibmtr.cmail20.com/t/d-e-emjrtl-djqpmli-r/)
|
- Data Quality Focus in March - Best Response on Post-HCT Disease-Specific Forms: PCD F2116
- US Recipient CPI Reminders
- International Recipient CPI Reminders
|
| February 27th, 2024
|
[Data Operations Updates for the Week of 2/26/24 (239)](https://cibmtr.cmail20.com/t/d-e-enjjit-djlhhhdtjr-r/)
|
- REGISTRATION EXTENDED! March New Data Manager Onboarding
- CIBMTR Forms Instruction Manual Updates
- 2024 Transplant Center Specific Analysis (TCSA)
|
| February 20th, 2024
|
[Data Operations Updates for the Week of 2/19/24 (238)](https://cibmtr.cmail20.com/t/d-e-elktrx-dyukurtjjy-r/)
|
- March New Data Manager Onboarding – REGISTRATION CLOSES NEXT WEEK!
- 2024 Transplant Center Specific Analysis (TCSA)
- CIBMTR Center Support – Delayed Staff Responses February 19 – 23, 2024
- Your Opinion Matters: CIBMTR.org Website
|
| February 13th, 2024
|
[Data Operations Updates for the Week of 2/12/24 (237)](https://cibmtr.cmail20.com/t/d-e-eldkhyk-dyulutlidh-r/)
|
- CIBMTR Center Support - Delayed Staff Responses February 19-23, 2024
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- 2024 Tandem Meetings - Last Chance for Virtual Registration!
- New Data Manager Onboarding - March 2024: Registration Open
- New and Improved Self-Guided Data Manager Onboarding Training
- Your Opinion Matters: CIBMTR.org Website
|
| February 6th, 2024
|
[Data Operations Updates for the Week of 2/5/24 (236)](https://cibmtr.cmail19.com/t/d-e-eltlhty-dykylyjuud-r/)
|
- New Data Manager Onboarding - March 2024: Registration Now Open!
- New and Improved Self-Guided Data Manager Onboarding Training
- Your Opinion Matters: CIBMTR.org Website
- Register for the 2024 Tandem Meetings!
|
| January 30th, 2024
|
[Data Operations Updates for the Week of 1/29/24 (235)](https://cibmtr.cmail19.com/t/d-e-elrclt-dyhyuliyky-r/)
|
- January 2024 Quarterly Release Now Live
- New Data Manager Onboarding - March 2024: Registration Now Open!
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Register for the 2024 Tandem Meetings!
|
| January 25th, 2024
|
[Important Recipient CPI Correction (234)](https://cibmtr.cmail20.com/t/d-e-vuuiddd-dyddojlhd-r/)
|
- US Recipient CPI - Correction
- International Recipient CPI - Correction
|
| January 23rd, 2024
|
[Important Winter Release Information Included - CIBMTR Data Operations Updates for the Week of 1/22/24 (233)](https://cibmtr.cmail19.com/t/d-e-vuktjdd-dydjjhdio-r/)
|
- January 2024 Quarterly Release Information
- 2024 Transplant Center Specific Analysis (TCSA)
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- New Data Manager Onboarding Coming Soon!
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Register for the 2024 Tandem Meetings!
|
| January 16th, 2024
|
[Data Operations Updates for the Week of 1/15/24 (232)](https://cibmtr.cmail19.com/t/d-e-vuikyn-dyiyhiulp-r/)
|
- January 2024 Quarterly Release Information
- New Data Manager Onboarding Coming Soon!
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Register for the 2024 Tandem Meetings!
|
| January 9th, 2024
|
[Data Operations Updates for the Week of 1/8/24 (231)](https://cibmtr.cmail19.com/t/d-e-vujjdid-dytthkjjdl-r/)
|
- CIBMTR Center Support Closed Monday, January 15th
- US Recipient CPI Reminders
- International Recipient CPI Reminders
- Data Quality Focus in January - Best Response on Post-HCT Disease-Specific Forms: ALL F2111
- Save the Date: FormsNet3 ISCN Functionality Training on January 16th!
- Last Chance to Register! Introductory Course for New Data Managers on January 10th
- Register for the 2024 Tandem Meetings!
|
| January 2nd, 2024
|
[Data Operations Updates for the Week of 1/1/24 (230)](https://cibmtr.cmail19.com/t/d-e-vurgik-dyjhdyidir-r/)
|
- Save the Date: FormsNet3 ISCN Functionality Training on January 16th!
- CIBMTR Forms Instruction Manual Updates
- Introductory Course for New Data Managers
- Register for the 2024 Tandem Meetings!
- Recorded New Data Manager Onboarding
|