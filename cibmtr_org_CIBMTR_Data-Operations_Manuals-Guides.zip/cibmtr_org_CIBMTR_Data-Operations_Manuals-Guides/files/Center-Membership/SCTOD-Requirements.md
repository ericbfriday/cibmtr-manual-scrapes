The Stem Cell Therapeutic and Research Act of 2005 requires US transplant centers to submit outcomes data on all allogeneic transplants, both related and unrelated, when either the donor or the recipient resides in the United States (US), or if the collection or infusion takes place in a US center. The contract to manage this outcomes database, named the Stem Cell Therapeutic Outcomes Database (SCTOD), was awarded to CIBMTR in 2006.

SCTOD reporting requirements vary depending on a center’s location, the origin of the transplanted graft, and the type of transplant performed: Recipient data are considered part of the SCTOD if they meet one of the following criteria:

Recipient data are not considered part of the SCTOD if they meet one of the following criteria:

Two important initiatives undertaken by CIBMTR to help transplant centers meet SCTOD data collection and submission requirements include: