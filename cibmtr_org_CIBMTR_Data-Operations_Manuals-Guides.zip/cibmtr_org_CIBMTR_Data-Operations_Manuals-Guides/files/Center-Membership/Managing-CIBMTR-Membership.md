Membership in the CIBMTR offers many advantages to centers, most notably the opportunity to join a large network of physicians and clinical research professionals around the world who share the goal of advancing the science of cellular therapies.


TED-only centers receive all CIBMTR general mailings, including our newsletter and summary slides, and they pay member rates for attending the CIBMTR’s annual meeting.

CRF centers receive all the benefits of TED-only centers; in addition, center members may chair CIBMTR Working Committees, may be members of the Executive Committee, and have voting privileges.

Data submission requirements vary depending on your center’s level of participation. Detailed requirements are explained in the CIBMTR Data Management Guide: Center Participation.

Click here to take the next step!

For more information about new center membership and becoming part of the CIBMTR community, please visit New Center Resources.

If you wish to reactivate your CIBMTR center membership, please complete the CIBMTR Center Reactivation Questionnaire. Completing the questionnaire will start the reactivation process. If you have questions, email: cibmtr-centermaintenance@nmdp.org.

If you wish to:

Please complete the Center Withdrawal or Closure Questionnaire. A ticket will be created for you in CIBMTR Center Support. If you have questions prior to completing the questionnaire, please submit a ticket via CIBMTR Center Support under CIBMTR Center Maintenance > Center Closure/Withdrawal from Participation.