### Data Management Guide

The Data Management Guide contains information on center participation and data submission to CIBMTR and serves as a resource for individuals seeking guidance about forms due, data quality, and the functions of CIBMTR research data processing.

[View Data Management Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/getting-started)