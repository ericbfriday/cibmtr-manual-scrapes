#### Questions 3-35: Hematologic Findings

These questions are intended to determine the hematological status of the recipient after the HCT. There are three sections to collect hematologic results at day +7, +14, and +21 post-HCT. Testing may be performed multiple times within the reporting period; however, report the laboratory values within +/-3 days of day +7, +14 and +21 post-HCT.

Report the laboratory value and unit (if applicable) for each hematologic finding. If a value is not known, select “unknown” and continue with the next laboratory value.

For platelets, check the box if platelets were transfused within seven days prior to the testing.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)