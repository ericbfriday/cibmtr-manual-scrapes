#### Question 21: What was the disease status?

Indicate the disease status of JMML as of the last evaluation during the reporting period.

**See JMML Response Criteria for disease status definitions.**

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 22: Date assessed

Enter the date of the most recent assessment establishing disease status within the reporting period. The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and/or laboratory evaluations, the date the imaging took place for radiographic assessments, or the date of physical examination.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)