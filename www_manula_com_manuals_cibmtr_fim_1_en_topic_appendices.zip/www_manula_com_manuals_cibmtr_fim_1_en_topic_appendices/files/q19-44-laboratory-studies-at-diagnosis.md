#### Question 2: Was a bone marrow examination performed? (at diagnosis)

Indicate **Yes** or **No** if a bone marrow examination was performed at diagnosis or prior to the first treatment of aplastic anemia. If a bone marrow examination was not performed or it is not known if one was performed, select **No** and continue with question 8.

#### Questions 3 – 4: Specify cellularity in bone marrow

Cellularity describes the percentage of bone marrow occupied by hematopoietic cells compared to other tissues, such as adipose (fat) cells. In aplastic anemia, the percentage of hematopoietic cells is likely decreased (hypocellular). The distinction between decreased and normal cellularity is made on the pathology report of the bone marrow examination.

Indicate whether the bone marrow examination revealed **Decreased** (hypocellular) or **Normal** (normocellular) cellularity at diagnosis or prior to the first treatment. If **Decreased**, specify the decreased overall cellularity percent in question 4.

#### Questions 5 – 6: Blasts in bone marrow

Indicate whether the percentage of blasts in the bone marrow was **Known** or **Unknown** at diagnosis. If **Known**, report the blast percentage documented on the laboratory report in question 6.

#### Question 7: Is a copy of the bone marrow biopsy report attached?

Indicate if a copy of the diagnostic bone marrow biopsy is attached to the form. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Questions 8 – 10: Telomere length (TL)

Telomeres are protective caps found at the end of chromosomes and shorten with each cell division. Abnormal telomere shortening has been reported in acquired hematologic disorders. The telomere length (TL) of the lymphocytes or granulocytes may be measured and testing is performed on either the bone marrow or peripheral blood. This assessment may be completed by an outside lab.

Indicate if the TL is **Known** or **Unknown** at diagnosis. If **Known**, specify the TL percentile and specify whether the TL was measured in **Lymphocytes** or **Granulocytes**.

If the TL was measured in both the **Lymphocytes** and **Granulocytes**, report the value of the lowest percentile.

When the telomere length value is noted in codes, report the percentile. For example, if the telomere length codes are (VL (<1%), L (>1% <10%) N (>10% and <90%) H (>90 % and <99%)), report VL <1%, L >1%, N >10%, and H >90%.

#### Question 11: Was screening for inherited bone marrow failure performed? (at any time prior to infusion)

Screening for inherited bone marrow failure may be performed to confirm the diagnosis of aplastic anemia. Screening may be performed for Diamond-Blackfan anemia, Dyskeratosis congenita, Fanconi anemia, and/or Shwachman-Diamond.

Report **Yes** if screening for Fanconi anemia, Dyskeratosis congenita, Diamond-Blackfan anemia, Shwachman-Diamond, and/or Kostmann agranulocytosis (congenital neutropenia) was performed at any time prior to start of the preparative regimen / infusion.

If screening for Fanconi anemia, Dyskeratosis congenita, Diamond-Blackfan anemia, Shwachman-Diamond, and/or Kostmann agranulocytosis (congenital neutropenia) was not done or is not known, report **No** or **Unknown**, respectively and continue with question 25.

#### Question 12: Specify inherited bone marrow failure screening performed (check all that apply)

Specify which inherited bone marrow failure screening was performed, select all that apply.

**Diamond-Blackfan anemia:** A hematologic disease in which the body does not create enough red blood cells. There are associated birth abnormalities and diagnosis is usually made early in life. If Diamond-Blackfan anemia is selected, continue with question 13.

**Dyskeratosis congenita:** A rare genetic form of bone marrow failure, characterized by nail dystrophy, changes in skin pigmentation, oral leukoplakia (lacy white patches inside the mouth). Recipients with this condition may develop aplastic anemia, MDS, and/or AML. If Dyskeratosis congenita is selected, continue with question 15.

**Fanconi anemia:** A rare inherited disorder. Recipients with this condition may have organ defects, physical abnormalities, impaired bone marrow function, and an increased risk of developing MDS and/or AML. If Fanconi anemia is selected, continue with question 17.

**Shwachman-Diamond:** A rare genetic disorder characterized by malabsorption due to pancreatic insufficiency, skeletal abnormalities, enlarged liver, and decreased bone marrow function. Recipients with this disorder are prone to bacterial infections due to neutropenia. If Shwachman-Diamond is selected, continue with question 21.

#### Questions 13 – 14: Was RPL5 gene testing performed?

RPL5 is a gene which may be mutated in recipients with Diamond-Blackfan anemia. A mutation in this gene results in anemia by causing a shortage of ribosomal function which increases apoptosis of hematopoietic cells.

Indicate if RPL5 genetic testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify the results as either **Positive** or **Negative**.

If RPL5 genetic testing was not performed or is not known if genetic testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion, report **No** or **Unknown**, respectively.

#### Questions 15 – 16: Was TERC / TERT gene testing performed?

Telomerase RNA component (TERC) and telomerase reverse transcriptase (TERT) are genes that may be mutated in recipients with dyskeratosis congenita. Mutations in these genes result in breakage and instability of chromosomes allowing cells to divide uncontrollably which results in the development of cancer in some recipients with dyskeratosis congenita.

Indicate if TERC / TERT genetic testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify the results as either **Positive** or **Negative**.

If TERC / TERT genetic testing was not performed or is not known if genetic testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion, report **No** or **Unknown**, respectively.

#### Questions 17 – 18: Was diepoxybutane (DEB) testing performed?

Diepoxybutane (DEB) is a study that measure the sensitivity of a recipient’s cells to cross-linking agents (i.e., chromosome breakage studies). This test can be performed by the hospital’s lab or sent to an outside facility.

Indicate if DEB testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify the results as either **Positive** or **Negative**.

If DEB testing was not performed or is not known if testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion, select **No** or **Unknown**, respectively.

#### Questions 19 – 20: Was mitomycin C (MMC) testing performed?

Similar to DEB, mitomycin C (MMC) is a study that measures the sensitivity of a recipient’s cells to cross-linking agents. This test can be performed by the hospital’s lab or sent to an outside facility.

Indicate if MMC testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify the results as either **Positive** or **Negative**.

If MMC testing was not performed or is not known if testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion, select **No** or **Unknown**, respectively.

#### Questions 21 – 22: Was biallelic Shwachman-Bodian-Diamond syndrome (SBDS) gene testing performed?

Shwachman-Bodian-Diamond syndrome (SBDS) is a gene which may be mutated in recipients with Shwachman-Diamond syndrome. This mutation causes a shortage of the SBDS protein, reducing the production of other proteins and alters developmental processes.

Indicate if SBDS genetic testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion. If Yes, specify the results as either **Positive** or **Negative**.

If SBDS genetic testing was not performed or is not known if genetic testing was performed on the screening for bone marrow failure at any time prior to the start of the preparative regimen / infusion, report **No** or **Unknown**, respectively.

#### Questions 23 – 24: Is there a family history of inherited bone marrow failure? (at any time prior to infusion)

Indicate if there is a diagnosis of an inherited bone marrow failure (see options below) in the recipient’s family at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify the inherited bone marrow failure syndrome – select all that apply.

- Diamond-Blackfan anemia
- Dyskeratosis congenita
- Fanconi anemia
- Shwachman-Diamond

If there is not a family history of the listed inherited bone marrow failure conditions or it is not known if there is a family history, report **No** or **Unknown** and continue with question 25.

#### Questions 25 – 27 Is there a family history of Aplastic Anemia? (at any time prior to infusion)

Indicate if there is a diagnosis of aplastic anemia in the recipient’s family at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify the relationship in question 26. If the family member is not an option listed, select **Other biological relative** and specify the relationship in question 27.

If there is not a family history or it is not known if there is family history of aplastic anemia, report **No** or **Unknown** and continue with question 28.

#### Questions 28 – 29: Did exposure to an environmental agent (drug or toxin) occur that was suspected to be associated with the diagnosis of aplastic anemia? (at any time prior to diagnosis)

Aplastic anemia has been linked to environmental agents, certain medications, and chemicals. It is thought these agents trigger an autoimmune response and erroneously destroy hematopoietic cells. Exposure to an environmental agent (drug or toxin) is based on the physician’s strong suspicion and would be documented within the progress notes.

Indicate if the recipient was exposed to an environmental agent, suspected to be associated with the diagnosis of aplastic anemia. If **Yes**, specify the environmental agent.

If there is not a strong suspicion (based on the physician’s opinion) the recipient was not exposed to an environmental agent, suspected to be associated with the diagnosis of aplastic anemia, report **No**.

The **Unknown** option should be used sparingly and only when there is limited documentation and it cannot be determined if there was or was not an exposure to an environmental agent, suspected to be associated with the diagnosis of aplastic anemia.

#### Question 30: Was the recipient pregnant? (Female only) (at diagnosis)

Indicate if the recipient was pregnant at the time of diagnosis of aplastic anemia.

This question is only enabled for biologically female recipients.

#### Question 31: Was testing for paroxysmal nocturnal hemoglobinuria (PNH) performed? (at diagnosis)

Paroxysmal nocturnal hemoglobinuria (PNH) is a disease in which the red blood cells break down too quickly. The disease is characterized by anemia, red urine, and thrombosis.

Indicate if the recipient had testing for PNH at the time of diagnosis of aplastic anemia. If **Yes**, specify the results in questions 32 – 33. If PNH testing was not done or it is not known if testing was performed at the diagnosis of aplastic anemia, report **No** or **Unknown** and continued with question 34.

#### Questions 32 – 33: Specify test and results

Flow cytometry for CD55 / CD16 / CD59 and PIGA GPI anchor protein defect are assessments that can detect the PNH clone. Flow cytometry is a technique that counts and differentiates cell surface markers. CD55, CD16, and CD59 surface markers are associated with PNH.

PIGA GPI anchor protein defects are associated with PNH. PIGA is an enzyme that is required to synthesize the GPI anchor. The GPI anchor allows proteins (such CD55, CD16, and CD59) to become attached to the surface of the cell. Defects in the PIGA enzyme, and subsequently the GPI anchor, prevent these surface marker proteins from becoming attached. Due to the lack of these proteins on the surface of red blood cells, the immune system may not recognize the cells causing them to be destroyed.

If PNH testing was performed by *flow cytometry panel for CD55 / CD16 / CD59* at the time of diagnosis of aplastic anemia, report the results as either **Positive** or **Negative** in question 32. If this assessment was not performed or it is not known if completed, report **Not done**.

If PNH testing was performed for the *PIGA GPI anchor protein defect* at the time of diagnosis of aplastic anemia, report the results as either **Positive** or **Negative** in question 33. If this assessment was not performed or it is not known if it was performed, report **Not done**.

The results of these assessments should not be interpreted; simply report the results as either **Positive** or **Negative** as listed on the report.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)