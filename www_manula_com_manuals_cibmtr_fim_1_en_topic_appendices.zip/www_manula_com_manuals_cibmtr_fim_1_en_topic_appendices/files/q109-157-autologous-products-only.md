#### Question 92: Date of this product infusion:

Report the date this product was infused. If the product was infused over multiple days, report the first date of infusion.

#### Question 93: Was the entire volume of received product infused?

Indicate **Yes** if the entire volume of the product received was infused. Indicate **No** if only a portion of the product received was infused.

See the infusion reporting examples below for further clarification.

Infusion Reporting Examples:

**A.**A PBSC product is collected and arrives at the transplant center in four bags. Two of the bags are infused fresh, and the remaining two bags are cryopreserved for future use. Since a portion of the product that was received was not infused, “no” should be reported for*Was the entire volume of the received product infused?*.**B.**A bone marrow product is collected and arrives at the transplant center in two bags and both bags of the fresh product are infused. As the entire volume of the received product was infused, “yes” should be reported for*Was the entire volume of the received product infused?*

#### Questions 94-95: Specify what happened to the reserved portion

Report if the product was **Discarded**, **Cryopreserved for future use**, or **Other fate**. If Other fate is selected, also report the outcome of this product.

#### Question 96: Time product infusion initiated (24-hour clock)

Report the start time of the infusion. If multiple bags were infused, report the start time of the infusion of the first bag. Show the time using a 24-hour clock and indicate if daylight savings time or standard time was in effect. If the location of your institution does not observe daylight savings time, report the time as standard time. For more information about daylight savings time schedules, go to [http://www.timeanddate.com/time/dst/](http://www.timeanddate.com/time/dst/).

If **multiple products** were infused, enter the initiation time of **the product for which this form is being completed**.

#### Question 97: Date infusion stopped

Report the date the infusion was completed. If multiple bags of the same product were infused, report the stop date of the last bag.

If **multiple products** were infused, enter the stop date of **the product for which this form is being completed**.

#### Question 98: Time product infusion completed (24-hour clock)

If multiple bags of the same product were infused, report the completion time of the last bag.

If **multiple products** were infused, enter the completion time of **the product for which this form is being completed**.

Enter the completion time of the infused product using a 24-hour clock and indicate if daylight savings time or standard time was in effect. If the location of your institution does not observe daylight savings time, report the time as standard time. For more information about daylight savings time schedules, go to [http://www.timeanddate.com/time/dst/](http://www.timeanddate.com/time/dst/).

#### Questions 99-100: Specify the route of product infusion

Report the route by which the product was infused.


**Intravenous**: Refers to infusion into the veins; examples include infusion via central line or via catheter (DL catheter, central venous catheter).**Intramedullary (Intraosseous)**: Refers to infusion into the marrow cavity within a bone, such as directly into the left or right iliac crest.

If the route of infusion is not one of the above options (including intraperitoneal), select **Other route of infusion** and specify the infusion route.

#### Question 101: Were there any adverse events or incidents associated with the stem cell infusion?

Indicate whether any adverse events or incidents occurred as a result of the stem cell infusion using a cord blood product. **Report all adverse events regardless of the grade or severity**.

If an adverse event occurred, select **Yes**. If an adverse event did not occur, select **No**.

A serious adverse event is defined as an event which:


- led to death,
- was considered life-threatening,
- required prolongation of hospitalization,
- led to persistent or significant disability/incapacity,
- or led to a congenital anomaly/birth defect.

If any of the above happened, an Adverse Event Form (Form 3001) must also be completed. **Important medical events that may not result in death, be life-threatening, or require hospitalization may be considered serious when, based upon appropriate medical judgment, they may jeopardize the patient and may require medical or surgical intervention to prevent one of the outcomes listed in this definition.** Please review Adverse Event reporting in the [Data Management Guide](http://www.cibmtr.org/DataManagement/TrainingReference/Pages/AdverseEvents.aspx).

#### Questions 102-141: Specify the following adverse event(s)

Indicate **Yes** or **No** for each adverse event listed. Do not leave any responses blank. If the recipient experienced an expected (in the physician’s opinion) adverse event that was not listed, select **Yes** for *Other expected adverse event* and specify. If the recipient experienced an unexpected adverse event (i.e., not one of the options listed above, or an “other expected AE”), select **Yes** for *Other unexpected adverse event* and specify the unexpected adverse event.

For each adverse event that occurred, indicate if the medical director believes the adverse event(s) to be directly related to the infusion of the product.

Flushing / facial flushing and cough should **not** be reported as an adverse event; however, abdominal pain may be reported (expected or unexpected).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)