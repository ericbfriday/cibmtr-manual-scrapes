[January 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#jan2019)

[February 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#feb2019)

[March 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#mar2019)

[April 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#apr2019)

[May 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#may2019)

[June 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#june2019)

[July 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#july2019)

[August 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#aug2019)

[October 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#oct2019)

[December 2019](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-manual-updates#dec2019)

Updates made during the current calendar year are included below. For updates prior to 2019, click on the subtopic corresponding to the year of interest. If you need to reference an archived manual section for a retired form, please refer to the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

**December 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 12/16/2019 |
|

**October 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/31/2019 |
|

[2804: CIBMTR Research ID Assignment Form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2804-cibmtr-research-id-assignment-form)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Relapse from CR***Requires one or more of the following:**Reappearance of serum or urine M-protein by immunofixation or electrophoresis; and/or**Development of ≥ 5% plasma cells in the bone marrow; and/or**Appearance of any other sign of progression (e.g., new plasmacytoma, lytic bone lesion, hypercalcemia).*

~~Positive immunofixation alone in a patient previously classified as achieving a complete response should~~**not**be considered a relapse.

**August 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 8/29/2019 | “
|

**Question 17-45: Reporting total number of cells**Report the total number of cells (not cells per kilogram) contained in the product administered

[4000: Cellular Therapy and HCT History](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000q14-28)[4000: Cellular Therapy and HCT History](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000q14-28)[2820: Recipient Contact Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2820)**July 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/3/19 |
|


A HLA-haploidentical donor is one who shares, by common inheritance, exactly one HLA haplotype with the recipient and is mismatched for a variable number of HLA genes, ranging from~~zero~~ one to five, on the unshared haplotype. Potential HLA-haploidentical donors include biological parents; biological children; full or half siblings; and even extended family donors such as aunts, uncles, nieces, nephews, cousins, or grandchildren. Indicate **Haploidentical Donors**A HLA-haploidentical donor is one who shares, by common inheritance, exactly one HLA haplotype with the recipient and is mismatched for a variable number of HLA genes, ranging from

**“HLA-mismatched relative”**for question 40 if a haploidentical donor was used for the HCT.**June 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/27/19 |
|

[4003: Cellular Therapy Product](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4003)[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000)[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)Indicate the relationship and match between the recipient and the donor. Only consider HLA-A, B, C, and DRB1 when determining the donor’s match / mismatched relationship to the recipient.

**Syngeneic:***Includes:*Monozygotic (identical) twins. Occurs when a single egg is fertilized to form one zygote, which then divides into two separate embryos.*Does not include:*Other types of twins or HLA-identical siblings (see below).

**HLA-identical sibling:***Includes:*Non-monozygotic (dizygotic, fraternal, non-identical) twins. Occurs when two eggs are fertilized by two different sperm cells at the same time. This category also includes siblings who aren’t twins, but have identical HLA types. The patient and donor will be allele-level matched at HLA-A, B, C, and DRB-1.*Does not include:*Half-siblings (report as “HLA matched other relatives” if their HLA is a match, or “mismatched relative” if it does not match).

**HLA-matched other relative:***Includes:*All blood-related relatives, other than siblings, who are HLA matched (e.g., parents, aunts, uncles, children, cousins, half-siblings). The patient and donor will be allele-level matched at HLA-A, B, C, and DRB1.*Does not include:*Adoptive parents/children or stepparents/children who are HLA matched.

**HLA-mismatched relative:***Includes:*Siblings who are not HLA-identical and all other blood-related relatives who have at least one HLA mismatch (e.g., parents, aunts, uncles, children, cousins, half-siblings). This includes haploidentical donors. The patient and donor will be allele-level mismatched at one or more loci (HLA-A, B, C, or DRB1).*Does not include:*Adoptive parents/children or stepparents/children.


**May 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/14/2019 |
|

**April 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/26/19 |
|

[2814: Indication for CRID Assignment](#404)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Relapse from CR***Requires one or more of the following:**Reappearance of serum or urine M-protein by*~~immunofixation or~~electrophoresis; and/or*Development of ≥ 5% plasma cells in the bone marrow; and/or**Appearance of any other sign of progression (e.g., new plasmacytoma, lytic bone lesion, hypercalcemia).*

*Positive immunofixation alone in a patient previously classified as achieving a complete response should***not**be considered a relapse.

[Waldenstrom’s Macroglobulinemia Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/wm-response-criteria)**Progressive disease (PD)***≥ 25% increase in serum monoclonal IgM spike from lowest nadir on serum electrophoresis and/or**Progression of clinically significant findings or symptoms (for example, anemia, adenopathy, constitutional symptoms, amyloidosis, etc.) attributed to WM/LPL*

[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)*Predominantly or completely donor (≥80% donor chimerism)**Mixed chimerism (5 – 79*~~80%~~donor)*Only host cells detected (<5% donor)*

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)*The presence of one or more of the following:**Any history of coronary artery disease (one or more vessels requiring medical treatment, stent, or bypass),**Any history of myocardial infarction, or**Any history of congestive heart failure , or**LVEF ≤ 50% (or a shortening fraction (SF) of < 26% for pediatric cases) on most recent evaluation prior to the start of the preparative regimen*

Also added instruction to the blue not box describing Hepatic and Renal comorbidities to clarify what to report based on laboratory values closest to the start of the preparative regimen.

[Appendix D: How to Distinguish Infusion Types](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d)*When reporting co-infusions, the Cellular Therapy Product form (4003) and Cellular Therapy Infusion form (4006)*~~is~~ are required for all recipients. The HCT Infusion form (2006) will capture information regarding the product intended for engraftment.[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)**Partial Response**:*≥ 50% reduction in current serum monoclonal protein levels > 0.5 g/dL**≥ 50% reduction in current*~~urine light chain~~urine m-protein levels > 100 mg/day with a visible peak*≥ 50% reduction in current free light chain levels > 10mg/dL*

**Renal Response**:*≥ 50% decrease of at least 0.5 g/day (500mg/24hr) in 24-hour urine protein of > 0.5 g/day (500mg/24hr) pre-treatment and**Creatinine clearance or serum creatinine must not have worsened by ≥ 25% over baseline*

*If only serum creatinine is obtained, an estimated creatinine clearance can be calculated using the following formula:*

**Estimated Creatinine Clearance**= [(140 – Age (years)) * Weight (kg)] / [72 * Serum Creatinine (mg/dL)]

*The calculation should be multiplied by 0.85 for women.*

[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)**March 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/19/19 |
|

Continued Complete Remission (CCR) should be reported for all patients who were already in CR at the start of the preparative regimen.

**February 2019**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/27/19 |
|

*However, bisphosphonate therapy (e.g., Zometa) should not be reported as planned therapy since it is universally administered to myeloma patients. Additionally, supportive care such as Denosumab (e.g., Prolia) should not be reported as planned therapy.*[2402: Disease Classification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2402)

Report “Yes” and go to question 278 if a PET scan was performed within three months prior to the start of the preparative regimen / infusion. Combination PET / CT may also be reported, but a CT scan alone should not be captured here. Centers may report a PET scan performed during the most recent line of therapy so long as it is the most recent scan and was done within noted period. Report “No” and go to question 283 if a PET scan was not performed within this period.**Question 277: Was a PET (or combination PET / CT) scan performed? (at last evaluation prior to the start of the preparative regimen / infusion)**Report “Yes” and go to question 278 if a PET scan was performed within three months prior to the start of the preparative regimen / infusion. Combination PET / CT may also be reported, but a CT scan alone should not be captured here. Centers may report a PET scan performed during the most recent line of therapy so long as it is the most recent scan and was done within noted period. Report “No” and go to question 283 if a PET scan was not performed within this period.

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)*Any history of:**Trasient ischemic attack**Cerebrovascular accident / stroke**Subarachnoid,*~~hemoorhage: do not include~~subdural, epidural, or intraparenchymal hemorrhage

[2402: Disease Classification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2402)*Indicate the number of times the recipient has been in the disease phase reported in question 163.*[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)**T-Cell depletion**: T-cell depletion removes some or all of the T cells in an effort to minimize GVHD. Methods of T-cell depletion include antibody affinity column, antibody-coated plates, antibody-coated plates and soybean lectin, antibody + toxin, immunomagnetic beads, CD34 affinity column plus sheep red blood cell resetting, and T-cell receptor alpha / beta depletion.[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)*If infusions of additional cells (not intended to produce engraftment) were given prior to the HCT being reported (i.e., prior to clinical day 0), the cells must be reported as a product on the Pre-TED Form (Form 2400, question 51) and on a separate Cellular Therapy*~~Infusion~~ Product Form (Form ~~4006~~ 4003). If the additional cells were infused post-HCT, for any reason other than a subsequent HCT, they should be reported as a DCI on the appropriate follow-up form. Reporting the additional cells (given pre-HCT and not intended to produce engraftment) on the Form ~~4006~~ 4003 is the only mechanism the CIBMTR has in place to collect this data and ensure that the quality assurance data is reported to cord blood banks, if applicable.[2556: Myelofibrosis Pre-HCT Data](#404)and[2557: Myelofibrosis Post-HCT Data](#404)[Cellular Therapy Manuals](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cellular-therapy)*What cellular therapies to report and when:**Cellular therapy given in context of HCT (e.g. co-infusion, DLI/DCI): When a cellular therapy is given in context of a transplant, such as a co-infusion with an HCT or a DLI/DCI post-HCT, these infusions need to be reported to the CIBMTR. This includes both autologous and allogeneic products, such as cell stored prior to an allogeneic HCT used for treatment of graft failure.**Cellular therapy given with a prior HCT (e.g. CAR T-cell therapy for treatment of relapse): When a cellular therapy (e.g. CAR T-cell therapy) is given and there is a prior HCT, reporting these infusions are voluntary at this time.**Stand-alone cellular therapy (no prior HCT) (e.g. CAR T-cells): reporting these infusions are voluntary at this time*.*

**Reporting of commercial products infusions (i.e. Kymriah, Yescarta) is strongly encouraged.*

**January 2019**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/25/2019 |
|

[2900: Recipient Death](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2900)[2018: LYM Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2018)[4100: Cellular Therapy Essential Data Follow-up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100q36)*If a new malignancy is reported, please complete the Subsequent Neoplasms Form 3500 to answer questions specific to the new malignancy. The option of ‘Previously reported’ should only be used if the same new malignancy instance has already been reported on a F3500. See examples below. If there is a question regarding use of this option, please contact your CIBMTR CRC.*

Example 1. Recipient develops a new malignancy at day +68. It is reported at the time the 100-day form 4100 is completed. Question 33 should be answered as ‘yes’ and the form 3500 should be completed to report all new malignancy information.

Example 2. Recipient develops a new malignancy at day +68 and had received a commercial CAR-T product. Per protocol, the new malignancy should be reported at the time of knowledge of the new malignancy. The form 3500 should be created as an unscheduled form in FormsNet3 and completed in a timely manner. No other new malignancy develops during the 100-day reporting period. When the 100-day form 4100 is completed, question 33 should be answered as ‘previously reported’.

Example 3. Recipient develops a new malignancy at day +68 and had received a commercial CAR-T product. Per protocol, the new malignancy should be reported at the time of knowledge of the new malignancy. The form 3500 should be created as an unscheduled form in FormsNet3 and completed in a timely manner. Another new malignancy develops at day +100. It is decided to report the 2nd new malignancy on the 100-day form 4100 since it is due. Question 33 should be answered as ‘yes’ to create another form 3500.Example 1. Recipient develops a new malignancy at day +68. It is reported at the time the 100-day form 4100 is completed. Question 33 should be answered as ‘yes’ and the form 3500 should be completed to report all new malignancy information.

Example 2. Recipient develops a new malignancy at day +68 and had received a commercial CAR-T product. Per protocol, the new malignancy should be reported at the time of knowledge of the new malignancy. The form 3500 should be created as an unscheduled form in FormsNet3 and completed in a timely manner. No other new malignancy develops during the 100-day reporting period. When the 100-day form 4100 is completed, question 33 should be answered as ‘previously reported’.

Example 3. Recipient develops a new malignancy at day +68 and had received a commercial CAR-T product. Per protocol, the new malignancy should be reported at the time of knowledge of the new malignancy. The form 3500 should be created as an unscheduled form in FormsNet3 and completed in a timely manner. Another new malignancy develops at day +100. It is decided to report the 2nd new malignancy on the 100-day form 4100 since it is due. Question 33 should be answered as ‘yes’ to create another form 3500.

[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100q79-174)*Report the date (YYYY-MM-DD) in question 126 when the hypogammaglobulinemia was documented by either a physician/health care provider or determined by lab results. If the hypogammaglobulinemia continues from a prior reporting period, report the original diagnosis date as the onset date and override the error.*

Example 1. The recipient developed hypogammaglobulinemia at day +22 which was reported on the 4100 day 100 form. The lab results continue to show IgG levels < 600 mg/dl during the 6 month reporting period. Report the original diagnosis date on the 4100 6 month form and override the error.Example 1. The recipient developed hypogammaglobulinemia at day +22 which was reported on the 4100 day 100 form. The lab results continue to show IgG levels < 600 mg/dl during the 6 month reporting period. Report the original diagnosis date on the 4100 6 month form and override the error.

[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000q250-252)~~These questions are for malignant disease indications or relapsed, persistent, or progressive disease only.~~
Last modified:
Dec 22, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)