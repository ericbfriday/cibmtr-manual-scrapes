#### Question 35: Was therapy given since the date of last report for reasons other than relapse or persistent disease?

Indicate if the recipient received treatment post-infusion for reasons other than relapse or persistent disease during the current reporting period. Recipients generally receive a HCT / cellular therapy under a specific protocol which defines radiation and / or systemic therapy to be given prior to infusion; prophylactic medications to be administered pre- and / or post-infusion; as well as any systemic therapy, radiation, and / or other treatments to be administered post-infusion as planned (or maintenance) therapy. Planned (maintenance) therapy is given to assist in prolonging a remission. Planned therapy may be described in a research protocol or standard of care protocol. Refer to these documents (if available) when completing this section. If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR, report the therapy in questions 35-47. *Do not include any treatment administered as a result of relapse or persistent disease (including treatment for minimal residual disease).*

If therapy was given for reasons other than relapse or persistent disease during the reporting period, report “Yes” and go to question 36. If “No” or “Unknown,” go to question 48.

#### Question 36-38: Central nervous system irradiation

Radiation therapy includes high-energy x-rays, gamma rays, electron beams, or proton beams to kill cancer cells. Radiation therapy may be used to kill cells that have invaded other tissues and lymph nodes. If the recipient received radiation targeting part or all of the central nervous system (CNS), excluding total body irradiation, during the reporting period for reasons other than relapse or persistent disease, report “Yes” and report all CNS sites to which radiation therapy was administered since the date of the last report. If no radiation therapy was administered to the CNS, report “No” for question 36 and go to question 39.

#### Question 39: Intrathecal Therapy

Report “Yes” if the recipient received intrathecal therapy given for reasons other than minimal residual disease, persistent disease, or relapse during the reporting period. Otherwise, report “No.”

#### Question 40: Systemic therapy

Systemic therapy includes chemotherapy, immunotherapy, or targeted therapies delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein or given orally. Do not report total body irradiation or subsequent HCT / cellular therapies in questions 40-44. If the recipient received systemic therapy during the reporting period for reasons other than relapse or persistent disease, report “Yes” and go to question 41. If not, report “No” and go to question 45.

#### Question 41-42: Date therapy (maintenance) was first started post-HCT / post- infusion

If the recipient started systemic therapy for reasons other than relapse or persistent disease during the reporting period, report “Known” for question 41 and indicate the date started in question 42. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms.](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms)

If the recipient started therapy for reasons other than relapse or persistent disease in a prior reporting period and continued the therapy into the current reporting period, report “Previously reported” and go to question 43.

For recipients who start and stop therapy multiple times post-infusion, first determine whether the recipient stopped therapy for at least 30 days. If not, consider the therapy continuous. Only report a new therapy start date if all three of the below conditions are met.

- The recipient stopped all therapy given for reasons other than relapse or persistent disease during a prior reporting period; and
- The recipient restarted therapy for reasons other than relapse or persistent disease during the current reporting period; and
- Therapy was restarted at least 30 days after the therapy stop date.

#### Question 43-44: Specify systemic therapy given

Select all systemic therapy (see question 40 for definition) given for reasons other than relapse or persistent disease during the reporting period. If a therapy is given, but not listed as an option in question 43, select “Other systemic therapy” and specify the drug in question 44.

#### Question 45: Cellular therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells). Do not report a HCT as a cellular therapy in question 45.

Report “Yes” if the recipient received cellular therapy for reasons other than relapse or persistent disease during the reporting period. If not, report “No.”

#### Question 46-47 Other therapy

Indicate if the recipient received any other therapy (not already reported in questions 42-48) given for reasons other than relapse or persistent disease during the reporting period. Do not report HCT in questions 46-47. If “Yes,” specify all other therapies given in question 47. If “No,” go to question 48.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)