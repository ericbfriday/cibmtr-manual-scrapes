This question corresponds to the serum ferritin value reported in the Additional Iron Overload Assessments section of the Thalassemia Post-Infusion (2158) Form.

#### Question 16: Date of serum iron ferritin

Indicate the date (YYYY-MM-DD) of serum ferritin as reported in the Additional Iron Overload Assessments section of the Thalassemia Post-Infusion (2158) Form. If the serum ferritin was assessed multiple times in the current reporting period, report the most recent date.

If the exact date is not known report an estimated date and check the **Date Estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)