CIBMTR collects comorbidities data based on criteria from the Hematopoietic Cell Transplantation-Comorbidity Index (HCT-CI), which was developed and validated by investigators at the Fred Hutchinson Cancer Research Center in Seattle, Washington. The HCT-CI was developed to identify comorbidities relevant to transplant and act as a tool for risk assessment before allogeneic hematopoietic stem cell transplantation. While the criteria were originally developed for use in the adult, allogeneic population, there is utility in collecting these data for all transplant populations, and used in conjunction with other relevant risk factors, these data are useful in determining risk for transplant for the purposes of predicting expected outcomes.

#### What to Report

Report a comorbidity in all the following areas if any of the specified criteria are met.

| Comorbidity | Adult Definition and/or criteria | Pediatric Definition and/or criteria | Where to look within the EMR¹ |
|---|---|---|---|
| Arrhythmia | Any history of (but not limited to) one or more of the following which required antiarrhythmic treatment:
|
Same as Adult |
|
| Cardiac (Cardiovascular disease) | The presence of one or more of the following:
|
Same as Adult |
|
| Cerebrovascular disease | Any history of one or more of the following:
|
Same as Adult |
|
| Diabetes | Current (within 4 weeks prior to HCT / CT) history of diabetes or steroid-induced hyperglycemia requiring insulin or oral hypoglycemics, not controlled by diet alone. | Same as Adult |
|
| Heart valve disease | The presence of one or more of the following, found on the most recent heart evaluation by an echocardiogram:
|
Same as Adult |
|
| Hepatic, mild | Any one or more of the following:
|
Same as Adult |
|
| Hepatic, moderate/severe | Any one or more of the following:
|
Same as Adult |
|
| Infection | The presence of one or more of the following requiring therapeutic antimicrobial / antifungal / antiviral treatment starting prior to the preparative regimen / lymphodepleting therapy (or prior to Day 0 if no preparative regimen / lymphodepleting therapy is being given) with a recommendation to continue treatment after Day 0:
|
The presence of one or more of the following:
|
|
| Inflammatory bowel disease | Any history of:
|
Same as Adult |
|
| Obesity | Body mass index (BMI) > 35.00 kg/m2
|
BMI-for-age ≥ 95% during the pre-infusion work-up period. If only the BMI is known, refer to the following link to determine the BMI-for-age:
|

- History and physical
- Progress notes
- Weight and / or BMI flow sheet

**Adult**- History and physical
- Progress notes
- Endoscopy results
- Radiologic scans
- Medical administration record

Do not report for recipients only receiving treatment (including counselling / therapy sessions) “as needed” or PRN

**Adult**- Medical administration record
- History and physical
- Progress notes

- Adjusted DLCO 66-80%
- FEV1 66-80%**
- Dyspnea on slight activity attributed to pulmonary disease and not anemia

**Adult**- History and physical
- Progress notes
- Pulmonary function tests

- Adjusted DLCO ≤ 65%
- FEV1 ≤ 65%**
- Dyspnea at rest attributed to pulmonary disease and not anemia
- Requires intermittent or continuous supplemental oxygen

- Adjusted DLCO ≤ 65%
- FEV1 ≤ 65%**
- Dyspnea at rest attributed to pulmonary disease and not anemia
- Requires intermediate or continuous supplemental oxygen
- History of mechanical ventilation (refer to
*Is there a history of mechanical ventilation (excluding COVID-19 (SARS-CoV-2)?*manual instructions located under the 2400 Comorbid Conditions section for further clarification)- Do not report if intubated due to premature birth for <24 hours.


- History and physical
- Progress notes
- Pulmonary function tests

- Serum creatinine > 2 mg/dL or 177 µmol/L
- On dialysis in pre-infusion evaluation period
- Prior renal transplant recipient

- Serum creatinine > 2 mg/dL or 177 µmol/L
- eGFR <60 ml>2 (by Bedside Schwartz calculation for <18 years old, CKD-EPI calculation for ≥18 years old)
- On dialysis in pre-infusion evaluation period
- Prior renal transplant recipient

- History and physical
- Progress notes
- Serum creatinine tests

- Systemic lupus erythematosus
- Rheumatoid arthritis
- Sjogren’
- Polymyositis
- Dermatomyositis
- Mixed connective tissue disease
- Polymyalgia rheumatic
- Polychondritis
- Psoriatic arthritis
- Sarcoidosis
- Vasculitis syndromes

**Adult**- Medical administration record
- History and physical
- Progress notes

If the recipient is receiving an infusion for a disease that transformed from one disease to another (i.e., MDS to AML, CLL to NHL), the original malignancy should not be reported as a comorbidity. Details regarding disease transformation will be captured on the Pre-TED Disease Classification (2402) Form. For more information regarding disease combinations and transformations, refer to the Common Disease Combinations and Common Disease Transformations tables in the Primary Disease for HCT section of the Pre-TED Disease Classification (2402) Form.

**Adult**- Medical administration record
- Past surgeries / procedures
- History and physical
- Progress notes

1 Examples of where to find source documents within the EMR; however, this will vary from institution to institution. Seek physician clarification on where to find this information, as needed.

(*) ULN refers to upper limit of normal for respective laboratory study

(**) If the PFT lists both a “control” FEV1 and “post-dilator” FEV1, the “control” FEV1 should be used to determine if a pulmonary comorbidity is present.

2 Sorror, M. L. (2013). How I assess comorbidities before hematopoietic cell transplantation. *Blood*, 121(15), 2854-2863.


Determine relevant comorbidities through careful review of the recipient medical record. Reviewed documentation should include the recipient’s past medical history and objective data from the pre-infusion work-up, including pulmonary function tests, echocardiogram, body weight, and laboratory results. The recipient medication list should be correlated with the past medical history to verify there are not any medications that do not align with the recipient’s medical history; if there were to be medications commonly used for a certain purpose not listed in the medical history, further clarify if a relevant comorbidity is present. However, if the medical record remains ambiguous, after careful review, as to whether a condition meets the criteria for reporting comorbidity, do not report.

Report all comorbidities meeting criteria at time of pre-infusion evaluation. This may include comorbidities secondary to the primary infusion disease or conditions resulting from prior therapy and persisting or meeting criteria for reporting at the time of infusion.

For instances in which the pulmonary function testing report does not correct diffusing capacity of carbon monoxide for hemoglobin, use the Dinakara equation to correct.

#### What not to report

The following conditions are not relevant transplant outcomes or risk, and should not be reported under the comorbidities section.

|
|
|

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/2024 |
|

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)**Prior Skin Malignancies**: All prior skin malignancies that have been treated should be reported as a**Prior malignancy**comorbidity; however, only melanoma will be given an HCT-CI score. If an**Other skin malignancy (basal cell, squamous)**is selected, an HCT-CI score is not given.[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)*Hepatic, mild: Any one or more of the following:**Chronic hepatitis**Any diagnosed history of Hepatitis B or Hepatitis C*

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)

- History of invasive fungal infection (refer to Is there a history of invasive fungal infection? manual instructions located under the 2400 Comorbid Conditions section for further clarification)

- Infection requiring antimicrobial treatment continued after Day 0

Do not report an infection comorbidity if the infection resolved prior to infusion and there was a recommendation to continue, or the recipient continued medication post-infusion as prophylaxis**Infection:****Pediatrics**: The presence of one or more of the following:- History of invasive fungal infection (refer to Is there a history of invasive fungal infection? manual instructions located under the 2400 Comorbid Conditions section for further clarification)

- Infection requiring antimicrobial treatment continued after Day 0

Do not report an infection comorbidity if the infection resolved prior to infusion and there was a recommendation to continue, or the recipient continued medication post-infusion as prophylaxis

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)

- Adjusted DLCO ≤ 65%

- FEV1 ≤ 65%**

- Dyspnea at rest attributed to pulmonary disease and not anemia

- Requires intermediate or continuous supplemental oxygen

- History of mechanical ventilation (refer to Is there a history of mechanical ventilation? manual instructions located under the 2400 Comorbid Conditions section for further clarification)

Do not report if intubated due to premature birth for <24 hours.**Pulmonary, severe**:**Pediatrics**: Any one or more of the following at the time of pre-infusion evaluation:- Adjusted DLCO ≤ 65%

- FEV1 ≤ 65%**

- Dyspnea at rest attributed to pulmonary disease and not anemia

- Requires intermediate or continuous supplemental oxygen

- History of mechanical ventilation (refer to Is there a history of mechanical ventilation? manual instructions located under the 2400 Comorbid Conditions section for further clarification)

Do not report if intubated due to premature birth for <24 hours.

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)