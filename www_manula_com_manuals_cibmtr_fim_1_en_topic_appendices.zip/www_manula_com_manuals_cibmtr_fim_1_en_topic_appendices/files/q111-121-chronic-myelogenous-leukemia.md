Chronic myelogenous leukemia (CML) is a slow-progressing cancer of the myeloid white blood cells. It is characterized by increased proliferation of immature white blood cells (granulocytes) with damaged DNA, or blasts, which accumulate in the blood and bone marrow. Normal blasts develop into white blood cells that fight infection. The symptoms of CML are caused by the replacement of normal bone marrow with leukemic cells, resulting in fewer red blood cells, platelets, and normal white blood cells.

#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the disease. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

#### Question 184: Was therapy given prior to this HCT?

If the recipient received therapy to treat CML prior to this HCT, check **Yes**. Do not report a prior HCT or cellular therapy as these are captured separately on the Pre-TED Form (Form 2400). If the recipient did **not** receive therapy to treat CML, check **No**.

#### Question 185 – 190: CML treatment

Indicate the therapy the recipient received to treat CML prior to this HCT. If the recipient’s treatment consisted of a combination of chemotherapeutic agents, check the **Combination chemotherapy** box **and** each drug included in the combination from the list provided. The **Other, specify** category should only be used if the drug is not one of the listed options. For example, if the recipient received a combination of interferon and cytarabine, check all of the following: **Combination chemotherapy, Interferon-α**, and **Other therapy** – specify ‘cytarabine’.

#### Question 191: What was the disease status?

Indicate the disease status of CML at the last evaluation prior to the start of the preparative regimen (or infusion if no preparative regimen was given). Refer to the CML Response Criteria section for a description of each disease response.

If the recipient is in **Complete hematologic response (CHR)** or **Chronic phase (CP)** at the start of the preparative regimen, continue with *Specify level of response*. Otherwise, go to *Number*.

#### Question 192: Specify level of response

If the recipient’s best response to therapy is **Complete hematologic remission (CHR)** or **Chronic phase (CP)**, specify the cytogenetic / molecular response. Refer to Table 8 for definitions of cytogenetic and molecular responses.

**Table 8. Definitions of Cytogenetic and Molecular Responses to Therapy**

| Response | Definition |
|---|---|
Complete molecular remission(most favorable) |
0% BCR / ABL transcripts detected in peripheral blood or bone marrow |
| Major molecular remission | > 0 – 0.1% BCR / ABL transcripts detected in peripheral blood or bone marrow |
| Complete cytogenetic response | 0% Ph+ cells detected in bone marrow |
| Partial cytogenetic response | > 0 – 35% Ph+ cells in bone marrow |
| Minor cytogenetic response | > 35 – 65% Ph+ cells in bone marrow |
| Minimal cytogenetic response | > 65 – 95% Ph+ cells in bone marrow |
No cytogenetic response (least favorable) |
> 95% Ph+ cells in bone marrow. |

Definitions taken from Hughes, T. P., Ross, D. M. & Melo, J. V. Handbook of chronic myeloid leukemia. (Adis, 2014).

The above responses are listed from most favorable (complete molecular remission) to least favorable (no cytogenetic response). Centers should report the most favorable response achieved. For example, if a recipient has achieved a major molecular remission by PCR testing as well as a complete cytogenetic response by karyotyping / FISH, the center should report “major molecular remission.”

#### Question 193: Number

Indicate the number of times the recipient has been in the disease phase reported above.

#### Question 194: Date assessed

Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)