#### Questions 312 – 313: Specify POEMS clinical features (check all that apply)

Indicate which clinical features, specific to POEMS only, are present at the time of evaluation for this reporting period. Check all that apply. If there are other clinical features not listed in this section, select **Other**, in addition to any available options that apply, and specify the other clinical feature..

#### Questions 314 – 316: Thyroid stimulating hormone (TSH)

Indicate whether the thyroid stimulating hormone (TSH) level was **Known** or **Unknown** at the last evaluation. If **Known**, report the value (in mU/L) (mU/L is equivalent to μU/mL) and the upper limit of normal. If **Unknown**, continue with question 317.

#### Questions 317 – 319: Testosterone level

Indicate whether the testosterone level was **Known** or **Unknown** at the last evaluation. If **Known**, report the value and unit of measure documented on the laboratory report and the upper limit of normal. If **Unknown**, continue with question 320.

#### Questions 320 – 322: Estradiol level

Indicate whether the estradiol level was **Known** or **Unknow*n at the last evaluation. If *Known**, report the value (in pg/mL) and upper limit of normal. If **Unknown**, continue with question 323.

#### Questions 323 – 325: Prolactin level

Indicate whether the prolactin level was **Known** or **Unknown** at the last evaluation. If **Known**, report the value (in ng/mL) and upper limit of normal. If **Unknown**, continue with question 326.

#### Questions 326 – 328: Cortisol level

Indicate whether the cortisol level was **Known** or **Unknown** at the last evaluation. If **Known**, report the value, unit of measure to the nearest tenth, and the upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 329.

#### Questions 329 – 331: Interleukin-6

Indicate whether the interleukin-6 value was **Known** or **Unknown** at the last evaluation. If **Known**, report the value (in pg/mL) to the nearest tenth and the upper limit of normal. If **Unknown**, continue with question 332.

#### Questions 332 – 333: Was pulmonary artery hypertension present?

Pulmonary hypertension (PH) refers to elevated pulmonary arterial pressure. PH can be due to primary elevation of pressure in the pulmonary arterial system alone (pulmonary arterial hypertension), or secondary to elevations of pressure in the pulmonary venous and pulmonary capillary systems (pulmonary venous hypertension; post-capillary PH). Indicate whether pulmonary artery hypertension was present at the time of evaluation for this reporting period. If present, report the estimated systolic artery pressure documented on the laboratory report. If not present, continue with question 334.

#### Questions 334 – 335: Forced vital capacity (FVC)

Forced vital capacity is the total amount of air that can be exhaled during the forced expiratory volume test. FVC is a measurement taken during spirometry studies. Indicate whether the forced vital capacity percentage was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the percentage documented on the pulmonary function test (PFT). If **Unknown**, continue with question 336.

#### Questions 336 – 337: Total lung capacity

Indicate whether the total lung capacity (volume) was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the value documented on the pulmonary function report. If **Unknown**, continue with question 338.

#### Questions 338 – 340: Vascular endothelial growth factor (VEGF) serum value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the serum-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the value and the upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 341.

#### Questions 341 – 343: Vascular endothelial growth factor (VEGF) plasma value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the plasma-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the value and the upper limit of normal, as documented on the laboratory report. If **Unknown**, submit the form..

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)