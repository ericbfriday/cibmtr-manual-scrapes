#### Question 178: Was the recipient’s bone marrow examined at any time between the diagnosis and the preparative regimen?

Indicate whether a karyotype was performed on the recipient’s bone marrow at any time between the diagnosis of Fanconi Anemia and the start of the preparative regimen. If **Yes**, continue with question 179.

If the bone marrow sample was inadequate, indicate **No evaluable metaphases**, and proceed to the *Signature Line*.

If no bone marrow karyotyping studies were obtained after diagnosis of Fanconi Anemia and prior to the start of the preparative regimen, indicate **No** and proceed to the *Signature Line*.

If it is not known whether any bone marrow karyotyping studies were performed, indicate **Unknown** and proceed to the *Signature Line*.

#### Question 179: Were any karyotype abnormalities identified?

If the results of the diagnostic bone marrow karyotyping detected abnormalities, indicate **Yes** and proceed to question 180.

If the results of the karyotype performed on the bone marrow obtained prior to the start of the preparative regimen was normal, either [46, XX] or [46, XY], select **No** and proceed to question 214.

#### Questions 180 – 213: Specify abnormalities identified

Specify all cytogenetic abnormalities detected in the bone marrow biopsy (reported in question 179). Indicate **Yes** for each cytogenetic abnormality identified after diagnosis and prior to the start of the preparative regimen. Indicate **No** for all options not identified on cytogenetic assessment. If an abnormality is detected but not listed as an option, select Yes for “other abnormality” and specify the abnormality in question 213.

If multiple “other abnormalities” were detected, report “see attachment” in question 213 and attach the final report(s) for any other abnormalities detected at diagnosis. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Questions 214 – 215: Date of karyotyping

Report the date the sample was collected for bone marrow karyotyping and indicate if documentation was submitted to the CIBMTR. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Signature Lines:

The FormsNet3SM application will automatically populate the signature data fields, including name and email address of person completing the form and date upon submission of the form.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)