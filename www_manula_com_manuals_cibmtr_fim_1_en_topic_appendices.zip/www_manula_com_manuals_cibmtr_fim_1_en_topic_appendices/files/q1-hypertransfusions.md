#### Question 1: Was the recipient hypertransfused?

Indicate if the recipient was hypertransfused. If **No**, continue with *Date of last iron chelation therapy dose given pre-infusion*.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Sep 30, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)