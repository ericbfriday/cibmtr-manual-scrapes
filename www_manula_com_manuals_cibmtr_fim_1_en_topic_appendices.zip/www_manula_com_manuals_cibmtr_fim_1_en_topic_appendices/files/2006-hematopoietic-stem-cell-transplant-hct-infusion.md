Centers must complete the Form 2006 for each product when the recipient is assigned to the **Comprehensive Report Form track**. Centers must also complete the Form 2006 for the following product types when the recipient is assigned to the **Transplant Essential Data track**:

- NMDP donor products
- NMDP and non-NMDP cord blood units
- Any product co-infused with a cord blood unit

**Additionally**, all transplant centers (TED-only and Comprehensive Report Form) **participating in the Related Sample Repository** must complete the Form 2006 for all non-NMDP donor products when a research sample is collected.

For more information see [General Instructions, Center Type and Data Collection Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/center-type-and-data-collection-forms).

The Form 2006 is designed to capture product- and infusion-specific information for all products given to a recipient as part of a Hematopoietic Stem Cell Transplant (HCT). **This includes cells given prior to the HCT for reasons other than engraftment**. In addition to use in research, this information is used for quality assurance measures, both by the NMDP and the Cord Blood Banks.

If more than one type of HCT product is infused, ** each product type** must be analyzed and reported on a

**form. For example, the scenarios below require two 2006 forms, one for each product:**

*separate*- Two different products from the same donor (i.e., PBSC and bone marrow)
- A co-infusion of two products (i.e., haplo donor PBSC and CBU)

**However**, a series of collections from the same donor that uses the same collection method and mobilization cycle, even if the collections are performed on different days, **should be considered a single product**.

For more information see [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d) and [Appendix E](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-e).

[Q1-3: Pre-Collection Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-15-donor-cord-blood-unit-identification)

[Q4-7: Product Collection](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q16-27-pre-collection-therapy)

[Q8-21: Product Transport and Receipt](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q28-42-product-collection)

[Q22-40: Product Processing/Manipulation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q43-56-product-transport-and-receipt)

[Q41-91: Product Analysis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q57-108-product-processing-manipulation)

[Q92-141: Product Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q109-157-autologous-products-only)

[Q142-168: Donor/Infant Demographic Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q158-195-product-analysis-all-products)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2006.Hematopoietic%20Stem%20Cell%20Transplant%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/2024 |
|

*Prior revisions of the HCT Product and Infusion (2006) Form (Revisions 1-4) have asked for product analysis values at multiple timepoints. In the new revision of the form, only the “At Infusion” timepoint is required for all product types.*~~, except cord blood units (CBUs).~~ For CBUs, an additional ~~both the “At Infusion” and~~ “At Arrival” timepoint-s- should be reported if the CBU was analyzed prior to the product wash. ~~are required.~~[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)*For all products, the “at infusion” timepoint must be reported. The “at infusion” timepoint should only report the values for the actual product volume infused. The*~~both a ‘product arrival’ and an ‘at infusion’ timepoint must be reported.~~ an “At Arrival” timepoint should be reported if the center performed an analysis prior to the CBU wash. An “At Infusion” timepoint must be reported and should reflect the product analysis performed post wash.**At Infusion**timepoint should include values reflective of the product infused regardless of when the analysis occurred. Since all products are analyzed prior to cryopreservation, the**At Infusion**timepoint would be applicable for these cell counts. Depending on the product type and your center’s practice, viability may be assessed closer to the time of infusion. For cord blood units,[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)**Omidubicel and Orca-T Products**If the product is Omidubicel, select**Ex vivo**expansion for the first product and**Other manipulation**for the second product – specify the manipulation as ‘Negative fraction.’ If the product is Orca-T, report the manipulation as**CD34 enriched**.[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)**Omidubicel and Orca-T Products**If the product is Omidubicel or Orca-T, select**Yes**the product was manipulated.[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)