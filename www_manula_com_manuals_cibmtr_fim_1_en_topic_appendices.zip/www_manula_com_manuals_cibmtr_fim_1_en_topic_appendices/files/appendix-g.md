Successfully tracking and reporting disease status for multiple myeloma requires a understanding of the different methods of assessment, away of organizing relevant test results, and the ability to identify the correct baseline against which changes in test results can be compared. For training on how to identify and interpret myeloma disease assessment, refer to the myeloma learning modules available on the CIBMTR website under [Online Training](https://www.cibmtr.org/DataManagement/TrainingReference/eLearning/Pages/index.aspx). For examples of ways to track disease assessments, refer to the documents included under Disease Status Tracking Examples below. Finally, for instructions on how to choose the correct baseline, refer to Determining a Baseline below.

### Disease Status Tracking Examples

[Tracking Disease Status for Multiple Myeloma – Word Document](https://cdn.manula.com/user/3235/docs/appendix-g-tracking-disease-status-for-multiple-myeloma-ver3-0-docx.docx)

[Tracking Disease Status for Multiple Myeloma – PDF](https://cdn.manula.com/user/3235/docs/appendix-g-tracking-disease-status-for-multiple-myeloma-ver3-0-pdf.pdf)

The links above go to a flowsheet to aid in the determination of disease status for patients with multiple myeloma.

### Determining a Baseline

**HCT is planned as part of initial therapy w/out prior disease progression or relapse.**

The baseline used to determine the best response to HCT is the disease parameters obtained at the time of diagnosis.

**Patients who have not received any chemotherapy within 6 months of HCT, untreated relapse/progression or if the recipient has never been treated (rare).**

The baseline used to determine the best response to HCT would be the disease parameters obtained immediately prior to the start of the preparative regimen (not the disease parameters at time of diagnosis).

**What if the patient had a disease progression or relapse of disease before HCT?**

If a patient had disease progression or relapse of disease & was treated to reduce the myeloma burden before any preparative regimen was given for HCT, the baseline used to determine the best response to HCT would be the disease parameters obtained at the time of the relapse or progression. In other words, the baseline is the reset to the time of the relapse or progression. Therefore, the disease parameters obtained at diagnosis or immediately prior to the start of the preparative regimen would not be used as the baseline to determine the best response to HCT.

**What if the patient had 2 or more disease progressions before HCT?**

The appropriate baseline to use would be the disease parameters documenting the most recent disease progression.

**What if the patient’s initial therapy was changed to a different regiment due to toxicity & there was not a disease progression or relapse at any time prior to HCT, what baseline is used to determine the best response to HCT?**

The baseline used to determine the best response to HCT is the disease parameters obtained at the time of diagnosis.

**Tandem Transplantation w/out disease progression or relapse in between.**

Since this is considered one treatment, the pre-HCT baseline for determining the best response following the second HCT would be the same baseline used prior to the first HCT (i.e. the disease parameters at diagnosis).

**Example 1:** A 62-year-old man is diagnosed with IgG Kappa multiple myeloma. He receives initial therapy with 6 cycles of bortezomib and lenalidomide/dexamethasone; and achieves a very good partial response (VGPR). The values used to determine disease status at transplant are the values obtained at diagnosis.

| Time Point | BMBX | SPEP | SIFE | UPEP | UIFE | Skeletal Survey | Treatment | Disease Status |
|---|---|---|---|---|---|---|---|---|
| 10/31/08 | 27% plasma cells | 3.3 g/dL | + | 336 mg/24 hours | + | Negative | Bortezomib/ Lenalidomide/Dexamethasone |
Diagnosis: IgG Kappa |
| 4/3/09 | 3% plasma cells | |||||||
| 4/17/09 | Negative | + | Negative | Negative | VGPR | |||
| 5/13/09 | Negative | + | Negative | Negative | VGPR (confirmatory) | |||
| 5/17/09 | Autologous HCT |

**Example 2:** A 59-year-old woman is diagnosed with IgA Lambda multiple myeloma. She receives bortezomib and thalidomide/dexamethasone as initial treatment and achieves a CR. A few months later she has evidence of relapse. She is then treated with lenalidomide/dexamethasone and achieves a PR. The patient receives high-dose cyclophosphamide as part of an autologous stem cell harvest. The values used to determine disease status at transplant would be the values obtained at the time of relapse.

| Time Point | BMBX | SPEP | SIFE | UPEP | UIFE | Skeletal Survey | Treatment | Disease Status |
|---|---|---|---|---|---|---|---|---|
| 1/27/10 | 4.5 g/dL | + | Negative | Negative | ||||
| 2/01/10 | Aspirate=18% plasma cells; biopsy= sheets of plasma cells |
Diagnosis: IgA lambda | ||||||
| 2/05/10 | Negative | Bortezomib/ Thalidomide/Dexamethasone |
||||||
| 3/05/10 | 2.6 g/dL | + | ||||||
| 4/5/10 | 1.7 g/dL | + | ||||||
| 5/5/10 | 0.5 g/dL | + | ||||||
| 6/4/10 | 0.03 g/dL | + | Negative | Negative | ||||
| 8/18/10 | 1% plasma cells | 0.01 g/dl | + | |||||
| 9/15/10 | Not detected | + | ||||||
| 10/15/10 | Not detected | Negative | CR | |||||
| 11/15/10 | Not detected | Negative | (no treatment given) | CR (confirmatory) | ||||
| 12/15/11 | Not detected | Negative | ||||||
| 1/15/11 | 1.9 g/dL | + | Negative | Negative | Relapse | |||
| 2/15/11 | 7% plasma cells | 2.2 g/dL | + | Negative | Lenalidomide/ Dexamethasone |
Relapse (confirmatory) | ||
| 3/15/11 | 1.4 g/dL | + | ||||||
| 4/15/11 | 0.9 g/dL | + | PR | |||||
| 5/15/11 | 0.7 g/dL | + | PR (confirmatory) | |||||
| 6/15/11 | 3% plasma cells | 0.5 g/dL | + | |||||
| 7/31/11 | Autologous HCT |

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for any of the appendices, please reference the retired appendix on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/19/2020 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)