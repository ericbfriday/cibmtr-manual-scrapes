#### Question 1: What was the date of diagnosis?

Wiskott-Aldrich syndrome (WAS) is characterized by multiple clinical, laboratory, and genetic features, rather than distinct pathological characteristics. Examples of testing done to confirm a diagnosis of WAS include peripheral blood sample analyses that can determine if there are fewer than 70,000 platelets/mm3 and if the platelets are abnormally small in size (low platelet volume). Lymphocyte studies, including mRNA assays and protein studies, are performed to determine gene expression and the presence or absence of functional WASp protein. In addition, genetic tests can detect WAS gene mutations. Since multiple assessments are used to diagnose a patient with WAS, the date of diagnosis should be the date of sample collection of last assessment used to establish a diagnosis of WAS. If there is a strong family history of WAS and no testing is done to confirm the diagnosis, report the recipient date of birth.

#### Question 2: Specify the WAS defining (diagnostic) criteria?

Depending on the criteria used to diagnose WAS select one of three options: Definitive, Probable, or Possible (see table below).

| Definitive | Male patient with congenital thrombocytopenia (<70,000 platelets/mm3), small platelets, and ≥1 one of the following:• mutation in WASp • absent WASp mRNA on northern blot analysis of lymphocytes • absent WASp protein in lymphocytes • maternal cousins, uncles, or nephews with small platelets and thrombocytopenia |
|---|---|
| Probable | Male patient with congenital thrombocytopenia (<70,000 platelets/mm3), small platelets, and ≥1 one of the following:• eczema • abnormal antibody response to polysaccharide antigens • Autoimmune disease(s) • lymphoma / leukemia |
| Possible | Male patient with congenital thrombocytopenia (<70,000 platelets/mm3) and small platelets |
OR |
|
| Male patient with splenectomy for thrombocytopenia* and ≥1 one of the following: • eczema • abnormal antibody response to polysaccharide antigens • Autoimmune disease(s) • lymphoma / leukemia |

*Destruction of platelets in the spleen is thought to play an important role in thrombocytopenia because corrections of platelet count and size have been reported after splenectomy.[1](#fn158929337068596bd08acae-1)

#### Questions 3-6: Specify all additional criteria for definitive WAS diagnosis

For a definitive WAS diagnosis at least one of the criteria from questions 3-6 must be true. For a probable or possible WAS diagnosis skip to question 7.

#### Question 3: Mutation in WASp?

WAS is an inherited disorder; for that reason, genetic testing may be performed as part of the diagnostic workup. If there is a known family history of WAS, or the mother is a known carrier, genetic testing may be done prior to the onset of symptoms or even prenatally using techniques like chorionic villus sampling or amniocentesis.

Indicate whether a genetic mutation was identified. Continue with question 4.

#### Question 4: Absent WASp mRNA on northern blot analysis of lymphocytes?

Northern blotting is a technique used to study gene expression by detecting mRNA. The absence of WASp mRNA reflects a lack of gene expression. Without mRNA, protein translation cannot occur.

Indicate “yes” if WASp mRNA was absent on northern blot analysis of lymphocytes. Indicate “no” if a northern blot analysis of lymphocytes was performed and detected WASp mRNA. Continue with question 5.

#### Question 5: Absent WASp protein in lymphocytes?

After RNA is transcribed from a gene’s DNA, the RNA is translated into protein. Lack of WASp protein is consistent with a definitive WAS diagnosis. WASp protein may be detected by performing tests on lymphocytes isolated from whole blood, including Western blotting and enzyme-linked immunosorbent assays (ELISA).

Indicate “yes” if WASp protein was absent from lymphocytes. Indicate “no” if WASp protein was detected in lymphocytes.

#### Question 6: Maternal cousins, uncles, or nephews with small platelets and thrombocytopenia?

X-linked patterns of inheritance are caused by genetic mutations carried on the X chromosome. Males normally carry one copy of the X chromosome and one copy of the Y chromosome. For this reason, a faulty X chromosome will affect all men who carry it. Females carry two copies of the X chromosome. This means they will be carriers for x-linked recessive traits, but will rarely be symptomatic since they will *generally* have a normal X chromosome that is expressed. (For x-linked *dominant* patterns of inheritance, only a single mutated X chromosome is necessary for symptomatic expression. Therefore, x-linked dominant patterns of inheritance affect both males and females).

WAS follows an x-linked recessive pattern of inheritance. Indicate whether the patient has maternal cousins, uncles, or nephews with small platelets and thrombocytopenia. Continue with question 11.

#### Questions 7-10: Specify all additional criteria for probable / possible WAS diagnosis

For a probable or possible WAS diagnosis at least one of the criteria from questions 7-10 must be selected.

#### Question 7: Eczema?

Eczema is a skin disorder with an immunologic basis. It is characterized by itchy, dry skin, as well as thickening of the skin (lichenification) and may be indicative of the immune dysfunction associated with WAS.

Indicate “yes” if the patient has eczema, otherwise indicate “no.” Continue with question 8.

#### Question 8: Abnormal antibody response to polysaccharide antigens?

The surface of many bacterial species is covered by polysaccharides (antigens). Immunity (antibodies) against these surface antigens confers protection against the disease. 2 Since WAS can affect the function of both T cells and B cells, the antibody response to polysaccharide antigens may be impaired. Examples of tests performed to detect antibody response include the enzyme-linked immunosorbent assay (ELISA) and quantitative PCR.

Indicate “yes” if an abnormal antibody response to polysaccharide antigens was detected. Indicate “no” if the antibody response to polysaccharide antigens was normal. Continue with question 9.

#### Question 9: Autoimmune disease(s)?

Autoimmune diseases are frequently observed in the Wiskott Aldrich syndrome. The most common manifestations are hemolytic anemia, arthritis, cutaneous vasculitis, and nephropathy. Other autoimmune manifestations include inflammatory bowel disease, idiopathic thrombocytopenic purpura (ITP), and neutropenia. Multiple autoimmune manifestations may present at the same time in patients with WAS.[1](#fn158929337068596bd08acae-1)[3](#fn158929337068596bd08acae-3)

Indicate whether the patient has an autoimmune disease(s) and continue with question 10.

#### Question 10: Lymphoma / Leukemia?

Lymphoma (often Epstein-Barr virus positive) and leukemia are the most frequently WAS-associated malignancies. Indicate if the patient had lymphoma or leukemia. Continue with question 11.

#### Question 11: Was a WAS gene mutation identified?

WAS is an inherited disorder; for that reason, genetic testing may be done to confirm the diagnosis. If there is a known family history of WAS, or the mother is a known carrier, genetic testing may be done prior to the onset of symptoms or even prenatally using techniques like chorionic villus sampling or amniocentesis. Indicate “yes” if testing revealed a mutation in the WAS gene and continue with question 12; indicate “no” if testing was done but did not reveal a WAS gene mutation and continue with question 13.

#### Question 12: Specify gene mutation identified

A gene is a linear sequence of nucleotides compromising a segment of DNA from which RNA is synthesized. Nucleotides are categorized by type of nitrogenous base: adenine (A), guanine (G), cytosine ©, uracil (U), and thymine (T). Nucleotides are given a number based on their location. After DNA has been transcribed into RNA, the RNA is translated into amino acids to form protein. Amino acids have distinct names which are abbreviated with a unique letter and are also assigned numbers based on their location.

Genetic mutations may be identified by the affected nucleotides or by predicted changes in amino acids. Indicate the type of gene mutation identified in question 11. Select either “nucleotides affected (e.g., 361C>T)” or “predicted amino acid change (e.g., W14R).”

#### Question 13: Was a WASp protein expressed?

WASp protein may be detected using tests such as Western blotting or an enzyme-linked immunosorbent assay (ELISA). Indicate whether WASp protein was expressed. Continue with question 14.

1 Bosticardo M, Marangoni F, Aiuti A, et al. Recent advances in understanding the pathophysiology of Wiskott-Aldrich syndrome. Blood, 2009;113(25):6288-96.

2 Weintraub, A. Immunology of bacterial polysaccharide antigens. Carbohydrate Research, 2003;338:2539-47.

3 Ochs HD. The Wiskott-Aldrich Syndrome. Journal of Allergy and Clinical Immunology, 2006;4:379-84.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)