Appendix C provides and overview of cytogenetics, using cytogenetics to assess donor chimerism, and using the ISCN Functionality in FormsNet3SM. Review the sections below for additional information.

Links to Sections

[Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cytogenetic-assessments)

[Chimerism and Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/chimerism-and-cytogenetics)

[ISCN Functionality](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

[Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c)[Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c)[Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c)[Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c)
Last modified:
Jan 27, 2025

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)