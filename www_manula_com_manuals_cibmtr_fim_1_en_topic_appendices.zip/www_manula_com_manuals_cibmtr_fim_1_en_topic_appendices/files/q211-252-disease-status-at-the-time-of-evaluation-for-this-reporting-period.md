For questions 211-252, report values obtained at the last evaluation for this reporting period. If testing is performed multiple times during the reporting period, report the values obtained at the last evaluation in the reporting period.

#### Questions 211 – 213: Serum creatinine

Indicate whether the serum creatinine was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the laboratory value, unit of measure, and the upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 214.

#### Questions 214 – 215: Serum monoclonal protein (M-spike) (only from electrophoresis)

Monoclonal gammopathy is defined as the increased production of abnormal immunoglobulins. The abnormal protein produced is called paraprotein or M-protein. Indicate whether the serum monoclonal immunoglobulin was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 216. Report **Not applicable** for recipients with non-secretory myeloma.

Do not report immunofixation results here.

#### Questions 216 – 217: Serum immunofixation

Indicate whether the serum paraprotein was detected on serum immunofixation. If detected, report **Known** and indicate the M-spike type, including both the heavy and light chain distinctions. The involved heavy chain and light chain can be identified but not quantified using this test. If multiple M-spike types are involved, select each that are present (e.g. IgG Kappa and IgA Lambda). Report **No bands** present if serum immunofixation was performed but no paraprotein was identified.

If **Unknown** or **Not applicable**, continue with question 220. Report Not applicable for recipients with non-secretory myeloma.

#### Question 218: Original monoclonal bands

Indicate **Yes** if the original monoclonal band was present or **No** if it was not present.

#### Question 219: New monoclonal (or oligoclonal) bands

Indicate **Yes** if a new monoclonal band (or oligoclonal) was present or **No** if it was not present

#### Questions 220 – 222: Serum free light chains – κ (kappa)

Indicate whether the serum κ (kappa) free light chain level at the time of evaluation for this reporting period is **Known** or **Unknown**. This value should reflect the quantity of serum free light chains, not a quantification of total light chains. If **Known**, report the value, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 223. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 223 – 225: Serum free light chains – λ (lambda):

Indicate whether the serum λ (lambda) free light chain level at the time of evaluation for this reporting period is **Known** or **Unknown**. This value should reflect the quantity of serum free light chains, not a quantification of total light chains. If **Known**, report the value, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 226. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 226 – 227: Total urine protein in 24 hours

Indicate whether the amount of urinary protein at the time of evaluation for this reporting period was **Known** or **Unknown**. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report7. If **Unknown** or **Not applicable**, continue with question 228. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 228 – 229: Urine albumin / creatinine ratio

Indicate whether the urinary albumin / creatinine ratio was **Known** or **Unknown** at the time of evaluation for this reporting period. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 230.

#### Questions 230 – 231: Urine protein / creatinine ratio

Indicate whether the urinary protein / creatinine ratio was **Known** or **Unknown** at the time of evaluation for this reporting period. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 232.

#### Questions 232 – 233: Urinary monoclonal protein (M-spike)

Indicate whether the amount of urinary monoclonal protein was **Known** or **Unknown** at the time of evaluation for this reporting period. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 234. Report **Not applicable** for recipients with non-secretory myeloma.

#### Question 234: Urinary immunofixation

Urine immunofixation is a laboratory technique that detects and types monoclonal antibodies or immunoglobulins in the urine. Indicate if the results of urinary immunofixation at the time of evaluation for this reporting period is **Known** or **Unknown**. If **Unknown** or **Not applicable**, continue with question 237. Report **Not applicable** for recipients with non-secretory myeloma.

#### Question 235: Original monoclonal bands

Indicate **Yes** if the original monoclonal band was present or **No** if it was not present.

#### Question 236: New monoclonal (or oligoclonal) bands

Indicate **Yes** if a new monoclonal (or oligoclonal) band was present or **No** if it was not present.

#### Questions 237 – 238: Plasma cells in bone marrow aspirate by flow cytometry

Indicate whether the percentage of plasma cells in the bone marrow aspirate assessed by flow cytometry at the time of evaluation for this reporting period is **Known** or **Unknown**. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 239.

#### Questions 239 – 240: Plasma cells in bone marrow aspirate by morphologic assessment

Indicate whether the percentage of plasma cells in the bone marrow aspirate was **Known** or **Unknown** by morphologic assessment at the time of evaluation for this reporting period. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 241.

#### Questions 241 – 242: Plasma cells in bone marrow biopsy

Indicate whether the percentage of plasma cells in the bone marrow biopsy at the time of evaluation for this reporting period is **Known** or **Unknown**. If **Known**, report the percentage of plasma cells in the bone marrow biopsy documented on the pathology report. If **Unknown**, continue with question 243.

#### Question 243: Did the recipient receive dialysis?

Indicate if the recipient received dialysis during this reporting period. If the recipient received dialysis at any point, report **Yes**. If the recipient did not receive dialysis during the reporting period, report **No** and continue with question 246.

#### Questions 244 – 245: Date of dialysis

Indicate if the date the recipient started dialysis was **Known** or **Unknown**. If **Known**, report the date that dialysis began. If **Unknown**, continue with question 246.

#### Question 246: Was a PET / CT scan performed?

A PET / CT combines the results of the PET (Positron Emission Tomography) scan along with the results of a CT (Computed Tomography) scan. If a PET / CT scan was performed at the time of evaluation for this reporting period, indicate **Yes**. If a PET / CT scan was not performed, select **No** and continue with question 251.

#### Questions 247 – 248: Was the PET / CT scan positive for myeloma involvement at any disease site?

Indicate if the PET / CT scan was positive for myeloma involvement at any disease site. If positive at any site, report **Yes** and specify which area(s) show involvement in. If negative, report **No** and continue with question 251.

#### Questions 249 – 250: Date of PET / CT scan

Indicate if the date of the PET / CT scan was **Known** or **Unknown** at the time of evaluation for this reporting period. If **Known**, report the assessment date. If **Unknown**, continue with question 251.

#### Question 251: What is the hematologic disease status at the time of the most current evaluation?

Report the disease status at the time of evaluation for this reporting period. See the [Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria) section for multiple myeloma and solitary plasmacytoma disease status definitions. See [Plasma Cell Leukemia Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/pcl-response-criteria) for plasma cell leukemia disease status definitions.

If the disease response prior to transplant is unknown, select **Unknown** and continue with question 253.

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

This question will not be enabled if the primary disease for transplant is monoclonal gammopathy of renal significance (MGRS).

#### Question 252: Date hematologic disease status assessed

Enter the date of the most recent disease evaluation. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathological evaluation. A PET scan may be used **if** a PET scan was previously obtained and **only** in limited circumstances (e.g., plasmacytomas, lytic lesions).

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)