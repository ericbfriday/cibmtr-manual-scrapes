If a pregnancy is reported, complete the Pregnancy (3501) Form to answer questions specific to the pregnancy. The option of **Previously reported** should only be used if the same pregnancy instance has already been reported on a Pregnancy (3501) Form that was created as an unscheduled form (“on demand”). If there is a question regarding use of this option, contact CIBMTR Center Support if there are questions.

**Example 1.** Recipient or recipient’s female partner becomes pregnant at day +68. It is reported at the time the 100-day Form Cellular Therapy Essential Data Follow-Up (4100) form is completed. These questions should be answered as **Yes**, and the Form 3501 should be completed to report all pregnancy information.

**Example 2.** Recipient or recipient’s female partner becomes pregnant at day +68 and had received a commercially available CAR-T product (e.g., Yescarta®). Per protocol, the pregnancy should be reported at the time of knowledge of the pregnancy. The Form 3501 should be created as an unscheduled form in FormsNet3 and completed in a timely manner. When the 100-day Cellular Therapy Essential Data Follow-Up (4100) form is completed, these questions should be answered as **Previously reported**.

**Example 3**. Recipient or recipient’s female partner becomes pregnant at 1 year and 1 month and had received a commercially available CAR-T product (e.g., Yescarta®). Per protocol, the pregnancy should be reported at the time of knowledge of the pregnancy. The Form 3501 should be created as an unscheduled form in FormsNet3 and completed in a timely manner. The outcome of the first pregnancy does not go to term or does not result in a live birth and another pregnancy event occurs at 1 year and 11 months. It is decided to report the 2nd pregnancy event on the 2 year Cellular Therapy Essential Data Follow-Up (4100) form since it is due. These questions should be answered as **Yes** to create another Form 3501.

#### Question 190: Was the recipient pregnant at any time in this reporting period? (Female Only)

Indicate whether the recipient was pregnant at any time during the reporting period. Skip this question for male recipients.

If **Yes**, complete the Pregnancy (3501) form also. The **Previously reported** option should only be used if the same pregnancy instance has already been reported on a Pregnancy (3501) form that was created as an unscheduled form (on-demand). See examples above.

Contact CIBMTR Center Support with questions.

#### Question 191: Was the recipient’s female partner pregnant at any time in this reporting period? (Male only)

Indicate whether the recipient’s female partner was pregnant at any time during the reporting period. Skip this question for female recipients.

If **Yes**, complete the Pregnancy (3501) form also. The **Previously reported** option should only be used if the same pregnancy instance has already been reported on a Pregnancy (3501) form that was created as an unscheduled form (on-demand). See examples above.

Contact CIBMTR Center Support with questions.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 190 – 191 | 10/25/2024 | Add | Added red warning box: Pregnancy Questions Pregnancy questions will only be answered for recipients between the ages of 10 and 60.
|
Added applicable age range |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)