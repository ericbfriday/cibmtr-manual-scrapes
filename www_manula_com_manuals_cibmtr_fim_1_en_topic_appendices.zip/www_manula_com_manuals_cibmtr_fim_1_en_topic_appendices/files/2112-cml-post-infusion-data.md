Chronic myelogenous leukemia (CML) is a slow-progressing cancer of the myeloid white blood cells. It is characterized by the increased proliferation of immature white blood cells (granulocytes) with damaged DNA, or blasts, which accumulate in the blood and bone marrow. Normal blasts develop into white blood cells which function to fight infection. The symptoms of CML are caused by the replacement of normal bone marrow with leukemic cells, resulting in a drop in red blood cells, platelets, and normal white blood cells.

The Chronic Myelogenous Leukemia Post-Infusion Data Form (Form 2112) is one of the Comprehensive Report Forms. This form captures CML-specific post-infusion data such as: the recipient’s best response to HCT or cellular therapy; planned treatments post-infusion; disease relapse data including treatment administered for relapse or persistent disease; and disease status for the reporting period.

This form must be completed for all recipients whose primary disease, reported on Pre-TED Disease Classification Form (Form 2402), is CML. This includes CML with the following chromosomal abnormalities: Philadelphia chromosome, complex variation and/or variant form, or BCR/ABL gene rearrangement. The CML Post-Infusion Data Form must be completed in conjunction with each Post-Infusion Data Form (Form 2100) completed. The post-infusion forms are designed to capture specific data occurring within the timeframe of each reporting period (i.e. between day 0 and day 100 date of contact for the 100 day follow-up, between day 100 date of contact and the six-month date of contact for the six-month follow-up, etc.).

Links to Sections of Form:

[Q1-63: Disease Assessment at the Time of Best Response](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2112-q1-63)

[Q64-99: Post-HCT / Post-Infusion Planned Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2112-q64-99)

[Q100-109: Disease Relapse or Progression Post-HCT / Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2112-q100-109)

[Q110-194: Post-HCT / Post-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2112-q110-194)

[Q195-198: Disease Status at Time of Evaluation for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2112-q195-198)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please click here or reference the retired manual section on the Retired Forms Manuals webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/19/18 | Comprehensive Disease Specific Manuals | Add | Added the following instruction for applicable post-infusion disease-specific forms where current disease status is asked (2110, 2111, 2112, 2113, 2114, 2115, 2116, 2118, 2119). The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression. |
| 1/31/17 | 2112: CML Post-Infusion Data Form | Add | Version 1 of the 2012: CML Post-Infusion Data Form section of the Forms Instructions Manual released. Version 1 corresponds to revision 2 of the Form 2112. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)