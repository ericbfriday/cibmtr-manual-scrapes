#### Question 2: Specify the leukodystrophy subtype

Indicate the recipient’s disease subtype:

**Krabbe Disease (globoid cell leukodystrophy):**A rare lysosomal storage disorder affecting the nervous system, most typically occurring in infants.**Metachromatic leukodystrophy (MLD):**A rare genetic disorder in which there is an accumulation of sulfatides, causing damage to the myelin sheath within the nervous system. The three types of MLD are based on age symptoms occur: late-infantile MLD, juvenile MLD, and adult MLD.**Adrenoleukodystrophy (ALD):**A rare genetic disorder causing buildup of very long-chain fatty acids (VLCFAs) and in response, damages the myelin sheath within the nervous system. The most common form of ALD is X-linked ALD, more commonly affecting males.**Hereditary diffuse leukoencephalopathy with spheroids (HDLS):**A rare hereditary disorder affecting adults. The disease is associated with leukoencephalopathy and spheroids in the axons of the brain.

#### Questions 3 – 4: Specify testing performed to establish the diagnosis (check all that apply)

Specify which testing was performed to establish the diagnosis of the primary disease for infusion, select all that apply.

**Newborn Screening:**A blood screen which looks for the defective molecules in the circulating blood. In the United States, this blood test is available as part of routine newborn screening. Infants are often diagnosed at birth or in utero.**Genetic mutational panel:**A genetic panel is a standard panel of genes known to be associated with hematopoietic abnormalities. The intent of this assessment is to screen for myeloid diseases. This assessment is typically a myeloid mutation panel and is usually labeled as a “Genetic Mutational Panel” within the EMR; however, this varies from institution to institution. If it is unclear if this assessment was performed, seek physician clarification.**Laboratory findings (enzyme levels, storage levels, hormone levels):**Laboratory studies such as enzyme levels, storage levels and hormone levels, may be used to identify deficiencies that cause leukodystrophy.**Other Testing:**Includes those methods of testing not already listed above. This option will rarely be used; however, a recipient may be diagnosed as a result of another family member’s prior leukodystrophy diagnosis or imaging testing characteristic of the disease. If**Other testing**was performed to establish the diagnosis select this option and specify other testing.

**Enzyme / storage activity at diagnosis – recipient**

#### Questions 5 – 6: Was enzyme / storage activity tested?

Indicate if enzyme / storage activity was tested for the recipient at diagnosis. This type of testing performed is specific to the leukodystrophy subtype. Types of testing include enzyme assays, urine testing, etc. If enzyme / storage activity was tested on the recipient select **Yes** and indicate the date (YYYY-MM-DD) of testing. An example of enzyme activity testing is the quantitative measurement of arylsulfatase A enzyme. If the arylsulfatase A enzyme is deficient, it is the gold standard to confirm a diagnosis of metachromatic Leukodystrophy.

Testing is generally only performed once. In the rare scenario testing is performed multiple times, report the date of the most recent assessment and the results prior to the start of treatment.

If the exact date is not known, use the process described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If enzyme / storage activity was not tested for the recipient at diagnosis or it is not known, select **No** or **Unknown**, respectively, and continue with *Was the donor / CBU/ a carrier?*

#### Questions 7 – 8: Recipient result

Indicate whether the results of the recipient’s enzyme / storage activity testing were **Normal** or **Abnormal** at diagnosis and if documentation was submitted to CIBMTR (CIBMTR recommends attaching the enzyme / storage activity testing).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

Enzyme / storage activity at diagnosis – donor

#### Question 9: Was the donor / CBU a carrier?

Indicate if the donor or CBU was a carrier for a genetic disease / leukodystrophies. If the donor was tested for being a carrier for genetic diseases / leukodystrophies and was negative, select **No** and continue with *Was a genetic mutational panel performed at any time prior to the start of the preparative regimen*. If the donor was not tested, or it is unknown if testing was performed, select **Unknown** and continue with *Was a genetic mutational panel performed at any time prior to the start of the preparative regimen*.

#### Questions 10 – 11: Was enzyme activity and / or enzyme substrate tested?

Indicate if enzyme activity and / or enzyme substrate was tested at any time prior to the start of the preparative regimen / infusion. The type of testing performed is specific to leukodystrophy subtype. Types of testing can include enzyme assays, urine testing, etc.

If enzyme / storage activity was tested on the donor select **Yes** and report the date (YYYY-MM-DD) when the donor / CBU was tested. Testing is generally only performed once. In the rare scenario testing is performed multiple times, report the most recent date and results prior to the start of the preparative regimen / infusion.

If the exact date is not known, use the process described in General Instructions, Guidelines for Completing Forms.

If enzyme activity / enzyme substrate was not tested for the donor or it is unknown, select **No** or **Unknown**, respectively and continue with *Was a genetic mutational panel performed at any time prior to the start of the preparative regimen*.

#### Questions 12 – 13: Donor / CBU testing result

Indicate whether the results of the donor’s / CBU’s enzyme activity and / or enzyme substrate testing were **Normal** or **Abnormal** and if documentation was submitted to CIBMTR (CIBMTR recommends attaching the enzyme / storage activity testing).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 14 – 16: Was a genetic mutational panel performed at any time prior to the start of the preparative regimen? (screening for myeloid diseases)

A genetic panel is a standard panel of genes that are known to be associated with hematopoietic abnormalities. The intent of this assessment is to screen for myeloid diseases and is typically a myeloid mutation panel. This report is usually labeled as a “Genetic Mutational Panel” within the EMR; however, this varies from institution to institution. If it is unclear if this assessment was performed, seek physician clarification.

Indicate **Yes** if a genetic panel was performed at any time prior to the start of the preparative regimen / infusion. If **Yes**, specify if the results of the genetic panel were **Normal** or **Abnormal** and if a copy of the genetic mutation panel was submitted to CIBMTR.

If a genetic panel was not performed or it not known if performed at any time prior to the start of the preparative regimen / infusion, select **No** and continue with *Were the recipient’s urinary sulfatides elevated at diagnosis*.

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 17: Were the recipient’s urinary sulfatides elevated at diagnosis? (MLD recipients only)

Indicate if the recipient’s urinary sulfatides were elevated at diagnosis. The analysis of urinary sulfatides is determined through a urine test, often performed for recipients with MLD. If the recipient’s urinary sulfatides are elevated above the lab’s upper limit of * (ULN), select **Yes**. If urinary sulfatide analysis was not completed at diagnosis or it is unknown if this analysis was completed, select **No** or **Unknown**, respectively.

#### Questions 18 – 19: Mean fasting plasma very-long-chain fatty acid (VLCFA) C26:0 level at diagnosis (fasting preferred, but not required) (ALD recipients only)

Indicate if the mean fasting plasma very-long-chain fatty acid (VLCA) level is known at diagnosis, prior to receiving any treatment for ALD. This assessment is typically found within the general lab section of the EMR.

If the mean fasting plasma very-long-chain fatty acid (VLCA) level is **Known**, report the value in μg/mL. If this value is not known, select **Unknown** and continue with *Specify therapy given for adrenal insufficiency with glucocorticoids or mineralocorticoids between diagnosis and infusion*.

#### Question 20: Specify treatment(s) given for adrenal insufficiency with glucocorticoids or mineralocorticoids between diagnosis and infusion (ALD recipients only) (check all that apply)

Select all treatments given for adrenal insufficiency between diagnosis and the start of the preparative regimen / infusion.

**Glucocorticoids:**Corticosteroids with anti-inflammatory properties used to treat conditions involving inflammation (e.g., cortisol and cortisone).**Mineralocorticoids:**Corticosteroids, assist in regulation of sodium and potassium (e.g., aldosterone).

If the recipient did not receive neither **Glucocorticoids** and / or **Mineralocorticoids** at any time prior to the start of the preparative regimen / infusion, select **None**.

#### Questions 21 – 22: Specify treatment(s) given to lower plasma very-long-chain fatty acids at any time prior to infusion (check all that apply) (ALD recipients only)

Select all treatments given to lower plasma very-long-chain fatty acids at any time prior to the start of the preparative regimen / infusion.

**N-acetyl-L-cysteine (NAC):**(Acetylcysteine) is a supplement of cysteine (amino acid). Cysteine is an antioxidant agent that assists with respiratory conditions, fertility, and brain health.**GTE:GTO oil (Lorenzo’s oil):**Composed of erucic acid and oleic acids. Known to decrease / lower very long chain fatty acids (VLCA) levels.**Other treatment:**Includes those treatments not already listed above. If the recipient received treatments not listed, such as experimental clinical trials, select this option and specify the other treatment(s). Report the generic name of the agent, not the brand name.

If no therapy was given at any time prior to the start of the preparative regimen / infusion, select **None**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)