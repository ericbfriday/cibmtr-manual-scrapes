The Mylotarg™ Supplemental Data Collection Form (Form 2543) is designed to support a retrospective and prospective, multicenter, observational registry of patients with Acute Myeloid Leukemia (AML) treated with Mylotarg™ alone or in combination in regimen prior to allogeneic or autogeneic hematopoietic cell transplantation.

The Mylotarg™ Supplemental Data Collection Form will come due for each patient that received Mylotarg™ pre transplant. The 2400 and 2402 will confirm eligibility. Once eligibility is confirmed, the 2500 will come due. The 2500 will confirm use of Mylotarg™ pre-transplant, triggering the 2543. Only one 2543 will be collected per transplant.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/DataCollectionForms/Pages/Retired.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/24/2020 | 2543: Mylotarg™ Supplemental Data Collection | Add | Version 1 of the 2543: Mylotarg™ Supplemental Data Collection section of the Forms Instruction Manual released. Version 1 corresponds to revision 1 of the Form 2543. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)