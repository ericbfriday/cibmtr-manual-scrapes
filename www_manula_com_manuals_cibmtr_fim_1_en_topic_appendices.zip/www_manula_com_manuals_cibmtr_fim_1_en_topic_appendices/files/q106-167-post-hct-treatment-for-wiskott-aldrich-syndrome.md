#### Question 106: Was any treatment given for relapsed, persistent, or progressive disease (since the date of last report)?

Following transplant, additional therapy may be given for relapsed, persistent, or progressive disease. Low lymphocyte counts, new or persistent autoimmunity, or thrombocytopenia may require additional therapy to start to treat these features of WAS.

Indicate if any treatment was given since the date of last report for relapsed, persistent, or progressive disease. If “yes” continue with question 107, if “no” go to question 169.

Report immunosuppressive medications given to prevent or treat GVHD in the corresponding questions on the Form 2000 – Recipient Baseline Data, Form 2100 – 100 days Post-HCT Data, Form 2200 – Six Months to Two Years Post-HCT Data, or Form 2300 – Yearly Follow-Up for Greater Than Two Years Post-HCT Data.

#### Questions 107-166: Treatments

Indicate whether each of the therapies listed in questions 107-168 were given for relapsed, persistent, or progressive disease since the date of last report. If a therapy was given, indicate if that therapy was stopped; if “yes” specify the stopping date. Therapy paused for < 1 week should not be considered as “Therapy Stopped.”

#### Question 167: Did the recipient receive any other significant treatment(s) for WAS (since the date of last report)?

Indicate whether the recipient received other significant treatment, such as those with IL-2, gene therapy, or clinical trial therapies, for WAS.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)