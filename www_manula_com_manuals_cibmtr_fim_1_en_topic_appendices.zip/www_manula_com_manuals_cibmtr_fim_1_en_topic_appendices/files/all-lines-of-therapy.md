Pre-infusion lines of therapy data fields capture the following information:


- CNS prophylaxis
- Systemic therapy, including start and stop dates number of cycles
- Intent of therapy
- Radiation treatment, including start and stop dates
- Best response to the line of therapy
- MRD status
- Clinical / hematologic relapse following the line of therapy

This section provides ALL specific reporting instructions used when completing the pre-infusion lines of therapy on the ALL Pre-Infusion (2011) Form.

### Intent of Therapy

If systemic therapy is reported, the intent of therapy is captured on the ALL Pre-Infusion (2011) Form. This form has four different options to report for the intent of therapy:


- Induction: The first line(s) of therapy given following diagnosis to achieve a complete remission (CR). If the first line of therapy (induction) fails to produce a CR, the recipient may undergo another cycle or a different line of therapy (re-induction) in order to achieve their first CR.
- Consolidation: Once a recipient has achieved a hematologic CR (1st, 2nd, 3rd or greater), they may receive several additional lines of therapy as part of a protocol or to eliminate known minimal residual disease.
- Maintenance: Following induction and consolidation, a recipient may receive low dose chemotherapy over an extended period of time to maintain a CR. Maintenance therapy is usually given as a single drug taken in the outpatient setting when the recipient has no known evidence of disease.
- Treatment for disease relapse: Once the recipient has achieved their first CR, their disease may relapse and require further treatment to produce another CR (2nd or greater). The intent is the same as induction, but the setting is different as the recipient has already achieved at least one prior CR.

### Bridging Therapy

Bridging therapy administered prior to infusion should be reported as a line of therapy. When the ALL Pre-Infusion (2011) Form is revised, a ‘bridging therapy’ option will be added. In the interim, use the following instructions when reporting the therapy intent for bridging therapy:


- Consolidation: If relapse did not occur, report the intent as consolidation.
- Treatment for relapse: If relapse occurred, report the intent as treatment for relapse.

### Children’s Oncology Group (COG) Protocols

Pediatric recipients may receive treatment using COG protocols and reporting these protocols on the CIBMTR forms is complex. COG protocols have many different classifications for various therapies, which include but are not limited to the following:


- Induction
- Intensified consolidation
- Interim maintenance
- Delayed intensification
- Maintenance
- Induction 1, 2, 3
- Re-induction
- Block 1, 2, 3
- Intensification

The following guidelines can be used when reporting the intent of therapy for COG classifications:


- Induction
- Induction

- Consolidation
- Delayed intensification
- Interim maintenance
- Intensified consolidation

- Maintenance
- Maintenance

- Treatment for relapse
- Re-induction
- Induction 1, 2, 3


On a COG protocol, different therapies may be administered over an extended amount of time with minimal disease assessments completed. In these cases, a single line of therapy can be reported, instead of reporting each line separately.


- Example: Standard consolidation, standard interim maintenance, and delayed intensification given over five months without any disease assessments except for CBCs.

### COG Reporting Examples

Example 1: A recipient with ALL is diagnosed in March 2020 and receives a cellular therapy in June 2021. The recipient was on a COG protocol and received multiple therapies. The disease tracker for this recipient is below:


Using the disease tracker, the lines of therapy on the ALL Pre-Infusion (2011) will be reported as the following:

- Line of therapy #1
- Intent: Induction
- Start / stop dates: 3/28/2020 – 4/23/2020
- Number of cycles: One
- Best response: CR
- Best response assessment date: 4/23/2020
- Relapse following this line: No

- Line of therapy #2
- Intent: Consolidation
- Start / stop dates: 4/30/220 – 11/6/2020
- Number of cycles: Five
- Best response: CR
- Best response assessment date: 10/26/2020
- Relapse following this line: No

- Line of therapy #3
- Intent: Maintenance
- Start / stop dates: 1/8/2021 – 2/21/2021
- Number of cycles: One
- Best response: Not in CR
- Best response assessment date: 4/2/2021
- Relapse following this line: Yes
- Relapse date: 4/2/2021

- Line of therapy #4
- Intent: Treatment for relapse
- Start / stop dates: 4/9/2021 – 4/16/2021
- Number of cycles: Two
- Best response: CR
- Best response assessment date: 4/30/2021
- Relapse following this line: No


Example 2: Similar to example 1 , a recipient with ALL is diagnosed in March 2020 and receives a cellular therapy in June 2021. The recipient was on a COG protocol and received multiple therapies but with limited disease assessments. The disease tracker for this recipient is below:


Using the disease tracker, the lines of therapy on the ALL Pre-Infusion (2011) will be reported as the following:


- Line of therapy #1
- Intent: Induction
- Start / stop dates: 3/28/2020 – 4/23/2020
- Number of cycles: One
- Best response: CR
- Best response assessment date: 4/23/2020
- Relapse following this line: No

- Line of therapy #2
- Intent: Consolidation
- Start / stop dates: 4/30/220 – 11/6/2020
- Number of cycles: Five
- Best response: CR
- Best response assessment date: 6/15/2020 or 12/28/2020
- The CSF is not applicable to assess the response as disease has not been detected by this method of assessment.
- The CBC must be used to report the disease status as no other assessments were completed within the time frame this line of therapy was administered (i.e., BMBX).
- The assessment date may be reported as either the first or last CBC, as long as it is consistent with the best response. The CBC completed on 4/30/2020 should not be reported as the assessment date as this CBC was performed on the start date of therapy.


- Relapse following this line: No

- Line of therapy #3
- Intent: Maintenance
- Start / stop dates: 1/8/2021 – 2/21/2021
- Number of cycles: One
- Best response: Not in CR
- Best response assessment date: 4/2/2021
- Relapse following this line: Yes
- Relapse date: 4/2/2021
- Relapse was first detected in the blood on 4/2/2021.


- Line of therapy #4
- Intent: Treatment for relapse
- Start / stop dates: 4/9/2021 – 4/16/2021
- Number of cycles: Two
- Best response: CR
- Best response assessment date: 4/30/2021
- Blasts were no longer detected in the blood on 4/16/2021; however, disease was still present in the CSF.
- The CSF may now be used to assess the response since disease was first detected by the CSF on 4/9/2021.

- Relapse following this line: No


**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)