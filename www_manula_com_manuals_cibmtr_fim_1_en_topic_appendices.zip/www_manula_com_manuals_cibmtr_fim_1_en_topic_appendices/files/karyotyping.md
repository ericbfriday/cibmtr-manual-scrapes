Karyotyping, also referred to as conventional cytogenetics, is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are performed to visualize chromosomes during cell division so various bands and reconfigurations are seen. Karyotype assessments typically examine around 20 cells. Figure 1 below shows an example of a karyotype. The chromosomes are arranged in numerical order with sex chromosomes included last.

Figure 1. Karyotype


Image source: Department of Pathology. Cytogenetics Gallery, University of Washington, www.pathology.washington.edu/galleries/cytogallery/main.php?file.

### Introduction to Chromosomes

Typical human cells contain 23 chromosome pairs (46 total chromosomes)


- 22 of these pairs are autosomal (non-sex) chromosomes
- Each autosomal chromosome is referred to by its number, one through 22

- The remaining two chromosomes (the 23rd pair) are referred to as sex chromosomes
- Identified by either X (female) or Y (male)
- Females have two X chromosomes while males have one X and one Y chromosome


### Karyotype Abnormalities

Karyotype results are provided in a unique format which is demonstrated in Figure 3 below. Karyotype abnormalities are described by identifying the involved chromosomes and specific locations, when applicable. The location is noted when an abnormality involves only a specific section of a chromosome or when a translocation has occurred. The location is defined by two pieces of information, the chromosome arm and the arm region. The arm refers to the short (p arm) or long (q arm) end of the chromosome on opposite sides of the centromere. The arm region describes the distance from the centromere. See Figure 2 below for a depiction of the chromosome arm and arm regions.

Figure 2. Chromosome Structure


Chromosomal abnormalities refer to changes in the amount or location of chromosomal material. A basic knowledge of chromosome symbols / abbreviations is required to interpret karyotype test results. Definitions of general categories of chromosomal abnormalities are provided below. Definitions of common cytogenetic symbols / abbreviations are provided in Table 1.


**Addition**: Extra chromosomal material is present. This includes extra material within a specific region of a chromosome and entire extra chromosomes. Extra material is described by the location while extra whole chromosomes are described based on the quantity present. Trisomy refers to three chromosomes present (one extra) while tetrasomy refers to four chromosomes present (two extra).**Deletion**: Loss of chromosomal material. This includes loss of material within a specific region of a chromosome and entire missing chromosomes. Loss of material is described by location while entire missing chromosomes are described based on the quantity present. Monosomy refers to one chromosome present (one lost) while nullisomy refers to no chromosomes present (both lost).**Translocation**: An exchange of chromosomal material between two or more chromosomes.**Inversion**: The base pair order is reversed for a specific region of a chromosome.**Hyperdiploidy**: The total number of chromosomes present is higher than normal. The definition of hyperdiploidy is typically further specified on the form being completed. For example, a form may require greater than 50 chromosomes be present to report hyperdiploidy.**Hypodiploidy**: The total number of chromosomes present is lower than normal.

Table 1. Cytogenetic Symbols and Abbreviations


### Interpreting Karyotype Results

In a karyotype result (see Figure 3 below), the first item noted is the total number of chromosomes, followed by a comma, and then the sex chromosomes. If the karyotype is abnormal, a comma follows the sex chromosomes, and then the abnormalities (listed as a symbol or abbreviation), each separated by a comma.

When one chromosome is altered in an abnormality, the affected chromosome is enclosed within parenthesis, immediately following the symbol indicating the alteration (i.e., del(8), inv(9)). When two more chromosomes are affected in an abnormality, a semicolon is used to separate the chromosomes (i.e., t(8;9)). To indicate additional, missing, normal, or abnormal chromosomes, a plus or minus sign is noted prior to the affected chromosome (i.e., -8, +21). A plus or minus sign noted after the chromosome arm symbol (p or q), indicates the addition or loss of chromosomal material to the specified arm. Abnormalities identified in different clones are separated by a backslash. Different clones are identified when findings are detected in some, but not all cells. The number of cells with the specified karyotype is enclosed in brackets, denoted at the end of the karyotype string.

Figure 3. Karyotype Results


Table 2. Karyotype Results


### Clonal verses Non-Clonal and Constitutional Findings

When reporting karyotype results, a data manager must distinguish between clonal and non-clonal findings. Clonal abnormalities are present in multiple cells and indicate a separate cell line, such as a malignant population, is present. Additionally, karyotyping may also detect constitutional abnormalities. These are abnormalities present since birth. Examples include, but are not limited to, trisomy 21 and Klinefelter’s syndrome. Constitutional abnormalities should not be reported.

Example 1: Karyotyping was performed at diagnosis and `46,XY,+21[20]`

was detected. In this case, since only +21 was detected, **No abnormalities** should be reported as the results for karyotype obtained at diagnosis.

### Reporting Other Karyotype Results

The ‘other’ karyotype data field is used to report abnormalities detected, but not listed as an option on the form. Abnormalities that should be reported in the ‘other’ specify data field, include, but are not limited to the following:


- Abnormality detected but not listed as a specific option on the form
- Tetrasomies: Four copies of a specific chromosome
- Example:
`48,XY,+21,+21[20]`

- The ‘+21,+21’, is not the same as ‘+21,’ which maybe listed as an option on the form. This abnormality indicates there are four copies of chromosome 21, where as +21 indicates there are three copies


- Example:
- ‘Monosomy or deletion’ of a specific chromosome: The entire chromosome or part of the chromosome is missing but the exact abnormality is unknown.
- Example: ‘Monosomy 7 or deletion 7’ is detected
- Report this abnormality under ‘other’ and specify ‘Monosomy 7 or deletion 7’


- Example: ‘Monosomy 7 or deletion 7’ is detected
- ‘Trisomy or add’: An extra entire chromosome or part of the chromosome but the exact abnormality is unknown.
- Example: ‘Trisomy 3 or addition 3’ is detected
- Report this abnormality under ‘other’ and specify ‘Trisomy 3 or addition 3’


- Example: ‘Trisomy 3 or addition 3’ is detected
- Derivatives: A chromosome derived from a translocation
- Example:
`46,XX,der(1)t(1;12)(p22;q13)[20]`

- This abnormality indicates one of the chromosome 1 has lost a some of the p arm from the other chromosome 1 and gained some of the q arm from chromosome 12. This is not the same as ‘t(1;12)’ where the material from chromosome 1 and 12 swap with each other.
- Report this abnormality under ‘other’ and specify ‘der(1)t(1;12)’


- Example:

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Reporting Other Karyotype Results | 4/4/2024 | Add | The Reporting Other Karyotype Results section added | Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)