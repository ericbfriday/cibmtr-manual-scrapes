This appendix includes definitions of Hematopoietic Cell Transplant (HCT) (including primary and subsequent, autologous cells given for graft failure, and HCT supporting solid organ transplant), Gene Therapies, Cellular Therapies (alone or post-HCT, co-infusion, DLI and micro-transplant). For more information see Table 1.

**Table 1.Distinguishing Infusion Types**

[ ](https://manula.s3.amazonaws.com/user/3235/img/appendix-d-7-2024.png)

## HCT Definitions

#### Hematopoietic Stem Cell Transplant (HCT) – Primary or Subsequent

An HCT, genetically modified or not, is *an infusion of a product (see Appendix E) that contains CD34+ cells.* The intention of a HCT is generally to restore hematopoiesis by replacing or repopulating the recipient marrow. A HCT is often preceded by a preparative regimen, which is used to kill normal cells, malignant cells (if present), and to prevent rejection. However, a preparative regimen may not always be used prior to a stem cell infusion. Examples of this may include a “boost” or infusions given for non-malignant diseases. These indications are still considered a HCT if they fit primary criteria used to define a transplant: the product infused contains CD34+ cells with the intent to restore hematopoiesis.

A **genetically modified** HCT product consists of cells with modified protein expression of stem cells (i.e. not to express CD33), but not modified to treatment of a disease at the genetic level (see gene therapy definition)

*Report infusions of bone marrow, cord blood, and mobilized PBSC as a HCT; as a general rule of thumb, infusion of portions of original HCT product without further manipulation would be considered subsequent transplants. The intent of these infusions is generally to restore hematopoiesis.*

**HCT Examples Outside of Standard Context**

- Recipient receives an allogeneic related HCT. The product is collected via a standard G-CSF mobilization. A portion of cells from the first HCT are saved for a second infusion. The portion of cells are then manipulated for CD34+ selection and infused. This second infused is considered an HCT because there are sufficient CD34+ cells for engraftment.
- Recipient receives an allogenic HCT. They never engrafted post-HCT & receive additional HPCs (hematopoietic progenitor cells, CD34+) to restore hematopoiesis. This infusion should be reported as a subsequent HCT because the intent is to restore hematopoiesis.
- FCRx product is comprised of donor peripheral blood-derived bioengineered hematopoietic stem cells. Mature graft versus host disease (GVHD)-producing and antigen-presenting cells were removed from the donor blood, for induction of immunological tolerance during organ transplantation and enriched for facilitating cells. Kidney transplant patients treated with FCRx were fully withdrawn from immunosuppression without loss of engraftment and achieved durable chimerism. Product contains high dose of CD34+ cells that could/would lead to engraftment, this in fusion should be reported as an HCT. Source:
[http://discovery.lifemapsc.com/regenerative-medicine/cell-therapy-applications/blood-fcrx-bioengineered-hematopoietic-stem-cells-for-immunological-tolerance](http://discovery.lifemapsc.com/regenerative-medicine/cell-therapy-applications/blood-fcrx-bioengineered-hematopoietic-stem-cells-for-immunological-tolerance) - Recipient receives an allogeneic unrelated (MUD) HCT. The PBSC product was collected in a total of 6 bags. Five of these bags were infused as the first HCT. The last bag was infused 6 months later as a “boost”. This infusion should be reported as a subsequent HCT because the intent is to restore hematopoiesis.

#### Autologous Cells Given for Graft Failure

A recipient may receive an infusion of autologous cells as a result of poor hematopoietic recovery or graft failure/rejection following prior allogeneic or autologous transplant; this is generally referred to as “autologous rescue.” The CIBMTR defines this type of infusion as a subsequent HCT; however, because the research value of these data does not justify the additional reporting burden to transplant centers, CIBMTR does not currently require additional forms in the event of these transplants. Necessary data are adequately captured on the routine follow-up forms.

#### HCT Supporting Solid Organ Transplant

immunosuppression, a recipient may receive an infusion of cells prior to a subsequent solid organ transplant. These infusions contain sufficient CD34 cells to result in engraftment and should be reported as an HCT.

## Gene Therapy Definition

Genetic diseases are conditions caused by one or more mutations in the genome (chromosomes containing DNA). Gene therapy is a way to treat these types of diseases at the genetic level with an autologous HCT using CD34+ cells that that have been genetically manipulated (modified). The intention of the autologous HCT is to restore hematopoiesis by replacing or repopulating the recipient marrow. The autologous HCT is typically preceded by a preparative regimen.

There are two general approaches to gene therapy: (1) gene addition, where correct copies of genes are inserted into the DNA of the stem cells using a vector system, and (2) gene editing, where defective DNA sequences at a specific location are removed or replaced with the correct sequence.

**Genetically Unmanipulated (Unmodified) Autologous Cells Given for Graft Failure**

A recipient may receive an infusion of unmanipulated autologous cells (“back-up cells”) as a result of poor hematopoietic recovery following a prior autologous transplant with a genetically manipulated product. The CIBMTR defines this type of infusion as a subsequent autologous HCT because there are sufficient CD34+ cells for engraftment; however, because the research value of these data does not justify the additional reporting burden to transplant centers, the data for the infusion is reported on the standard Gene Therapy Product Infusion form.

## Cellular Therapy Definitions

#### Cellular Therapy (Alone or Post-HCT)

Cellular therapy is a form of immunotherapy that is commonly used to treat recurrent disease infections (e.g. viral), or mixed chimerism. Treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g. cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g. CAR T-cells).

The infused product does not contain sufficient CD34+ cells to result in engraftment and the intent is not to restore hematopoiesis. The recipient does not routinely receive a preparative regimen prior to receiving a cellular therapy; however, chemotherapy or immunotherapy that is not sufficient to ablate the marrow to the point where stem cell support is required may be given prior to a cellular therapy.

A cellular therapy should not be reported if additional donor cells (containing CD34+ cells) are given for failed ANC recovery, partial or poor ANC recovery, loss of graft, or late graft failure. Hematopoietic progenitor cell products infused for these indications would be considered a subsequent HCT.

A **genetically modified** cellular therapy product consists of cells that were genetically modified outside the body after pheresis (i.e. product collection). The most common example of a genetically modified product is a CAR-T cell. The patient’s own cells are modified in a laboratory after collection to recognize a specific target.

A **non-genetically modified** cellular therapy consists of cells that are collected and infused into the patient without any processing, or the product can undergo a cell selection process to restrict the cells to a specific population of cells. The cells are selected but un-modified in any way. Examples of this are (but not limited to) mesenchymal cells, virus specific T cells (VSTS), donor lymphocyte infusions (DLI).

The types of cells used for a cellular therapies include, but are not limited to the following:


**Lymphocytes:**A therapeutic product from any source containing a fixed or prescribed dose of T-cells**Peripheral blood mononuclear cells:**Whole blood collected as a source of nucleated cells (not hematopoietic progenitor cells) intended for therapeutic use other than restoring hematopoiesis**Dendritic cells from the original donor**: A therapeutic cell product containing dendritic cells for therapeutic use**Mesenchymal cells:**A therapeutic product containing mesenchymal stromal cells for therapeutic use

Cellular therapy may be given as a stand alone therapy (with no history of HCT) or given post-HCT.

**Examples of Cellular Therapy Alone**

- Autologous CAR-T cells to treat hematologic disease. Report the primary indication as cellular therapy on the Indication for CRID Assignment form.
- Cell therapy for treatment of autism. Report the primary indication as cellular therapy on the Indication for CRID Assignment form.

**Examples of Post-HCT Cellular Therapy (e.g., CAR-T, DCI)**

- Recipient receives autologous-derived marrow-infiltrating lymphocytes (MILs) after an autologous HCT for multiple myeloma. The protocol randomizes the infusion of this product to be post-HCT or at relapse. This infusion should be reported as a post-HCT cellular therapy.
- Recipient receives an autologous HCT and as part of the protocol will also receive a planned NK cell infusion from the same donor on Day 10. This infusion should be reported as a post-HCT cellular therapy.

#### Co-Infusion (with HCT)

A co-infusion (or supplemental infusion) is defined as an infusion of cells given prior to clinical Day 0 (after the start of the prep regimen) of an HCT or on Day 0 for any reason other than to produce engraftment. An infusion of supplemental cells may be given in conjunction with a preparative regimen for an HCT. A co-infusion is distinct form of cellular therapy as it is given in conjunction with an HCT, either prior to or on the day of HCT.

Examples of supplemental infusions include, but are not limited to the following:


- NK Cells
- T-Regulatory cells (TREG)
- Mesenchymal cells

Co-infusion cells should be reported in the “Donor Information” section of the Pre-TED, in the “Other” and “Specify cell source” fields. The cell source that is intended to produce engraftment should also be reported in the “Donor Information” section of the Pre-TED. When reporting co-infusions, the Cellular Therapy Product form (4003) and Cellular Therapy Infusion form (4006) are required for all recipients. The HCT Infusion form (2006) will capture information regarding the product intended for engraftment.

**Co-Infusion Reporting Scenario**

A recipient is scheduled to receive an allogeneic HCT infusion along with infusions of alpha / beta depleted T cells.

Three infusions


- CD34+ HPCs and alpha / beta depleted T cells on 3/1/2016
- HPCs (pure product) 3/2/2016
- Modified T cells 3/23/2016

How to report


- The infusion of CD34+ HPCs on 3/1/2016 is the event date of HCT
- The infusion of T cells also on 3/1/2016 would be reported as a co-infusion on the pre-TED
- The T cells infused on 3/23/2016 would be reported as a post-HCT cellular therapy on the appropriate HCT follow up form

#### Micro-transplant

An example of a micro-transplant is provided below. For further assistance identifying and reporting micro-transplants, contact CIBMTR Center Support.

**Micro-transplant Example**

A recipient receives an HLA-mismatched related donor micro-transplant as treatment to maintain remission for AML. Donor GCSF-mobilized donor peripheral stem cells (GPBSCs) are infused at a target dose of 1.0 ×108 CD3+ cells / kg (recipient weight). Since the target dose is of CD3+ cells, the dose of CD34+ is insufficient for engraftment. This is reported as a cellular therapy.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/2024 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)