#### Questions 1 – 2: Was the recipient red blood cell (RBC) transfusion independent for the entire reporting period?

Indicate if the recipient was RBC transfusion independent for the entire reporting period.

Some discretion may be required if the recipient received a transfusion for a surgical procedure or other reason. If a recipient received an RBC transfusion for a procedure and would otherwise be transfusion independent, the recipient may still be reported as being transfusion independent.

If the recipient did not receive an RBC transfusion in the reporting period or was never dependent on RBC transfusions, report **Yes** and continue with question 3.

If the recipient received one or more RBC transfusion(s) in the reporting period, report **No** and specify the date of the *most recent* RBC transfusion administered in the current reporting period.

#### Questions 3 – 4: Was the recipient platelet transfusion independent for the entire reporting period?

Indicate if the recipient was platelet transfusion independent for the *entire* reporting period.

Some discretion may be required if the recipient received a transfusion for a surgical procedure or other reason. If a recipient received a platelet transfusion for a procedure and would otherwise be transfusion independent, the recipient may still be reported as being platelet transfusion independent.

If the recipient did not receive a platelet transfusion in the reporting period or was never dependent on platelet transfusions, report **Yes** and continue with question 5.

If the recipient received one or more platelet transfusion(s) in the reporting period, report **No** and specify the date of the *most recent* platelet transfusion administered in the current reporting period.

#### Question 5: Did graft failure occur?

Graft failure specific to aplastic anemia is defined as donor chimerism < 5% or need to begin transfusion (platelets or blood). Indicate if graft failure occurred in the current reporting period.

Report **Yes** in any of the following scenarios:


- If the donor chimerism was < 5% at any time in the reporting period
- If the donor chimerism was < 5% in a prior reporting period and the donor chimerism remained < 5% in the current reporting period
- If the donor chimerism was not < 5% but platelet and / or RBC transfusions were administered for cytopenias related to graft failure

Report **No** in any of the following scenarios and continue with question 8:


- If chimerism studies were not performed in the reporting period and platelet and / or RBC transfusions were not given for cytopenias
- If chimerism studies were performed but the donor chimerism was ≥ 5% in the reporting period and platelet and / or RBC transfusions were not given for cytopenias

Questions 6 – 7: Did autologous recovery occur?

After graft failure, a recipient’s own cells may return – this is known as autologous recovery. Chimerism studies can determine if autologous recovery occurred by identifying if recipient cells are present. If autologous recovery occurred, this information is typically documented within the medical record.

Indicate if autologous recovery occurred in the reporting period. If **Yes**, report the date of autologous recovery in question 7 (this should be the first date when autologous recovery is documented within the physician’s note).

If autologous recovery did not occur in the reporting period, report **No** and continue with question 8.

Questions 8 – 10: Was a bone marrow biopsy examination performed?

Indicate whether or not a bone marrow biopsy was performed in the current reporting period.

If a bone marrow biopsy was performed in the reporting period, select **Yes**, report the date of the *most recent* bone marrow examination, and specify if a copy of the most recent bone marrow examination is attached.

If a bone marrow biopsy was not performed or it unknown if one was performed in the reporting period, report **No** and continue with question 24.

For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 11: Were cytogenetic tested? (by karyotyping and/or FISH)

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the abnormal cells.

Indicate whether cytogenetic studies were obtained in the current reporting period. If **Yes**, continue with question 12.

If cytogenetic studies were not obtained or it is unknown if chromosome studies were performed in the current reporting period, select **No** or **Unknown**, respectively and continue with question 24.

#### Questions 12 – 13: Were cytogenetics tested via FISH?

If FISH studies were performed in the current reporting period, report **Yes** and indicate whether abnormalities were identified.

If FISH studies were not performed, it is unknown if performed in the current reporting period, or if the sample was inadequate (i.e., FISH failed), report **No** and continue with question 18.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

Questions 14 – 17: Specify cytogenetic abnormalities identified via FISH

Report the ISCN compatible string, if applicable, in question 14.

Select all FISH abnormalities identified in the current reporting period in question 15 and indicate if the FISH report(s) are attached in FormsNet3SM in question 17.

If any abnormality is detected but not listed as an option in question 15, select **Other abnormality** and specify the abnormality in question 16. If multiple other abnormalities were detected, report “see attached report” in question 16 and attach the final report(s) for any other abnormality detected. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Questions 18 – 19: Were cytogenetics tested via karyotyping?

If karyotyping was performed in the current reporting period, report **Yes** and indicate whether abnormalities were detected. If the karyotype sample was inadequate or yielded no results, select **No evaluable metaphases**.

If karyotyping was not performed or unknown if performed, report **No** and continue with question 24.

#### Questions 20 – 23: Specify cytogenetic abnormalities identified via conventional cytogenetics

Report the ISCN compatible string, if applicable, in question 20.

Select all cytogenetic abnormalities identified in the current reporting period by conventional cytogenetics in question 21 and indicate if karyotype report(s) is attached in FormsNet3SM in question 23.

If an abnormality is detected but not listed as an option in question 21, select **Other abnormality** and specify the abnormality in question 22. If multiple other abnormalities were detected, report “see attached report” in question 22 and attach the final report(s) for any other abnormality detected. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Questions 24 – 25: Was a genetic mutational panel performed? (screening for myeloid diseases)

A genetic panel is a standard panel of genes that are known to be associated with hematopoietic abnormalities. The intent of this assessment is to screen for myeloid diseases that resembles aplastic anemia (i.e., MDS). This assessment is typically a myeloid mutation panel. This report is usually labeled as a “Genetic Mutational Panel” within the EMR; however, this varies from institution to institution. If it is unclear if this assessment was performed, seek physician clarification.

Indicate whether a genetic panel was performed in the current reporting period. If **Yes**, specify if a copy of the genetic panel is attached. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

If a genetic panel was not performed in the current reporting period, select **No**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)