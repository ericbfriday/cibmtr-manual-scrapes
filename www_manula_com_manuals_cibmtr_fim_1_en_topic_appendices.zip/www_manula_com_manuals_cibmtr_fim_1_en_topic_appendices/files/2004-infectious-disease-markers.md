Form 2004 will come due in the following instances:

- Non-NMDP unrelated donor (TED or CRF track)
- Non-NMDP unrelated cord blood (TED or CRF track)
- Related cord blood (TED or CRF track)
- HLA-identical sibling (CRF track or when consented for “Research Sample Repository” on TED track)
- HLA-matched other relative or HLA-mismatched relative (CRF track or when consented for “Research Sample Repository” on TED track)

If the donor or cord blood unit was secured through the NMDP, IDM test results will be reported by the donor center on NMDP Forms 24 and 50, or will be submitted by the cord blood bank through CORD Link®.

Infectious diseases result from pathogens that enter the human body and multiply. Examples of pathogens include viruses, bacteria, fungi, and parasites. Infectious diseases may be transmitted through liquids, food, body fluids, contaminated objects, or airborne particles.

An Infectious Disease Marker (IDM) indicates if an individual currently has, or previously has had, an infectious disease that could be transferred to another person.

- Antibody testing assesses whether an individual’s immune system recognizes an antigen presentation, which indicates previous exposure to the pathogen.
- Antigen testing, such as testing for the presence of the Hepatitis B surface antigen, assesses whether the individual has an active infection, where the pathogen is present in the blood. Antigen testing is done because the individual may not yet have developed antibodies against the pathogen at the time of infection.

The purpose of IDM testing is to assess the donor’s exposure to infectious diseases and the likelihood of their transmitting a disease to the recipient.

For a glossary of terms used in this section of the manual, see [Appendix B](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-b-glossary-of-terms).

[Q1: Donor/Cord Blood Unit Identification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-9-donor-cord-blood-unit-identification)

[Q2-29: Infectious Disease Markers](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q10-46-infectious-disease-markers)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2004.Infectious%20Disease%20Markers%20Manual%20Update%20History%20Through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 9/23/2022 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)