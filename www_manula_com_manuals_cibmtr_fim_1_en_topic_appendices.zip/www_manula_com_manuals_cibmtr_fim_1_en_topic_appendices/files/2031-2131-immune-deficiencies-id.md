Immune deficiencies (ID) are genetic disorders characterized by dysfunction of the immune system. Because immune deficiencies are caused by a broad range of genetic mutations, symptoms for each disorder vary. Immune deficiencies are often diagnosed at birth following newborn screening, or following severe and/or persistent infections. Symptoms of immune deficiencies include severe, protracted, difficult to treat infections, decreased weight and height for age, autoimmune disorders, and/or developmental delay. Hematopoietic cell transplant (HCT) is currently the major curative treatment for immune deficiencies.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)