#### Question 1: Specify the multiple myeloma / plasma cell disorder (PCD) classification:

Specify the indication for transplant. This question will be auto-populated from the Pre-TED Disease Classification and Characteristics (2402) Form. See below for characteristics of each disease.

Plasma Cell Disorders and Characteristics

*Multiple Myeloma (symptomatic)*

[1](#fn212452402668596ac3dc0f3-1)

Diagnostic criteria for symptomatic multiple myeloma require clonal bone marrow plasma cells in ≥ 10% or biopsy proven bony or extramedullary plasmacytoma and any one or more of the following myeloma-defining events:


- Evidence of end organ damage (i.e., CRAB features) that can be attributed to the underlying plasma cell proliferative disorder, specifically:
- Hypercalcemia: serum calcium >1 mg/dL (> 0.25 mmol/L) higher than the ULN or > 11 mg/dL (> 2.75 mmol/L)
- Renal insufficiency: creatinine clearance < 40 ml/min or serum creatinine > 2 mg/dL (> 177 μmol/L)
- Anemia: hemoglobin > 2 g/dL (> 20 g/L) below the LLN or a hemoglobin < 10 g/dL (< 100 g/dL)
- Bone lesions: one or more osteolytic lesions on skeletal x-ray, CT or PET-CT

- Any one or more of the following biomarkers of malignancy:
- Clonal bone marrow plasma cell percentage ≥ 60%
- Involved : uninvolved serum free light chain ratio ≥ 100
- > 1 focal lesion on MRI studies (each lesion must be ≥ 5 mm in size)


1 (2015, October 29). International Myeloma Working Group (IMWG) Criteria for the Diagnosis of Multiple Myeloma. Retrieved February 15, 2017, from http://imwg.myeloma.org/international-myeloma-working-group-imwg-criteria-for-the-diagnosis-of-multiple-myeloma/

*Plasma Cell Leukemia*


- Peripheral blood absolute plasma cell count of at least 2.0 × 109/L (2,000 cells/mm3)
- ≥ 20% plasma cells in the peripheral differential white blood cell count.1

*Solitary Plasmacytoma (in absence of bone marrow findings diagnostic for Multiple Myeloma or Plasma Cell Leukemia)*

Extramedullary:


- A small M-protein may be present in serum and/or urine; most commonly IgA
- Extramedullary tumor of clonal plasma cells
- Normal bone marrow
- Normal skeletal survey
- No related organ or tissue impairment (end organ damage including bone lesions)

Bone Derived:


- A small M-protein may be present in serum and/or urine
- Single area of bone destruction due to clonal plasma cells
- Bone marrow not consistent with multiple myeloma
- Normal skeletal survey (and MRI of spine and pelvis if done)
- No related organ or tissue impairment (no end organ damage other than solitary bone lesion)1

*Note: if the recipient has greater than one plasmacytoma but has not been diagnosed with another plasma cell disorder, select “other plasma cell disorder” and specify how many plasmacytomas are present and if each is bone derived or extramedullary.*

*Smoldering Myeloma (asymptomatic)*

Smoldering myeloma is diagnosed in persons who meet the following criteria:


- Serum monoclonal (M) protein >/= 3 g/dL and/or 10-60% clonal plasma cells in the bone marrow.
- Absence of myeloma defining events
- No end organ damage (e.g., hypercalcemia, renal insufficiency, anemia, and bone lesions; CRAB criteria) that can be attributed to the plasma cell proliferative disorder.
- Absence of biomarkers associated with malignancy (i.e., >/= 60% clonal plasma cells in the marrow; involved : uninvolved free light chain ratio >/= 100, or more than one focal bone lesion on MRI).


*Amyloidosis*

Amyloidosis is the buildup of abnormally folded proteins in various tissues of the body. Affected tissues may include the kidneys, heart, liver, gastrointestinal tract, etc. In the most common type of amyloidosis, “AL amyloidosis,” light chains from antibodies function as the amyloid protein, building up within organs and disrupting organ function. Serum and urine tests are useful for evaluating amyloidosis, but a tissue biopsy is the best way to diagnose the condition.

*Osteosclerotic Myeloma/ POEMS Syndrome*

POEMS syndrome is poorly understood, but generally refers to **p** olyneuropathy, **o** rganomegaly, **e** ndocrinopathy, **M** protein, and **s** kin changes. Diagnosis may be made using the following diagnostic criteria:

Mandatory Criteria (both of the following):


- Polyneuropathy (typically demyelinating)
- Monoclonal plasma cell proliferative disorder

Major Criteria (at least one of the following required)


- Castleman disease
- Osteosclerotic bone lesions
- VEGF elevation

Minor Criteria (at least one of the following required):


- Organomegaly (splenomegaly, hepatomegaly, lymphadenopathy)
- Edema (edema, pleural effusion, or ascites)
- Endocrinopathy (adrenal, thyroid‡, pituitary, gonadal, parathyroid, pancreatic‡)
- Skin changes (hyperpigmentation, hypertrichosis, plethora, hemangiomata, white nails)
- Papilledema
- Thrombocytosis

† Osteosclerotic lesion or Castleman disease is usually present.

‡ Because of the high prevalence of diabetes mellitus and thyroid abnormalities, this diagnosis alone is not sufficient to meet this minor criterion.[2](#fn212452402668596ac3dc0f3-2)

1 The International Myeloma Working Group. Criteria for the classification of monoclonal gammopathies, multiple myeloma, and related disorders: a report of the international myeloma working group. Brit J Haematol. 2003;121(5):749-57.

2 Dispenzieri A, Kyle RA, Lacy MQ, et al. POEMS syndrome: definitions and long-term outcome. Blood. 2003;101(7):2496-506.

3 UNC Kidney Center, University of North Carolina. Light Chain Deposition Disease. 5 Apr. 2013. Accessed at: http://www.unckidneycenter.org/kidneyhealthlibrary/lightchain.html Accessibility verified on October 21, 2013

*Monoclonal Gammopathy of Renal Significance (MGRS)*

Monoclonal gammopathy of renal significance (MGRS), similar to monoclonal gammopathies of unknown significance (MGUS), represent a group of disorders in which a monoclonal immunoglobulin is secreted by a non-malignant or pre-malignant B cell or plasma cell clone. MGRS is characterized by demonstrated renal damage attributable to the underlying M-protein, unlike MGUS patients who exhibit no end-organ damage. By definition and classification criteria, these disorders differ from symptomatic myeloma and lymphoproliferative disorders. Patients diagnosed with MGRS are at risk of developing progressive renal disease in addition to other hematologic disorders 4.

*Monoclonal Gammopathy of Undetermined Significance (MGUS)*

MGUS is a clinically asymptomatic premalignant clonal plasma cell or lymphoplasmacytic proliferative disorder. It is defined by the presence of a serum monoclonal protein (M protein) at a concentration <3 g/dL, a bone marrow with < 10% monoclonal plasma cells and absence of end-organ damage (lytic bone lesions, anemia, hypercalcemia, renal insufficiency, hyperviscosity) related to the proliferative process.

1 The International Myeloma Working Group. Criteria for the classification of monoclonal gammopathies, multiple myeloma, and related disorders: a report of the international myeloma working group. Brit J Haematol. 2003;121(5):749-57.

2 The Hematologist: ASH News and Reports. Monoclonal Gammopathy of Renal Significance. 16 Oct. 2018. Accessed at: https://www.hematology.org/Thehematologist/Ask/9059.aspx Accessibility verified on November 4, 2019.

#### Question 2: Specify preceding / concurrent disorder (check all that apply):

Indicate if the recipient had a concurrent or preceding plasma cell disorder. Many recipients progress to symptomatic myeloma from a preceding condition or have a concurrent plasma cell disorder, such as amyloidosis. See the Plasma Cell Characteristics information above for descriptions of disease and below for examples of situations with preceding or concurrent disorders. If the recipient has a preceding or concurrent plasma cell disorder that is not listed, select “other plasma cell disorder (PCD).”

**Example 1.** If a recipient has smoldering myeloma (asymptomatic) and then develops symptomatic multiple myeloma, “multiple myeloma (symptomatic)” should be reported as the primary diagnosis in question 1 and “smoldering myeloma (asymptomatic)” should be reported in question 2.

**Example 2.** If a recipient has smoldering myeloma (asymptomatic) and amyloidosis, “amyloidosis” should be reported as the primary diagnosis in question 1 and “smoldering myeloma (asymptomatic)” should be reported in question 2.

**Example 3.** If the recipient has symptomatic multiple myeloma and amyloidosis, “multiple myeloma (symptomatic)” should be reported as the primary diagnosis in question 1 and “amyloidosis” should be reported as a concurrent diagnosis is question 2.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)