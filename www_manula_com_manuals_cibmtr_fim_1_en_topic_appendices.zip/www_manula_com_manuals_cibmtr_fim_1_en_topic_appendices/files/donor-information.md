#### Question 42: Multiple donors?

Indicate if cells from multiple different donors (multiple CBUs, combinations of other products from different donors) are to be used for this HCT.

For example, supplemental infusions should be included when determining if multiple donors were used for this HCT event. An infusion of supplemental cells is often given in conjunction with a preparative regimen for HCT. A supplemental infusion is defined as an infusion of cells given prior to clinical day 0 (of an HCT) for any reason other than to produce engraftment

For more information on supplemental infusions, see [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

If multiple donors were not used, select **No**.

#### Question 43: Specify number of donors

Report the number of donors used for this HCT. Note that this value should never be “1,” since multiple donors were reported in the prior question.

#### Question 44: Specify donor

Indicate the donor type for this product .

An **Autologous** product has cells collected from the recipient for his / her own use.

An unrelated donor (**Allogeneic, unrelated**) is a donor who shares no known ancestry with the recipient. Include adoptive parents / children or stepparents / children.

A related donor (**Allogeneic, related**) is a blood-related relative. This includes monozygotic (identical twins), non-monozygotic (dizygotic, fraternal, non-identical) twins, siblings, parents, aunts, uncles, children, cousins, half-siblings, etc.

#### Questions 45 – 46: Specify product type (check all that apply)

Select from the list of product type(s) for the donor being reported in this instance.

If **Other product** is indicated, specify the product type. If your center has a protocol where using “other products” is common, consistently report the same text in the specify field so that the “like” products can be grouped together. Do not report the cell type (i.e., CD3+ cells), report the product type.

#### Question 47: Is the product genetically modified?

Genetically modified products include any product where the cells are manipulated via either:


- Gene transfer: a process by which copies of a gene are inserted into living cells in order to induce synthesis of the gene’s product; or
- Transduction: a process by which foreign DNA is introduced into a cell by a virus or viral vector

These techniques alter its gene expression through the insertion of different genes or editing of genes. If more than one product is being infused, indicate if any of the products are genetically modified.

If the infusion is a gene therapy, select **Yes**.

Continue with *Specify the related donor type* if the donor type is a related donor (allogeneic, related).

Continue with *Specify unrelated donor type* if the donor type is an unrelated donor (allogeneic, unrelated).

Continue with *Specify number of products infused from this donor* if the donor type is autologous.

#### Question 48: Specify the related donor type

Indicate the relationship and match between the recipient and the related donor being reported in this instance. When determining the donor’s match / mismatched relationship to the recipient, only consider HLA-A, B, C, and DRB1.

**Syngeneic:**

Includes: Monozygotic (identical) twins. Occurs when a single egg is fertilized to form one zygote, which then divides into two separate embryos.

Does not include: Other types of twins or HLA-identical siblings (see below).

Continue with *Did NMDP facilitate the procurement, collection, or transportation of the product*.

**HLA-identical sibling:**

Includes: Non-monozygotic (dizygotic, fraternal, non-identical) twins. Occurs when two eggs are fertilized by two different sperm cells at the same time. This category also includes siblings who aren’t twins but have identical HLA types. The recipient and donor with be allele level matched at HLA-A, B, C, and DRB1.

Does not include: Half-siblings (report as **HLA-matched other relatives** if their HLA typing is a match, or **HLA-mismatched relative** if it does not match).

Continue with *Did NMDP facilitate the procurement, collection, or transportation of the product*.

**HLA-matched other relative:**

Includes: All blood-related relatives, other than siblings, who are HLA matched (e.g., parents, aunts, uncles, children, cousins, half-siblings). The recipient and donor will be allele level matched HLA-A, B, C, and DRB1.

Does not include: Adoptive parents / children or stepparents / children who are HLA matched.

Continue with *Specify the biological relationship of the donor to the recipient*.

**HLA-mismatched relative:**

Includes: Siblings who are not HLA-identical and all other blood-related relatives who have at least one HLA mismatch (mismatch can be at the antigen or allele level) (e.g., parents, aunts, uncles, children, cousins, half-siblings). The recipient and donor will be antigen or allele level mismatched at 1 or more loci (HLA-A, B, C, or DRB1).

Does not include: Adoptive parents / children or stepparents / children.

This is the option that should be used for haploidentical transplants.

Continue with *Specify the biological relationship of the donor to the recipient*.

#### Questions 49 – 50: Specify the biological relationship of the donor to the recipient

Indicate the relationship between the recipient and the related donor being reported in this instance. If the donor is **Other biological relative**, specify the donor’s relationship to the recipient.

#### Question 51: Degree of mismatch (related donors only)

If the donor being reported in this instance is an HLA-mismatched relative, indicate the degree of mismatch as either **HLA-mismatched 1 allele** or **HLA-mismatched ≥ 2 alleles (does include haploidentical donor)**.

Haploidentical means that one half of the HLA type matches the recipient. This type of HLA mismatch is common between blood-related parents and children. When determining the donor’s matched/mismatched relationship to the recipient, only consider HLA-A, B, C and DRB1.

#### Question 52: Specify unrelated donor type

Indicate the unrelated donor type. When determining the donor’s match/mismatched relationship to the recipient, only consider HLA-A, B, C, and DRB1.

#### Question 53: Did NMDP / Be The Match facilitate the procurement, collection, or transportation of the product?

Determine if the NMDP (previously known as NMDP or Be The Match) facilitated the procurement, collection, and / or transportation of the product (i.e., the product from the donor being reported in this instance is an NMDP product or a non-NMDP product). Examples of non-NMDP donor registries include but are not limited to St. Louis Cord Blood Bank, Anthony Nolan, and StemCyte International Cord Blood Center. This information is included on the product label, the paperwork accompanying the product, and within the NMDP search/product documentation.

If the documentation is unclear if NMDP facilitated the procurement, collection, and / or transportation of the product, seek clarification from the transplant coordinator.

If the recipient received a product facilitated by NMDP select **Yes** and then either report the NMDP cord blood unit ID or the GRID. Additionally, ensure the NMDP RID is reported on the CRID Assignment (2804) Form. For products facilitated by NMDP, the Registry or UCB Bank ID question will be disabled, and the Infectious Disease Markers (2004) and HLA Typing (2005) forms will not come due.

Below is a list of donor registries who were once “non-NMDP” registries but may now be an “NMDP-facilitated” registry:


- Matchis Foundation 71 (Netherlands)
- Hadassah Medical Organization 72 (Israel)
- Knochenmarkspenderzentrale – Dusseldorf 114 (Germany)
- The Tobias Registry of Swedish Bone Marrow Donors 119 (Sweden)
- The Norwegian Bone Marrow Donor Registry 120 (Norway)
- Welsh Bone Marrow Donor Registry 131 (Wales)
- British Bone Marrow Registry 134 (United Kingdom)
- Anthony Nolan 135 (United Kingdom)
- ZKRD 136 (Germany)

#### Question 54: Was this donor used for any prior HCTs? (for this recipient)

Indicate if the current donor for this HCT was used for any prior HCTs for this recipient. If this is the recipient’s first HCT, select **No**.

If this is an autologous infusion, select **No**.

#### Question 55: Global Registration Identifier for Donors (GRID)

The Global Registration Identifier for Donors (GRID) was developed by the WMDA to ensure secure, reliable and unambiguous assignment of donors. The GRID standard is a 19-character donor identifier composed of three elements: Issuing Organization Number (ION), Registration Donor Identifier, and Checksum (shown below). This standard will ensure each donor ID is globally unique and will reduce the risk of misidentification of donors or their donations.


https://www.wmda.info/professionals/optimising-search-match-connect/why-global-identifier/

If the product is not NMDP facilitated (PBSC or marrow product), indicate the GRID number and continue with *Registry or UCB Bank ID*.

If the product is NMDP facilitated (PBSC or marrow product), indicate the GRID number and continue with *Donor CMV-antibodies (IgG or Total)*.

#### NMDP cord blood unit ID

Report the NMDP Donor ID (e.g., 0000-0000-0). This ID is unique for each donor and is assigned by NMDP. This information is included on the product label, the paperwork accompanying the product, and within the NMDP search / product documentation.

#### Question 57: Registry donor ID (not applicable for related donors)

Report the non-NMDP unrelated donor ID. Examples of non-NMDP donor registries include Australia Bone Marrow Donor Registry and REDOME. This ID may be located on the product label, the paperwork accompanying the product, and registry-specific search / product documentation.

#### Question 58: Non-NMDP cord blood unit ID (include related and autologous CBUs)

Report the non-NMDP cord blood unit ID. Examples of non-NMDP donor registries include St. Louis Cord Blood Bank and StemCyte International Cord Blood Center. This ID is often located on the product label, the paperwork accompanying the product, and registry-specific search / product documentation.

Note that some cord blood banks can ship their units either through the NMDP or directly to the transplant center. Carefully review the accompanying documentation to determine which is appropriate for your unit. You may wish to consult with your center’s Transplant Coordinator, as he or she will have insight as to how the product was acquired.

#### Question 59: Is the CBU ID also the ISBT DIN number?

Report Yes if the non-NMDP CBU ID is the same as the International Society of Blood Transfusion (ISBT) Donation Identification Number (DIN) and continue with question 61. If the product has an ISBT label on it, the ISBT DIN number is in the upper-left-hand corner and consists of a letter followed by 12 numbers, two sideways numbers, and a letter in a box. Example below:


Please find additional information regarding the ISBT DIN numbers and traceability [here](https://www.isbt128.org/_files/ugd/83d6e1_1b3f6d518990430fa36ee5d8d2c14de9.pdf). For example, you may see a barcode with an alphanumeric string below it.

If the CBU ID is not the same as the ISBT DIN number, or it is not known, select **No**.

#### Question 60: Specify the ISBT DIN number:

Report the ISBT DIN number using the letter, 12 digits, 2 sideways numbers, and the letter in the box.

#### Question 61: Registry or UCB Bank ID

Specify the registry used to obtain the adult donor or umbilical cord blood unit and continue with question 68. The Bone Marrow Donors Worldwide (BMDW) codes have been adopted to avoid submitting the entire name and address of the donor registry. Some common banks that do not list with BMDW have been added to the FormsNet list, including St Louis Cord Blood Bank (SLCBB) and Viacord (VIAC).

The registry code for NMDP donors is USA1 and for NMDP cord units is U1CB.

If the donor was found through DKMS, report the registry that facilitated the HCT. Some registries may be listed more than once with BMDW (one way for marrow/PBSC products and differently for cord blood products). Ensure that the appropriate code for the product was selected because distribution of data depends on the code.

If the registry code cannot be determined using the BMDW website, select **Other registry**.

#### Question 62: Specify other Registry or UCB Bank

If the BMDW website does not list a match code for the adult donor registry or cord blood bank, provide the registry’s official name in *Specify other Registry or UCB Bank*.

Ensure the registry entered is not already listed in the pull-down list for *Registry or UCB Bank ID* question. For example, NMDP adult donors, NMDP cords, and New York Cord Bank each have their own entries above in the registry or UCB Bank ID drop down menu.

#### Questions 63 – 64: Donor date of birth

Report if the donor’s / infant’s date of birth is **Known** or **Unknown**. If the donor’s / infant’s date of birth is **Known**, report the date of birth (YYYY-MM-DD).

#### Questions 65 – 66: Donor age

Report if the donor’s / infant’s age is **Known** or **Unknown**. If the donor’s/infant’s age is **Known**, report the donor’s/infant’s age at the time of product collection. Report the age in months if the donor is less than 1 year old, otherwise report the age in years.

#### Question 67: Donor sex

Indicate the donor’s biological sex as **Male** or **Female**. For cord blood units, report the infant’s sex.

#### Question 68: Specify blood type (donor) (non-NMDP allogeneic donors only)

Indicate the donors’ blood type as **A**, **B**, **AB**, or **O**. Blood type is an important characteristic in allogeneic transplant because products may require manipulation to minimize the risk of immune reaction due to incompatibility.

#### Question 69: Specify Rh factor (donor) (non-NMDP allogeneic donors only)

Indicate the donor’s Rh (rhesus) factor. The Rh factor is an important characteristic in allogeneic transplant because product may require manipulation to minimize the risk of immune reaction due to incompatibility.

#### Question 70: Donor CMV-antibodies (IgG or Total) (Allogeneic HCTs only)

CMV is a common virus that infects 50-80% of adults worldwide and is transmitted from person to person through bodily fluids. The virus that causes CMV is part of the herpes virus family and, like other herpes viruses, CMV may be dormant for a period of time before the virus is activated in the host. CMV infections are usually harmless in a healthy immune system and typically cause only mild symptoms, if any. However, if a person’s immune system is seriously weakened (as in an immunosuppressed stem cell recipient) the virus can have serious consequences such as pneumonia, liver failure, and even death.

Most laboratory reports indicate a positive result as *reactive*, and a negative result as *non-reactive*. Occasionally, laboratory reports show a specific antibody titer. In this case, compare the laboratory result to the reported standards to determine if the result was reactive or non-reactive.

If the laboratory reports the results as “inconclusive” or “equivocal,” select **Indeterminant**.

If the laboratory reports a CMV IgM antibody only, not total IgG/IgM or CMV IgG antibody; report the result as **Not done**.

If the laboratory reports CMV testing by PCR (DNA detection), report the result as **Not done**. CMV testing by PCR is used to detect the presence of the CMV virus and does not test for prior exposure.

Indicate the test result documented on the laboratory report as either **Reactive**, **Non-reactive**, **Indeterminant**, **Not done**, or **Not applicable (cord blood unit)**.

#### Question 71: Has the donor signed and IRB / ethics committee (or similar body) approved consent form to donate research blood samples to the NMDP / CIBMTR? (Related donors only)

Indicate if the related donor signed an IRB-approved consent form to donate research blood samples to the CIBMTR.

#### Questions 72: Date form signed

Report the date (YYYY-MM-DD) the research sample consent form was signed by the related donor. Do not report the date that the witness or healthcare professional signed the consent form.

#### Questions 73 – 74: Did the donor submit a research sample to the NMDP / CIBMTR repository? (Related donors only)

There are a select number of transplant centers participating in the Related Sample Repository. If your center is one of the participating centers, and the donor provided a research sample, select **Yes** and provide the donor’s sample ID. The ID number is located on the bar code that is attached to the sample tube.

If the donor did not provide a research sample, select **No**.

#### Question 75: Specify number of products infused from this donor

Report the number of products infused from the donor being reported for this infusion. See below for examples of HCT versus gene therapy products..

**HCT**

Single Product: CIBMTR defines a single product (i.e., cellular product) as **cells collected from a single donor using the same mobilization cycle and collection method regardless of the number of collection days.**

**Example 1 (multiple bags):** A G-CSF stimulated donor had two PBSC collections on subsequent days. The products collected over the two days were divided into four bags. Although the product is contained in multiple bags, this collection is considered a single product, as there was no change in mobilization technique or collection method.

**Example 2 (change in mobilization):** A G-CSF stimulated donor had a PBSC collection, but the cell count was poor. Plerixafor (Mozobil) was added as part of the mobilization and the donor was re-collected the following day. As the change in mobilization occurred during the same mobilization cycle, these collections are considered a single product.

Multiple Products: For the purposes of this manual, the CIBMTR defines multiple products as cells collected using more than one mobilization technique and / or collection method.

**Example 3 (multiple collection methods):** A G-CSF-stimulated donor had a PBSC collection and the product was cryopreserved. One month later the donor had a marrow collection; both products were infused at the time of transplant. Each collection is considered a separate product because different collection methods were used. The number of products infused from this donor is two.

**Example 4 (re-mobilization):** A G-CSF-stimulated donor had a PBSC collection, but the cell count was poor. No further collections were attempted and a week later the donor was re-mobilized with G-CSF and a second PBSC collection was performed. Each collection is considered a separate product due to the re-mobilization of the donor.

**Example 5 (two different product types):** A cord blood unit is infused at the same time as marrow. Each product type is considered a separate product. The number of products infused is two.

**Gene therapy**

p(. **Example 6 (single product):** a single mobilization event, even when collected over several days

**Example 7 (single product):** A recipient may require multiple mobilizations, and possibly multiple manufacturing steps, for the final product intended for infusion. It should be considered a single gene therapy product, regardless of how many mobilizations or steps required for manufacturing.

#### Question 76: Specify the number of these product intended to achieve hematopoietic engraftment

If infusions of additional cells (not intended to product engraftment) were given as a supplemental infusion either prior to the HCT being reported (i.e., prior to clinical Day 0) or shortly after the HCT being reported, the cells must be reported as a product on the Pre-TED Form (2400) form and on a separate Cellular Therapy Product (4003) form.

If additional cells were infused post-HCT, for any reason other than a subsequent HCT or a supplemental infusion as part of the HCT, they should be reported as cellular therapy on the appropriate follow-up form. Reporting the additional cells (given pre-HCT and not intended to produce engraftment) on the Form 4003 is the only mechanism the CIBMTR has in place to collect this data and ensure that the quality assurance data is reported to the cord blood banks, if applicable.

Report the number of products administered to achieve hematopoietic engraftment.

#### Questions 77 – 78: What agents were used to mobilize the autologous recipient for this HCT? (check all that apply)

Report if any of the following agents listed were used in the mobilization event(s).

**G-CSF:**granulocyte colony-stimulating factor, filgrastim, Neupogen®**Pegylated G-CSF:**pegfilgrastim, Neulasta®**Perlixafor:**Mozobil®**Combined with chemotherapy:**Systemic therapies used to enhance the stem cell product may include cyclophosphamide or ICE chemotherapy (Ifosfamide, carboplatin, and etoposide) with or without rituximab.**Anti-CD20:**rituximab, Rituxan®**Other agent**: If an agent was used but not listed above, select Other agent and specify.

#### Questions 79 – 80: Name of product (gene therapy recipients)

Report the name of the product. If the name is not listed, select **Other name** and specify the gene therapy product name.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 75 | 4/18/25 | Modify | Examples of single vs multiple products have been updated to include gene therapy examples. See added example 6 & 7 | The definition of a gene therapy product has been updated |
| Q42 | 7/26/2024 | Add | Orca Bio Products and Donor Information blue box added above Q42: Orca Bio Products and Donor Information: Refer to the Orca Bio Reporting Guide, located on the CIBMTR Portal , to determine how to report donor information for Orca Bio products. |
Orca Bio Reporting Guide now available |
| Q42 | 7/26/2024 | Remove | Omidubicel and Orca-T Products blue box updated above Q42 to clarify instructions are only applicable for Omidubicel: Omidubicel : If the product is Omidubicel No for multiple donors. |
Orca Bio Reporting Guide now available |
| Q42 | 3/8/2024 | Add | Omidubicel and Orca-T Products blue box added above Q42: Omidubicel and Orca-T Products: If the product is Omidubicel or Orca-T, select No for multiple donors. |
Added for product specific reporting |
| Q45 | 7/26/2024 | Remove | Omidubicel and Orca-T Products blue box updated above Q45 to clarify instructions are only applicable for Omidubicel: Omidubicel : If the product is Omidubicel, report the product type as CBU. BM |
Orca Bio Reporting Guide now available |
| Q45 | 3/8/2024 | Add | Omidubicel and Orca-T Products blue box added above Q45: Omidubicel and Orca-T Products: If the product is Omidubicel, report the product type as CBU. If the product is Orca-T, report the product type as BM. |
Added for product specific reporting |
| Q45 | 12/4/2023 | Remove | Removed the Cord Blood Units and Ex-vivo Expansion blue box: Cord Blood Units and Ex-vivo Expansion If the product is a cord blood unit that was ex-vivo expansion was performed, select Other product and specify ‘ex-vivo cord blood unit’ along with the method of expansion (examples of expansion methods include, but are not limited to, with Omidubicel, with UM171, or on mesenchymal stem cells). |
Due to CIBMTR Cord Blood Quality Reports requirements |
| Q45 | 5/1/2023 | Add | Cord Blood Units and Ex-vivo Expansion blue box added: Cord Blood Units and Ex-vivo Expansion If the product is a cord blood unit that was ex-vivo expansion was performed, select Other product and specify ‘ex-vivo cord blood unit’ along with the method of expansion (examples of expansion methods include, but are not limited to, with Omidubicel, with UM171, or on mesenchymal stem cells. |
Instructions added to explain how to report ex-vivo expansion of CBUs |
| Q47 | 7/26/2024 | Remove | Omidubicel and Orca-T Products blue box updated above Q47 to clarify instructions are only applicable for Omidubicel: Omidubicel : If the product is Omidubicel No, the product was not genetically modified. |
Orca Bio Reporting Guide now available |
| Q47 | 3/8/2024 | Add | Omidubicel and Orca-T Products blue box added above Q47: Omidubicel and Orca-T Products: If the product is Omidubicel or Orca-T, report No, the product was not genetically modified. |
Added for product specific reporting |
| Q47 | 10/25/2023 | Modify | Navigation instructions updated: Continue with Specify number of products infused from this donor |
Incorrect ‘go-to’ navigation |
| Q75 | 4/19/2025 | Add | Gene therapy examples 6 and 7 added: Example 6 (single product): a single mobilization event, even when collected over several days Example 7 (single product): A recipient may require multiple mobilizations, and possibly multiple manufacturing steps, for the final product intended for infusion. It should be considered a single gene therapy product, regardless of how many mobilizations or steps required for manufacturing. |
Added for product specific reporting |
| Q75 | 7/26/2024 | Remove | Omidubicel and Orca-T Products blue box updated above Q75 to clarify instructions are only applicable for Omidubicel: Omidubicel and : If the product is Omidubicel, report the number of products from the donor as two. three. |
Orca Bio Reporting Guide now available |
| Q75 | 3/8/2024 | Add | Omidubicel and Orca-T Products blue box added above Q75: Omidubicel and Orca-T Products: If the product is Omidubicel, report the number of products from the donor as two. If the product is Orca-T, report the number of products from the donor as three. |
Added for product specific reporting |
| Q76 | 7/26/2024 | Remove | Omidubicel Omidubicel and : If the product is Omidubicel, report the number of products intended to achieve hematopoietic engraftment as two and complete two HCT Product and Infusion (2006) forms. one and complete one HCT Product and Infusion (2006) forms and two Cellular Therapy Product (4003) forms. |
Orca Bio Reporting Guide now available |
| Q76 | 3/8/2024 | Add | Omidubicel and Orca-T Products blue box added above Q76: Omidubicel and Orca-T Products: If the product is Omidubicel, report the number of products intended to achieve hematopoietic engraftment as two and complete two HCT Product and Infusion (2006) forms. If the product is Orca-T, report the number of products intended to achieve hematopoietic engraftment as one and complete one HCT Product and Infusion (2006) forms and two Cellular Therapy Product (4003) forms. |
Added for product specific reporting |
| Q79-80 | 7/28/2023 | Add | Instructions updated on how to report product name due to specific products being added to the form: Report the name of the product. If the name is not listed, select Other name and specify the gene therapy product name. |
Due to Summer 2023 Quarterly Release – additional response options added |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)