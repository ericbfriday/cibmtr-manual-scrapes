#### Question 1: What is the diagnosis?

Waldenström’s macroglobulinemia (WM) and lymphoplasmacytic lymphoma (LPL) are two closely related neoplasms. They are both characterized by an abnormal population of small B-cells, lymphoplasmacytoid cells, and plasma cells. WM is characterized by an IgM paraprotein and bone marrow involvement, whereas these two features may be absent in LPL.[1](#fn201057664468596a7131678-1)

Indicate if the patient was diagnosed with WM or LPL.

1 World Health Organization. (2008). *WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues* (4th ed.). Lyon, France.

#### Question 2: What was the date of diagnosis?

Report the date of the first pathological diagnosis (e.g., bone marrow biopsy) of WM or LPL. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared. The date of diagnosis is important because the interval between diagnosis and HCT is often a significant indicator for the recipient’s prognosis post-HCT.

If the exact pathological diagnosis date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)