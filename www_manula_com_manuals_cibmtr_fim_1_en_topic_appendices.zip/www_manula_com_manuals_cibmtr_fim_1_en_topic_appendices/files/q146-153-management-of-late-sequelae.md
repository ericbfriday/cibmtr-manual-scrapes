#### Question 146: Was management of late sequelae required?

Report treatment for any complications associated with the diagnosis of VOD/SOS. Common treatments/procedures have been defined below.

#### Question 147-153: Specify

**Variceal banding**: An endoscopic procedure to place a band around a vessel to restrict flow in order to treat portal hypertension.

**Transjugular Intrahepatic Portosystemic Shunt (TIPS)**: An artificial tube is used to connect the portal vein to the hepatic vein in order to treat portal hypertension.

**Paracentesis**: A needle or catheter is inserted to remove ascites fluid from the peritoneal cavity in order to treat associated pressure and other complications. This is a typical treatment for ascites.

**Thoracentesis**: A needle is used to remove excess fluid from the pleural cavity in order to treat associated pressure and other complications. This is a typical treatment for ascites.

**Dialysis dependent**: Regular dialysis treatments to address chronic renal failure. Report “yes” for recipients receiving regular dialysis treatments.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)