### Reporting the International System of Human Cytogenetic Nomenclature (ISCN) Compatible String in FormsNet3SM

CIBMTR is licensing a software program developed by Washington University School of Medicine in St. Louis, called CytoGenetic Pattern Sleuth (CytoGPS) to validate the International System of Human Cytogenetic Nomenclature (ISCN) compatible string data field. This program utilizes the 2016 edition of the International System of Human Cytogenomic Nomenclature (ISCN 2016).

As of July 28, 2023, the International System of Human Cytogenetic Nomenclature (ISCN) compatible string is enabled for karyotyping on the Disease Classification (2402) Form for AML, ALL, MDS, MPN, and PCD. As of December 8, 2023, this data field is also enabled for the following disease-specific forms:

- MDS Pre-Infusion (2014) and MDS Post-Infusion (2114) Forms
- PCD Pre-Infusion (2016) Form
- Aplastic Anemia Pre-Infusion (2028) and Aplastic Anemia Post-Infusion (2128) Forms
- MPN Pre-Infusion (2057) and MPN Post-Infusion (2157) Forms

This data field is not enabled for FISH.

Depending on the lab used, karyotype results may not be structured using the ISCN nomenclature. Additionally, karyotype results may have an error or typo, causing the karyotype string to not be valid within ISCN nomenclature.

Review the sections below for information on to use the ISCN functionality, common errors, and how to resolve them.

Links to Sections

[Entering the ISCN Compatible String](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/valid-iscn-compatible-string)

[Common Errors](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/common-errors)

[Reporting at the In Between Timepoint](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/reporting-at-the-in-between-timepoint)

[Additional Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/additional-information)

**Section Updates:**

| Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|
| 7/26/2024 | Add | Information added to clarify additional forms have the ISCN functionality enabled as of 12/8/2023 | Added for clarification |
| 7/28/2023 | Add | Appendix C: Cytogenetics re-vamped. ISCN Functionality added with version 3 of Appendix C | Added with release of ISCN Functionality in the Summer 2023 release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)