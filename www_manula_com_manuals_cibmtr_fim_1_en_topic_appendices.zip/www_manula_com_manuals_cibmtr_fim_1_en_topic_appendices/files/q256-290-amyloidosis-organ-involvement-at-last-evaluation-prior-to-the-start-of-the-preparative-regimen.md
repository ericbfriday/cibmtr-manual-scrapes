# Q255-289: Amyloidosis Organ Involvement at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion

#### Question 255: Was the left ventricular ejection fraction measured?

Question 255: Was the left ventricular ejection fraction measured?

The left ventricular ejection fraction (LVEF) is a percentage that represents the volume of blood pumped from the left ventricle into the aorta (also known as stroke volume) compared to the volume of blood in the ventricle just prior to the heart contraction (also known as end diastolic volume). Indicate **Yes** or **No** if the left ventricular ejection fraction (LVEF) was measured at the last evaluation prior to the start of the preparative regimen. If **No**, continue with question 258.

#### Question 256: Left ventricular fraction

Indicate the left ventricular ejection fraction at the last evaluation prior to the start of the preparative regimen. Most imaging reports will report the LVEF. If the LVEF is not explicitly documented it should be determined by dividing the stroke volume (SV, the volume of blood pumped into the aorta from the left ventricle) by the end diastolic volume (EDV, the volume of blood in the left ventricle just prior to contraction) of the left ventricle. For example, if the stroke volume was 75 ml and the end diastolic volume was 150 ml, the ejection fraction would be 50%.

#### Question 257: Specify the method used to determine the left ventricular ejection fraction

Indicate the method used to determine the reported LVEF.

#### Question 258: Was diastolic dysfunction present?

Diastole is the period in which chambers of the heart fill with blood. Diastolic dysfunction may be characterized by the difficulty of the ventricles to expand and contract appropriately due to stiffening of the heart walls by amyloid deposits. Indicate **Yes**, **No**, or **Unknown** if diastolic dysfunction was present at the last evaluation prior to the start of the preparative regimen.

#### Questions 259 – 260: Specify the intraventricular septal wall thickness measured by echocardiogram

The heart is divided into the right and left sides by the septum. The area between the left and right ventricles is the intraventricular septum. Indicate if the intraventricular septal thickness is **Known** or **Unknown**. If **Known**, based on evaluation by echocardiogram, indicate the thickness of the intraventricular septal wall in millimeters. If **Unknown** or not measured by echocardiogram, continue with question 261.

#### Questions 261 – 262: Specify left ventricular (LV) strain percentage

A strain pattern, as determined by electrocardiography, is a well-recognized marker of hypertrophy of the left ventricular (LVH) and is characterized by ST depression and T wave inversion on a resting ECG / EKG. The LV strain percentage is typically a negative percentage. The normal range for the LV global longitudinal strain (LV GLS) is -15.9% to -22.1%. Indicate if the left ventricular strain percentage is **Known** or **Unknown**. If **Known**, based on evaluation by electrocardiogram, indicate the strain percentage. If **Unknown**, or not measured by electrocardiogram, continue with question 263.

#### Questions 263 – 264: Were any serum cardiac biomarkers assessed?

Assessment of cardiac biomarkers helps determine if injury to cardiac tissue has occurred. Cardiac biomarkers include brain natriuretic peptide (BNP), N-terminal prohormone brain natriuretic peptide (NT-proBNP), Troponin I, and Troponin T. Indicate if serum cardiac biomarkers were assessed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the date assessed. If **No** or **Unknown**, continue with question 280.

#### Questions 265 – 267: Brain natriuretic peptide (BNP)

Indicate if the BNP was assessed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the value (in pg/mL) and specify the upper limit of normal. If **No**, continue with question 268.

#### Questions 268 – 270: N-terminal prohormone brain natriuretic peptide (NT-proBNP)

Indicate if the NT-proBNP was assessed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the value (in pg/mL) and specify the upper limit of normal. If **No**, continue with question 271.

#### Questions 271 – 273: Troponin I

Indicate if the Troponin I was assessed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the value (in µg/L) and specify the upper limit of normal. If **No**, continue with question 274.

#### Questions 274 – 276: Troponin T

Indicate if the Troponin T was assessed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the value (in µg/L) and specify the upper limit of normal. If **No**, continue with question 277.

#### Questions 277 – 279: High-sensitivity troponin T

Indicate if the high-sensitivity troponin T was assessed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the value (in ng/L) and specify the upper limit of normal. If **No**, continue with question 280.

#### Questions 280 – 281: Was a 6-minute walk test performed?

A 6-minute walk test is used to assess total distance walked within 6 minutes to determine aerobic capacity and endurance. Indicate if a 6-minute walk test was performed at the last evaluation prior to the start of the preparative regimen. If **Yes**, report the total distance walked and specify the unit of measure. If **No**, continue with question 282.

#### Question 283: Specify the recipient’s New York Heart Association functional classification of heart failure: (Symptoms may include dyspnea, chest pain, fatigue, and palpitations; activity level should be assessed with consideration for patient’s age group)

Indicate the recipient’s New York Heart Association functional classification at the last evaluation prior to the start of the preparative regimen using the following guidelines:


**Class I**– Able to perform ordinary activities without symptoms; no limitation of physical activity**Class II**– Ordinary physical activity produces symptoms; slight limitation of physical activity**Class III**– Less-than-ordinary physical activity produces symptoms; moderate limitation of physical activity**Class IV**– Symptoms present even at rest; severe limitation of physical activity

If the recipient’s NYHA functional classification it not known, select **Unknown**.

#### Questions 283 – 285: Recipient blood pressure (at last assessment prior to the start of the preparative regimen)

Indicate if the recipient’s blood pressure was assessed at the last evaluation prior to the start of the preparative regimen. If **Known**, report the recipient’s blood pressure at the last evaluation and indicate in which body position the measurement was taken.

If **Unknown**, continue with question 286.

#### Question 286: Was hepatomegaly present on radiographic imaging (liver span > 15 cm) or on examination (liver edge palpable > 3 cm below right costal margin)?

At the last evaluation prior to the start of the preparative regimen, indicate if the liver spanned more than 15 cm (by radiographic imaging) or the edge of the liver was palpable more than 3 cm below the right costal margin (by physical examination). If hepatomegaly was present, select **Yes**. If hepatomegaly was not present or it is not possible to determine the presence or absence of hepatomegaly, select **No** or **Unknown**, respectively.

#### Questions 287 – 289: Specify the level of serum alkaline phosphatase

Indicate whether the alkaline phosphatase (ALP) level at the last evaluation prior to the start of the preparative regimen is **Known** or **Unknown**. If **Known**, report the laboratory count, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 290.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)