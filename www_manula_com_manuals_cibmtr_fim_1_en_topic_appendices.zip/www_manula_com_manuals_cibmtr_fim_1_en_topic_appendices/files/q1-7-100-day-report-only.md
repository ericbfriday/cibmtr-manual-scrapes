The date of actual contact with the recipient to determine medical status for this follow-up report is based on a medical evaluation conducted by a clinician with responsibility for the recipient’s care. Report the date of the medical evaluation performed closest to the designated time period of the form (e.g., Day+100, 6 months, or annual follow-up visit). Time windows are provided to guide selection of dates for reporting purposes. Recipients are not always seen within the time windows used for reporting follow-up dates, and some discretion is therefore required when determining which date to report. If the recipient is not seen within the time windows, report the date closest to the date of contact within reason.

If the Post-TED Form reports a subsequent infusion (transplant or genetically modified cellular therapy), report the date of latest follow-up as the day prior to the start of the preparative regimen / systemic therapy. If no preparative regimen or conditioning / systemic therapy was given, report the day prior to infusion as the date of contact.

#### Question 1: Date of actual contact with the recipient to determine medical status for this follow-up report

Enter the date of actual contact with recipient to determine medical status for this follow-up report. Acceptable evaluations include those from the transplant center, referring physician, or other physician currently assuming responsibility for the recipient’s care. Please capture a physician evaluation that falls within the appropriate range, if possible, rather than other types of patient contact that may be closer to the actual time point. If an evaluation was not performed at Day+100, at 6 months, or on the HCT anniversary, choose the date of the visit closest to the actual time point.

If the recipient has not been seen by a clinician during the reporting period but the survival status is known, complete the Survival Tool referenced in the CIBMTR Data Management Guide, found [here](http://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/survival-form-status).

In general, the date of contact should be reported as close to the 100-day, 6 month, or annual anniversary to transplant as possible. Report the date of actual contact with the recipient to evaluate medical status for the reporting period. In the absence of contact with a clinician, other types of contact may include a documented phone call with the recipient, a laboratory evaluation, or any other documented recipient interaction on the date reported. If there was no contact on the exact time point, choose the date of contact closest to the actual time point. Below, the guidelines show an ideal approximate range for reporting each post-transplant time point:

| Time Point | Approximate Range |
|---|---|
| 100 days | +/- 15 days (Day 85-115) |
| 6 months | +/- 30 days (Day 150-210) |
| 1 year | + 60 days (Day 366 – 425) |
| Annual reporting 2+ years | +/- 30 days (Months 23-25, 35-37, etc.) |

Recipients are not always seen within the approximate ranges and some discretion is required when determining the date of contact to report. In that case, report the date closest to the date of contact within reason. The examples below assume that efforts were undertaken to retrieve outside medical records from the primary care provider, but no documentation was received.

**Date of Contact & Death**

In the case of recipient death, the date of death should be reported as the date of contact regardless of the time until the ideal date of contact. The date of death should be reported no matter where the death took place (inpatient at the transplant facility, at an outside hospital, in a hospice setting, or within the recipient’s home).

If the death occurred at an outside location and records of death are not available, the dictated date of death within a physician note may be reported. If the progress notes detailing the circumstances of death are available, request these records. These records are useful for completing required follow-up data fields and the cause of death data fields on this form. If the exact date of death is not known, use the processed described for reporting partial or unknown dates, see General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Date of Contact & Subsequent Infusion**

If the recipient has a subsequent infusion (HCT or cellular therapy), the date of contact will depend on the type of subsequent infusion. If the subsequent infusion is an HCT or genetically modified cellular therapy (e.g. CAR-T), report the date of contact as the day before the preparative regimen / lymphodepleting therapy begins for the subsequent infusion. If no preparative regimen / lymphodepleting therapy is given, report the date of contact as the day before the subsequent infusion. In these cases, actual contact on that day is **not** required, and the day prior to the initiation of the preparative regimen (or infusion, if no preparative regimen / lymphodepleting therapy) should be reported. This allows every day to be covered by a reporting period but prevents overlap between infusion events. If the subsequent infusion is a non-genetically modified (e.g. DLI) cellular therapy infusion, report the date of contact as appropriate to the reporting period.

Review the [Contact Dates Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/contact-dates) for additional information on reporting contact dates for recipient death, subsequent infusions, and various contact date reporting examples.

#### Question 2: Specify the recipient’s survival status at the date of last contact

Indicate the clinical status of the recipient on the date of actual contact for follow-up evaluation.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)