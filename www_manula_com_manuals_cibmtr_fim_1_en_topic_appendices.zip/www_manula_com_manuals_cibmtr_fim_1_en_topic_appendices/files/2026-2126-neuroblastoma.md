Neuroblastoma is an extracranial solid malignancy that predominately affects children between the ages of 1 and 51. The malignant cells arise from neuroblasts of the neural crest; precursors of the sympathetic nervous system. The abdomen is the most common site of primary tumor, either in the adrenal medulla or paraspinal sympathetic ganglia. Other sites of origin can include the neck, chest, and pelvis. Neuroblastomas typically metastasize from the site of origin to lymph nodes, bone, and bone marrow. A distinct pattern of metastasis to the liver and skin, resulting in visible blue nodules, can also occur.2

Neuroblastoma is typically diagnosed by histopathologic findings, tumor marker analyses, and imaging studies. Small, undifferentiated neuroblasts with dark nuclei that can form distinct cellular clusters termed Horner-Wright rosettes are typical of neuroblastoma tumor tissue. If the bone marrow is affected, neuroblastoma cells may also be identified in a bone marrow biopsy.3

Tumor markers, also known as biomarkers, are substances produced by cancer tissue or by the body in response to cancer at higher than normal levels. In certain situations, these substances can be used to detect and monitor disease due to their elevated presence in blood, urine, and/or tissue. A majority of neuroblastoma tumors produce excess amounts of catecholamines such as epinephrine/adrenaline. Catecholamine metabolites, including homovanillic acid (HVA) and vanilmandelic acid (VMA) are excreted in the urine and may serve as tumor markers. As a result, elevated levels of HVA and VMA detected by urinary analysis can be indicative of neuroblastoma.4

Relevant imaging studies include CT, MRI, ultrasound, scintigraphy, and skeletal surveys. A multimodal approach helps stage the disease at diagnosis, monitor progression, and response to treatment. The most common scintigraphic studies for patients with neuroblastoma are I-MIBG, Tc-MDP and 18F-FDG PET scans.5, 6, 9

The etiology of neuroblastoma is unknown, and it has a diverse clinical course. In certain cases, generally those with early disease onset (<1 year of age), spontaneous regression the disease without treatment is possible. however, rapid progression despite intensive therapy can occur in patients with neuroblastoma (generally>1 year of age).

Classification systems have been developed to better understand this diverse clinical behavior, and to establish more effective treatment guidelines. The Shimada Classification, Pediatric Oncology Group, and International Staging System correlates biological and clinical factors with risk groups.7 For example; amplification of the proto-oncogene MYCN is associated with more aggressive disease and a poorer outcome. Structural changes in chromosomes, including 1p or 11q deletion, and/or unbalanced gain of 17q are also associated with a poorer outcome.8,9 Additional molecular and histological prognostic correlations have been identified; however, further elucidation is necessary to fully understand the pathogenesis and natural history of neuroblastoma

[Neuroblastoma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/neuroblastoma-response-criteria)

[2026: Neuroblastoma Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2026-neuroblastoma-pre-infusion)

[2126: Neuroblastoma Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2126-neuroblastoma-post-infusion)

1 ,3,6Papaioannou G and McHugh K. Neuroblastoma in childhood: review and radiological findings. Cancer Imaging, 2005;5:116-127.

2,8 Brodeur, G. Neuroblastoma: Biological Insights into a Clinical Enigma. Nature Reviews Cancer, 2003;3:203-216.

4 Erdelyi DJ, Elliot M, and Phillips B. Urine catecholamines in paediatrics. Arch Dis Child Educ Pract Ed, 2011;96:107-111.

5 Chu CM, Rasalkar DD, Hu YJ, et al. Clinical presentations and imaging findings of neuroblastoma beyond abdominal mass and a review of imaging algorithm. The British Jounral of Radiology, 2011;84:81-91.

7,9 Weinstein JL, Katzenstein HM, and Cohn SL. Advances in the Diagnosis and Treatment of Neuroblastoma. The Oncologist, 2003;8:278-292.

9Sharp, S. E., Shulkin, B. L., Gelfand, M. J., Salisbury, S., & Furman, W. L. (2009). 123I-MIBG scintigraphy and 18F-FDG PET in neuroblastoma. Journal of Nuclear Medicine, 50(8), 1237-1243.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)