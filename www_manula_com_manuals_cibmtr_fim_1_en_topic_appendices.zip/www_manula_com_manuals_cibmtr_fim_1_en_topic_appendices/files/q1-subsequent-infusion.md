#### Question 1: Is this the report of a second or subsequent infusion for the same disease?

Indicate if this report is being completed for a second or subsequent infusion for the same disease.

Report **No** in the following scenarios:

- This is the first infusion reported to CIBMTR
- This is the first infusion given to treat the recipient’s current disease
- This is a second or subsequent infusion for the same disease and this baseline disease insert was not completed for the previous infusion (i.e., recipient was on TED track for the prior infusion, prior infusion was autologous with no consent, etc.)

Report **Yes** if this is a report of a second or subsequent infusion for the *same disease* and this *CLL Pre-Infusion (2013) disease insert form was previously completed*. If **Yes**, continue with the *Pre-Infusion Therapy* section.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Oct 27, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)