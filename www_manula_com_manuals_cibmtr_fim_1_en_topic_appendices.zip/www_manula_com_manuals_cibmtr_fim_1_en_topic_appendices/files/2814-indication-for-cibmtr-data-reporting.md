The Indication for CIBMTR Data Reporting (2814) Form collects information to initiate CIBMTR reporting on the appropriate research or data collection forms. This form must be completed for the first indication requiring the individual to register for a CIBMTR Research ID (CRID) and any subsequent infusions the recipient received.

Links to Sections of Form:

[Reporting process](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/reporting-process)

[Q1 – 2: Indication](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-2-indication)

[Q3 – 12: Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q3-12-infusion)

[Q13 – 15: Non-Cellular Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q13-15-non-cellular-therapy)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/28/2025 |
|

**Infusion**(e.g., hematopoietic cellular transplant (HCT), gene therapy, cellular therapy),**Marrow toxic injury**, or**Non-cellular therapy**(e.g., study enrollment, chemotherapy, immunotherapy, etc.).[2814: Indication for CIBMTR Data Reporting](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2814-indication-for-cibmtr-data-reporting)[2814: Indication for CIBMTR Data Reporting](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2814-indication-for-cibmtr-data-reporting)**CMS Innovation Center’s Cell and Gene Therapy (CGT) Access Model for Sickle Cell Disease (SCD)**Select “non-cellular therapy” when completing this form for the first time for a CRID to be enrolled in the CMS Innovation Center’s Cell and Gene Therapy (CGT) Access Model for Sickle Cell Disease (SCD). Contact CIBMTR Center Support with any questions.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)