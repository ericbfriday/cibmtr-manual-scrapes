#### General Terms

**absolute neutrophil count (ANC)**

Neutrophils are a type of white blood cell that helps protect the body from infection. The number of neutrophils in a recipient’s blood is used to track recovery after chemotherapy or HSCT. In some types of HSCT, the number of neutrophils is a marker of engraftment.

**allele**

One of the different forms of a gene that can occur at a single spot on a chromosome. A part of DNA representing a gene inherited from each parent to make a pair.

**allele code**

The NMDP uses allele codes to report the HLA allele combinations used to match recipients and donors. The codes reduce multiple allele combinations into an alphabetic term.

**allogeneic hematopoietic cell transplant**

Any cord blood, bone marrow or peripheral blood stem cell transplant that uses cells from a person other than the recipient. The donated cells can come from a family member or a donor who is not related to the recipient.

**antibody**

A protein in the blood that is created by the immune system in response to foreign substances like viruses, bacteria or tumor antigens. Each antibody recognizes a specific antigen unique to its target.

**antigens**

Substances capable of activating the immune system. Antigens include toxins, bacteria, foreign blood cells, and the cells of transplanted organs. Proteins found on most cells of the body are antigenic and therefore are the targets for graft-versus-host disease and graft rejection.

**apheresis**

A procedure where blood is taken from a person’s arm and passed through a machine. The machine separates and collects certain cells such as blood-forming cells, white blood cells or platelets. The rest of the blood is returned through the other arm.

**autologous hematopoietic cell transplant**

A transplant using blood-forming cells collected from the recipient. The recipient’s own blood-forming cells are collected, stored and then returned to the body after the recipient receives high doses of chemotherapy and/or radiation therapy. The cells are generally collected when the recipient is in remission to minimize cancer cell contamination.

**blast phase**

The advanced stage of chronic myelogenous leukemia or chronic lymphocytic leukemia when the number of abnormal white blood cells in the bone marrow and blood is very high.

**cellular transplantation, cellular transplant therapy**

The process of replacing or supplementing a recipient’s diseased blood and immune system with healthy, blood-forming, immune or other hematopoietic-derived cells collected from marrow, peripheral blood or cord blood. This may include, but is not limited to, an infusion of donor lymphocytes or mesenchymal stem cells.

**chemotherapy**

A drug treatment that kills cancer cells. Used to prepare recipients for a marrow, PBSC, or cord blood transplant.

**confirmatory test (CT)**

An additional test designed to detect only a targeted substance (i.e., virus, protein, DNA, antibody, etc.) with high specificity and low sensitivity; generally done to confirm disease after a positive screening test, as it is more costly and time consuming than a screening test.

**contact date**

In order for a form (Pre-, Post-TED, and/or Comprehensive Report Form) to be entered into the database, the contact date must be at least a day greater than the contact date of the previous form. If the center has not had contact with the recipient since the contact date that was reported on the previous form, a Lost to Follow-up (Form 2802) should be submitted instead.

**cord blood unit (CBU)**

Cord blood that meets eligibility requirements and has been typed and stored for potential transplantation.

**cryopreservation**

A procedure for storing tissues or blood products at extremely low temperatures.

**cytomegalovirus (CMV)**

A virus that can cause pneumonia, gastroenteritis or urinary tract infection in people with weakened immune systems. Many healthy people infected with the virus have no signs of infection. CMV infection is a concern because of the risk of infection to people with weakened immune systems, such as transplant recipients and those with HIV.

**disease**

An abnormal condition of an organism that impairs bodily functions and can be deadly. Also defined as a way of the body harming itself in an abnormal way, associated with specific symptoms and signs.

**disease specific forms**

Previously called “inserts” by both the Minneapolis and Milwaukee campuses of the CIBMTR. These forms are due once the primary Comprehensive Report Form (i.e., Form 2000, 2100, 2200 or 2300) is complete.

**DNA repository**

A facility that stores NMDP volunteer donor blood samples for HLA testing. Blood samples are either frozen or spotted on filter paper cards for later DNA-based HLA typing.

**engraftment**

The stage when the transplanted blood-forming cells start to grow and make healthy new blood cells derived from the donor (including autologous).

**enzyme immunoassay (EIA)**

*See ELISA*

**enzyme-linked immunosorbent assay (ELISA)**

A biochemical technique used to detect the presence of specific substances such as antibodies or antigens. Because it can be performed to evaluate either the presence of antigen or the presence of antibody in a sample, it is a useful tool both for determining serum antibody concentrations (such as with the HIV or hepatitis) and also for detecting the presence of antigen.

**false positive**

Reactive test result not due to the presence of the substance being tested but rather to an interfering or cross-reacting substance; confirmatory testing is necessary to differentiate true positive from false positive.

**filgrastim**

A man-made version of a normal human protein that increases the number of blood-forming cells in the body. Filgrastim is used to treat neutropenia (a low number or neutrophils), stimulate the bone marrow to increase production of neutrophils. Filgrastim is also given to donors who have agreed to donate peripheral blood stem cells (PBSC). Filgrastim is also known as G-CSF (granulocyte-colony stimulating factor) or by the trade name Neupogen®.

**good clinical practices (GCP)**

An international ethical and scientific quality standard for designing, conducting, recording, and reporting, trials that involve the participation of human subjects.

**graft**

Tissue or organ transplanted from a donor to a recipient. In some cases the recipient can be both donor and recipient.

**graft failure**

When transplanted blood-forming cells fail to make enough white blood cells, platelets and red blood cells. There are several causes for graft failure, including graft rejection. Failure to engraft occurs when there is no recovery of donor (or autologous) stem cell function following the HSCT, and may be caused by inadequate numbers of blood-forming cells at the time of transplantation.

**graft-versus-host disease (GVHD)**

A condition where the transplanted marrow or blood stem cells react against the recipient’s tissues. GVHD is caused by the donor’s T cells. There are two types of GVHD, acute GVHD (aGVHD) and chronic GVHD (cGVHD). GVHD can be mild or serious and is sometimes life threatening. Recipients are given immunosuppressive medication after transplant to prevent and control GVHD.

**growth factor**

A substance that affects cellular growth, proliferation and cellular differentiation. Cytokines and hormones are examples of growth factors that bind to specific receptors on the surface of their target cells. Growth factors often promote cell differentiation and maturation. Filgrastim is one type of growth factor.

**HLA (human leukocyte antigen)**

The name of the major histocompatibility complex (MHC) in humans. The superlocus contains a large number of genes related to immune system function in humans. This group of genes resides on chromosome 6 and encodes cell-surface antigen-presenting proteins and many other genes. The proteins encoded by certain genes are also known as antigens, as a result of their historic discovery as factors in organ transplantations. The major HLA antigens are essential elements in immune function.

Different classes have different functions:

**HLA class I** antigens (A, B & C) present peptides from inside the cell (including viral peptides if present). These peptides are produced from digested proteins that are broken down in the lysozomes. The peptides are generally small polymers, about 9 amino acids in length. Foreign antigens attract killer T-cells (also called CD8 positive cells) that destroy cells.

**HLA class II antigens** (DR, DP, & DQ) present antigens from outside of the cell to T-lymphocytes. These particular antigens stimulate T-helper cells to reproduce and these T-helper cells then stimulate antibody producing B-cells, self-antigens are suppressed by suppressor T-cells.

HLA testing is used to match recipients and donors for marrow, blood stem cell and organ transplants.

**human T-cell lymphotropic virus (HTLV)**

A single-stranded RNA retrovirus that causes T-cell leukemia and T-cell lymphoma in adults and may also be involved in certain demyelinating diseases.

**immuniobiology**

The study of the immune response and the biological aspects of immunity to disease.

**indeterminate**

Test results that do not meet criteria for either positive or negative; may require repeat or additional testing.

**infectious disease markers (IDMs)**

Proteins in the blood that show if a person has had an infectious disease that could be transferred to a recipient through a marrow or PBSC transplant.

**informed consent**

The process by which a person receives an explanation of the risks and benefits of a medical treatment or research study. If a person agrees to participate, he or she must indicate in writing that they understand and agree to the information provided. A person can provide informed consent at the age of 18.

**institutional review board (IRB)**

An IRB is an administrative body established to protect the rights and welfare of human research subjects recruited to participate in research activities conducted under the auspices of the institution with which it is affiliated. The IRB has the authority to approve, require modifications in, or disapprove all research activities that fall within its jurisdiction as specified by both the federal regulations and local institutional policy.

**neutralization test**

A test that determines the power of an antiserum or other substance by testing its action on the pathogenic properties of a microorganism, virus, bacteria, or toxic substance.

**non-myeloablative transplant**

A type of transplant that uses lower doses of chemotherapy and /or radiation to prepare a recipient for transplant. In this type of preparative regimen, the recipient’s hematopoietic system is not expected to be completely destroyed.

**nucleic acid amplification test (NAT/NAAT)**

A test can detect evidence of infection by amplifying nucleic acid in a virus, allowing for early detection of minute quantities of viral genes in the blood. The NAT can detect disease at an earlier stage than antibody testing (e.g. ELISA) since the appearance of antibodies and antigens take time to be detectable. Also see: PCR.

**polymerase chain reaction (PCR)**

A method of NAT testing, PCR is a powerful method for amplifying specific DNA/RNA segments and is used in the diagnosis of both infections and genetic diseases.

**radiation therapy**

Treatment with high-energy rays used to destroy or shrink cancer cells, or suppress the immune system.

**recombinant immunoblot assay (RIBA)**

A confirmatory test for hepatitis C, RIBA can detect whether a positive anti-HCV test is due to exposure to HCV (positive RIBA) or represents a false signal (negative RIBA).

**research sample repository**

A facility operated by the NMDP that stores research blood samples collected from marrow, PBSC donors, cord blood units, and recipients whose transplants were facilitated through the NMDP. The research samples are used in studies designed to improve outcomes for future transplant recipients.

**screening test**

An inexpensive, easy and rapidly performed test with high sensitivity and low specificity; used with the intention of detecting early evidence of disease.

**sensitivity**

A measure of how well a test correctly identifies everyone who has a disease or condition; the proportion of individuals with a disease or condition that will have a positive test.

**seroconversion**

The development of detectable antibodies in the blood as a result of exposure to an infectious agent.

**serology**

The scientific study that tests the blood serum for antibodies. Prior to seroconversion, the blood tests seronegative for the antibody; after seroconversion, the blood tests seropositive for the antibody.

**specificity**

A measure of how well a test eliminates everyone who does not have a disease or condition; the proportion of individuals without a disease or condition that will have a negative test.

**western blot**

An immunoassay technique used to detect specific proteins in blood or tissue. Western blot is used as the confirmatory HIV test. A western blot is also used to detect other diseases such as bovine spongiform encephalopathy and Lyme disease.

**window period**

Time between infection with a virus and the time the immune system has produced enough antibodies for the antibody test to detect. This time period can vary from person to person.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for any of the appendices, please reference the retired appendix on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)