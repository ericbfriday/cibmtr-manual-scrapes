#### Questions 16-19: Where was the gene therapy product manufactured / processed?

Indicate the location where the gene therapy product was manufactured / processed.

**Cell processing laboratory at the same center as the product is being infused:**The gene therapy product was manufactured / processed at a cell processing lab associated with the same center where the product is being infused. This includes both cell processing labs located onsite and offsite.**Cell processing laboratory offsite:**The gene therapy product was manufactured / processed at a cell processing lab, not associated with the transplant center, such as stand-alone or privately held manufacturing / processing lab. This does not include pharmaceutical / biotech companies.**Pharmaceutical / biotech company:**The gene therapy product was manufactured / processed**by or on behalf of a**pharmaceutical or biotech company. Refer to question 17 on the form for a list of possible pharmaceutical / biotech companies. Companies may partner with other companies to perform the manufacturing / processing. If the company is not listed from the options provided, select**Other pharmaceutical / biotech company**and specify the company.**Other site**: If the gene product therapy was manufactured / process at a site not listed above, select this option, and specify.

#### Question 20: Specify the portion of the gene therapy product manipulated

Report the portion of the gene therapy product manipulated. This information may be found with the gene therapy product processing information that comes with the product. If the entire product was manipulated, select **Entire product**. If only a portion of the product was manipulated select **Portion of product**.

If the portion of the gene therapy product manipulated is not known, select **Unknown**.

#### Question 21: Was the manipulated product cryopreserved?

Specify **Yes** or **No** if the manipulated gene therapy product was cryopreserved prior to infusion.

#### Question 22: Was the unmanipulated (“back up”) portion of the product cryopreserved?

Specify **Yes** or **No** if the unmanipulated portion of the gene therapy product was cryopreserved for future use.

This question is only enabled if the portion of the gene therapy product manipulated is* Portion of the product*.

#### Question 23: Specify the type(s) of genetic manipulation

Specify the type(s) of genetic manipulation. Check all that apply.

**Ex vivo transduction:**Ex vivo transduction is a method of using a carrier (called a vector) to introduce genetic material into cells that are outside (ex vivo) the body. If this option is selected, specify the type of vector and transgene.**Gene editing:**Gene editing refers to the manipulation of genetic material by deleting, replacing, or inserting a DNA sequence. If this option is selected, continue with Methodology.**Other genetic manipulation:**If a method of genetic manipulation was performed on the gene therapy product but is not listed above, select this option, and specify the other genetic manipulation.

#### Questions 24 – 25: Type of vector

A vector is used to carry foreign genetic material into another cell. Specify the type of vector used in ex vivo transduction. This information may be available from a clinical study protocol or information that comes with the product. If **Other vector** is selected, specify the vector. If the type of vector is not known, select **Unknown**.

#### Questions 26 – 27: Specify the transgene

A transgene is the therapeutic gene that has been transferred into the gene therapy product cells. This information may be available from a clinical study protocol or information that comes with the product. Specify the transgene used in ex vivo transduction. If **Other transgene** is selected, specify the transgene. If the type of transgene is not known, select **Unknown**.

#### Questions 28 – 29: Methodology

Specify the methodology used for gene editing. This information may be available from a clinical study protocol or information that comes with the product.

**Base editor:**a genome editing approach that uses the CRISPR (clustered regularly interspaced short palindromic repeats) system with enzymes to directly install point mutations into cellular DNA or RNA without making double-stranded DNA breaks.**Cas protein:**a genome editing approach that uses the CRISPR (clustered regularly interspaced short palindromic repeats) system with the Cas protein to cut DNA at the targeted site.**Transcription activator-like effector nucleases (TALENs):**restriction enzymes that can be engineered to cut specific sequences of DNA.**Zinc finger nucleases (ZFNs):**class of engineered DNA-binding proteins that facilitate targeted editing of the genome by creating double-strand breaks at the targeted site.**Other methodology:**If the method of gene editing is not listed above, select this option, and specify the other methodology.**Unknown:**If the methodology of gene editing is not known, select this this option

#### Questions 30 – 31: Specify the gene target

Specify the name of the gene targeted for editing. If **Other** is selected, specify the gene target. If the gene target is not known, select **Unknown**.

#### Question 32: Specify other genetic manipulation

If the method of genetic manipulation is other than ex vivo transduction or gene editing, specify the method of genetic manipulation.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)