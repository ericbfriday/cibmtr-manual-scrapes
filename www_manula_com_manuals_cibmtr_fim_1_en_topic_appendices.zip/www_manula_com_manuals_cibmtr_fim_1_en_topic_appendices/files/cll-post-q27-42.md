#### Questions 33 – 34: Was a disease relapse or progression detected by clinical / hematologic assessment?

Refer to the International Working Group criteria provided in [CLL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-response-criteria) section of the Forms Instructions Manual for more information on how to determine recurrence or progression of disease.

Specify if the CLL International Working Group criteria for a clinical / hematologic relapse or progression was met within the current reporting period. If **Yes**, specify the date when clinical / hematologic relapse or progression. This should be the first date when CLL International Working Group criteria for a clinical / hematologic relapse or progression was met.

If the CLL International Working Group criteria for a clinical / hematologic relapse or progression was not met or unknown if met, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 35 – 36: Were tests for molecular markers performed? *(and positive for disease) (e.g., PCR, NGS)*

Indicate if testing for molecular markers was performed and molecular markers were detected (i.e., positive for disease) in the current reporting period. If Yes, report the sample collection date. If molecular marker testing detected disease multiple times in the reporting period, report the date (and results) of first molecular testing identifying disease.

If molecular marker testing was performed in the current reporting period but did not identify molecular markers (i.e., negative for disease) or ‘failed,’ select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 37 – 40: Specify positive mutation(s) *(check all that apply)*

Specify the molecular markers identified at the time of the molecular assessment date reported above.

If **BTK** was detected, specify the BTK mutation(s) identified. If **Other** is selected, specify the other BTK mutation detected.

If an **Other molecular** marker was detected at diagnosis, specify the marker identified.

#### Question 41: P53 / TP53 mutation

Specify if the P53 / TP53 mutation was detected by molecular testing (i.e., PCR, NGS) in the current reporting period. If molecular testing for the P53 / TP53 mutation was not completed or unknown if completed at this time point, select **Not done**.

#### Questions 42 – 43: Was disease detected via flow cytometry? *(minimum 4-color flow) (immunophenotyping)*

Indicate if disease was detected by flow cytometry in the current reporting period. If **Yes**, report the sample collection date. If flow cytometry detected disease multiple times in the reporting period, report the date of first flow cytometry result identifying disease.

If flow cytometry was performed in the current reporting period but did not detect disease, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 44: Was disease detected via cytogenetic testing? (FISH or karyotyping)

Indicate if disease was detected by cytogenetics (FISH or karyotyping) in the current reporting period.

If cytogenetics (FISH or karyotyping) was performed in the current reporting period but did not detect disease, select **No**.

#### Questions 45 – 46: Were cytogenetic abnormalities identified via FISH?

Indicate if disease was detected by FISH in the current reporting period. If **Yes**, report the sample collection date. If FISH detected disease multiple times in the reporting period, report the date of first FISH result identifying disease.

If FISH was performed in the current reporting period but did not detect disease or ‘failed,’ select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 47 – 49: Specify results

Specify the FISH abnormalities identified at the time of the FISH assessment date reported above. Report the International System for Human Cytogenetic Nomenclatures (ISCN) compatible string, if applicable, and specify all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality(ies) or report ‘see attached report’ and attach the report(s). For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Questions 50 – 51: Were cytogenetic abnormalities identified via karyotyping?

Indicate if disease was detected by karyotyping in the current reporting period. If **Yes**, report the sample collection date. If karyotype detected disease multiple times in the reporting period, report the date of first karyotype result identifying disease.

If karyotyping was performed in the current reporting period but did not detect disease, select **No**.

If karyotyping was performed in the current reporting but ‘failed,’ select No evaluable metaphases.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 52: What type of cytogenetic karyotype was performed?

Specify if the karyotype performed as a **Stimulated karyotype** or **Unstimulated karyotype**. This information is typically located within the karyotype report and is important to understand when reviewing the abnormalities detected for research.

If the type of karyotype performed is unclear, seek clinician clarification.

#### Question 53 – 56: Specify results

Report the International System for Human Cytogenetic Nomenclatures (ISCN) compatible string. If the ISCN compatible string cannot be reported, then specify the number of cytogenetic abnormalities and specify all abnormalities detected.

The number of abnormalities detected is important for disease prognosis.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality(ies) or report ‘see attached report’ and attach the report(s). For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Question 57: Was any therapy given for relapse or progressive disease?

Systemic therapy, radiation, withdrawal of immunosuppression, and/or other treatments may be administered for persistent, relapsed, or progressive disease. Additionally, therapy for measurable residual disease (MRD) may also be administered. Indicate if the recipient received treatment post-infusion for measurable residual disease (MRD), persistent, relapsed, or progressive disease in the current reporting period.

#### Question 58: Date started

Report the date when treatment for measurable residual disease (MRD), persistent, relapsed, or progressive disease was started in the current reporting period. If multiple treatments were started in the reporting period, report the date of the first treatment.

If therapy was started in a prior reporting period and the same treatment was continued into the current reporting period, leave the data field blank and override the error as ‘Unable to answer.’

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 59 – 62: Specify therapy given (check all that apply)

Specify the treatment(s) administered in the current reporting period for measurable residual disease (MRD), persistent, relapsed, or progressive disease.

**Radiation**: Radiation therapy utilizes high-energy x-rays, gamma rays, electron beams, or proton beams to kill cancer cells. For CLL, radiation therapy may be used to kill cells that have invaded other tissues and lymph nodes. Radiation therapy may be given in conjunction with systemic chemotherapy or as a separate line of therapy.**Systemic therapy**: Systemic therapy is delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein / central line or given orally. If**Systemic therapy**is given, specify the type of therapy.**Withdrawal of immunosuppression**: Immunosuppressive medications may be tapered or entirely withdrawn in order to promote a graft vs leukemia effect in the setting of relapsed, progressive, or persistent disease post-infusion.**Other therapy**: If the treatment option is not listed above, select Other therapy and specify the treatment. Do not report supportive therapies (i.e., transfusions, growth factors) or subsequent infusions (i.e., transplant, cellular therapy).

#### Questions 63 – 64: Was therapy given as part of clinical trial?

Indicate whether the treatment was administered as part of a clinical trial. Consult the physician overseeing treatment if it is not clear if the therapy is being given as part of a clinical trial.

If **Yes**, specify the clinical trial number (NCT number). The clinical trial number can be looked up using the ‘Find a Study’ feature on www.clinicaltrials.gov.

If the treatment was given as part of a clinical trial that is not registered with clinicaltrials.gov but is registered elsewhere, leave the *Specify the ClinicalTrials.gov identification number* data field blank and override the FormsNet3SM error as ‘unable to answer.’ Additionally, attach documentation which displays the clinical trial number and corresponding registry in FormsNet3SM. For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q57 | 1/24/2025 | Add | Clarification where MRD treatment is reported: Systemic therapy, radiation, withdrawal of immunosuppression, and/or other treatments may be administered for persistent, relapsed, or progressive disease. Additionally, therapy for measurable residual disease (MRD) may also be administered. Indicate if the recipient received treatment post-infusion for measurable residual disease (MRD), persistent, relapsed, or progressive disease in the current reporting period. |
Added for clarification |
| Q58 | 1/24/2025 | Add | Clarified where MRD treatment is reported: Report the date when treatment for measurable residual disease (MRD), persistent, relapsed, or progressive disease was started in the current reporting period. If multiple treatments were started in the reporting period, report the date of the first treatment. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)