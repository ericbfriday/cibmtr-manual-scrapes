The Immune Deficiency Post-HCT Data Form is one of the Comprehensive Report Forms. This form captures ID-specific post-HCT data such as: laboratory studies post-HCT, clinical features assessed post-HCT, Post-HCT treatment, and status of hematologic engraftment.

This form must be complete for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as Disorders of the Immune System and specified as:


- Adenosine deaminase (ADA) deficiency / severe combined immunodeficiency (SCID)
- Absence of T and B cells SCID
- Absence of T, normal B cell SCID
- Omenn syndrome
- Reticular dysgensis
- Bare lymphocyte syndrome
- Other SCID
- SCID, not otherwise specified
- Ataxia telangiectasia
- HIV infection
- DiGeorge anomaly
- Common variable immunodeficiency
- Leukocyte adhesion deficiencies, including GP180, CD-18, LFA, and WBC adhesion deficiencies
- Kostmann agranulocytosis (congenital neutropenia)
- Neutrophil actin deficiency
- Cartilage-hair hypoplasia
- CD40 ligand deficiency
- Other Immunodeficiencies
- Immune deficiency, not otherwise specific

The Immune Deficiency Post-HCT Data Form (Form 2131) must be completed in conjunction with each Post-HCT follow-up form (Forms 2100, 2200, 2300). The form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100 for Form 2100, between day 100 and the six-month date of contact for Form 2200, between the date of contact for the six-month follow up and the date of contact for the one-year follow up for Form 2200, etc.).

[Q1-43: Laboratory Studies Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-43-laboratory-studies-post-hct)[Q44-94: Clinical Features Assessed Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q44-94-clinical-features-assessed-post-hct)[Q95-166: Post-HCT Treatment for Immune Deficiency](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q95-166-post-hct-treatment-for-immune-deficiency)[Q167-172: Status of Hematologic Engraftment](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q167-172-status-of-hematologic-engraftment)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/19 |
|

*Predominantly or completely donor (≥80% donor chimerism)**Mixed chimerism (5 – 79*~~80%~~donor)*Only host cells detected (<5% donor)*

[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)[question 25](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-43-laboratory-studies-post-hct#25): If CD56+ cells were not tested, centers may report CD16+ results in these data fields.[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)[question 24](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-43-laboratory-studies-post-hct#q24):If CD20+ cells were not tested, centers may report CD19+ results in these data fields.

[2131: ID Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)[question 171](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q167-172-status-of-hematologic-engraftment#171):Myeloid subsets may be reported as

*CD15+*or CD33+ on the laboratory report.[2031/2131: Immune Deficiencies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-2131-immune-deficiencies-id)**Published new manual for**[2031](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)&[2131](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)Pre- and Post-HCT Immune Deficiencies Data
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)