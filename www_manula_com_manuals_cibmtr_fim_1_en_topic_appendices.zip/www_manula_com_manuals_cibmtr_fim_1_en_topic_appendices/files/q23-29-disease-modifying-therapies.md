#### Question 23: Were disease modifying therapies given? (excludes blood transfusions)

Indicate if the recipient received disease modifying therapies at any time between the diagnosis and the start of the preparative regimen, excluding blood transfusion(s) (review the question below for a list of common disease modifying therapies).

If the recipient did not receive disease modifying therapies or if no information is available to determine if the recipient received disease modifying therapies, select **No** or **Unknown**, and continue with *Was enzyme activity and/or enzyme substrate tested?*

#### Questions 24 – 25: Specify the disease modifying therapy (check all that apply)

Select the disease modifying therapy administered as part of the line of therapy being reported.

**Leriglitazone:**a novel selective peroxisome proliferator-activated receptor gamma agonist.

If the recipient received a therapy which is not listed, select**Other**and specify the treatment. Report the generic name of the agent, not the brand name.

#### Questions 26 – 27: Date therapy started

Indicate if the therapy start date (YYYY-MM-DD) is known. If **Known**, report the first date the recipient began this line of therapy.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Questions 28 – 29: Date therapy stopped

Indicate if the stop date is known. If the therapy stop date is **Known**, report the date (YYYY-MM-DD) when the therapy end. If the therapy is being given in cycles, report the end date as the date when the recipient started the last cycle for this line of therapy. Otherwise, report the final administration date for the therapy being reported.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

Report **Not applicable** if the recipient is still receiving therapy at the start of the preparative regimen / infusion.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)