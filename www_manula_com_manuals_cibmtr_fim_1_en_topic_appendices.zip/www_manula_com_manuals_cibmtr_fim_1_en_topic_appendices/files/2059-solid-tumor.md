The Solid Tumor Pre-Infusion (2059) and Solid Tumor (3507) Response Forms must be completed for cell therapy recipients when the indication is to treat solid tumors and the sub-type is Bone sarcoma (excluding Ewing family tumors) (273), Myxoid round cell sarcoma (2217), or Synovial sarcoma (245).

[RECIST criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/recist-criteria)

[2059: Solid Tumor Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2059-solid-tumor-pre-infusion)

[3507: Solid Tumor Response](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/3507-solid-tumor-response)

Last modified:
Jan 27, 2025

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)