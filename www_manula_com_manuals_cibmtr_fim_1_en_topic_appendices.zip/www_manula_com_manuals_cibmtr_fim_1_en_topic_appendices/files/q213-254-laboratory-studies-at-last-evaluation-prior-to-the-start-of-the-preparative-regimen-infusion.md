# Q213-254: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion

#### Question 213: Date CBC with differential drawn

Report the date of the CBC with differential was drawn at the last evaluation prior to the start of the preparative regimen / infusion and continue with question 214. If multiple assessments were performed, report the most recent one prior to the start of the preparative regimen / infusion.

#### Question 214-215: Neutrophils

Indicate whether the neutrophil percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the value documented on the laboratory report in question 215. If “unknown,” continue with question 216.

#### Questions 216-217: Bands

Indicate whether the band percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 217. If “unknown,” continue with question 218.

#### Questions 218-219: Metamyelocytes

Indicate whether the percentage of metamyelocytes in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 219. If “unknown,” continue with question 220.

#### Question 220-221: Myelocytes

Indicate whether the myelocyte percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 221. If “unknown,” continue with question 222.

#### Questions 222-223: Monocytes

Indicate whether the monocyte percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 223. If “unknown,” continue with question 224.

#### Questions 224-225: Basophils

Indicate whether the basophils percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 225. If “unknown,” continue with question 226.

#### Questions 226-227: Eosinophil

Indicate whether the eosinophil percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 227. If “unknown,” continue with question 228.

#### Questions 228-229: Was a bone marrow examination performed?

Indicate if a bone marrow examination was performed at the last evaluation prior to the preparative regimen / infusion. If “yes,” indicate the date the sample was collected in question 229. If “no” or “unknown,” continue with question 233.

#### Question 230: Cellularity

Cellularity describes the percentage of bone marrow occupied by hematopoietic cells compared to other tissues, such as adipose (fat) cells. In MPN, the percentage of hematopoietic cells is likely increased (hypercellular) due to proliferation of immature cells. In other cases, the cellularity may be normal (normocellular) or decreased (hypocellular). This distinction is made on the pathology report of a bone marrow examination.

Indicate whether the bone marrow examination revealed “decreased (hypocellular),” “normal (normocellular),” or “increased (hypercellular)” cellularity at the last evaluation. If a biopsy was not obtained or if the degree of cellularity is not addressed in the report, select “unknown.”

#### Question 231: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This is evident in MPN diseases. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented on the pathology report or stated in a physician progress note, select “known,” and continue with question 232.

If the myelofibrosis grade is not documented, select “unknown,” continue with question 233.

#### Question 232 Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal BM.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with local bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 233: Were molecular tests for molecular markers performed (e.g., PCR) (please do not include driver mutations JAK2, CALR, MPL, and CSF3R as previously captured on the Disease Classification F2402)

Molecular assessment involves testing blood or bone marrow for the presence of known molecular markers associated with the recipient’s disease. Molecular assessments are the most sensitive test for genetic abnormalities and involve amplifying regions of cellular DNA by polymerase chain reaction (PCR), typically using RNA to generate complementary DNA through reverse transcription (RT-PCR). The amplified DNA fragments are compared to a control, providing a method of quantifying log increase of genetic mutation transcripts. Each log increase is a 10-fold increase of gene transcript compared to control.

Indicate if tests for molecular markers (excluding driver mutations previously captured on the Disease Classification F2402) were obtained at the last evaluation prior to the start of the preparative regimen / infusion.

If tests for molecular markers (excluding driver mutations previously captured on the Disease Classification F2402) were obtained, select “yes” and continue with question 234.

If tests for molecular markers (excluding driver mutations previously captured on the Disease Classification F2402) were not obtained or it is unknown if molecular studies were performed, indicate “no” or “unknown” and continue with question 241.

#### Question 234: Indicate if a positive molecular marker(s) was identified

Indicate if positive molecular marker(s) was identified at the last evaluation.

If a positive molecular marker was identified, select “yes” and continue with question 235.

If there were no molecular markers identified, select “no” and continue with question 241.

#### Question 235: Date sample collected

Report the date the sample was collected for molecular testing. If multiple assessments were performed, report the most recent one prior to the start of the preparative regimen / infusion.

#### Questions 236-237: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 238. If a positive marker is detected, but not listed as an option, select “Other molecular marker” and specify the positive molecular marker in question 237.

#### Questions 238-239: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

**Figure 1**. Molecular disease assessment with amino acid changes documented (highlighted in yellow).


For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

Indicate if the amino acid change is “known” or “unknown” for the positive molecular marker reported in questions 236-237. If known, report the amino acid change in question 239. If unknown, continue with question 240.

Copy questions 236-239 to report more than one positive molecular marker.

#### Question 240: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, molecular report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 241: Was flow cytometry performed?

Indicate whether flow cytometry (immunophenotyping) was performed on the blood and / or bone marrow at the last evaluation prior to the start of the preparative regimen / infusion. If “Yes,” go to question 242. If “No” or “Unknown,” go to question 250.

#### Question 242-245: Flow cytometry testing on blood

Indicate whether flow cytometry was performed on the blood at the last evaluation prior to the start of the preparative regimen / infusion. If “Yes,” report the date the sample was collected and whether disease was detected in questions 243 and 244, respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 245. Otherwise, go to question 246.

If flow cytometry was not performed on the blood at the last evaluation prior to the start of the preparative regimen / infusion, report “No” for question 242 and go to question 246.

#### Question 246-249: Flow cytometry testing on bone marrow

Indicate whether flow cytometry was performed on the bone marrow at the last evaluation prior to the start of the preparative regimen / infusion. If “Yes,” report the date the sample was collected and whether disease was detected in questions 247 and 248, respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 249. Otherwise, go to question 250.

If flow cytometry was not performed on the bone marrow at the last evaluation prior to the start of the preparative regimen / infusion, report “No” for question 246 and go to question 250.

#### Question 250-252: Total serum ferritin

Ferritin is a blood protein that contains iron. Ferritin levels indicate how much iron a person’s body is storing. If the ferritin level is lower than normal, it indicates the body’s iron stores are low (iron deficiency). If the ferritin level is higher than normal it could indicate hemochromatosis, a condition that causes the body to store too much iron. Other causes of an elevated ferritin level include liver disease, acute and chronic inflammatory conditions, malignancy to name a few.

Indicate whether the total serum ferritin value is “known” or “unknown” at the last evaluation prior to the start of the preparative regimen / infusion. If “known”, report the ferritin value documented on the laboratory report in question 251 and the date of sample collection in question 252. If “unknown”, continue with question 253.

#### Question 253-254: CD34+ cells (peripheral blood)

Indicate whether the CD34+ cell count is “known” or “unknown” at the last evaluation prior to the start of the preparative regimen / infusion. The number of CD34+ cells in the peripheral blood are usually detected via flow cytometry. If “known”, report the CD34+ cell count documented on the laboratory report in question 254. The reported value must be in units of cells / µL.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)