This section provides explanatory text for each question on the Baseline, Follow-up, IDMs, HLA, and Infusion forms.

[2000: Recipient Baseline](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2000)

[2004: Infectious Disease Markers](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2004-infectious-disease-markers)

[2005: Confirmation of HLA Typing](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2005-confirmation-of-hla-typing)

[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)

[2100: Post-HCT Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)

[2900: Recipient Death](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2900)

Last modified:
Jul 05, 2017

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)