This section of the CIBMTR Forms Instruction Manual is intended to be a resource for completing the Aplastic Anemia Pre-Infusion Data Form (Form 2028 – Revision 3).

#### Aplastic Anemia Pre-Infusion Data

The Aplastic Anemia Pre-Infusion Data Form is one of the Comprehensive Report Forms. This form captures aplastic anemia specific pre-Infusion data such as: disease assessment at diagnosis, laboratory studies at diagnosis, transfusion status prior to the start of the preparative regimen, and laboratory studies prior to the start of the preparative regimen.

This form must be completed for all recipients whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as aplastic anemia or one of the following inherited bone marrow failure syndromes: Shwachman-Diamond syndrome, Diamond-Blackfan anemia (pure red cell aplasia), Dyskeratosis congenita, or other inherited bone marrow failure syndrome. Fanconi Anemia and Sickle Cell Anemia each have their own forms to complete (Forms 2029 and 2030, respectively).

[Q1: Subsequent Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-18-disease-assessment-at-diagnosis)

[Q2-33: Disease Assessment](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q19-44-laboratory-studies-at-diagnosis)

[Q34-58: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q45-47-transfusion-status-from-diagnosis-to-the-start-of-the-preparative-regimen)

[Q59-70: Pre-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q48-79-laboratory-findings-to-the-start-of-the-preparative-regimen)

[Q71 – 79: Transfusion Status from Diagnosis to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q71-79-transfusion-status-from-diagnosis-to-the-start-of-the-preparative-regimen-infusion)

[Q80 – 97: Laboratory Findings Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q78-95-laboratory-findings-prior-to-the-start-of-the-preparative-regimen-infusion)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

*Red blood cells may be leukodepleted (may also be documented as leukoreduced) to prevent post-transfusion complications by reducing the number of WBCs transfused. This information is typically found within the “blood blank” or “transfusion history” information. Report***Yes**if any of the red blood cells administered between diagnosis and the start of the preparative regimen / infusion were leukodepleted or leukoreduced. If none of the red blood cells administered between diagnosis and the start of the preparative regimen were leukodepleted or leukoreduced, report**No**. If it is not known if the red blood cells were leukodepleted or leukoreduced, seek clarification from the blood bank. If it cannot be determined if leukodepleted or leukoreduced red blood cells were administered prior to the start of the preparative regimen, report**Unknown**.[2028: Aplastic Anemia Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2028-aplastic-anemia-pre-hct)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)