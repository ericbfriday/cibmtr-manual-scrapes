This form must be completed for all recipients of cellular therapy (non-HCT), including post-HCT DCI infusions, selected for CRF reporting level. It will be completed in conjunction with the Pre-Cellular Therapy Essential Data (Pre-CTED) (4000) form. For more information on TED and CRF level reporting, [click here](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/cell-therapy-reporting-tracks-and-follow-up-schedules)

The Pre-Cellular Therapy Baseline Data (4001) form will come due after the Pre-CTED (4000) form has been completed if the infusion is selected for CRF reporting level. This form captures pre-infusion data such as: setting for the infusion, lymphodepleting therapy details, toxicity prophylaxis, and socioeconomic information. The Baseline Form is due within 30 days after infusion.

Links to sections of form:

[Q1-4: Product Identification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-4-product-identification)

[Q5-10: Lymphodepleting Therapy Prior to Cellular Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q5-10-lymphodepleting-therapy-prior-to-cellular-therapy)

[Q11-14: Toxicity Prophylaxis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-14-toxicity-prophylaxis)

[Q15-33: Hematologic Findings Prior to Lymphodepleting Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-33-hematologic-findings-prior-to-lymphodepleting-therapy)

[Q34-47: Socioeconomic information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q34-47-socioeconomic-information)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 11/6/2023 |
|

[4001: Pre-Cellular Therapy Baseline Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4001-pre-cellular-therapy-baseline-data)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)