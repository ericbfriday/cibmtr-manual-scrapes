Report findings at the time of diagnosis. If multiple studies were performed prior to beginning therapy, report the values closest to the diagnosis date of the primary disease for infusion.

#### Questions 24-25: Absolute lymphocyte count

Indicate whether the lymphocyte count was “known” or “unknown” at the time of WM or LPL diagnosis. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 25. If “unknown,” continue with question 26.

#### Questions 26-27: Hemoglobin

Indicate whether the hemoglobin was “known” or “unknown” at the time of WM or LPL diagnosis. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 27. If “unknown,” continue with question 28.

#### Questions 28-29: Platelets

Indicate whether the platelet count was “known” or “unknown” at the time of WM or LPL diagnosis. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 29. If “unknown,” continue with question 30.

#### Questions 30-31: Bone marrow aspirate (examined for histologic involvement)

Indicate whether the extent of histologic involvement in the bone marrow aspirate was “known” or “unknown” at the time of diagnosis. If bone marrow aspirate was not examined, report “not applicable.” If “known,” report the extent of aspirate histologic involvement in question 31. If “unknown” or “not applicable,” continue with question 32.

#### Questions 32-33: Bone marrow biopsy (examined for histologic involvement)

Indicate whether the extent of histologic involvement in the bone marrow biopsy was “known” or “unknown” at the time of diagnosis. If bone marrow biopsy was not examined, report “not applicable.” If “known,” report the extent of biopsy histologic involvement in question 33. If “unknown” or “not applicable,” continue with question 34.

#### Question 34: Specify the type of histological involvement in marrow

WM and LPL are often characterized by histologic involvement of the bone marrow. However, there are variations in the type of involvement:[2](#fn11035862068596c1a9a5e8-1)

*Lymphoplasmacytoid*: This variant is primarily defined by small lymphocytes with some plasmacytoid lymphocytes and rare mature plasma cells. Lymphoplasmacytoid cells (plasmacytoid lymphocytes) are mononuclear cells with dark, irregular nuclei. They are slightly larger than a small lymphocyte. Additionally, mitotic and large cells are rare.*Lymphoplasmacytic*: In this variant, the involved cells are a mix of small lymphocytes, plasmacytoid lymphocytes, and mature plasma cells. Mitotic and large cells are rare.*Polymorphous*: This variant can resemble either lymphoplasmacytoid or lymphoplasmacytic variants, but mitotic and large cells are more common. Large cells are still less common than in large cell lymphomas.

Specify the type of histologic involvement as indicated by the pathology report or transplant physician. Report “unknown” if the bone marrow was not examined, there was no bone marrow involvement, or if the type of histologic involvement cannot be specified.

2 Ioachim HL, Medeiros LJ. (2009) *Lymph Node Pathology*, 4th edition. Philadelphia, PA: Lippincott Williams & Wilkins.

#### Question 35: Was flow cytometry (immunophenotyping) performed?

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics. Its primary clinical purpose in the setting of WM or LPL is to identify unique cell populations through immunophenotyping.

Indicate if flow cytometry was performed at diagnosis. If flow cytometry was performed, check “yes” and continue with question 36.

If flow cytometry was not performed or it is unknown if flow cytometry was performed, indicate “no” or “unknown” and continue with question 43.

#### Questions 36-41: Specify cell population phenotype

Flow cytometry utilizes fluorescent-tagged monoclonal antibodies to identify cell marker expression by binding to cell surface antigens. Certain cell or disease panels use different combinations of monoclonal antibodies to identify cell markers that typically characterize that population, either by their presence or absence. Flow cytometry report formatting is highly variable among labs. However, most laboratories will summarize significant findings, including characteristics of the neoplastic cell population. Indicate if the cell population was “positive” or “negative” for each marker. If certain monoclonal antibodies were not part of the panel used, indicate “not done.”

#### Question 42: Was documentation submitted to the CIBMTR? (e.g., flow cytometry report)

Indicate if a copy of the flow cytometry report at diagnosis is attached. Use the Log of Appended Documents (Form 2800) to attach a copy of the report. Attaching a copy of the report may prevent additional queries.

#### Questions 43-44: Serum ß2 macroglobulin

Elevation in ß2 microglobulin at diagnosis is considered a negative prognostic indictor. Indicate whether ß2 microglobulin was “known” or “unknown” at the time of WM or LPL diagnosis. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 44. If “unknown,” continue with question 45.

#### Question 45: Serum heavy chain – IgM

Immunofixation is used to detect abnormal immunoglobulins in serum or urine, and to identify the heavy and/or light chain characterizing the clonal population. WM is generally characterized by an IgM monoclonal protein. Indicate whether an IgM paraprotein was identified on serum immunofixation.

#### Question 46: Urine heavy chain – IgM

Immunofixation is used to detect abnormal immunoglobulins in serum or urine, and to identify the heavy and/or light chain characterizing the clonal population. WM is generally characterized by an IgM monoclonal protein. Indicate whether an IgM paraprotein was identified on urine immunofixation.

#### Question 47: Serum light chain

Immunofixation is used to detect abnormal immunoglobulins in serum or urine, and to identify the heavy and/or light chain characterizing the clonal population. Report the light chain that was identified on serum immunofixation.

#### Question 48: Urine light chain

Immunofixation is used to detect abnormal immunoglobulins in serum or urine, and to identify the heavy and/or light chain characterizing the clonal population. Report the light chain that was identified on urine immunofixation.

#### Questions 49-51: Relative serum viscosity

Hyperviscosity syndrome is a common manifestation of WM and LPL. Indicate if relative serum viscosity was “known” or “unknown” at diagnosis. If “known,” report the laboratory value in question 50 and laboratory upper limit of normal in question 51. If “unknown,” continue with question 52.

#### Questions 52-53: Serum monoclonal protein (M-spike) (only from electrophoresis)

Indicate whether serum monoclonal protein quantification from electrophoresis was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 53. If serum electrophoresis was done and did not show monoclonal protein, report “0.” If “unknown,” continue with question 54.

#### Questions 54-55: Urinary monoclonal protein (M-spike)

Indicate whether 24-hour urine monoclonal protein quantification from electrophoresis was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 55. If urine electrophoresis was done and did not show monoclonal protein, report “0.” If “unknown,” continue with question 56.

#### Questions 56-58: LDH

LDH elevation at diagnosis is considered a negative prognostic indicator. Indicate whether LDH was “known” or “unknown” at diagnosis. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 57; report the laboratory upper limit of normal and unit of measure in question 58. If “unknown,” continue with question 59.

#### Question 59: Cold agglutinins

Cold agglutinin disease is a common manifestation of WM and LPL. Cold agglutinins are autoantibodies that bind to the red blood cells, manifesting as autoimmune hemolytic anemia. Indicate if cold agglutinins were “positive” or “negative” at diagnosis. If cold agglutinins were not tested or it is unknown if cold agglutinins were tested, report “unknown.”

#### Question 60: Cryoglobulin

Cryoglobulins are immunoglobulins that aggregate as a gel at temperatures below 37°C. Cryoglobulins may be mixed immunoglobulins or a single component; the majority of cryoglobulin in WM or LPL patients will be mixed IgM-IgG. Indicate if cryoglobulin was “present” or “absent” at diagnosis. If cryoglobulin was not tested or it is unknown if cryoglobulin was tested, report “unknown.”

#### Questions 61-63: IgG

Indicate whether IgG level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 62; report the laboratory upper limit of normal value and unit of measure in question 63. If “unknown,” continue with question 64.

#### Questions 64-66: IgA

Indicate whether IgA level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 65; report the laboratory upper limit of normal value and unit of measure in question 66. If “unknown,” continue with question 67.

#### Questions 67-69: IgM

Indicate whether IgM level was “known” or “unknown” at diagnosis. If “known,” report the laboratory value and unit of measure in question 68; report the laboratory upper limit of normal value and unit of measure in question 69. If “unknown,” continue with question 70.

#### Question 70: Were cytogenetics tested (conventional or FISH)?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality that reflects the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) and fluorescence *in situ* hybridization (FISH) testing. For more information about cytogenetic testing and terminology, see [Appendix C](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Indicate if cytogenetic studies were obtained at the time the recipient was diagnosed with WM or LPL, or prior to the start of treatment.

If cytogenetic studies were obtained, check “yes” and continue with question 71.

If cytogenetic studies were not obtained or it is unknown if cytogenetic studies were performed, indicate “no” or “unknown” and continue with question 76.

#### Question 71: Results of tests

If cytogenetic studies identified abnormalities (any karyotype other than 46XX or 46XY), indicate “abnormalities identified” and continue with question 72.

If cytogenetic studies yielded no evaluable metaphases or there were no abnormalities identified, indicate this and continue with question 76.

#### Questions 72-74: Specify abnormalities.

Deletion of the long arm of chromosome 6 is the most common structural abnormality in WM and LPL. However, other structural and numeric abnormalities have been noted.

If question 71 indicates that abnormalities were identified at the time of WM or LPL diagnosis, questions 72-73 must be answered as “yes” or “no.” Do not leave either response blank. If the patient had any abnormality other than del(6q), select “yes” for “other abnormality,” and specify in question 74.

#### Question 75: Was documentation submitted to the CIBMTR? (e.g., cytogenetic or FISH report)

Indicate if a copy of the cytogenetic or FISH report is attached. Use the Log of Appended Documents (Form 2800) to attach a copy of the cytogenetic or FISH report. Attaching a copy of the report may prevent additional queries.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 24 | 4/21/2023 | Modify | Clarified the instructions for the labs at diagnosis should reflect the labs closest to the date of diagnosis. | To ensure more consistent reporting, all labs for the “at diagnosis” timepoint were clarified to reflect the values obtained closest to the date of diagnosis, prior to the start of any therapy. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)