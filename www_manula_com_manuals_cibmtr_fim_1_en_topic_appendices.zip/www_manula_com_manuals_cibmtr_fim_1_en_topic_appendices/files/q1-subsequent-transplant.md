#### Question 1: Is this the report of a second or subsequent transplant or cellular therapy for the same disease?

If this is a report of a second or subsequent transplant/cellular therapy for the same disease subtype and **this baseline disease insert was not completed for the previous transplant** (e.g., recipient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), continue with question 2.

If this is a report of a second or subsequent transplant/cellular therapy for a **different disease** (e.g., recipient was previously transplanted for a disease other than MPN), begin at question 2.

If this is a report of a second or subsequent transplant/cellular therapy for the s*ame disease and this baseline disease insert has previously been completed*, select “yes” and continue with question 41.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)