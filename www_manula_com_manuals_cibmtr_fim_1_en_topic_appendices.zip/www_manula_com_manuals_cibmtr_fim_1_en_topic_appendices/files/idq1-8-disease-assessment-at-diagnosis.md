#### Question 1: What was the date of diagnosis of Immune Deficiency (ID)?

Immune Deficiencies are characterized by multiple clinical, laboratory, and genetic features. Definitive diagnosis is often based on molecular testing such as detection of mutations in IL-2RG for common gamma chain deficiency (X-linked SCID) or ADA for adenosine deaminase (ADA) deficiency. Report the date the specimen was collected for molecular analysis.

If molecular analysis was not performed, but diagnosis of the recipient with ID was based on newborn screening, report the date of the newborn screening sample collection.

If the recipient had a strong family history of the disease and was tested in utero, the date of birth should be used as the date of diagnosis.

#### Questions 2-4: What is the immune deficiency molecular abnormality?

A variety of molecular abnormalities have been identified in those with immune deficiencies. Indicate the molecular abnormality used to diagnose the recipient’s immune deficiency.

If the recipient was diagnosed with Omenn Syndrome, indicate the identified molecular abnormality in question 3.

If the recipient has an identified molecular abnormality other than those listed, indicate the other molecular abnormality in question 4.

| Disease | Circulating T cells | Circulating B cells | Molecular Abnormality | Inheritance |
|---|---|---|---|---|
Common gamma chain (γc; CD132) deficiencyMay also be referred to as IL2RG deficiency or X-linked SCID |
Markedly decreased | Normal or increased | Mutation in IL-2RG |
X-Linked |
| Adenosine deaminase (ADA) deficiency | Absent from birth or progressive decrease | Absent from birth or progressive decrease | Mutation of ADA |
Autosomal Recessive |
| Janus kinase 3 (JAK3) deficiency | Markedly decreased | Normal or increased | Mutation of JAK3 |
Autosomal Recessive |
| Recombination-activating gene 1 (RAG1) deficiency | Markedly decreased | Markedly decreased | Mutation of RAG1 |
Autosomal Recessive |
| Recombination-activating gene 2 (RAG2) deficiency | Markedly decreased | Markedly decreased | Mutation of RAG2 |
Autosomal Recessive |
| IL-7Rα deficiency | Markedly decreased | Normal or increased | Mutation of IL7RA |
Autosomal Recessive |
| DNA cross-link repair 1C (DCLRE1C) / Artemis deficiency | Markedly decreased | Markedly decreased | Mutation of DCLRE1C/ARTEMIS |
Autosomal Recessive |
| CD3γ (gamma) deficiency | Normal (reduced TCR expression) | Normal | Mutation of CD3G |
Autosomal Recessive |
| CD3δ (delta) deficiency | Markedly decreased | Normal | Mutation of CD3D |
Autosomal Recessive |
| CD3ε (epsilon) deficiency | Markedly decreased | Normal | Mutation of CD3E |
Autosomal Recessive |
| CD3ζ (zeta)-chain deficiency | Markedly decreased | Norma | l Mutation of CD3Z |
Autosomal Recessive |
| Zeta-chain (TCR) associated protein kinase 70 dKa (ZAP-70) deficiency | Decreased CD8, normal CD4 | Normal | Mutation in ZAP70 |
Autosomal Recessive |
| CD25 deficiency | Normal to decreased | Normal | Mutation in IL-2RA |
Autosomal Recessive |
| CD45 deficiency | Markedly decreased | Normal | Mutation of PTPRC |
Autosomal Recessive |
| Purine nucleoside phosphorylase (PNP) deficiency | Progressive Decrease | Normal | Mutation of PNP |
Autosomal Recessive |
| Cernunnos-XLF / NHEJ1 deficiency | Decreased | Decreased | Mutation in NHEJ1/Cernunnos |
Autosomal Recessive |
| DNA ligase 4 deficiency | Decreased | Decreased | Mutation in LIG4 |
Autosomal Recessive |
| DNA-protein kinase catalytic subunit (DNA-PKcs) deficiency | Markedly decreased | Markedly Decreased | Mutation of PRKDC |
Autosomal Recessive |
| Adenylate kinase 2 (AK2) deficiency (reticular dysgenesis) | Markedly Decreased | Decreased or normal | Mutation of AK2 |
Autosomal Recessive |
| Omenn syndrome | Present; restricted T-cell repertoire, and impaired function | Normal or decreased | Mutation(s) in RAG1, RAG2, ARTEMIS, IL7RA, RMRP, ADA, LIG4, IL2RG, AK2. Some cases have no defined gene mutation |
|
| Bare lymphocyte syndrome (MHC class II) deficiency | Normal number, decreased CD4 cells | Normal | Mutation in CIITA, RFX5, RFXAP, RFXANK transcription factors |
Autosomal Recessive |
| Cartilage-hair hypoplasia (CHH) / metaphyseal dysplasia, McKusick type | Varies from severely decreased to normal; impaired lymphocyte proliferation | Normal | Mutations in RMRP |
Autosomal Recessive |
Orai1 deficiencyMay also be referred to as Ca++ channel deficiency (orai1 defect) |
Normal number, but defective TCR-mediated activation | Normal | Mutation in ORAI1 |
Autosomal Recessive |

1 Adapted from: International Union of Immunological Societies Expert Committee on Primary Immunodeficiencies. “Primary immunodeficiencies: 2009 update” The Journal of Allergy and Clinical Immunology Volume 124, Issue 6 , Pages 1161-1178, December 2009.

2 Al-Herz, W., Bousfiha, A., Casanova, J. L., Chapel, H., Conley, M. E., Cunningham-Rundles, C., … & Tang, M. L. (2011). Primary immunodeficiency diseases: an update on the classification from the international union of immunological societies expert committee for primary immunodeficiency. *Frontiers in immunology*, 2.

#### Question 5: Is the mutated protein or enzyme expressed?

Immune Deficiency proteins or enzymes may be detected using tests such as Western blotting or an enzyme-linked immunosorbent assay (ELISA). Indicate whether the mutated protein or enzyme was expressed. If the protein or enzyme was expressed, select “yes.” If the protein or enzyme was not expressed, select “no.” If the test was not performed or the results of the test were inconclusive, select “unknown.”

#### Question 6: What is the pattern of inheritance for the genetic disorder?

Report the pattern of inheritance for the genetic disorder.

Sporadic inheritance indicates that there is no family history of the disease.

X-linked inheritance indicates that the genetic disease is located on the X chromosome and that the lack of a functioning copy of the gene causes the disease. Diseases inherited in an X-linked fashion are passed from parent to child via the X chromosome, a sex chromosome. X-linked disorders are much more common in males (XY) than females (XX) because only one copy of a mutation on the X chromosome is sufficient to cause the disorder in males, whereas females would require that the mutation is present on both X chromosomes to cause the disorder. X-linked SCID, or common gamma chain (γc; CD132) deficiency, is caused by a mutation in the IL2RG gene located on the chromosome X and is the most common type of primary immune deficiency. A second example of a disorder with X-linked inheritance is CD40 ligand deficiency 1.

Autosomal recessive inheritance indicates that two non-functioning copies of the gene are required to cause the disease. In the majority of cases, the mutations for the genetic disease were passed from both parents to the child. Autosomes are non-sex chromosomes numbered 1-22. Because the disorder is recessive, mutations must be present on each chromosome in the pair (i.e., the mutation must be present on the maternal and paternal chromosome) for the disease to be expressed. For example, ADA deficiency (or ADA-SCID) is an autosomal recessive disease caused by mutations in the q13.12 location of the maternally- and paternally -inherited copies of chromosome 20.

If the inheritance pattern was autosomal dominant, leave the question blank and override the error.

Indicate the pattern of inheritance. If the pattern of inheritance is not known, select “unknown” and continue with question 7.

1 International Union of Immunological Societies Expert Committee on Primary Immunodeficiencies. “Primary immunodeficiencies: 2009 update” The Journal of Allergy and Clinical Immunology Volume 124, Issue 6 , Pages 1161-1178, December 2009.

#### Question 7: Are the parents of the patient consanguineous (related by blood ancestry)?

Indicate if the recipient’s parents are related by blood ancestry. For example, if the parents of the recipient are first cousins (i.e., the parents are children of two siblings), the relationship is considered consanguineous. The limit for consanguinity is biological parents who are second cousins or less (Bittles A, Clin Genet 2001; 60; 89-98).

#### Question 8: Are there other blood relatives in the patient’s family with immunodeficiency disease?

Indicate if the recipient has blood relatives that have an immunodeficiency. Blood relatives include parents, siblings, grandparents, cousins, aunts, uncles, and other biological members of the recipient’s extended family, through great-grandparents.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)