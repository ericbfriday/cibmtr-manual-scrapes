Graft versus Host Disease (GVHD) is an immunological phenomenon resulting from the reaction of donor immune cells against major or minor histocompatibility antigens of the recipient. GVHD is primarily caused by donor-derived T-cells. Very rarely, GVHD may occur due to autologous reactivity (autologous GVHD), third party transfusions, or with identical twin transplantation. Factors influencing the severity of GVHD are related to three main categories:

- Donor or graft
- Recipient
- Treatment

The most influential donor/graft factor is the degree of genetic disparity between the donor and the recipient (HLA match), but other risk factors include female donor to male recipient, donor parity, older donors, and T-cell dose. The occurrence of acute GVHD becomes a risk factor for the development of chronic GVHD. Recipient age and prior infections are also factors.

### Determination of Acute vs Chronic GVHD

In the past, GVHD was classified as acute or chronic based on its onset following transplant, in addition to other clinical and histological (biopsy or post-mortem) features. Today, there has been increased recognition that acute and chronic GVHD are not dependent upon time since HCT, so determination of acute or chronic should rest on clinical and histologic features. **However, organ staging, and overall grade should only be calculated from the clinical picture, not histology.** Acute GVHD usually begins between 10 and 40 days after HCT but can appear earlier or later. The organs most affected by acute GVHD are the skin, gut, and / or liver. Other sites, such as the lung, may be involved.

### Reporting Acute and / or Chronic GVHD Developed versus Persisted

The CIBMTR forms capture if acute and / or chronic GVHD developed or persisted into the current reporting period. These questions are intended to capture if there were active symptoms of acute and / or chronic GVHD in the current reporting period. Additionally, these questions are intended to decrease the reporting burden by not requiring diagnostic GVHD information to be re-reported if it has been previous captured on a prior form. If GVHD was active during the reporting period, one of the two questions must be answered as **Yes**, depending on the type of GVHD being reported:

Acute GVHD


*Did acute GVHD develop since the date of last report?**Did acute GVHD persist since the date of last report?*

Chronic GVHD


*Did chronic GVHD develop since the date of the report?**Did chronic GVHD persist since the date of last report?*

There will not be a situation where **Yes** is reported for both the ‘developed’ and ‘persisted’ questions.

### GVHD Diagnosis Date

The Post-TED (2450) and Post-Infusion Follow-Up (2100) forms capture the diagnosis date of acute and chronic GVHD. The clinical diagnosis date of GVHD should be reported, which may not necessarily be the date when symptoms began. If there is a clinical diagnosis of GVHD but the diagnosis date is unclear, obtain documentation from the physician confirming the clinical diagnosis date.

If the physician cannot determine the exact date, use the process for reporting partial or unknown dates. Review the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for more information.

### Occurrence of Both Acute and Chronic GVHD

When there is a diagnosis of both acute and chronic GVHD, specific reporting rules are provided, designed to reduce the reporting burden. Review the guidance below to determine how to answer the GVHD data fields when there is a diagnosis of acute and chronic GVHD:

- When completing the acute GVHD section, do not include any signs, symptoms, or treatment occurring on or after the onset of chronic GVHD.
- If chronic GVHD was diagnosed in a prior reporting period, acute GVHD should never be reported after the diagnosis of the chronic GVHD (i.e., acute GVHD will never be reported in subsequent reporting periods).
- If there are any new or persistent acute GVHD symptoms occurring after the onset of chronic GVHD, those symptoms will be reported in the chronic GVHD section of the form.


**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)