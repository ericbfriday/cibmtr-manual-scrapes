#### Questions 1 – 2: Was hemoglobin electrophoresis performed? (do not include results if an RBC transfusion occurred within 4 weeks of the electrophoresis study)

Indicate if hemoglobin electrophoresis studies were performed in the current reporting period. If a hemoglobin electrophoresis studies were not performed or it is not known if performed, select **No** or **Unknown**, respectively and continue with *Were any red blood cell (RBC) transfusion administered?*

If a hemoglobin electrophoresis study was performed but RBC transfusion(s) were given within four weeks prior to the study, select **Not applicable** and continue with *Were any red blood cell (RBC) transfusion administered?*

If **Yes**, report the date (YYYY-MM-DD) of the most recent hemoglobin electrophoresis study performed in the reporting period. If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Questions 3 – 15: Specify the hemoglobin allele types based on the sample tested above

Specify the hemoglobin types identified in the reported hemoglobin study (reported in question 2). If the hemoglobin allele type was assessed, report **Yes** and specify the percentage.

If additional thalassemia related hemoglobin types are identified but not listed as options on the form, select **Yes** for *Other thalassemia related hemoglobin type*, specify the other hemoglobin type, and report the percentage.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)