#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the disease. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the other leukemia is CLL and CLL transformed to DLBCL (Richter syndrome), report the diagnosis date of DLBCL and the primary disease for infusion as **Non-Hodgkin lymphoma** above. Ensure the Hodgkin / Non-Hodgkin Lymphoma section is completed. The CLL diagnosis is captured in the Hodgkin / Non-Hodgkin Lymphoma section.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

#### Questions 386 – 387: Specify the other leukemia classification

CIBMTR captures the classification of AML based on the World Health Organization (WHO) 2022. Report the other leukemia disease classification at diagnosis. See below for general information about the other leukemia classifications listed on the form:


**CLL**, or chronic lymphocytic leukemia, is characterized by ≥ 5 × 10[^9]/L monoclonal lymphocytes with a CLL phenotype (usually co-expressed CD5 and CD23). The term SLL, or small lymphocytic lymphoma is used for non-leukemic cases with the tissue morphology and immunophenotype of CLL.**Hairy cell leukemia**is characterized by the presence of abnormal B-lymphocytes in the bone marrow, peripheral blood, and spleen.**PLL**, or prolymphocytic leukemia, is a type of CLL and is characterized by increased presence of immature prolymphocytes in the bone marrow and peripheral blood.

If the subtype is not listed, report as **Other leukemia** and specify the disease.

#### Question 388: Was any 17p abnormality detected?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality that reflects the recipient’s disease. Testing methods you may see include conventional chromosome analysis (karyotyping) or fluorescence *in situ* hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Indicate if cytogenetic studies detected any 17p abnormality at any time prior to the start of the preparative regimen.

If **Yes**, and the disease classification is CLL, continue with *Did a histologic transformation to diffuse large B-cell lymphoma (Richter syndrome) occur at any time after CLL diagnosis*. If **Yes**, and the disease classification is PLL, continue with to specify the disease status.

If cytogenetic studies did not detect any 17p abnormality at any time prior to the start of the preparative regimen, select **No**.

#### Question 389: Did a histologic transformation to diffuse large B-cell lymphoma (Richter syndrome) occur at any time after CLL diagnosis?

Always report this question as **No.** This question will be updated in future releases. If CLL transformed, the primary disease should be reported as **Hodgkin lymphoma** or **Non-Hodgkin’s lymphoma** – do not report the primary disease as **Other leukemia.**

#### Question 390: What was the disease status? (Atypical CML)

Indicate the disease status for atypical CML at the last evaluation prior the start of the preparative regimen (or infusion of no preparative regimen was given). If no treatment was given prior to HCT, select **No treatment** and submit the form.

*Disease Status of Atypical CML*

*Primary Induction Failure (PIF)*

The patient received treatment for atypical CML **but never achieved complete remission at any time**. PIF is not limited by the number of unsuccessful treatments; this disease status only applies to recipients who have *never been in complete remission.*

*Complete Remission (CR)*

**All** of the following criteria are met and maintained for four or more weeks:


- Marrow with normal maturation of all cellular components
- ≤ 5% blasts in the marrow
- No signs or symptoms of the disease

If the timeframe between achieving CR and the start date of the HCT (i.e., day 0) is less than four weeks, and the recipient is believed to be in CR, report the status at transplantation as CR.

*Important: if within four weeks following transplant the recipient’s status is determined to not be CR, an Error Correction Form must be submitted to change the pre-HCT status.*

Include recipients with persistent cytogenetic abnormalities who otherwise meet all the criteria of CR.

Report that the recipient is in CR at the time of transplant no matter how many courses of therapy it may have taken to achieve that CR.

The number of this complete remission can be determined by using the following guidelines:


- 1st CR: no prior relapse
- 2nd CR: one prior relapse
- 3rd or higher: two or more prior relapses

*Relapse (REL)*

Recurrence of disease after CR. Relapse is defined as:


- > 5% blasts in the marrow
- Extramedullary disease
- Reappearance of cytogenetic abnormalities and/or molecular markers associated with the diagnosis at levels that, as determined by a physician, represent relapse.

The number of this relapse can be determined by using the following guidelines:


- 1st relapse: one prior CR
- 2nd relapse: two prior CRs
- 3rd or higher: three or more CRs

*No treatment*

The recipient was diagnosed with atypical CML and never treated.

#### Question 391: What was the disease status? (CLL, PLL, Hairy cell leukemia, Other leukemia)

Indicate the disease status for CLL / SLL, PLL, hairy cell leukemia, or other leukemia at the last evaluation prior the start of the preparative regimen (or infusion if no preparative regimen was given). If no treatment was given prior to HCT, select Untreated and submit the form.

If reporting **CLL / SLL** or **PLL**, refer to the [CLL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-response-criteria) section of the Forms Instructions Manual for definitions of each response.

*Disease Status of Hairy Cell Leukemia*[1](#fn68033196868596b10bcd12-1)

*Untreated*

The recipient was diagnosed with hairy cell leukemia and never treated.

*Complete Remission (CR)*

Disappearance of all evidence of disease.

Requires **all** of the following:


- Neutrophils ≥ 1.5 × 10
9 - Hemoglobin ≥ 11.0 g/dL (without transfusion)
- Platelets ≥ 100 × 10
9/L - Absence of hairy cells on peripheral blood smear and on bone marrow examination
- No palpable lymphadenopathy or hepatosplenomegaly

*Partial Remission (PR)*

Requires **all** of the following:


- ≥ 50% reduction in the absolute hairy cell count in the peripheral blood and the bone marrow
- ≥ 50% improvement of all cytopenias
- ≥ 50% reduction in abnormal lymphadenopathy or hepatosplenomegaly

*Stable Disease (SD)*

Not meeting the criteria for any of the other disease response criteria.

*Progressive Disease*

Requires one or more of the following:


- ≥ 25% increase in the absolute hairy cell count in the peripheral blood and/or bone marrow
- ≥ 25% decrease in any of the hematologic parameters (i.e., neutrophils, hemoglobin or platelets)
- ≥ 25% increase in abnormal lymphadenopathy or hepatosplenomegaly

*Not assessed*

No assessment of organomegaly, peripheral blood counts, absolute hairy cell count in the bone marrow or the peripheral blood smear was done at any time after treatment.

*Relapse (untreated)*

Relapse after CR:


- Reappearance of hairy cells in the peripheral blood smear and/or bone marrow (regardless of the degree of infiltration)
- Development of peripheral blood cytopenias
- Splenomegaly

Relapse after PR:


- ≥ 50% increase of residual hairy cells in the marrow
- Development of cytopenias
- Splenomegaly insufficient to qualify as PR

OR - Reappearance of hairy cells in the bone marrow of those patients who had been classified as partial responders based on residual splenomegaly only

1 Saven, A., Burian, C., Koziol, J. A., & Piro, L. D. (1998). Long-term follow-up of patients with hairy cell leukemia after cladribine treatment. *Blood*, 92(6), 1918-1926.

*Other leukemia:*

To determine the disease status, use the criteria for the leukemia that most closely resembles the disease for which this form is being completed. For questions, contact the CIBMTR Customer Service Center.

#### Question 392: Date assessed

Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q390 | 1/24/2025 | Add | Myelodysplastic/myeloproliferative neoplasm with neutrophilia and Disease Status added: Myelodysplastic/myeloproliferative neoplasm with neutrophilia and Disease Status: As of October 2024, atypical CML is captured as an MDS and the disease classification is reported as Myelodysplastic/myeloproliferative neoplasm with neutrophilia. The disease status for Myelodysplastic/myeloproliferative neoplasm with neutrophilia will be reported in the Other Leukemia section of the form. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)