Best response is based on response to the HCT and does NOT include response to therapy given for disease relapse or progression post-HCT.


- If the HCT or cellular therapy was planned as part of initial therapy for a recipient with no disease progression or relapse at any time prior to HCT or cellular therapy, determine the best response by comparing to the disease assessment at the time of initial diagnosis.
- If the HCT or cellular therapy was performed later in the disease course for a patient who has not received any chemotherapy within 6 months of HCT or cellular therapy or has untreated relapse or progression, determine the best response to HCT or cellular therapy by comparing the disease status immediately prior to the start of the preparative regimen.
- If the patient had a disease progression or relapse of disease at any time prior to HCT or cellular therapy and was treated to reduce the myeloma burden prior to the start of the preparative regimen, determine the best response to HCT or cellular therapy by comparing to the disease evaluation at the time of relapse or progression. In other words, the baseline is reset to the time of relapse or progression.
- This comparison is meant to capture the best disease status in response to HCT or cellular therapy that occurred in the reporting interval, even if a subsequent disease relapse or progression occurred during the same reporting interval. If a recipient already achieved their best response in a previous reporting interval, confirm the best response and indicate that the date was previously reported (question 4).

#### Question 3: For all recipients with primary disease multiple myeloma / plasma cell disorder (PCD) classifications, excluding Amyloidosis, compared to the disease status prior to the preparative regimen, what was the best hematologic response to HCT or cellular therapy since the date of last report? (Include response to any therapy given for post-HCT or post-cellular therapy maintenance or consolidation, but exclude any therapy given for relapsed, persistent, or progressive disease)

The intent of this question is to determine the best overall response to HCT or cellular therapy, which could include any response to planned therapy post-HCT or cellular therapy, or to therapy given for maintenance or prophylaxis. (DO NOT include any response to treatment given for relapsed or progressive disease.) This is assessed in each reporting period. When evaluating the best response, determine the disease status within the reporting period and compare it to all previous post-HCT or post-cellular therapy reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status. See question 4 to indicate that this disease status was previously reported.

See the [Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria) section for multiple myeloma and solitary plasmacytoma disease status definitions. See [Plasma Cell Leukemia Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/pcl-response-criteria) for plasma cell leukemia disease status definitions.

This question will not be enabled if the primary disease for transplant is monoclonal gammopathy of renal significance (MGRS).

If the recipient was already in CR at the start of the preparative regimen, select **Continued complete response (CCR)**, and continue with question 4.

**Example 1**: A myeloma patient is transplanted in PR. In the 100-day reporting period all the CR criteria (3% plasma cells in the bone marrow, SPEP/UPEP negative) are met with the exception of a positive immunofixation on serum and urine (two disease assessments were performed in the reporting period indicating a positive immunofixation); in this case VGPR should be reported as the best response to transplant.

**Example 2**: A recipient with myeloma goes to transplant having established a PR prior to transplant, achieves a VGPR during the first 100 days, and then progresses during the six-month reporting period. The best response to transplant should be reported as “VGPR” on all subsequent forms. See below:


| Reporting Period | Current Disease Status | Q1. Best Response | Q5. Date Assessed |
|---|---|---|---|
| Pre-transplant | PR | —- | —- |
| 100-Days Post-HCT | VGPR | VGPR | [date of 1st confirmatory labs] |
| 6-Months Post-HCT | Progression | VGPR | Previously Reported |
| 1-Year Post-HCT | PR | VGPR | Previously Reported |

**Example 3**: A recipient with myeloma goes to transplant having established a CR prior to transplant, maintains the response after transplant, and then relapses within the six-month reporting period. The best response to transplant would be reported as “CCR” for all subsequent reporting periods. See below:


| Reporting Period | Current Disease Status | Q1. Best Response | Q5. Date Assessed |
|---|---|---|---|
| Pre-transplant | CR | —- | —- |
| 100-Days Post-HCT | CR | CCR | [date of labs that first confirmed a continued CR] |
| 6-Months Post-HCT | Relapsed | CCR | Previously Reported |
| 1-Year Post-HCT | VGPR | CCR | Previously Reported |

**Example 4**: A recipient with myeloma goes to transplant having established a PR prior to transplant and maintains the response throughout the 100-day reporting period. During the six-month reporting period, the recipient progresses and begins unplanned therapy to treat the worsening disease. During the one-year reporting period, the recipient achieves VGPR. The best response to transplant occurred during the 100-day reporting period because response to unplanned therapy is not captured using this set of questions. See below:


| Reporting Period | Current Disease Status | Q1. Best Response | Q5. Date Assessed |
|---|---|---|---|
| Pre-transplant | PR | —- | —- |
| 100-Days Post-HCT | PR | PR | [date of latest labs that confirmed a continued PR] |
| 6-Months Post-HCT | Progression | PR | Previously Reported |
| 1-Year Post-HCT | VGPR | PR | Previously Reported |

**Example 5**: A recipient with myeloma goes into transplant having established VGPR prior to transplant and maintains the response throughout the 100-day reporting period. During the six-month reporting period, the recipient achieves a CR and is placed on maintenance therapy. During the one-year reporting period the recipient maintains the CR. The best response to transplant occurred in the six-month reporting period. See below:


| Reporting Period | Current Disease Status | Q1. Best Response | Q5. Date Assessed |
|---|---|---|---|
| Pre-transplant | VGPR | —- | —- |
| 100-Days Post-HCT | VGPR | VGPR | [date of latest labs that confirmed a continued VGPR] |
| 6-Months Post-HCT | CR | CR | date of labs that first confirmed CR |
| 1-Year Post-HCT | CR | CR | Previously Reported |

#### Question 4: Was the date of best response previously reported?

Indicate if the best response was reported on a previous post-HCT plasma cell disorder form (Form 2116). If **Yes**, and the recipient has a preceding / concurrent diagnosis of amyloidosis (question 2) continue with question 6. If not, continue with question 142.

If the best response achieved during the 100-day reporting period is the same as the pre-transplant disease status, select **No**, report the latest disease assessment that confirmed the ongoing disease status post-HCT in question 5. For all subsequent reporting periods, report **Yes**, until a better disease response is achieved.

If the recipient’s pre-transplant disease status was **Continued complete response (CCR)**, select No, report the date of the first assessment that confirmed the ongoing CR in question 5 on the 100-day form. For all subsequent reporting periods, report Yes.

#### Question 5: Date assessed

Enter the date the best response first began. Report the date of the first assessment, *not* the date of the second confirmatory assessment. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathologic examination.

If the recipient has a preceding / concurrent diagnosis of amyloidosis (question 2) continue with question 6. If not, continue with question 9.

**Example 1**: A recipient with myeloma goes into transplant having established a PR prior to transplant. During the 100-day reporting period, the recipient achieves a VGPR. However, the second disease assessment to confirm the VGPR was not performed until one month later (which is in the next reporting period). Those results are available at the time the Day 100 disease form is being completed. The best response to transplant would be reported as “VGPR” with the date it first began in the 100-day reporting period. The recipient maintains the VGPR in the six-month reporting period. The best response to transplant would be reported as “VGPR” with the date as “previously reported” in the six-month reporting period.

**Example 2**: A recipient with myeloma goes into transplant having established a PR prior to transplant. During the 100-day reporting period, the recipient achieves a VGPR. However, a second disease assessment to confirm the VGPR response is not available when the form is being completed. The best response to transplant would be reported as “PR” with the date of the latest disease assessment.

**Example 3**: A recipient with myeloma goes into transplant having established a PR prior to transplant. During the 100-day reporting period, the recipient achieves a VGPR. However, a second disease assessment to confirm the VGPR response is not available when the form is being completed. The best response to transplant would be reported as “PR” with the date of the latest disease assessment in the 100-day reporting period. When completing the six-month form, a second disease assessment to confirm a VGPR response is available. The best response to transplant would be reported as “VGPR.” However, since the VGPR first began during the Day 100 reporting period, an error correction needs to be completed to update the disease status and date first achieved on the Day 100 report.

#### Question 6: For recipients with primary disease or concurrent / history of Amyloidosis, compared to the disease status prior to the preparative regimen, what was the best hematologic response to HCT or cellular therapy since the date of last report? (Include response to any therapy given for post-HCT or post-cellular therapy maintenance or consolidation, but exclude any therapy given for relapsed, persistent, or progressive disease):

The intent of this question is to determine the best overall response to HCT or cellular therapy, which could include any response to planned therapy post-HCT or post-cellular therapy, or to therapy given for maintenance or prophylaxis. (DO NOT include any response to treatment given for relapsed or progressive disease.) This is assessed in each reporting period. When evaluating the best response, determine the disease status within the reporting period and compare it to all previous post-HCT or post-cellular therapy reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status. See question 7 to indicate that this disease status was previously reported.

See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

If the recipient was already in CR at the start of the preparative regimen, select **Continued complete response (CCR)**, and continue with question 7.

#### Question 7: Was the date of best response previously reported?

Indicate **Yes** or **No** if the best response was reported on a previous post-HCT plasma cell disorder form (Form 2116). If **No**, continue with question 54.

If the best response achieved during the 100-day reporting period is the same as the pre-transplant disease status, select **No**, report the latest disease assessment that confirmed the ongoing disease status post-HCT in question 8. For all subsequent reporting periods, report **Yes** until a better disease response is achieved.

If the recipient’s pre-transplant disease status was Continued complete response (CCR), select No, report the date of the first assessment that confirmed the ongoing CR post-HCT in question 8 on the 100-day form. For all subsequent reporting periods, report Yes.

#### Question 8: Date assessed

Enter the date the best response first began and continue with question 9. Report the date of the first assessment, not the date of the second confirmatory assessment. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathologic examination.

## Laboratory Assessments at the Time of Best Response

Questions 9-33 refer to disease assessments performed at the time of best response for their primary disease for infusion (question 5 or 8). Report testing performed closest to the date of best response and within the time windows in the Disease Assessment Time Windows table.

**Disease Assessment Time Windows**


| Follow-Up Form | Approximate Range |
|---|---|
| 100 Day | +/- 15 days of date of best response (question 5 or 8) |
| 6 Month | +/- 15 days of date of best response (question 5 or 8) |
| Annual | +/- 30 days of date of best response (question 5 or 8) |

#### Questions 9 – 11: Serum creatinine

Indicate whether the serum creatinine was **Known** or **Unknown** at the time of best response. If **Known**, report the laboratory value, unit of measure, and specify the upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 12.

#### Questions 12 – 13: Serum monoclonal protein (M-spike) (only from electrophoresis)

Monoclonal gammopathy is defined as the increased production of abnormal immunoglobulins. The abnormal protein produced is called paraprotein or M-protein. Indicate whether the serum monoclonal immunoglobulin was **Known** or **Unknown** at the time of best response If **Known**, report the value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 14. Report **Not applicable** for recipients with non-secretory myeloma.

Do not report immunofixation results here.

#### Question 14: Serum immunofixation

Serum immunofixation is a laboratory technique that detects and types monoclonal antibodies or immunoglobulins in the blood. If **Unknown** or **Not applicable**, continue with question 17. Report **Not applicable** for recipients with non-secretory myeloma.

#### Question 15: Original monoclonal bands

Indicate **Yes** if the original monoclonal band was present or **No** if it was not present.

#### Question 16: New monoclonal (or oligoclonal) bands

Indicate **Yes** if a new monoclonal band (or oligoclonal) was present or **No** if it was not present.

#### Questions 17 – 19: Serum free light chains – κ (kappa)

Indicate whether the serum κ (kappa) free light chain level at the time of best response is **Known** or **Unknown**. This value should reflect the quantity of serum free light chains, not a quantification of total light chains. If **Known**, report the value, unit of measure, and the upper limit of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 20. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 20 – 22: Serum free light chains – λ (lambda)

Indicate whether the serum λ (lambda) free light chain level at the time of best response is **Known** or **Unknown**. This value should reflect the quantity of serum free light chains, not a quantification of total light chains. If **Known**, report the laboratory value, unit of measure, and the upper limit of normal, as documented on the laboratory If **Unknown** or **Not applicable**, continue with question 23. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 23 – 24: Urinary monoclonal protein (M-spike) / 24 hours

Indicate whether the amount of urinary monoclonal protein at the time of best response is **Known** or **Unknown**. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 25. Report **Not applicable** for recipients with non-secretory myeloma.

Do not report immunofixation results here.

**Example**:

(total in g/dL of monoclonal protein) x (total urine volume) = **urinary M-protein/24 hours**

(0.145 g/dL of monoclonal protein) x (1500 mL total urine) x (1 dL/100 mL) = **2.175 g/24 hours**

#### Question 25: Urinary immunofixation

Urine immunofixation is a laboratory technique that detects and types monoclonal antibodies or immunoglobulins in the urine. Indicate if the results of urinary immunofixation at the time of best response are **Known** or **Unknown**. If **Unknown** or **Not applicable**, continue with question 28. Report **Not applicable** for recipients with non-secretory myeloma.

#### Question 26: Original monoclonal bands

Indicate **Yes** if the original monoclonal band was present or **No** if it was not present.

#### Question 27: New monoclonal (or oligoclonal) bands

Indicate **Yes** if a new monoclonal (or oligoclonal) band was present or **No** if it was not present.

#### Questions 28 – 29: Total urine protein in 24 hours

Indicate whether the amount of urinary protein at the time of best response was **Known** or **Unknown**. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure. If **Unknown** or **Not applicable**, continue with question 30. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 30 – 31: Urine albumin / creatinine ratio

Indicate whether the urinary albumin / creatinine ratio was **Known** or **Unknown** at the time of best response. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 32. This question is only required if the primary disease (question 1) is MGRS or Amyloidosis or if there is evidence / history of (question 2) MGRS or Amyloidosis.

#### Questions 32 – 33: Urine protein / creatinine ratio

Indicate whether the urinary protein / creatinine ratio was **Known** or **Unknown** at the time of best response. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 34. This question is only required if the primary disease (question 1) is MGRS or Amyloidosis or if there is evidence / history of (question 2) MGRS or Amyloidosis.

#### Question 34: Was minimal residual disease (MRD) assessed post-HCT / CT or post-infusion evaluation? (report only bone marrow or blood results)

Minimal residual disease (MRD), is an indicator of increased risk for disease relapse and / or progression. MRD can be assessed by different methods including, but not limited to, next generation sequencing (NGS), Sanger sequencing, polymerase chain reaction (PCR) testing, chromosomal / genomic microarray analysis, fluorescence in situ hybridization (FISH), karyotyping, or flow cytometry.

Indicate if MRD was performed by next generation sequencing (NGS) or next generation flow (NGF) at the time of best response.

If any MRD testing was performed for patients with myeloma, answer this question as **Yes**. If no MRD testing methods were performed or it was not known if performed, report **No** or **Unknown** and continue with question 43.

#### Questions 35 – 36: Next generation sequencing (NGS)

Indicate whether the MRD result at the time of best response is **Positive**, **Negative**, or **Not done** by NGS testing. If **Positive**, report the sample source (**Blood** or **Bone marrow**). If **Negative** or **Not done**, continue with question 39.

#### Questions 37 – 38: Indicate the sensitivity of the next generation sequencing (NGS) testing

Indicate the testing sensitivity of the NGS testing performed at the time of best response. If the specificity is not listed in this section, report **Other** and specify the sensitivity as documented on the laboratory report in question 38.

#### Questions 39 – 40: Next generation flow (NGF)

Indicate whether the MRD result at the time of best response is **Positive**, **Negative**, or **Not done** by NGF testing.

- If
**Positive**, report the sample source (**Blood**or**Bone marrow**) - If
**Negative**, report the sample source (**Blood**or**Bone marrow**) - If
**Not done,**continue with question 43

#### Questions 41 – 42: Indicate the sensitivity of the next generation flow (NGF) testing

Indicate the testing sensitivity of the NGF testing performed at the time of best response.

NGF testing is used to identify minimal residual disease (MRD) in patients with multiple myeloma. Some NGF reports include a “level of detection” rather than a “level of sensitivity.” In these cases, the “level of sensitivity” can be derived from the level of detection. Please refer to the report and example below for further instruction.


**Example:**


- Level of Detection: 0.001
*is equal to:* - Level of Sensitivity: 10
-5(1/100,000 cells)*and should be reported in question 41)*

If the specificity is not listed in this section, report **Other** and specify the sensitivity as documented on the laboratory report.

#### Questions 43 – 44: Plasma cells in bone marrow aspirate by flow cytometry

Indicate whether the percentage of plasma cells in the bone marrow aspirate assessed by flow cytometry at the time of best response is **Known** or **Unknown**. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 45.

#### Questions 45 – 46: Plasma cells in bone marrow aspirate by morphologic assessment

Indicate whether the percentage of plasma cells in the bone marrow aspirate was **Known** or **Unknown** by morphologic assessment at the time of best response. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 47.

#### Questions 47 – 48: Plasma cells in bone marrow biopsy

Indicate whether the percentage of plasma cells in the bone marrow biopsy at the time of best response is **Known** or **Unknown**. If **Known**, report the percentage of plasma cells in the bone marrow biopsy documented on the pathology report. If **Unknown**, continue with question 49.

#### Question 49: Was a PET / CT scan performed?

A PET / CT combines the results of the PET (Positron Emission Tomography) scan along with the results of a CT (Computed Tomography) scan. If a PET / CT scan was performed at the time of best response, indicate **Yes**. If a PET / CT scan was not performed, select **No** and continue with question 54.

#### Questions 50 – 51: Was the PET / CT scan positive for myeloma involvement at any disease site?

Indicate if the PET / CT scan was positive for myeloma involvement at any disease site. If positive at any site, report **Yes** and specify which area(s) show involvement in question 51. If negative, report **No** and continue with question 52.

#### Questions 52 – 53: Date of PET / CT scan

Indicate if the date of the PET / CT scan was **Known** or **Unknown** at the time of best response. If **Known**, report the assessment date. If **Unknown**, continue with question 54.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)