#### Question 1: Was the recipient red blood cell (RBC) transfusion independent since the date of the last report?

Indicate if the recipient was RBC transfusion independent for the entire reporting period.

Some discretion may be required if the recipient received a transfusion for a surgical procedure or other reason. If a recipient received an RBC transfusion for a procedure and would otherwise be transfusion independent, the recipient may still be reported as being transfusion independent.

If the recipient did not receive an RBC transfusion in the reporting period or was never dependent on RBC transfusions, report **Yes** and continue with question 3.

If the recipient received one or more RBC transfusion(s) in the reporting period, report **No** and specify the date of the most recent RBC transfusion administered in the current reporting period.

If it is not known if the recipient was RBC transfusion independent on the date of contact, select **Unknown** and continue with question 3. This option should be used sparingly and only when there is no information to determine if any RBC transfusions were administered in the current reporting period.

#### Question 2: Date of the most recent RBC transfusion

Report the date of the most recent RBC transfusion administered in the current reporting period.

If the recipient was RBC transfusion independent for ≥ one month, but subsequently experienced a decline in RBCs and required transfusions, report the date of the last RBC transfusion *before* the date of decline. If the recipient did not require any RBC transfusions since the initial date of recovery, record the date of the last RBC transfusion administered in the current reporting period.

#### Question 3: Was the recipient platelet transfusion independent since the date of the last report?

Indicate if the recipient was platelet transfusion independent for the entire reporting period.

Some discretion may be required if the recipient received a transfusion for a surgical procedure or other reason. If a recipient received a platelet transfusion for a procedure and would otherwise be transfusion independent, the recipient may still be reported as being platelet transfusion independent.

If the recipient did not receive a platelet transfusion in the reporting period or was never dependent on platelet transfusions, report **Yes** and continue with question 5.

If the recipient received one or more platelet transfusion(s) in the reporting period, report **No** and specify the date of the most recent platelet transfusion administered in the current reporting period.

If it is unknown if the recipient was platelet transfusion independent on the date of contact, select **Unknown** and continue with question 5. This option should be used sparingly and only when there is no information to determine if any platelet transfusions were administered in the current reporting period.

If the recipient was never dependent on platelet transfusions or never received a platelet transfusion in the prior reporting period, select **Not applicable / never dependent** and continue with question 5.

#### Question 4: Date of most recent platelet transfusion

Report the date of the most recent platelet transfusion.

If the recipient was platelet transfusion independent for ≥ 14 days, but subsequently experienced a decline in platelets and required transfusions, record the date of the last platelet transfusion *before* the date of decline. If the recipient did not require any platelet transfusions since the initial date of recovery, record the date of the last platelet transfusion administered in the current reporting period.

If the date reported on question 4 is more than seven days prior to the date of contact, evaluate if the recipient is platelet transfusion independent.

#### Questions 5 – 6: Specify reticulocyte level (uncorrected)

Reticulocytes are newly produced, relatively immature red blood cells (RBCs). A reticulocyte count helps determine the number and / or percentage of reticulocytes in the blood and is a reflection of recent bone marrow function or activity. Reticulocytes are in the blood for 2 days before developing into mature red blood cells.

When a recipient has anemia the number of red blood cells, hemoglobin, and hematocrit are low and thus the percentage of reticulocytes may appear high compared to the overall number of RBCs. In order to get a more accurate assessment of bone marrow function, the reticulocyte percentage is often corrected with a calculation called a corrected reticulocyte count, which is equal to the following:

**Corrected reticulocyte count = Reticulocyte percentage x Patient’s hematocrit % / Average normal hematocrit**

The above formula will correct for hemoglobin and thus show if the patient is making enough reticulocytes for the degree of anemia present. For reporting purposes, the CIBMTR data collection forms would like the absolute or uncorrected reticulocyte level.

If uncorrected serum reticulocyte count is **Known** for the current reporting period, report the value documented on the laboratory report. Report the absolute value of reticulocytes in 109 / L. Do not report a percentage, the corrected reticulocyte count, or the reticulocyte production index. If the reticulocyte count was assessed multiple times during the reporting period, report the results of the latest reticulocyte count.

If the uncorrected reticulocyte count is not unknown or the recipient received an RBC transfusion within 30 days prior to the last reticulocyte count, select **Not known / transfused** and continue with the signature line.

#### Signature Lines:

The FormsNet3SM application will automatically populate the signature data fields, including name and email address of person completing the form and date upon submission of the form.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)