For each method of assessment, report **Yes** if that method detected the recipient’s MDS (or markers of MDS) during the reporting period. If testing by a particular method (e.g., molecular makers, cytogenetic, flow cytometry, etc.) was done, but did not show evidence of disease during the reporting period, report **No** for that method. If testing for splenomegaly, hepatomegaly, molecular or cytogenetic markers / abnormalities, or bone marrow was not done during the reporting period or it is not known whether testing was performed, report **Unknown** for those methods. If testing by flow cytometry, extramedullary disease detection or other assessment was not done during the reporting period or it is not known whether testing was performed, report **No** for those methods.

#### Questions 88-89: Did the recipient have splenomegaly?

Indicate if the recipient had splenomegaly indicative of disease detection since the date of the last report. Splenomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate **Yes** if splenomegaly was present and indicated disease detection since the date of the last report and report the date of assessment in the next question.

Indicate **No** if splenomegaly was not present, or if splenomegaly was not indicative of disease, since the date of the last report and continue to *Did the recipient have hepatomegaly?*

Indicate **Unknown** if it is not possible to determine the presence or absence of splenomegaly since the date of the last report and continue to *Did the recipient have hepatomegaly?*

Indicate **Not applicable** if the question does not apply to the recipient (e.g. prior Splenectomy or congenital asplenia) and continue to *Did the recipient have hepatomegaly?*

#### Question 90: Specify the method used to measure spleen size:

Indicate the method used to measure the spleen size, if the method selected is **Physical assessment** continue with question 91. If the method selected is **Ultrasound** or **CT / MRI** continue with question 92. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 91: Specify the spleen size in centimeters below the left costal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 93.

#### Question 92: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 93.

#### Question 93: Was this considered a disease relapse?

If the physician believes the size of the spleen indicates a disease relapse, check **Yes.** If the recipient had an enlarged spleen, but the physician does not believe the result represents disease relapse, check **No**. Continue to the next question.

#### Questions 94-95: Did the recipient have hepatomegaly?

Indicate if the recipient had hepatomegaly indicative of disease detection since the date of the last report. Hepatomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding.

Indicate **Yes** if hepatomegaly was present and indicated disease detection since the date of the last report and report the date of assessment in question 95. Indicate **No** if hepatomegaly was not present, or if hepatomegaly was not indicative of disease, since the date of the last report and continue with question 100. Indicate **Unknown** if it is not possible to determine the presence or absence of hepatomegaly since the date of the last report and continue with question 100.

#### Question 96: Specify the method used to measure liver size:

Indicate the method used to measure the liver size, if the method selected is **Physical assessment** continue with question 97. If the method selected is **Ultrasound** or **CT / MRI** continue with question 98. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Questions 97: Specify the liver size in centimeters below the right costal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 99.

#### Question 98: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 99.

#### Question 99: Was this considered a disease relapse?

If the physician believes the size of the liver indicates a disease relapse, check **Yes.** If the recipient had an enlarged liver, but the physician does not believe the finding represents disease relapse, check **No.** Continue with question 100.

#### Question 100: Were molecular tests for molecular markers performed (e.g., PCR, NGS)?

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. FISH testing for molecular markers should **NOT** be reported here.

Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If any molecular testing for molecular markers was performed and disease was detected during the reporting period, report **Yes** and go to question 101.

If molecular testing for molecular markers was performed but did not detect disease at any time during the reporting period, report No.

If molecular testing for molecular markers was not performed at any time during the reporting period, or it is unknown if testing was done, report **Unknown** respectively and go to question 109.

#### Question 101: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker associated with the recipient’s primary disease was identified during the reporting period.

If a positive molecular marker associated with the recipient’s primary disease was identified, select **Yes** and continue with question 102.

If there were no molecular markers associated with the recipient’s primary disease identified, no positive molecular markers identified, or it is unknown whether molecular markers were identified, select **No** and continue with question 108.

#### Question 102: Date sample collected

Report the date the sample was collected for molecular testing. If disease was detected multiple times by this method of assessment in the reporting period, report the first assessment which detected disease.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 103-104: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 105. If a positive marker is detected, but not listed as an option, select **Other molecular marker** and specify the positive molecular marker in question 104.

#### Questions 105-106: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

Figure 1. Molecular disease assessment with amino acid changes documented (highlighted in yellow).

For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 105, indicate if the amino acid change is **Known** or **Unknown** for the positive molecular marker reported in questions 103-104. If known, report the amino acid change in question 106. If unknown, continue with question 107.

Copy questions 103-106 to report more than one positive molecular marker.

#### Question 107: Was this considered a disease relapse?

Indicate if the molecular abnormalities were considered a disease relapse. Criteria for molecular relapse are established by clinical judgment, and should reflect the clinical decision of the transplant physician. A recipient may be reported to have molecular relapse even in the setting of hematologic CR; criteria for complete remission are based on hematologic and pathologic characteristics and are independent of molecular markers of disease.

If the recipient has molecular abnormalities that the physician considers to be consistent with disease relapse, select **Yes**.

If the recipient has molecular abnormalities that the physician does not consider to be consistent with molecular relapse, select **No**.

#### Question 108: Was documentation submitted to the CIBMTR?

Indicate if the pathology report is attached to support the molecular findings reported in questions 102-106. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 109: Was disease detected via flow cytometry?

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

If disease was detected via flow cytometry, select **Yes** and continue to the next question.

If disease was not detected via flow cytometry, flow cytometry wasn’t performed at any time during the reporting period, or it is unknown if disease was detected via flow cytometry, select **No** and continue to *Was disease detected via cytogenetic testing (karyotyping or FISH)?*

#### Question 110-112: Blood

Indicate whether flow cytometry detected disease in a blood sample at any time during the reporting period. If **Yes** report the date the sample was collected and the percent disease detected (i.e., percent leukemic blasts) in questions 111 and 112, respectively. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Report **No** for question 110 and go to question 114 in either of the following cases:


- all flow cytometry assessments performed on the blood were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the blood during the reporting period.

If multiple flow cytometry assessments performed on blood samples were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period

#### Question 113: Was this considered a disease relapse?

Indicate if the peripheral blood flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with flow cytometric relapse, select **Yes**. Continue with question 114.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select **No**. Continue with question 114.

#### Question 114-116: Bone Marrow

Indicate whether flow cytometry detected disease in a bone marrow at any time during the reporting period. If **Yes**, report the date the sample was collected and the percent disease detected (i.e., percent leukemic blasts) in questions 115 and 116, respectively. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Report **No** for question 114 and go to question 118 in either of the following cases:


- all flow cytometry assessments performed on the bone marrow were negative for evidence of the recipient’s primary disease during the current reporting period; or
- flow cytometry testing was not performed on the bone marrow during the reporting period.

If multiple flow cytometry assessments performed on bone marrow were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period

#### Questions 117: Was this considered disease relapse?

Indicate if the bone marrow flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with flow cytometric relapse, select **Yes**. Continue with question 118.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select **No**. Continue with question 118.

#### Question 118: Was disease detected via cytogenetic testing (karyotyping or FISH)?

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic testing detected the recipient’s primary disease at any time during the reporting period, report **Yes** and go to question 119. If all cytogenetic testing was negative for evidence of the recipient’s primary disease during the current reporting period, report **No** and go to question 137. Report **Unknown** for question 118 and go to question 137 in any of the following cases:


- cytogenetic testing was not performed during the reporting period; or
- cytogenetic testing was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether cytogenetic testing was performed during the reporting period.

#### Question 119: Were cytogenetic abnormalities identified via FISH?

Indicate whether FISH studies detected disease at any time during the reporting period. If **Yes** go to question 120.

Report **No** for question 119 and go to question 128 in any of the following cases:


- FISH testing was not performed during the reporting period; or
- FISH testing was performed during the reporting period but no abnormalities associated with the recipient’s primary disease were detected
- FISH testing was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether FISH testing was performed during the reporting period.

#### Questions 120-121: Sample source

Indicate if the sample was from **Bone marrow** or **Peripheral blood** and report the date the sample was collected in question 121. If multiple sources were used to test FISH, the most preferred sample is the bone marrow.

If multiple FISH assessments were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 122-125: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 122, then continue with question 123.

Report the number of abnormalities detected by FISH in question 123. After indicating the number of abnormalities in question 123, select all abnormalities detected in questions 124-125.

If an abnormality is detected, but not listed as an option in question 124, select **Other abnormality** and specify the abnormality in question 125. If multiple “other abnormalities” were detected, report “see attachment” in question 125 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 126: Was this considered a disease relapse?

Indicate if the FISH results were considered consistent with disease relapse. Criteria for FISH relapse are established by clinical judgment. If the recipient has abnormalities detected by FISH that the physician considers to be consistent with relapse, select **Yes**. Continue with question 127.

If the recipient has residual disease by FISH that the physician does not consider to be consistent with relapse, select **No**. Continue with question 127.

#### Question 127: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if the FISH report is attached to support the cytogenetic findings reported in questions 122-126. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 128: were cytogenetic abnormalities identified via karyotyping?

Indicate whether karyotyping studies detected disease at any time during the reporting period. If **Yes** go to question 129.

Report **No** for question 128 and go to question 137 in any of the following cases:


- karyotyping was not performed during the reporting period; or
- karyotyping was performed during the reporting period but no abnormalities associated with the recipient’s primary disease were detected
- karyotyping was attempted, but no assessments could be performed during the reporting period (e.g., insufficient sample); or
- it cannot be determined whether karyotyping was performed during the reporting period.

#### Questions 129-130: Sample source

Indicate if the sample was from **Bone marrow** or **Peripheral blood** and report the date the sample was collected in question 130. If multiple sources were used for karyotyping analysis, the preferred sample is the bone marrow.

If multiple karyotyping assessments were positive for disease, report the date / results of the earliest positive assessment performed during the reporting period.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 131-134: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 131, then continue with question 132.

Report the number of abnormalities detected by karyotyping in question 132. After indicating the number of abnormalities in question 132, select all abnormalities detected in questions 133-134.

If an abnormality is detected, but not listed as an option in question 133, select **Other abnormality** and specify the abnormality in question 134. If multiple “other abnormalities” were detected, report “see attachment” in question 134 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the Training Guide.

Question 135: Was this considered a disease relapse?

Indicate if the karyotyping results were considered consistent with disease relapse. Criteria for karyotype relapse are established by clinical judgment. If the recipient has abnormalities detected by karyotyping that the physician considers to be consistent with relapse, select **Yes**. Continue with question 136.

If the recipient has residual disease by karyotyping that the physician does not consider to be consistent with relapse, select **No**. Continue with question 136.

Question 136: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if the karyotyping report is attached to support the cytogenetic findings reported in questions 131-134. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Questions 137-138: Was disease detected via bone marrow examination?

If a bone marrow biopsy detected disease during the reporting period, report **Yes** for *Was disease detected via bone marrow examination?* and report the date of the positive assessment.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If multiple bone marrow biopsies detected disease, report the date of the earliest positive assessment performed during the reporting period.

If bone marrow biopsies did not detect disease at any time during the reporting period report **No**. If no bone marrow biopsies were done during the reporting period, or it is unknown if any bone marrow biopsies were done, report **Unknown** and go to *Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma).*

#### Questions 139-140: Blasts in the bone marrow

Indicate whether the percentage of blasts in the bone marrow was **Known** or **Unknown**. If **Known** report the percentage documented on the laboratory report in question 140. If **Unknown**, continue with question 141.

#### Question 141: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is **Known** or **Unknown**. If the myelofibrosis grade is documented in the pathology report, select **Known**, continue with question 142. If the pathology report is not available and the grade is documented in a physician note, then this would be sufficient.

If the myelofibrosis grade is not documented on the pathology report, select **Unknown**, continue with question 143.

#### Question 142: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist or may be found in a physician note if the BM path report is not available.

Select **MF-0** if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select **MF-1** if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select **MF-2** if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with local bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select **MF-3** if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 143: Was this considered a disease relapse?

Indicate if the bone marrow biopsy results were considered a disease relapse. If the bone marrow biopsy is consistent with relapse, select **Yes**. Continue with question 144.

If the recipient has residual myelofibrosis that the physician does not consider to be consistent with relapse, select **No**. Continue with question 144.

#### Questions 144-145: Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma)

Indicate if the recipient had extramedullary disease indicative of AML during the reporting period. An example of extramedullary disease would be a myeloid sarcoma. Indicate **Yes** if extramedullary disease indicative of AML was present and report the date of assessment in question 145. Indicate **No** if extramedullary disease indicative of AML was not present during the reporting period and continue with question 148.

If multiple assessments detected extramedullary disease indicative of AML during the reporting period, report the date of the earliest positive assessment performed during the reporting period.

#### Questions 146-147: Specify site(s) of disease (check all that apply)

Select each site where extramedullary disease indicative of AML was detected on the date reported in question 145. If extramedullary disease indicative of AML was detected at a site not specified in question 146, report **Other site** and specify all other sites where extramedullary disease indicative of AML have been identified in question 147.

#### Questions 148-150: Was disease detected by other assessment?

Indicate if disease was detected by any other assessment during the reporting period. Indicate **Yes** if disease was detected by other assessment during the reporting period, report the date of assessment in question 149, and specify the name of the other assessment in question 150. Indicate **No** if disease was not detected by any other during the reporting period and continue with question 152.

#### Question 151: Was this considered a disease relapse?

Indicate if the result of the other disease assessment was considered a disease relapse. Criteria for disease relapse are established by clinical judgment. If the recipient has another disease assessment that the physician considers to be consistent with relapse, select **Yes**. Continue with question 152.

#### Question 152: Was intervention given for minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML since the date of the last report?

Indicate if the recipient received treatment post-infusion for minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML since the date of last report. If **Yes** go to question 153. If **No** go to question 172. See question 153 for definitions each of these indications for treatment.

#### Question 153: Specify reason for which intervention was given

Select all indications for which treatment was administered during the reporting period. See below for definitions of each indication.

**Minimal Residual Disease**: Recipient is in hematologic CR, but has evidence of disease by more sensitive assessments including molecular, flow cytometry or cytogenetic methods.

**Persistent Disease**: The recipient was in primary induction failure or relapse at the time of infusion and has not achieved a hematologic CR post-infusion.

**Relapsed Disease**: The recipient was in CR at the time of infusion or the recipient achieved a CR post-infusion. In either case, treatment is administered for a relapse which occurred post-infusion.

**Decreased / Loss of Chimerism**: If the recipient’s chimerism decreased or was being lost during the reporting period, treatment is administered to recover the lost chimerism.

**Progression to AML**: If an examination demonstrated ≥20% blasts in the blood or bone marrow during the reporting period, this is a progression to AML and treatment would be administered in order to treat this progression.

#### Question 154: Systemic therapy

Systemic therapy includes chemotherapy, immunotherapy, or targeted therapies delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein or given orally. Do not report subsequent HCT / cellular therapies in questions 154-162. If the recipient received systemic therapy during the reporting period to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, report **Yes** and go to question 155. If not, report **No** and go to question 163.

#### Questions 155-156: Date therapy was first started

Indicate if the therapy start date is **Known** or **Unknown** in question 155. If “Known” indicate the start date in question 156. If the date therapy first started is **Unknown** go to question 157 If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the recipient started therapy in a prior reporting period to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, and continued the therapy into the current reporting period, report **Previously reported** and go to question 157.

For recipients who start and stop therapy multiple times post-infusion, first determine whether the recipient stopped therapy for at least 30 days. If not, consider the therapy continuous. Only report a new therapy start date if all three of the below conditions are met.


- The recipient stopped all therapy given for treatment; and
- The recipient restarted therapy for treatment during the current reporting period; and
- Therapy was restarted at least 30 days after the therapy stop date.

#### Questions 157-158: Date therapy stopped

Indicate if therapy stop date is **Known** or **Unknown**. If the therapy is being given in cycles, report the date the recipient started the last cycle for this line of therapy in question 158. Otherwise, report the final administration date for the therapy being reported.

If the recipient is still receiving this treatment at the end of the reporting period, report **Not applicable (still receiving therapy)** and continue with 161.

If the stop date is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy stopped is **Unknown**, go to question 159.

#### Questions 159-160: Reason therapy stopped

If the systemic therapy was stopped during the reporting period, indicate the reason it was stopped in question 159. If the reason therapy stopped isn’t listed in question 159, select **Other** and report the other reason therapy stopped in question 160. Continue with question 161.

#### Question 161-162: Specify systemic therapy given for maintenance: (check all that apply)

Report the drug(s) given as part of this line of therapy. If multiple lines of therapy were given during the reporting period, they must be reported separately. If the drug given is not listed as an option for question 161, report **Other systemic therapy** and specify the drug in question 162.

#### Question 163-164: Supportive Treatment

Supportive treatment is given to patients with MDS to treat the symptoms of their disease. If supportive treatment was given as part of this line of therapy, report **Yes** for question 163. Select all supportive treatments administered as part of this line of therapy in question 164.

If supportive treatment was not given as part of this line of therapy, report **No** for question 163 and continue with question 165.

#### Question 165: Cellular Therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells).

Report **Yes** if the recipient received cellular therapy as part of the line of therapy being reported. If not, report **No**.

#### Question 166: Subsequent HCT

If the recipient received a subsequent HCT to treat minimal residual disease, persistent disease, relapsed disease, decreased/loss of chimerism, or progression to AML, report **Yes**. If not, report **No**.

If a subsequent HCT was performed during the reporting period, ensure this was reported on the Post-infusion Data (2100 or 4100) forms as well. Reporting a subsequent HCT given to treat the recipient’s primary disease will prompt a new Pre-TED (2400) form to come due in FormsNet3SM.

#### Question 167: Accelerated withdrawal of immunosuppression in response to disease assessment

Immunosuppressive medications may be tapered or entirely withdrawn in order to promote a graft vs leukemia effect in the setting of relapsed, progressive, persistent disease or decreased/loss of chimerism. If immunosuppression is reduced or stopped during the reporting period in order to treat disease, report **Yes**. If not, report **No**.

#### Question 168-169: Blinded randomized trial

Indicate whether treatment was administered as part of a blinded randomized trial. Consult the physician overseeing treatment if it is not clear whether the therapy is being given as part of a blinded randomized trial. If **Yes**, report the clinicaltrials.gov number in question 169. Otherwise, go to question 170.

If the clinical trial number (NCT number) is not clearly documented, it can be looked up using the Find a Study feature on [www.clinicaltrials.gov](http://www.clinicaltrials.gov).

If the recipient is participating in a clinical trial that is not registered with clinicaltrials.gov, but is registered elsewhere, leave question 169 blank and override the validation error using the code **Unable to answer**. Also, attach documentation which displays the clinical trial number and corresponding registry to the form in FormsNet3SM. For further instructions on how to attach documents in FormsNet3SM, refer to the Training Guide.

#### Question 170-171: Other therapy

Indicate if the recipient received any other therapy (not already reported in questions 154-169) given for minimal residual disease, persistent disease, relapsed disease, decreased / loss of chimerism, or progression to AML. Do not report supportive therapies (e.g., transfusions, growth factors) or a subsequent HCT in questions 170-171, as they should already have been reported above. If **Yes**, specify all other therapies given in question 171. If **No**, go to question 172.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Intro | 4/12/2024 | Add | Disease Detection Since the Date of Last Report blue box and introduction added: Disease Detection Since the Date of Last Report:This section is intended to capture information only for recipients who relapse / progress, have persistent or minimal residual disease in this reporting period. If disease was not detected by the method of assessment, report No. If disease was detected by the method of assessment, the earliest instance in which disease was detected in the reporting period is reported. If multiple tests by a particular method have demonstrated evidence of disease during the reporting period, report the date / result of the earliest positive assessment(s) performed during the reporting period; For each method of assessment, report Yes if that method detected the recipient’s MDS (or markers of MDS) during the reporting period. If testing by a particular method (e.g., molecular makers, cytogenetic, flow cytometry, etc.) was done, but did not show evidence of disease during the reporting period, report No for that method. If testing for splenomegaly, hepatomegaly, molecular or cytogenetic markers / abnormalities, or bone marrow was not done during the reporting period or it is not known whether testing was performed, report Unknown for those methods. If testing by flow cytometry, extramedullary disease detection or other assessment was not done during the reporting period or it is not known whether testing was performed, report No for those methods. |
Added for clarification |
| Q100 | 4/12/2024 | Modify | Instructions updated for molecular markers: If any molecular testing for molecular markers was performed and disease was detected during the reporting period, report Yes and go to question 101. If molecular testing for molecular markers was performed but did not detect disease at any time during the reporting period, report No. If molecular testing for molecular markers was not performed at any time during the reporting period, or it is unknown if testing was done, report |
Incorrect instructions |
| Q102 | 4/12/2024 | Add | Clarification added to explain which date to report: Report the date the sample was collected for molecular testing. If disease was detected multiple times by this method of assessment in the reporting period, report the first assessment which detected disease. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, Guidelines for Completing Forms. |
Added for clarification |
| Q109 | 10/5/2023 | Modify | Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing. If the disease was detected via flow cytometry, select Yes and continue to the next question.If disease was not detected via flow cytometry, flow cytometry wasn’t performed at any time during the reporting period, or it is unknown if disease was detected via flow cytometry, select No and continue to Was disease detected via cytogenetic testing (karyotyping or FISH)? |
Provided clarity on how to report when no flow assessments were completed |
| Q137 | 10/5/2023 | Modify | If a bone marrow biopsy detected disease during the reporting period, report Yes for Was disease detected via bone marrow examination? and report the date of the positive assessment.If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, Guidelines for Completing Forms. If multiple bone marrow biopsies detected disease, report the date of the earliest positive assessment performed during the reporting period. If bone marrow biopsies did not detect disease at any time during the reporting period report No. If no bone marrow biopsies were done during the reporting period, or it is unknown if any bone marrow biopsies were done, report Unknown |
Provided clarity on how to report when no bone marrow assessments were completed |
| Q143 | 9/21/2022 | Modify | Indicate if the |
Original instructions were incorrect |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)