This form captures information regarding a female recipient’s or a male recipient’s female partner’s pregnancy. This form must be completed when a pregnancy is reported on a Cellular Therapy Essential Data Follow-Up (4100) or Post-Infusion Follow-Up (2100) Form. The Pregnancy (3501) Form will also have the option to be created on-demand (on-demand is when a form can be generated at any time). Centers are encouraged to generate this form on-demand as soon as it is known that a female recipient or a male recipient’s female partner is pregnant. This form is used to capture information regarding pregnancies following HCT or cellular therapy infusions.

One Pregnancy (3501) Form must be completed for each pregnancy and is designed to capture the estimated delivery date, the outcome of the pregnancy and the delivery date. If the form was created using the on-demand function and the female recipient or the male recipient’s female partner is still pregnant at the time of submitting this form, submit the form and later update the same form to report the outcome of the pregnancy. If the form came due as a result of reporting a pregnancy on the Cellular Therapy Essential Data Follow-Up (4100) or Post-Infusion Follow-Up (2100) Form and the female recipient or the male recipient’s female partner is pregnant on the reported contact date for the current reporting period, submit the form and return to complete the same form when the outcome of the pregnancy is known. This will ensure that all data corresponding to each pregnancy is correctly captured on the same form.

Links to Sections of Form:

[Q1 – 8: Functional Status](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-6-functional-status)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/2025 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)