Report findings at the time of diagnosis. If multiple studies were performed prior to the institution of therapy (such as IL-2 therapy or gene therapy), report the values closest to the diagnosis date of Wiskott-Aldrich syndrome.

#### Question 14: Date CBC tested

Report the date of CBC testing done within 6 weeks of diagnosis. Continue with question 15.

#### Question 15: WBC

Report the white blood cell (WBC) count and unit of measure as documented on the laboratory report. If the WBC is unknown leave the count and unit fields blank and select “WBC not tested.” Continue with question 19.

#### Question 16: Lymphocytes

Report the percentage of lymphocytes. If lymphocytes were not tested leave the count field blank and select “Lymphocytes not tested.” Continue with question 17.

#### Question 17: Eosinophils

Report the percentage of eosinophils. If eosinophils were not tested leave the count field blank and select “Eosinophils not tested.” Continue with question 18.

#### Question 18: Polymorphonuclear leukocytes (PMN)

Polymorphonuclear leukocytes are white blood cells containing cytoplasmic granules. PMNs are also referred to as granulocytes and include neutrophils, basophils, and eosinophils; however, this question refers to **neutrophils**. Report the percentage of neutrophils. If neutrophils were not tested leave the count field blank and select “Polymorphonuclear leukocytes (PMN) not tested.” Continue with question 19.

#### Question 19: Hemoglobin

Report the hemoglobin count and the unit of measure as documented on the laboratory report. If the hemoglobin was not tested leave the count and unit fields blank and indicate “Hemoglobin not tested.”

Indicate if red blood cells (RBC) were transfused ≤ 30 days from date of test. Continue with question 20.

#### Question 20: Platelets

Report the platelet count and unit of measure as documented on the laboratory report. If the platelet count was not tested leave the count and unit fields blank and indicate “Platelets not tested.”

Indicate if platelets were transfused ≤ 7 days from date of test. Continue with question 21.

#### Question 21: Mean platelet volume

Report the mean platelet volume in femtoliters (fl). If the mean platelet volume was not tested leave the count field blank and indicate “Mean platelet volume not tested.” Continue with question 22.

## Immunoglobulin Analysis

Specify the following quantitative immunoglobulins measured at the time of diagnosis; if multiple studies were performed prior to the institution of therapy, report the latest values prior to any first treatment of Wiskott-Aldrich syndrome.

#### Question 22: IgG

Report the IgG level and the unit of measure documented on the laboratory report. Continue with question 23. If IgG was not tested leave the value and unit fields blank and indicate “IgG not tested,” and continue with question 24.

#### Question 23: Date tested

Report the date of IgG testing and continue with question 24.

#### Question 24: IgM

Report the IgM level and the unit of measure documented on the laboratory report. Continue with question 25. If IgM was not tested leave the value and unit fields blank and indicate “IgM not tested,” and continue with question 26.

#### Question 25: Date tested

Report the date of IgM testing and continue with question 26.

#### Question 26: IgA

Report the IgA level and the unit of measure documented on the laboratory report. Continue with question 27. If IgA was not tested leave the value and unit fields blank and indicate “IgA not tested,” and continue with question 28.

#### Question 27: Date tested

Report the date of IgA testing and continue with question 28.

#### Question 28: IgE

Report the IgE level in international units per milliliter (IU/ml). Continue with question 29. If IgE was not tested leave the value field blank and indicate “IgE not tested,” and continue with question 30.

#### Question 29: Date tested

Report the date of IgE testing and continue with question 30.

#### Question 30: Did the recipient receive supplemental intravenous immunoglobulins (IVIG) prior to any first treatment of WAS?

IVIG is a product made from pooled human plasma that primarily contains IgG. It is used to provide immune-deficient recipients with antibody function to help prevent infection.

Indicate whether the recipient received IVIG prior to any first treatment of WAS. If “yes” continue with question 31. If “no” or “unknown” continue with question 32.

#### Question 31: Was therapy ongoing within one month of immunoglobulin testing?

Indicate whether the recipient received IVIG within one month prior to the immunoglobulin testing done at diagnosis. Patients exhibiting signs of a compromised or dysfunctional immune system may have received IVIG prior to a diagnosis being made. If IVIG is given within one month of immunoglobulin testing, the IgG level would not represent the recipient’s native IgG. Continue with question 32.

## Lymphocyte Analysis

Specify the following lymphocyte analyses performed at the time of diagnosis; if multiple studies were performed prior to the institution of therapy, report the latest values prior to any first treatment of Wiskott-Aldrich syndrome.

#### Question 32: Were lymphocyte analyses performed?

Lymphocyte analyses include quantifying specific types of T cells, B Cells, and natural killer (NK) cells. Cells can be identified by cell-specific surface molecules using the clusters of differentiation (CD) nomenclature. For example, T cells can be classified as helper (CD4+) or cytotoxic (CD8+) cells depending on their cell surface markers designated with CD notation.

Indicate if lymphocyte analyses were performed. If “yes” continue with question 33. If “no” continue with question 42.

#### Question 33: Date of most recent testing performed

Report the date of most recent lymphocyte testing performed prior to any disease treatment. Continue with question 34.

#### Question 34: Absolute lymphocyte count

Report the absolute lymphocyte count in cells per microliter (cells/µL). Continue with question 35.

#### Question 35: CD3 (T cells)

T cells are a type of lymphocyte that can be characterized by CD3. If the laboratory quantifies CD3 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD3 cells as an absolute value, then report the value in the count field and specify the count units. If CD3 cells were not tested, select the “CD3 (T cells) not tested” option. Continue with question 36.

#### Question 36: CD4 (T helper cells)

T helper cells are a subset of T cells characterized by CD4, sometimes reported as CD3+CD4+. If the laboratory quantifies CD4 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4 cells as an absolute value, then report the value in the count field and specify the count units. If CD4 cells were not tested, select the “CD4 (T cells) not tested” option. Continue with question 37.

#### Question 37: CD8 (cytotoxic T cells)

Cytotoxic T cells are a subset of T cells characterized by CD8, sometimes reported as CD3+CD8+. If the laboratory quantifies CD8 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD8 cells as an absolute value, then report the value in the count field and specify the count units. If CD8 cells were not tested, select the “CD8 (T cells) not tested” option. Continue with question 38.

#### Question 38: CD20 (B lymphocyte cells)

B cells are a type of lymphocyte that can be characterized by CD20. If the laboratory quantifies CD20 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD20 cells as an absolute value, then report the value in the count field and specify the count units. If CD20 cells were not tested, select the “CD20 (B lymphocyte cells) not tested” option. Continue with question 39.

#### Question 39: CD56 (natural killer (NK) cells)

NK cells are a type of lymphocyte that can be characterized by CD56. If the laboratory quantifies CD56 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD56 cells as an absolute value, then report the value in the count field and specify the count units. If CD56 cells were not tested, select the “CD56 (natural killer (NK) cells) not tested” option. Continue with question 40.

#### Question 40: CD4+/CD45RA+ (naïve T cells)

Naïve T cells are a type of T cell that can be characterized by CD4+/CD45RA+. T cells are considered naïve prior to encountering an antigen. If the laboratory quantifies CD4+/CD45RA+ cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4+/CD45RA+ cells as an absolute value, then report the value in the count field and specify the count units. If CD4+/CD45RA+ cells were not tested, select the “CD4+/CD45RA+ (naïve T cells) not tested” option. Continue with question 41.

#### Question 41: CD4+/CD45RO+ (memory T cells)

Memory T cells are a type of T cell that can be characterized by CD4+/CD45RO+. If the laboratory quantifies CD4+/CD45RO+ cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4+/CD45RO+ cells as an absolute value, then report the value in the count field and specify the count units. If CD4+/CD45RO+ cells were not tested, select the “CD4+/CD45RO+ (memory T cells) not tested” option. Continue with question 42.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 14 | 4/21/2023 | Modify | Clarified the instructions for the labs at diagnosis should reflect the labs closest to the date of diagnosis. | To ensure more consistent reporting, all labs for the “at diagnosis” timepoint were clarified to reflect the values obtained closest to the date of diagnosis, prior to the start of any therapy. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)