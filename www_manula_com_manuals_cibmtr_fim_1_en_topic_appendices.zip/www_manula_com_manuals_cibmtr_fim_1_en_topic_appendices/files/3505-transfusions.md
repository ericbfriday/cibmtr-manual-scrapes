The Transfusions (3505) Form is a Gene Therapy registry form which captures any red blood cell (RBC) and platelet transfusions administered at any time post infusion.

This form will come due for those recipients enrolled onto CIBMTR study CS22-24 (Zyntelgo®). This is a post marketing prospective, multicenter, observational, long-term safety and effectiveness registry study of recipients with beta-thalassemia treated with Betibeglogene Autotemcel (Zynteglo®).

The Pre-Transplant Essential Data (2400) Form will confirm study eligibility, this includes event date, genetic modification, and gene therapy product infused. Once eligibility is confirmed, the Transfusion (3505) Form will come due along with the Post-Infusion Follow-Up (2100) Form for each timepoint, 100 days through 15 years annually, per FDA Gene Therapy Long Term Follow Up Guidelines.

Links to Sections of Form:

[Q1 – 9: Transfusions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-9-transfusions)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/20/2025 |
|

[3505: Transfusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-9-transfusions)[3505: Transfusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-9-transfusions)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)