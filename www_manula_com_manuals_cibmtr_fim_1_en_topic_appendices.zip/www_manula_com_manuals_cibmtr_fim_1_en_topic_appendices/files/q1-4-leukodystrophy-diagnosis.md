#### Questions 1-2: Date of diagnosis ALD

Indicate if the date of ALD diagnosis is **Known**. If so, report diagnosis date (YYYY-MM- DD). If the exact date is not known, use the process for reporting estimated dates, as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the diagnosis date is not known and cannot be estimated, report **Unknown**. This option should rarely be used.

#### Questions 3-4: Specify assessment performed to establish the diagnosis (check all that apply)

Indicate the assessment(s) to establish the ALD diagnosis.

**Newborn screening:**A blood screen which looks for the defective molecules in the circulating blood. In the United States, this blood test is available as part of routine newborn screening. Infants are often diagnosed at birth or in utero.**Family history:**Diagnosis may be made because of another family member’s prior ALD diagnosis.**Other assessment:**Includes those methods of testing not already listed above. This option will rarely be used; however, a recipient may be diagnosed based on imaging testing characteristic of the disease. If Other assessment was performed, specify the assessment.

If the assessment is not documented, report **Unknown**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Sep 30, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)