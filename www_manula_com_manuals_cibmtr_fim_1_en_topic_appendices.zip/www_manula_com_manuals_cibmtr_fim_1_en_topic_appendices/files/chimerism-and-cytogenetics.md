**Chimerism Methods of Assessment**

Various methods of assessment can be used to assess donor chimerism. Table 1 provided below lists chimerism methods and their descriptions:

Table 1. Chimerism Methods

| Method | Description |
|---|---|
| Karyotyping for XX / XY | Cells grown in culture, stained, and examined under a microscope to identify the number* of cells matching the sex of the donor. This method is only valid when donor and recipient are sex mismatched. |
| Fluorescent in situ hybridization (FISH) for XX / XY | Cells are exposed to fluorescent DNA probes which attach to X and Y chromosomes. A microscope is used to identify the number of cells matching the sex donor. This method is only valid when donor and recipient are sex mismatched. |
| Restricted fragment length polymorphisms (RFLP) | A restriction fragment is a portion of DNA which has been cut out by an enzyme. RFLP testing beings by isolating DNA from the sample. Enzymes are used to cut the DNA at specific loci resulting in many unique restriction fragments. The fragments are separated according to size by electrophoresis. The unique pattern of separation is used to identify the percent donor DNA present in the sample. |
| Variable number tandem repeat (VNTR), micro-or minisatellite | VNTR refers to a portion of DNA containing a repeating sequence of base pairs (micro- or minisatellite). The number of times a micro- or minisatellite repeats within specific loci can differ between individuals. These differences are used to distinguish donor DNA from recipient DNA. VNTR testing involves obtaining samples from the recipient and donor prior to transplant. Specific loci are compared to determine which loci contains VNTRs unique to the donor. After transplant, DNA is isolated from recipient samples. Donor-specific VNTRs are amplified by PCR techniques. The sample is then analyzed to determine the percent donor DNA present. |
| Small tandem repeat (STR), micro-or minisatellite | STR also refers to a portion of DNA containing a repeating sequence of base pairs (micro- or minisatellite). The number of times a micro- or minisatellite repeats within specific loci can differ between individuals. These differences are used to distinguish donor DNA from recipient DNA. STR testing involves obtaining samples from the recipient and donor prior to transplant. Specific loci are compared to determine which loci contains STRs unique to the donor. After transplant, DNA is isolated from recipient samples. Donor-specific STRs are amplified by PCR techniques. The sample is then analyzed to determine the percent donor DNA present. |
| Amplified fragment length polymorphisms (AFLP) | A restriction fragment is a portion of DNA which has been cut out by an enzyme. AFLP testing begins by isolating DNA from the sample. Enzymes are used to cut the DNA at specific loci resulting in many unique restriction fragments. Many restrictions fragments are amplified using PCR techniques. The fragments are separated according to size by electrophoresis. The unique pattern of separation is used to identify the percent donor DNA present in the sample. |

**Cytogenetic Methods**

Cytogenetic assessments can be performed to identify markers of disease, determine chimerism following an allogeneic cellular infusion, or both. Cytogenetic assessment of chimerism is usually only done for sex mismatched pairs of recipients and donors. In these cases, a karyotype or FISH study can determine the ratio of cells containing female vs. male sex chromosomes. A unique form of karyotype assessment, Q banding, can also be used to assess chimerism for sex matched recipient and donor pairs; however, molecular techniques involving PCR amplification are much more common.

Disease assessment by cytogenetic methods involves the identification of disease-specific markers (e.g., -7, del(5q), Philadelphia chromosome). Once a marker is identified, cytogenetic assessments can be repeated to determine whether the marker, and therefore the disease, is still detectable. The types of markers identified can affect the disease classification and inform the treatment plan. A cytogenetic assessment cannot be considered a disease assessment until this method has detected a marker of disease. In other words, if cytogenetic studies have always been negative, the recipient’s disease is not considered to be assessed by this method because there are no known cytogenetic abnormalities to evaluate.

CIBMTR forms generally capture chimerism data separately from disease assessment data. Therefore, it is important to know what information can be reported based on the assessment performed.

Example 1: Consider a recipient of an allogeneic product obtained from a sex mismatched donor as part of treatment for AML. The cytogenetic abnormality t(8;21) was identified as a marker of this recipient’s disease on previous cytogenetic assessments. Would the following cytogenetic assessments be reported in chimerism data fields, disease assessment data fields, or both?

- Karyotype: Report this assessment in both chimerism and disease assessment data fields. A karyotype is capable of detecting autosomal and sex chromosomes. The test would confirm whether the t(8;21) abnormality was still present and also provide a ratio of female to male cells.
- FISH [X / Y probe(s) only]: Only report this assessment in chimerism data fields. The probes are able to provide a ratio of female to male cells, but are not capable of detecting the t(8;21) abnormality.
- FISH [t(8;21) probes only]: Only report this assessment in disease assessment data fields. The probes are able to detect the t(8;21) abnormality, but are not capable of providing a ratio of female to male cells.
- FISH [X / Y probe(s) and t(8;21) break apart probe]: Report this assessment in both chimerism and disease assessment data fields. The X / Y probe(s) will provide chimerism data while the t(8;21) probe results will be captured as a disease assessment.

**Section Updates:**

| Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|
| 1/24/2025 | Add | Chimerism Methods of Assessment section and Table 1. Chimerism Methods added | Added for clarity |
| 7/28/2023 | Add | Appendix C: Cytogenetics re-vamped. The original ‘Chimerism and Disease Assessments’ previously listed in version 2 of Appendix C is now separated into its own subsection in version 3 of Appendix C | Added with release of ISCN Functionality in the Summer 2023 release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)