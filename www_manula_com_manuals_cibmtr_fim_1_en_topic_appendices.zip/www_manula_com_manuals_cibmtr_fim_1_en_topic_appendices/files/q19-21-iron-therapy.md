#### Question 17: Was iron chelation therapy received at any time?

Iron chelation therapy is used to prevent or reduce iron overload. Examples include Deferoxamine (Desferal) and Deferasirox (Jadenu, Exjade).

Select **Yes** if iron chelation therapy was performed at any time prior to the start of the start of the preparative regimen / infusion. If iron chelation therapy was not given or it is unknown whether iron chelation therapy was given, select **No** or **Unknown**.

#### Questions 18 – 19: Specify therapy (check all that apply)

Specify the iron chelation therapy(ies) administered to reduce iron overload. Select all that apply. If the administered agent is not listed, select **Other** and specify the agent.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Oct 27, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)