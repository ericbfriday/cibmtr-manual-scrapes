## Metabolic Criteria

#### Complete Remission (CR)

Complete metabolic remission requires all of the following:


- A score of 1, 2, or 3 with or without a residual mass on a PET 5 point scale; and
- Disappearance of any previously non-measured lesions; and
- No new lesions; and
- No evidence of FDG-avid disease in the marrow.

#### Partial Remission

Partial metabolic remission requires all of the following:


- Score 4 or 5 on a PET 5 point scale with reduced uptake compared with baseline; and
- No new lesions.

#### Stable Disease

Does not meet metabolic criteria for complete remission, partial remission, or progressive disease.

#### Progressive Disease (after Partial Remission, Stable Disease), Relapsed Disease (after Complete Remission)

Metabolic progression or relapse requires at least one of the following:


- Score 4 or 5 on a PET 5 point scale with increased uptake compared with baseline; or
- Any new FDG-avid foci consistent with lymphoma; or
- New or recurrent FDG avid foci in the bone marrow.

## Radiographic Response Criteria

The following acronyms are used in the radiographic response criteria provided below:

**LDi:** longest transverse diameter of a lesion

**SDi:** shortest axis perpendicular to the LDi

**SPD:** sum of the product of the perpendicular diameters for multiple lesions

**PPD:** cross product of the LDi and perpendicular diameter

#### Complete Remission (CR)

Complete radiographic remission requires all of the following:


- All target nodes / nodal masses must have regressed as measured by CT to ≤ 1.5 cm in longest diameter; and
- Disappearance of any previously non-measured lesions; and
- No extralymphatic sites of disease; and
- No organomegally.

Normal morphology of **bone marrow** is also required for a complete radiological remission if the marrow was an involved site. Immunohistochemical stains must be negative if morphology is indeterminate.

#### Partial Remission

Partial radiographic remission requires all of the following:


- ≥ 50% decrease in the SPD of up to 6 target measurable nodes and extranodal sites
; and[1](#fn36825195968596b86ba844-1) - No increase in the size of previously non-measurable lesions; and
- No new lesions.

If **splenomegaly** is present, a > 50% decrease in spleen length is also required to report a partial radiological remission

#### Stable Disease

Does not meet radiographic criteria for complete remission, partial remission, or progressive disease.

#### Progressive Disease (after Partial Remission, Stable Disease), Relapsed Disease (after Complete Remission)

Radiographic progression or relapse requires at least one of the following:


- An individual node must be abnormal with:
- LDi >1.5 cm; and
- ≥ 50% increase from nadir in the PPD; or

- An increase in LDi or SDi from nadir
- ≥ 0.5 cm increase in LDi or SDi from nadir for any lesion ≤ 2cm; or
- ≥ 1.0 cm increase in LDi or SDi from nadir for any lesion > 2 cm; or

- A 50% increase in spleen length compared to its prior increase beyond baseline; or
- New or recurrent splenomegally; or
- Clear progression of pre-existing non-measured lesions; or
- Regrowth of any previously resolved lesions; or
- A new node > 1.5 cm in any axis; or
- A new extranodal site > 1.0 cm in any axis or if < 1.0 cm in any axis, its presence must be unequivocally attributable to lymphoma; or
- Assessable disease of any size unequivocally attributable to lymphoma; or
- New or recurrent involvement of the bone marrow.

1 For lesions too small to measure on CT, assign 5mm x 5mm as the default value and then 0 mm x 0 mm when the lesion is no longer visible. For a node >5 mm x 5 mm, but smaller than normal, use the actual measurement of the node for calculations.

Adapted from: Cheson, B. D., Fisher, R. I., Barrington, S. F., Cavalli, F., Schwartz, L. H., Zucca, E., & Lister, T. A. (2014). Recommendations for Initial Evaluation, Staging, and Response Assessment of Hodgkin and Non-Hodgkin Lymphoma: The Lugano Classification. Journal of Clinical Oncology, 32(27), 3059-3067. doi:10.1200/jco.2013.54.8800

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/17/2022 |
|

[LYM Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/lymphoma-response-criteria)[LYM Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/lymphoma-response-criteria)[LYM Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/lymphoma-response-criteria)[LYM Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/lymphoma-response-criteria)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)