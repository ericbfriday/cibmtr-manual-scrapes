#### Question 151: What was the disease status at the last evaluation prior to the preparative regimen?

Indicate the disease status of WM or LPL at last evaluation prior to the start of the preparative regimen.

**See WM Response Criteria for disease status definitions.**

#### Question 152: Date assessed

Enter the date of the most recent assessment of disease status within the pre-transplant work-up period (approximately 30 days) prior to the start of the preparative regimen. Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., SPEP), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluation; enter the date the imaging took place for radiographic assessment.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)