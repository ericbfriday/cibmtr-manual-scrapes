#### Question 1: Did the recipient have an eligible diagnosis?

Primary Myelofibrosis, Post-polycythemia vera myelofibrosis and post-essential thrombocythemia myelofibrosis are the three eligible sub-types for the Myelofibrosis Medicare study. Select the eligible diagnosis for the recipient.

#### Question 2-3: Has the recipient ever had Int-2 or high-risk disease as determined by the DIPSS?

Refer to the [Myeloproliferative Neoplasm (MPN) Pre-Infusion (2057) form manual](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q41-54-dipss-prognosis-score) for a description of Intermediate-2 and high risk disease DIPSS scores.

Indicate **Yes** or **No** if the recipient at any time had Intermediate-2 or high-risk disease and report the date assessed (YYYY-MM-DD).

If the exact date is unknown, please view [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for more information on reporting partial and unknown dates.

#### Question 4: Specify Donor:

Related donors must be a 6/6 HLA-matched donors, defined by Class I (HLA-A and -B) intermediate resolution or high-resolution DNA-based typing and Class II (HLA-DRBI) at high-resolution DNA-based typing. There is no age restriction for sibling donors. Donors that are monozygotic twins are ineligible for the study.

Unrelated donors must be an 8/8 HLA-A, -B, -C, and -DRB1 at high-resolution DNA-based typing. Donors must meet institutional or NMDP selection criteria.

Donors that are 7/8 matched are ineligible for the study.

If a matched related or unrelated donor cannot be identified, patients may proceed to allogeneic HCT with a suitable haploidentical donor (Recipient’s parents or children).

Indicate if the donor is **6/6 HLA-matched related (not monozygotic twin)**, **8/8 HLA-A, -B, -C, -DRB1 unrelated**, or **Haploidentical**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)