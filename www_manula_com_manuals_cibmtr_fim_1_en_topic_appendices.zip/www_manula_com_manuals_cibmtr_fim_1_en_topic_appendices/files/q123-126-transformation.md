#### Question 48: Specify the maximum IPSS-R score the patient ever achieved:

The revised International Prognostic Scoring System (IPSS), known as the IPSS-R, is based on five variables including blasts in the bone marrow, cytogenetic findings, hemoglobin, absolute neutrophil count (ANC), and platelet count. Each variable is assigned a point value which are added together to determine the overall score. Refer to Tables 1 and 2*. Report the maximum IPSS-R score the patient ever achieved between diagnosis and the start of the preparative regimen (or infusion if no preparative regimen was given) in question 48. Note the maximum score that can be reported is 10.

**Table 1.** IPSS-R variables


| Prognostic Variable | Notes | Value | IPSS-R Score |
|---|---|---|---|
| Blasts in Bone Marrow (%) | — | ≤ 2% | 0 |
| — | — | > 2% to < 5% | 1 |
| — | — | 5% to 10% | 2 |
| — | — | > 10% | 3 |
| Cytogenetics | -Y; del(11q) | Very Good | 0 |
| — | Normal; del(5q); del(12p); del(20q); double including del(5q) | Good | 1 |
| — | del(7q); +8; +19; i(17q); any other single or double independent clone | Intermediate | 2 |
| — | -7; inv(3)/+(3q)/del(3q); double including -7 /del(7q); complex: 3 abnormalities | Poor | 3 |
| — | complex: > 3 abnormalities | Very poor | 4 |
| Hemoglobin (g/dL) | — | ≥ 10 g/dL | 0 |
| — | — | 8 to 10 g/dL | 1 |
| — | — | < 8 g/dL | 1.5 |
Absolute Neutrophil Count (x 109/L) |
— | ≥ 0.8 × 109/L |
0 |
| — | — | < 0.8 × 109/L |
0.5 |
Platelet County (x 109/L) |
— | ≥ 100 × 109/L |
0 |
| — | — | 50 to < 100 × 109/L |
0.5 |
| — | — | < 50 × 109/L |
1 |

**Table 2.** IPSS-R risk category and prognosis


| IPSS-R Score | IPSS-R Risk Category |
|---|---|
| ≤ 1.5 | Very low |
| > 1.5 – 3.0 | Low |
| > 3.0 – 4.5 | Intermediate |
| > 4.5 – 6 | High |
| > 6.5 | Very high |

#### Question 49: Specify when maximum IPSS-R score was documented:

Specify when the maximum IPSS-R score was documented.

“At diagnosis” is defined as any time between the date of diagnosis and the start of any treatment for MDS.

“Between diagnosis and the preparative regimen” is defined as any time which cannot be reported as part of either of the two time points.

“At last evaluation prior to the start of the preparative regimen” is defined any time during the recipient’s work-up for HCT or cellular therapy (generally within 30 days of the start of the preparative regimen or infusion).

#### Question 50: Date CBC drawn

These questions are intended to determine the clinical status of the recipient when determining the maximum IPSS-R score.

#### Questions 51-60: Provide the lab values used to determine the maximum IPSS-R score

For each value below, indicate if the result was “known” or “unknown” when determining the maximum IPSS-R score. Indicate the units for each testing, taking care to convert them to a unit available on the form, if necessary.

**WBC**: The white blood cell count is a value that represents all the white blood cells in the blood. If the count is too high or too low, the ability to fight infection may be impaired.

**Neutrophils**: Neutrophils are a subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage or an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage. Neutrophils are also known as polymorphonuclear leukocytes (PMNs).

**Hemoglobin**: Hemoglobin is a molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level. Also indicate if the recipient received a red blood cell transfusion within 30 days prior to testing.

**Platelets**: Platelets are formed elements within the blood that help with coagulation. A low platelet count, called thrombocytopenia, may lead to easy bleeding or bruising. Thrombocytopenia may require platelet transfusions. Indicate if the recipient received a platelet transfusion within 7 days prior to testing.

#### Questions 61-62: Blasts in bone marrow

Indicate whether the percentage of blasts in the bone marrow was “known” or “unknown” when determining the maximum IPSS-R score. If “known,” report the percentage documented on the laboratory report in question 62. If “unknown,” continue with question 63.

#### Question 63: Were cytogenetics tested (karyotyping or FISH)

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells.

If cytogenetic (karyotyping or FISH) studies were obtained when determining the maximum IPSS-R score, report “yes” and continue with question 64.

If no cytogenetic studies were obtained when determining the maximum IPSS-R score, indicate “no” and continue with question 82.

If it is not known whether any cytogenetic studies were obtained when determining the maximum IPSS-R score, indicate “unknown” and go to question 82.

#### Question 64: Were cytogenetics tested via FISH?

If FISH studies were performed when determining the maximum IPSS-R score, report “yes” for question 64 and continue with question 65. If FISH studies were not performed when determining the maximum IPSS-R score, report “no” for question 64 and go to question 73. Examples include: no FISH study performed, or FISH sample was inadequate.

See [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c), for assistance interpreting FISH results.

#### Questions 65-66: Sample source

Indicate if the sample was from “bone marrow” or from “peripheral blood” and report the date the sample was collected in question 66. If multiple sources were used to test FISH, the most preferred sample is the bone marrow.

#### Question 67: Results of tests

If FISH assessments identified abnormalities, indicate “abnormalities identified” and continue with question 68.

If FISH assessments were unremarkable, indicate “no abnormalities” and continue with question 72.

#### Questions 68-71: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 68, then continue with question 69.

Report the number of abnormalities detected by FISH when determining the maximum IPSS-R score in question 69. After indicating the number of abnormalities in question 69, select all abnormalities detected in questions 70-71.

If an abnormality is detected, but not listed as an option in question 70, select “other abnormality” and specify the abnormality in question 71. If multiple “other abnormalities” were detected, report “see attachment” in question 71 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 72: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if FISH testing report is attached to support the cytogenetic findings reported in questions 70-71. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 73: Were cytogenetics tested via karyotyping?

If karyotyping was performed when determining the maximum IPSS-R score, report “yes” for question 73 and continue with question 74. If karyotyping was not performed when determining the maximum IPSS-R score, report “no” for question 73 and go to question 82. Examples of this include: karyotyping was not performed, or karyotyping sample was inadequate.

#### Question 74-75: Sample source

Indicate if the sample was from “bone marrow” or from “peripheral blood” and report the date the sample was collected in question 75. If multiple sources were used for karyotyping, the most preferred sample is the bone marrow.

#### Question 76: Results of tests

If karyotyping assessments identified abnormalities, indicate “abnormalities identified” and continue with question 77.

If karyotyping assessments were unremarkable, indicate “no abnormalities” and continue with question 81.

If karyotyping assessment yielded an inadequate result, indicate “no evaluable metaphases” and continue with question 81.

#### Question 77-80: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 77, then continue with question 78.

Report the number of abnormalities detected by karyotyping when determining the maximum IPSS-R score in question 78. After indicating the number of abnormalities in question 78, select all abnormalities detected in questions 79-80.

If an abnormality is detected, but not listed as an option in question 79, select “other abnormality” and specify the abnormality in question 80. If multiple “other abnormalities” were detected, report “see attachment” in question 80 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 81: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if a karyotyping testing report is attached to support the cytogenetic findings reported in questions 77-78. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)