#### Question 1: Date of this DLI infusion

Report the date (YYYY-MM-DD) the DLI being reported in this instance was infused. If the product was infused over multiple days, report the first date of infusion.

If the exact date is unknown, please view [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for more information on reporting partial and unknown dates.

#### Question 2-3: What was the primary indication for performing treatment with donor lymphocyte infusion (DLI)?

From the list provided, select the primary indication for which the recipient is receiving the DLI.

These indications are all given with an HCT or post-HCT. No additional consent is required from the patient per CIBMTR. Please confirm with your local IRB.

If **Other indication** is selected, specify the other indication in question 3.

#### Question 4: What therapy to treat disease given prior to the DLI?

This question is intended to capture if the recipient received therapy to treat disease *at any time* prior the DLI. Do not count preparative regimen or bridging therapy. If Yes, and the recipient is on CRF track for the HCT, please ensure that all lines of therapy are reported on the disease specific form.

#### Question 5: Date complete blood sample drawn (CBC):

These questions are intended to determine the clinical status of the recipient prior to the infusion. Testing may be performed multiple times within the pre-infusion work-up time period; report the most recent CBC obtained. Typically, no systemic therapy (therapy not for treatment of disease, but analogous to preparative regimen) is given prior to DLIs. However, if that is the case, laboratory values obtained on the first day of the systemic therapy may be reported as long as the blood was drawn before any systemic therapy was administered.

#### Question 6-14: Complete blood count results available (check all that apply):

For each cell type listed, checking the box will indicate a result is available. Provide the most recent laboratory values from the CBC on the date reported in the prior question.

**WBC:** The white blood cell count is a value that represents all the white blood cells in the blood. If the count is too high or too low, the ability to fight infection may be impaired. Report the WBC value in question 7.

**Neutrophils:** Neutrophils are a subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage or an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage. Neutrophils are also known as polymorphonuclear leukocytes (PMNs). Report the neutrophil value in question 8.

**Lymphocytes:** Lymphocytes are another subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage of an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage. Report the lymphocyte value in question 9.

**Hemoglobin:** Hemoglobin is a molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count value is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level. Report the hemoglobin value in question 10.

**Hematocrit:** The hematocrit is the percentage (sometimes displayed as a proportion) of red blood cells relative to the total blood volume. A low hematocrit may require red blood cell transfusions or growth factors. Indicate if the recipient received a red blood cell transfusion within 30 days prior to sample draw date. Report the hematocrit value in question 11.

If a hematocrit value is reported, also indicate if the recipient received a red blood cell transfusion within 30 days prior to the date of the CBC reported in question 5.

**Platelets:** Platelets are formed elements within the blood that help with coagulation. A low platelet count, called thrombocytopenia, may lead to easy bleeding or bruising. Thrombocytopenia may require platelet transfusions. Indicate if the recipient received a platelet transfusion within 7 days prior to testing. Report the platelet value in question 13.

If a platelet value is reported, also indicate if the recipient received a platelet transfusion within 7 days prior to the date of the CBC reported in question 5.

#### Question 15: What scale was used to determine the recipient’s functional status prior to the donor lymphocyte infusion?

For centers that collect only the ECOG performance score refer to [Appendix L](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-l-karnofsky-lansky-performance-status).

The CIBMTR uses the Karnofsky / Lansky scale to determine the functional status of the recipient immediately prior to the start of the cellular therapy. The Karnofsky Scale is designed for recipients aged 16 years and older and is not appropriate for children under the age of 16. The Lansky Scale is designed for recipients one year old to less than 16 years old. For recipients less than one year old, questions 15-17 should be left blank.

#### Question 16-17: Performance score prior to donor lymphocyte infusion:

Recipient performance status is a critical data field that has been determined to be essential for all outcome- based studies. The CIBMTR uses the Karnofsky / Lansky scale to determine the functional status of the recipient immediately prior to the start of the lympho-depleting therapy or systemic therapy. For the purposes of this manual, the term “immediately prior” represents the pre-infusion work-up phase, or approximately one month prior to the start of the lympho-depleting therapy or preparative regimen.

Select the appropriate performance scale, Karnofsky or Lansky, based on the recipient’s age. Using this scale, select the score (10-100) that best represents the recipient’s activity status immediately prior to the start of the lympho-depleting therapy or systemic therapy. For an example of the Karnofsky / Lansky scale, see [Appendix L](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-l-karnofsky-lansky-performance-status).

If a Karnofsky / Lansky score is not documented in the source documentation (e.g., inpatient progress note, physician’s clinic note), data management professionals should not assign a performance score based on analysis of available documents. Rather, a physician or mid-level health care provider (NPs and PAs) should provide documentation of the performance score. Documentation from an RN who has been trained and authorized to determine performance scores may also be used.

The CIBMTR recognizes that some transplant centers prefer to collect and use the ECOG performance score as opposed to the Karnofsky / Lansky score. Although the ECOG and Karnofsky / Lansky performance score systems are based on similar principles, the scales are not the same. For example, the Karnofsky / Lansky scale is described in 11 categories, whereas the ECOG performance status is reported in six categories. Due to the overlap between the two systems, an ECOG score of “one” can represent either “80” or “90” on the Karnofsky / Lansky scale. For centers that collect only an ECOG performance score, CIBMTR will make the following accommodations when auditing the source data:


- Centers collecting ECOG scores should do so using standard practices to ensure accuracy.
- For the purposes of CIBMTR reporting, conversion of ECOG to Karnofsky / Lansky should follow a standard and consistent practice. This practice should be clear and reproducible.

For more information regarding converting an EGOG score to a Karnofsky / Lansky score, see [Appendix L.](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-l-karnofsky-lansky-performance-status)

#### Question 18-19: Date of cell product collection:

Report if the date of cell product collection is **Known** or **Unknown**. If the date of cell product collection is **Known**, report the date (YYYY-MM-DD) in question 19. If the date of cell product collection is **Unknown**, continue with question 20.

If the exact date is not known, refer to [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for more information regarding reporting partial or unknown dates.

#### Question 20: Was the product previously cryopreserved?

DLI products can be leftover products from a prior HCT. Indicate if the DLI product was previously cryopreserved.

#### Question 21-22: Tissue Source

Select from the list the tissue source(s) of the cellular product being reported in this instance. If the source is selected as **Other tissue source**, specify the other source in question 22.

The tissue source for non-mobilized peripheral blood, peripheral blood apheresis, and MNCs should be reported as **peripheral blood**.

#### Question 23: Were the cells in the infused product selected/modified/engineered/manipulated prior to infusion?

Indicate **Yes** if the cells contained in the product were selected (i.e., selective retention of a population of desired cells through recognition of specified characteristics) or modified. Indicate **No** if the cells contained in the product were not selected or modified in any way prior to infusion and continue with question 31.

#### Question 24-25: Specify the method(s) used to manipulate the product (check all that apply):

Indicate the method(s) of manipulation.

**Cultured (ex-vivo expansion):** cells were placed in culture to increase in number (i.e., to expand) allowing for sufficient cells for infusion. Continue with question 26.

**Induced cell differentiation:** cells were placed in culture to give rise to cellular elements with biological characteristics other than those of the cells being cultured (i.e., mesenchymal stromal cells cultured to make osteoblasts; pluripotent stem cells cultured to make neural cell precursors). Usually, the description of the process would include the term “differentiation of cells X into cells Y”. This scenario can be seen in regenerative medicine indications. Continue with question 26.

**Cell selection – positive:** the manipulation of a cellular therapy product that a specific cell population(s) is enriched. This may be achieved by using an antibody that binds to a specific population of cells (e.g., CD4+ selection). Continue with question 26.

**Cell selection – negative:** the manipulation of a cellular therapy product such that a specific cell population(s) is reduced. Continue with question 26.

**Cell selection based on affinity to a specific antigen:** the cellular product undergoes selection to isolate the target population based on the ability of the target population to bind or recognize a specific antigen (e.g., a T cell population recognizing viral proteins, or a protein associated with a cancer). Continue with question 26.

**Other cell manipulation:** not fitting an above category. Specify the other cell manipulation in question 25 and continue with question 26.

#### Question 26-32: Specify the cell type(s) administered

**Lymphocytes (unselected):** Unselected means a specific lymphocyte sub-population (e.g. CD4+) was not targeted. This includes all types of lymphocytes, those that have not been selected via flow cytometry or other method. Report the total number of unselected lymphocytes (e.g., CD3+ cells) administered in the product in question 27.

**CD4+ lymphocytes:** The lab report may display this value as CD3+CD4+. These cells are also known as T-helper cells. Report the total number of CD4+ cells administered in the product in question 28.

**CD8+ lymphocytes:** The lab report may display this value as CD3+CD8+. These cells are also known as cytotoxic T-cells which can destroy virus-infected cells, tumor cells, tissue grafts, etc. Report the total number of CD8+ cells administered in the product in question 29.

**Regulatory T-cells (TREG):** TREG cells express the biomarkers CD4, FOXP3, and CD25. Report the total number of TREG cells administered in the product in question 30.

**Other cell type:** If a different cell type not previously mentioned was infused, specify the other cell type in question 31 and report the total number administered in the infusion in question 32.

#### Question 33: What was the best response to the donor lymphocyte infusion (DLI)?

This section collects the data known as “best response to donor lymphocyte infusion”. The purpose of this section is to report the recipient’s best response to the DLI. If the recipient received a prior HCT, do not report the response to the HCT, a separate evaluation to establish best response after the DLI is required. Report best response to DLI when the assessment was done per routine clinical evaluation, within 30-60 days post-infusion, and prior to any subsequent DLI. If an assessment post-DLI was not performed, select **Not assessed**.

Table 1 describes the appropriate best response option to choose by indication.

**Table 1. Examples of best response to DLI**


| Indication | Applicable response options | Partial Response | Complete Response |
|---|---|---|---|
| GVHD prophylaxis (with HCT) | Do not answer best response | - | - |
| GVHD treatment | Complete Response, Partial Response, or No Response | Improvement but not resolution of symptoms, Remains on immune suppression | Improvement but not resolution of symptoms, or Remains on immune suppression |
| Immune Reconstitution (post-HCT) | Complete Response or No Response | - | CD3 >200/mm3 |
| Infection treatment | Complete Response, Partial Response, No Response, or Unknown | Decrease in infectious burden without resolution | Undetectable infection |
| Prevent disease relapse | Do not answer best response | - | - |
| Suboptimal donor chimerism (post-HCT) | Complete Response, Partial Response, or No Response | Increase in chimerism but not 100% donor | 100% donor chimerism |
| Treatment of MRD | Complete Response, Partial Response, or No Response | Refer to the disease specific manuals for disease criteria | Refer to the disease specific manuals for disease criteria |
| Treatment of disease relapse/progression | Complete Response, Partial Response, No Response, or Disease Progression | Refer to the disease specific manuals for disease criteria | Refer to the disease specific manuals for disease criteria |
| Other | Do not answer best response | - | - |

#### Question 34: Date respond established:

Report the date (YYYY-MM-DD) the best response was established. It should be the first date all criteria were met.

If the exact date is unknown, please view [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for more information on reporting partial and unknown dates.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 4 | 3/7/2024 | Modify | Added text for clarification of therapy timepoint: This question is intended to capture if the recipient at any time prior the DLI. |
To provide clarification on the time point of prior therapy |
| 33 | 11/14/2022 | Modify | Added sentence about time point of best response: Report best response to DLI when the assessment was done per routine clinical evaluation, within 30-60 days post-infusion, and prior to any subsequent DLI. | To provide clarification on the time point of best response |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)