This section of the HCT Infusion (2006) form captures pre-collection therapy information regarding the donor’s mobilization or priming; this section of the form is not completed for cord blood units or products from NMDP donors.

#### Question 1: Did the donor receive growth and mobilizing factors, prior to any stem cell harvest, to enhance the product collection for this HCT? (*Allogeneic donors only*)

Stem cells do not typically circulate in the blood stream. Therefore, in order to increase the quantity of cells for collection, an agent is frequently given to the allogeneic donor. The purpose of the agent is to move the stem cells from the bone marrow into the peripheral blood where the cells can be collected by apheresis. This practice is often referred to as mobilization or priming. Occasionally, a donor may be primed using a growth factor prior to collection of bone marrow.

If the Allogeneic donor received therapy (such as growth factors, mobilizing agents, etc.), report **Yes**.

If the Allogeneic donor did not receive therapy to enhance the stem cell product, report **No**.

This question is only enabled for PBSC and bone marrow products from non-NMDP donors.

#### Questions 2-3: Specify growth and mobilizing factor(s)

Examples of growth and mobilizing factors include, but are not limited to, the following:

Epidermal growth factor – EGF

Erythropoietin – EPO

Fibroblast growth factor – FGF

Granulocyte-colony stimulating factor – G -CSF

Granulocyte-macrophage colony stimulating factor – GM-CSF

Growth differentiation factor-9 – GDF9

Hepatocyte growth factor – HGF

Insulin-like growth factor – IGF

Platelet-derived growth factor – PDGF

Thrombopoietin – TPO

Transforming growth factor alpha – TGF-α

Transforming growth factor beta – TGF-β

Report if any of the following growth or mobilizing factors were given. Check all that apply.

**G-CSF** (granulocyte-colony stimulating factor, **filgrastim**, **Neupogen®**)

**Pegylated G-CSF** (**pegfilgrastim**, **Neulasta®**)

**Plerixafor** (**Mozobil®**)

If a growth or mobilizing factor was given is not included in the above list, select **Other growth or mobilizing factor(s)** and specify the generic name for the growth or mobilizing factor.

**Example 1**: The donor was mobilized with Granix (tbo-Filgrastim) prior to the start of collection. Since this is a biologic medical product that is highly similar to Neupogen, this would be captured under G-CSF.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)