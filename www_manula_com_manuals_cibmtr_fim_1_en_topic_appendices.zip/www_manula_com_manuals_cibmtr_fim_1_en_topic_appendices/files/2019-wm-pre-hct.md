The Waldenström’s Macroglobulinemia/Lymphoplasmacytic Lymphoma Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures WM/LPL-specific pre-HCT data such as: the recipient’s clinical and genetic findings at the time of diagnosis and prior to the start of the preparative regimen, pre-HCT treatments administered, and disease manifestations prior to the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as Non-Hodgkin lymphoma and the subytpe is reported as Waldenström’s Macroglobulinemia/Lymphoplasmacytic Lymphoma.

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype and **this baseline disease insert was not completed for the previous transplant** (e.g., patient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), begin at question 1.

If this is a report of a second or subsequent transplant for a **different disease** (e.g., patient was previously transplanted for a disease other than WM/LPL), begin at question 1.

If this is a report of a second or subsequent transplant for the **same disease and this baseline disease insert has previously been completed**, check yes and continue with the next question.

For the next question, indicate if this form is being completed for a **relapse or a progression of the same disease**. If “yes”, continue with question 76; if “no”, continue with question 121.

[Q1-2: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-2-disease-assessment-at-diagnosis)

[Q3-23: Clinical Features Present at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q3-23-clinical-features-present-at-diagnosis)

[Q24-75: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q24-75-laboratory-studies-at-diagnosis)

[Q76-120: Pre-HCT Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q76-120-pre-hct-therapy)

[Q121-150: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q121-150-laboratory-studies-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

[Q151-152: Disease Status at Last Evaluation Prior to the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q151-152-disease-status-at-last-evaluation-prior-to-the-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/21/2023 |
|

**Lines of Therapy and Subsequent Infusions***If this is a subsequent infusion and a 2019 was completed for the previous infusion, lines of therapy do not need to be reported in duplication on the subsequent 2019. Please report from post previous infusion to time of preparative regimen / infusion for the current infusion. If a 2019 was not previously completed, all lines of therapy from diagnosis to the current preparative regimen / infusion must be completed.*
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)