#### Question 104: Does the current disease status reflect the disease detected in this reporting period section (as captured in questions 51-89), without subsequent therapy?

This section of the form is intended to capture the most recent disease assessment. The most recent disease assessments may have already been reported in the Disease Detection Since the Date of Last Report (questions 51-89) and, if that is the case, it is not necessary to report those same disease assessments in the Disease Status at the Time of Evaluation for this Reporting Period (questions 105-143). Refer to the instructions below to determine how to complete this section of the form. Reporting scenarios have also been provided below.

Report “Yes” for question 104 and go to question 144 in *any* of the following scenarios:


- Disease was detected by any method in the reporting period (reported in the Disease Detection Since the Date of Last report, questions 51 – 89) and
*no*therapy was given to treat disease between the date(s) of the assessments reported in the Disease Detection Since the Date of Last Report (questions 51-58) for the form and the date of contact for this reporting period - Disease was detected by any method in the reporting period (reported in the Disease Detection Since the Date of Last Report, questions 51 – 89), therapy was administered, but no assessments were performed after the initiation of therapy

Report “No” for question 104 and report the most recent disease assessments in the reporting period in questions 105 – 143 in *any* of the following scenarios:


- Disease was not detected by any method of assessment during the reporting period
- Disease was detected in the reporting period (reported in the Disease Detected Since the Date of Last Report, questions 51 – 89), therapy was administered, and additional assessment(s) were performed after therapy


Report “Not applicable” for question 104 and submit the form if no disease assessments were performed during the current reporting period. Only report this option if the recipient did not have any disease assessments, including a physical exam by their primary care provider, performed during the reporting period. Contact the CIBMTR Customer Service Center if there are questions regarding whether a visit or test should be reported as a disease assessment.

**Disease Status Evaluation Reporting Scenarios:**

**A.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD (FLT3-ITD was detected at diagnosis). Disease was not detected by any of these three assessments. Subsequently, on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are negative. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 51-89:** No assessments will be reported here since the recipient’s disease did not relapse, did not persist or have evidence of minimal residual disease. In this scenario, questions 51, 63, 70, 80, and 87 must be answered “No”.

**Question 104:** Report “No” for question 104. Disease was not detected by any method of assessment during the reporting period.

**Questions 105-143:** Report the results of the most recent assessment by each method including:

- PCR testing for FLT3-ITD performed on 1/15/2016.
- Flow cytometry testing performed on the bone marrow on 3/20/2016.
- Morphology review performed on the bone marrow on 3/20/2016.

**B.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD (FLT3-ITD was detected at diagnosis). Disease was not detected by any of these three assessments. Subsequently, on D+95 (3/20/2016), all three tests are repeated and are positive indicating disease relapse. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 51-89:** All three disease assessments performed on 3/20/2016 (PCR test for FLT3-ITD as well as morphology and flow cytometry on the bone marrow) will be reported because they were the earliest positive assessments of disease during the reporting period.

**Question 104:** Report “Yes” for question 104. The most recent assessments have already been reported in questions 51-59.

**Questions 105-143:** These questions will be left blank (i.e., not enabled).

**C.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD (FLT3-ITD was detected at diagnosis). Disease was not detected by any of these three assessments. Subsequently, on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are positive indicating disease relapse. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 51-89:** Morphology and flow cytometry assessments of the bone marrow on 3/20/2016 will be reported because they were the earliest positive assessments of disease during the reporting period. Testing for molecular markers was not done at the time of relapse and should not be reported here.

**Question 104:** Report “Yes” for question 104 since the most recent test results were reported in Q51-88.

**Questions 105-143:** These questions will be left blank (i.e., not enabled).

**D.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD. All three assessments detect disease. Subsequently, on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are again positive for disease. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 51-89:** All three disease assessments performed on 1/15/2016 (PCR test for FLT3-ITD as well as morphology and flow cytometry on the bone marrow) will be reported because they were the earliest positive assessments of disease during the reporting period.

**Question 104-143:** Report “Yes” for question 104 if no therapy was given to treat the disease between 1/15/2016 and 3/20/2016. If therapy was used to treat the disease during this time frame, indicate “No” and report the most recent test results in questions 105-143.

**E.** A recipient has a bone marrow assessment on D+30 (1/15/2016), including morphology review, flow cytometry, and PCR testing for FLT3-ITD. All three assessments detect disease. Therapy was started and assessments were performed again on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are again positive for disease. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 51-89:** All three disease assessments performed on 1/15/2016 (PCR test for FLT3-ITD as well as morphology and flow cytometry on the bone marrow) will be reported because they were the earliest positive assessments of disease during the reporting period.

**Question 104-143:** Report “No” for question 104 and report the testing performed after treatment (bone marrow and flow on the bone marrow done on D+95).

#### Question 105: Were tests for molecular markers performed (e.g. PCR, NGS)?

Refer to [question 4](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#mol) for a description of testing for molecular markers. If molecular testing was performed during the reporting period, report “Yes” and go to question 106. If testing was not performed during the reporting period or it is not known whether testing was performed, report “No” or “Unknown” respectively and go to question 116.

#### Question 106-115: Specify results

For each molecular marker in questions 106-115, report whether testing was “Positive,” “Negative,” or “Not done” at the time of the most recent assessment during the reporting period. If the most recent testing performed during the reporting period identified a molecular marker other than those listed in questions 106-113, report the result in question 114 and specify the marker in question 115.

If multiple “Other molecular marker[s]” were tested at the time of best response, report one instance (i.e., copy) of question 114-115 for each “Other molecular marker” tested. If greater than 3 “Other molecular marker[s]” were tested, do the following:


- report one instance of question 114-115; and
- report “Positive” if any of the “Other molecular marker[s]” were positive, otherwise, report “Negative;” and
- report “see attachment” in question 115; and
- attach any / all reports documenting the results of testing for “Other molecular marker[s].”

If CEBPA is reported as “Positive” (question 106) question 107 must be completed. If the lab report does not specify whether the detected marker was biallelic / homozygous or monoallelic / heterozygous, confirm with the laboratory whether this information can be determined prior to reporting “Unknown.”

#### Question 116: Was the disease status assessed via flow cytometry?

Refer to [question 15](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#flow) for a description of flow cytometry. Only testing performed on the blood or bone marrow may be reported in questions 116-124. If flow cytometry was performed on the blood and / or bone marrow during the reporting period, report “Yes” and go to question 117. If testing was not performed during the reporting period, report “No” and go to question 125.

#### Question 117-120: Flow cytometry testing on blood

If flow cytometry was performed on the blood during the reporting period, report “Yes” for question 117 and go to question 118. If testing was not performed during the reporting period, report “No” and go to question 121.

If “Yes” has been reported for question 117, report the date of collection and results for the most recent assessment performed during reporting period in questions 118 and 119 respectively. If disease was detected by the most recent assessment, report the percent disease detected (i.e., percent leukemic blasts) in question 120. Otherwise, go to question 121.

#### Question 121-124: Flow cytometry testing on bone marrow

If flow cytometry was performed on the bone marrow during the reporting period, report “Yes” for question 121 and go to question 122. If testing was not performed during the reporting period, report “No” and go to question 125. If it is not known whether testing was performed, leave question 121 blank and override the validation error using the code “Unknown.”

If “Yes” has been reported for question 121, report the date of collection and results for the most recent assessment performed during reporting period in questions 122 and 123 respectively. If disease was detected by the most recent assessment, report the percent disease detected (i.e., percent leukemic blasts) in question 124. Otherwise, go to question 125.

#### Question 125: Were cytogenetics tested (karyotyping or FISH)?

Refer to [question 24](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110disease-assessment-at-the-time-of-best-response-to-hct#cyto) for a description of cytogenetic testing. If cytogenetic testing was performed during the reporting period, report “Yes” and go to question 126. If testing was not performed during the reporting period or it is not known whether testing was performed, report “No” or “Unknown” respectively and go to question 137.

If cytogenetic studies were attempted during the reporting period, but there were not adequate cells (metaphases) for any cytogenetic assessments, report “No,” and go to question 137.

#### Question 126-127: Were cytogenetics tested via FISH?

If FISH studies were performed during the reporting period, report “Yes” and indicate whether clonal abnormalities were detected on the most recent assessment in the reporting period in question 127. If FISH studies were not performed, report “No” for question 126 and go to question 131. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Question 128-130: Specify cytogenetic abnormalities (FISH)

Report the number of clonal abnormalities detected by the most recent FISH assessment in the reporting period in question 128. After indicating the number of abnormalities in question 128, select all clonal abnormalities detected in questions 129-130.

If a clonal abnormality is detected on the most recent FISH assessment in the reporting period, but not listed as an option in question 129, select “Other abnormality” and specify the abnormality in question 130. If multiple “Other abnormalities” were detected, report “see attachment” in question 130 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 131-132: Were cytogenetics tested via karyotyping?

If karyotyping was performed during the reporting period, report “Yes” for question 131 and indicate whether clonal abnormalities were detected in question 132. If karyotyping was not performed, indicate “No” for question 131 and go to question 136. Examples of this include: karyotyping was not performed or karyotyping sample was inadequate.

#### Question 133-135: Specify cytogenetic abnormalities (karyotyping)

Report the number of clonal abnormalities detected by the most recent karyotype in the reporting period in question 133. After indicating the number of clonal abnormalities in question 133, select all abnormalities detected in questions 134-135.

If a clonal abnormality is detected on the most recent karyotype during the reporting period, but not listed as an option in question 134, select “Other abnormality” and specify the abnormality in question 135. If multiple “Other abnormalities” were detected, report “see attachment” in question 135 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 136: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported in questions 125-135. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 137-139: Was disease detected by clinical / hematologic assessment?

Clinical / hematologic assessments include, but are not limited to, biopsies, imaging assessments, complete blood counts, radiographic studies and physical exams. If clinical / hematologic testing was performed during the reporting period, report “Yes” for question 137 and report the date and result in questions 138 and 139 respectively. The date and results reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). Indicate the date the sample was collected for examination for pathological and laboratory evaluations; enter the date of physical examination. If no disease assessments were performed within approximately 30 days prior to the date of contact, report the results and date of the most recent assessment performed during the reporting period. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If no clinical / hematologic assessments (including a physical exam by the recipient’s primary care provider) were performed during the reporting period, report “No” for question 137 and go to question 140.

#### Question 140-143: Was the disease status assessed by other assessment?

Indicate in question 140 whether AML was assessed by any method other than those included in questions 105-139 during the reporting period. If “Yes,” report the date of assessment and specify the type of assessment in questions 141 and 142 respectively. Also report the results of the assessment in question 143. If the exact date of assessment is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If AML was not assessed by any methods other than those included in questions 105-139, report “No” for question 140 and go to question 144.

#### Question 144: What is the current disease status?

Indicate the hematologic disease status of AML as of the last evaluation during the reporting period. Determine the current disease status using the international working group criteria provided in the in AML Response Criteria of the Forms Instructions Manual. Report “Complete Remission” for recipients who meet the criteria for complete remission (CR). Do not consider testing for molecular markers, testing for cytogenetic abnormalities, or testing by flow cytometry when reporting the hematologic disease status in question 144.

Some clinical judgment is required for evaluating whether a recipient meets the CR criteria, specifically neutrophil, platelet, and transfusion parameters. If a recipient does not meet these specifications, the underlying cause should be assessed; if the cause for not meeting one of these parameters is felt to be due to a reason other than underlying leukemia, such as renal insufficiency, hemolysis, or drug-related causes, the disease status may be reported as “complete remission.” If the cause for not meeting the parameters is judged to be leukemia-related, the disease status should be reported as “not in complete remission.”

If the recipient did not meet the criteria for CR report “Not in complete remission.”

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 145: Date assessed

Enter the date of the most recent assessment establishing disease status within the reporting period. The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). In addition to clinician evaluation and physical examination, clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory analysis (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluation; the date the imaging took place for radiographic assessments, or the date of physical examination.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)