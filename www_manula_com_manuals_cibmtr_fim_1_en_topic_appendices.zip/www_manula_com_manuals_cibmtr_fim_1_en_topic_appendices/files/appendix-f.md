## Response Evaluation Criteria in Solid Tumors (RECIST)

The Response Evaluation Criteria in Solid Tumors (RECIST) were published in February 2000 by the European Organization for Research and Treatment of Cancer (EORTC), the National Cancer Institute of the United States, and the National Cancer Institute of Canada Clinical Trials Group. RECIST criteria are used to evaluate a patient’s response to the therapy used to treat their disease.

The content of this appendix has been modified to fit the needs of the CIBMTR data collection forms. For the complete text and more detailed information regarding confirmation of response, methods of measurement, and use of RECIST in clinical trials, see [http://ctep.cancer.gov/protocolDevelopment/docs/quickrcst.doc](http://ctep.cancer.gov/protocolDevelopment/docs/quickrcst.doc) and [http://ctep.cancer.gov/protocolDevelopment/docs/therasserecistjnci.pdf](http://ctep.cancer.gov/protocolDevelopment/docs/therasserecistjnci.pdf).

### Baseline documentation of *Target* and *Non-Target* lesions:

- All measurable lesions up to a maximum of five lesions per organ and 10 lesions in total that are representative of all involved organs should be identified as
recorded, and measured at baseline. Target lesions should be selected on the basis of their size (lesions with the longest diameter) and their suitability for accurate repeated measurements (either by imaging techniques or clinically). A sum of the longest diameter (LD) for**target lesions***all target lesions*will be calculated and reported as the baseline sum LD. The baseline sum LD will be used as the reference by which to characterize the objective tumor. - All other lesions (or sites of disease) should be identified as
and should also be recorded at baseline. Measurements of these lesions are not required, but the presence or absence of each should be noted throughout follow-up.**non-target lesions**

### Response Criteria for *Target* and *Non-Target* lesions:

*Target*

*Non-Target*

**Table 1. Evaluation of target lesions**

| Disease Status | Evaluation of Target Lesions | Evaluation of Non-Target Lesions |
|---|---|---|
| Complete Response | Disappearance of all target lesions for a period of at least one month. | Disappearance of all non-target lesions and normalization of tumor marker level. |
| Complete Response Unknown | Complete response with persistent imaging abnormalities of unknown significance. | No definition available. |
| Partial Response | At least a 30% decrease in the sum of the longest diameter of measures lesions (target lesions), taking as reference the baseline sum of the longest diameter. | No definition available. |
| No Response / Incomplete Response / Stable Disease | Neither sufficient shrinkage to qualify for PR nor sufficient increase to qualify for PD, taking as reference the smallest sum of the longest diameter since the treatment started. | Persistence of one or more non-target lesion(s) or/and maintenance of tumor marker level above the normal limits. |
| Progressive Disease (PD) | A 20% or greater increase in the sum of the longest diameter of measured lesions (target lesions), taking as reference the smallest sum LD recorded since the treatment started or the appearance of one or more new lesions. | Appearance of one or more new lesions and/or unequivocal progression of existing non-target lesions.1 |

1 Although a clear progression of “non target” lesions only is exceptional, in such circumstances, the opinion of the treating physician should prevail and the progression status should be confirmed later on by the review panel (or study chair).

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/30/17 | Appendix F: Response Evaluation Criteria in Solid Tumors (RECIST) | Add | Added all retired content from Appendix N: Response Evaluation Criteria in Solid Tumors (RECIST) to Appendix F. |
| 6/30/17 | Appendix F: Response Evaluation Criteria in Solid Tumors (RECIST) | Modify | Appendix N: Response Evaluation Criteria in Solid Tumors (RECIST) has been renamed to Appendix F: Response Evaluation Criteria in Solid Tumors (RECIST). |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)