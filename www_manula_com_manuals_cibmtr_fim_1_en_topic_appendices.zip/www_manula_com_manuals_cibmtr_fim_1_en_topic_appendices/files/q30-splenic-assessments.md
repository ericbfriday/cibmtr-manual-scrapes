#### Question 30: Did the recipient have a splenectomy?

Specify if the recipient had a splenectomy in the current reporting period. Report **Not applicable** in the following scenarios:

**Yes**, was reported in a prior reporting period (i.e., splenectomy occurred in a previous reporting period)- The recipient had a splenectomy prior to infusion

The **Unknown** option should be used sparingly and only if there is no information to determine if the recipient had a splenectomy.

#### Question 31: Did the recipient have splenomegaly?

Indicate if the recipient had splenomegaly (i.e., abnormal enlargement of the spleen) in this reporting period. Splenomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Last modified:
Jul 29, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)