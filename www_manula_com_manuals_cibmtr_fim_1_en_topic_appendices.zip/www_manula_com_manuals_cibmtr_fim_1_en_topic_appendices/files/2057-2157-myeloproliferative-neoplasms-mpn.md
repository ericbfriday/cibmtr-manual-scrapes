**Myeloproliferative neoplasms** (MPN) are characterized by the overproduction of blood cells (red blood cells, white blood cells, and/or platelets) or collagen in the bone marrow. Often the MPN will be identified due to a blood test for another condition, as some patients are asymptomatic. Common symptoms found in the array of myeloproliferative disorders include fatigue and the enlargement of the spleen (splenomegaly).

[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)

[2057: MPN Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2057-myeloproliferative-neoplasm-mpn-pre-infusion)

[2157: MPN Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2157-myeloproliferative-neoplasm-mpn-post-infusion)

Last modified:
Jul 22, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)