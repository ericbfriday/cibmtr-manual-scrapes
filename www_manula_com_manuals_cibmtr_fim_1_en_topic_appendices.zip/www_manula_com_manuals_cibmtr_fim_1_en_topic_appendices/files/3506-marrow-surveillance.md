The Marrow Surveillance (3506) Form is a Gene Therapy registry form which captures cytogenetic assessment results of a bone marrow aspirate / biopsy performed pre- and post-infusion.

The Marrow Surveillance (3506) Form will come due for those recipients enrolled onto CIBMTR study CS20-51 (Skysona®) or CS22-24 (Zyntelgo®). These are post-marketing prospective, multicenter, observational, long-term safety and effectiveness registry studies of recipients with cerebral adrenoleukodystrophy treated with Elivaldogene Autotemcel (Skysona ®) or beta-thalassemia treated with Betibeglogene Autotemcel (Zynteglo®).

The Pre-Transplant Essential Data (2400) Form will confirm study eligibility, this includes event date, genetic modification, and gene therapy product infused.

**Pre-Infusion**

Once study eligibility is confirmed, the Marrow Surveillance (3506) Form will come due for the “at infusion” timepoint with the Laboratory Studies (3502) Form, Leukodystrophies Pre-Infusion (2037) Form for CS20-51 or Thalassemia Pre-Infusion (2058) Form for CS22-24. The form will capture the most recent bone marrow for the *last evaluation prior to the preparative regimen (or infusion)*.

**Post-Infusion**

The Marrow Surveillance (3506) Form and Laboratory Studies (3502) Form will also come due when the Leukodystrophy Post-Infusion (2137) Form for CS20-51 or Thalassemia Post-Infusion (2158) Form for CS22-24 indicates a marrow biopsy and/or aspirate was performed in the current reporting period.

Links to Sections of Form:

[Q1 – 18: Marrow Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-18-marrow-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/25/2024 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)