#### Question 1: Is the disease (AML) therapy related? (not MDS / MPN)

Agents such as radiation or systemic therapy used to treat other diseases (e.g., Hodgkin lymphoma, non-Hodgkin lymphoma, and breast cancer) can damage the marrow and lead to a secondary malignancy such as AML. If the diagnosis of AML is therapy-related, report “Yes” and go to question 2.

Report “No” and go to question 10 in any of the following scenarios:


- the diagnosis of AML was not therapy related; or
- AML was preceded by therapy-related MDS; or
- the recipient developed AML after an environmental exposure (e.g., exposure to benzene), check “no.”

If it is not known whether the diagnosis of AML was therapy-related, check “Unknown” and go to question 10

#### Question 2-3: Specify prior disease

Indicate the disease for which the recipient received therapy prior to the diagnosis of therapy-related AML. If the patient’s prior disease is best classified as “Other disease (malignant or non-malignant),” specify in question 3.

#### Question 4-5: Date of diagnosis of prior disease

Report “Known” if the exact date or an estimated date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) has been documented. Enter the date the sample was collected for examination. Do not report the date symptoms first appeared. This date must be prior to the AML diagnosis date reported on the Disease Classification Form (Form 2402). If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms.

If the date is “Unknown,” continue with question 6.

#### Question 6-9: Specify therapy for prior disease

Indicate whether each type of therapy was given to treat the recipient’s prior disease. Report “Yes” for any therapies known to have been given to treat the disease reported in questions 2-3. Report “No” for any therapies which were not given to treat the disease reported in questions 2-3. Report “Unknown” if no information is available to determine whether the therapy was given to treat the disease reported in questions 2-3.

See below for descriptions of each type of therapy captured on the form. Do not report surgery or intrathecal chemotherapy in questions 6-9.

**Cytotoxic Therapy:** chemotherapy injected into a vein or given orally.

**Radiation:** high-energy x-rays, gamma rays, electron beams, or proton beams to kill cancer cells. Radiation therapy may be used to kill cells that have invaded other tissues and lymph nodes.

**Other Therapy:** cellular therapy, therapeutic vaccines, hormone therapy, or other treatments which would not be considered systemic or radiation therapy.

#### Questions 10-11: Did the recipient have an antecedent hematologic disorder (preleukemia or myelodysplastic syndrome)?

AML often evolves from MDS or MPN, but may also transform from other diseases including juvenile myelomonocytic leukemia (JMML), chronic myelomonocytic leukemia (CMMoL), and aplastic anemia. AML which transforms from MDS or MPN has a lower survival prognosis because of the association with unfavorable cytogenetic abnormalities. Only report antecedent disorders which were diagnosed prior to the diagnosis of AML. Do not report suspected or concurrent diagnoses of antecedent disorders in questions 10-13. See reporting Antecedent Disorder Reporting Scenarios below.

If AML transformed from an antecedent hematologic disorder, report “yes” and indicated the date of diagnosis in question 11. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms. Also report the specific antecedent hematologic disorder in questions 12-13.

If the recipient did not have an antecedent hematologic disorder or it is not known, report “No” or “Unknown” respectively and go to question 14. Unknown should only be reported if there is no documentation available summarizing the recipient’s medical history.

Antecedent Disorder Reporting Scenarios:

**A.** Patient presents with fatigue; initial work-up reveals anemia. Subsequent bone marrow biopsy with specimen taken on May 14, 2015 shows MDS, refractory anemia with excess blasts at 7%, or RAEB-1. The patient chooses supportive therapy and their disease progresses to AML, which is shown in a bone marrow biopsy with 28% blasts on September 7, 2015 of the same year.

*AML Pre-Infusion Data Form:*

**Question 10:** Report “Yes” to confirm an antecedent hematologic disorder was diagnosed prior to the diagnosis of AML.

**Question 11:** Report 5/14/2015 as the date of diagnosis of the antecedent hematologic disorder.

**Questions 12-13:** Report RAEB-1 as the disorder identified.

**B.** Patient presents with severe fatigue and chronic upper respiratory infections; initial work-up reveals anemia. Subsequent bone marrow biopsy with specimen taken June 17 shows 26% blasts and myelodysplasia-related features; an aspirate sample was sent for cytogenetic testing, which reveals monosomy 7. The physician states this recipient has AML arising from MDS.

*AML Pre-Infusion Data Form:*

**Question 10:** Report “No.” This would be considered as concurrent diagnosis which should not be reported in questions 10-13. Only report antecedent hematologic disorders diagnosed prior to the diagnosis of AML.

#### Question 12-13: What was the classification of the hematologic disorder at diagnosis?

Indicate the classification of the antecedent hematologic disorder at diagnosis. Do not report any transformations or progressions of an antecedent hematologic disorder. See Antecedent Disorders Reporting Scenarios below for examples. For a list of MDS / MPN subtypes and their diagnostic criteria, see Appendix H, MDS / MPN Subtypes.

If the antecedent hematologic disorder is not listed as an option choice in question 12, report “Other hematologic disorder” and specify the disorder in question 13.

An additional pre-infusion disease insert must be completed if any of the following have been reported in questions 12-13:


**MDS subtype:**complete the Myelodysplastic Syndromes Pre-HCT Data Form (Form 2014).**MPN subtype:**complete the Myeloproliferative Neoplasms Pre-HCT Data Form (Form 2057).**JMML:**complete the Juvenile Myelomoncytic Leukemia Pre-HCT Data Form (Form 2015).**Aplastic anemia:**Complete the Aplastic Anemia Pre-HCT Data Form (Form 2028).**Fanconi anemia:**Complete the Fanconi Anemia Pre-HCT Data Form (Form 2029).

Any additional required forms should appear automatically in FormsNet3SM after the AML Pre-Infusion Data Form (Form 2010) has been successfully submitted. If the appropriate forms do not appear, contact CIBMTR Center Support.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)