The Betibeglogene Autotemcel (Zynteglo®) Pre-Infusion Supplemental Data Collection (2544) Form must be completed for recipients who are enrolled onto CIBMTR study CS22-24. This is a post-marketing prospective, multicenter, observational, long-term safety and effectiveness registry study of recipients with beta-thalassemia treated with betibeglogene autotemcel (beti-cel).

The Pre-Transplant Essential Data (2400) Form will confirm study eligibility, this includes event date and gene therapy product infused. Once eligibility is confirmed, the Betibeglogene Autotemcel (Zynteglo®) Pre-Infusion Supplemental Data Collection (2544) Form will come due for all recipients along with the Recipient Baseline (2000), Gene Therapy Product (2003) and Thalassemia Pre-Infusion (2058) Forms.

Links to Sections of Form:

[Q1: Hypertransfusions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-hypertransfusions)

[Q2-5: Splenic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-5-splenic-assessments)

[Q6-10: Transfusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q6-10-transfusion-therapy)

[Q11: Mobilization](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-mobilization)

[Q12-13: Additional Iron Overload Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q12-13-additional-iron-overload-assessments)

[Q14-17: Additional Hematologic Labs](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q14-17-additional-hematologic-labs)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, you can reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 9/27/2024 | Betibeglogene Autotemcel (Zynteglo®) Pre-Infusion Supplemental Data | Add | Version 1 of the Betibeglogene Autotemcel (Zynteglo®) Pre-Infusion Supplemental Data section of the Forms Instruction Manual released. Version 1 corresponds to revision 1 of the Form 2544. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)