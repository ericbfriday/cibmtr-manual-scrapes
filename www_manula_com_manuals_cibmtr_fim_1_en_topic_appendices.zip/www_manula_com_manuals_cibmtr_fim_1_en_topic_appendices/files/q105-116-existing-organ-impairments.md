#### Question 105: Specify co-existing diseases or organ impairments developed

Indicate if the recipient developed any of the co-existing disease or organ impairments listed below during the current reporting period. Select all that apply.

**Amenorrhea**: Absence of menstruation**Cardiomyopathy**: A disease of the heart muscle that makes it more difficult for the heart to pump blood to the rest of the body**Cholelithiasis**: Presence of one or more gallstones in the gallbladder**Growth hormone deficiency / short stature**: A condition in which the body does not produce enough growth hormone / a reduced overall rate of growth.**Hypersplenism**: Overactive spleen. Diagnosis is typically based on a physician’s exam (checking for splenomegaly), a CBC to assess the concentration of red and white blood cells, and / or an ultrasound, measuring the size of the spleen.**Hypogonadism / gonadal dysfunction**: A condition where there is a hyperfunction of the gonads. It can manifest as precocious puberty, and is caused by abnormally high levels of testosterone or estrogen, crucial hormones for sexual development.**Hypothyroidism requiring replacement therapy**: Decreased activity of the thyroid gland. Diagnosis of hypothyroidism includes high levels of thyroid-stimulating hormone (TSH). Symptoms of hypothyroidism include fatigue, depression, weakness, weight gain, musculoskeletal pain, decreased taste, hoarseness, and / or puffy face.**Osteonecrosis**: Flow to part of a bone is disrupted. This results in death of bone tissue, and the bone can eventually break down and the joint will collapse.**Osteopathies (porosis, penia)**: Includes osteoporosis or osteopenia. Osteopathies should be reported if osteopenia or osteoporosis is documented within the medical record by the physician or based on the Z or T-score. Osteopenia is defined as a Z or T-score between -1.0 and -2.0 by a DEXA or quantitative CT scan. Osteoporosis is defined as a Z or T-score less than -2.0 by a DEXA or quantitative CT scan.**Retinal changes**: Changes include but are not limited to macular degeneration, floaters, diabetic eye disease, retinal detachment, and retinitis pigmentosa.**Thrombosis**: Blood clot within the vein or artery.

The co-existing disease or organ impairment should be reported in any of the following scenarios:


- The co-existing disease or organ impairment was first diagnosed in the current reporting period.
- The co-existing disease or organ impairment was diagnosed prior to infusion or in a prior reporting period and persisted into the current reporting period.
- The co-existing disease or organ impairment was diagnosed prior to infusion or in a prior reporting period, resolved, and then recurred in the current reporting period.

Report **None** in any of the following scenarios:


- No co-existing disease or organ impairments developed during the current reporting period.
- A co-existing disease or organ impairment developed prior to start of the preparative regimen / infusion or in a prior reporting period but resolved before the current reporting period.

#### Question 106: Was this organ impairment previously reported?

Specify if the co-existing disease or organ impairment diagnosis date was previously reported. If **Yes**, continue with the next question.

If the co-existing disease or organ impairment was diagnosed prior to infusion or in a prior reporting period, resolved, and then recurred in the current reporting period, report No.

#### Question 107: Date of diagnosis

Report the diagnosis date of the co-existing disease or organ impairment.

If the co-existing disease or organ impairment was diagnosed prior to infusion or in a prior reporting period, resolved, and then recurred in the current reporting period, report the diagnosis date as the date of the most recent episode.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Question 108: Method used to assess osteopathies *(report the most recent Z or T-score available. Z-scores are used in patients younger than or equal to 20 and T-scores in patients older than 20) (check all that apply)*

Specify the method used to assess osteopathies during the current reporting period. Select all that apply.

If the osteopathy was not assessed during the current reporting period or is not known if assessed, select **Unknown** and continue with Disease Modifying Therapies.

#### Questions 109 – 110: DEXA scan vertebral

Indicate if the vertebral Z-score by DEXA is known. If **Known**, report the Z or T-score. Select Negative value if the Z or T-score is a negative (i.e., Z-score is -1.0).

If multiple DEXA scans were performed during the current reporting period, report the most recent vertebral Z or T-score.

#### Questions 111 – 112: DEXA scan hip

Indicate if the hip Z-score by DEXA is known. If **Known**, report the Z or T-score. Select Negative value if the Z or T-score is a negative (i.e., Z-score is -1.0).

If multiple DEXA scans were performed during the current reporting period, report the most recent hip Z or T-score

#### Questions 113 – 114: Quantitative CT vertebral

Indicate if the vertebral Z-score by quantitative CT is known. If **Known**, report the Z or T-score. Select Negative value if the Z or T-score is a negative (i.e., Z-score is -1.0).

If multiple quantitative CT scans were performed during the current reporting period, report the most recent vertebral Z or T-score.

#### Questions 115 – 116: Quantitative CT hip

Indicate if the hip Z-score by quantitative CT is known. If **Known**, report the Z or T-score. Select Negative value if the Z or T-score is a negative (i.e., Z-score is -1.0).

If multiple quantitative CT scans were performed during the current reporting period, report the most recent hip Z or T-score.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)