# Q157-193: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion

#### Question 157: Date CBC with differential tested

Report the date the sample was collected for testing and continue with question 158. If multiple studies were performed, report the last assessment prior to the start of the preparative regimen or infusion.

#### Questions 158-159: Neutrophils

Indicate whether the neutrophil percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the value documented on the laboratory report in question 159. If “unknown,” continue with question 160.

#### Questions 160-161: Bands

Indicate whether the band percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 161. If “unknown,” continue with question 162.

#### Questions 162-163: Metamyelocytes

Indicate whether the percentage of metamyelocytes in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 163. If “unknown,” continue with question 164.

#### Questions 164-165: Myelocytes

Indicate whether the myelocyte percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 165. If “unknown,” continue with question 166.

#### Questions 166-167: Monocytes

Indicate whether the monocyte percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 167. If “unknown,” continue with question 168.

#### Questions 168-169: Basophil

Indicate whether the basophils percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 169. If “unknown,” continue with question 170.

#### Questions 170-171: Eosinophil

Indicate whether the eosinophil percentage in the blood was “known” or “unknown” at the last evaluation. If “known,” report the percentage documented on the laboratory report in question 171. If “unknown,” continue with question 172.

#### Questions 172-173: Was a bone marrow examination performed?

Indicate if a bone marrow examination was performed at the last evaluation. If “yes,” indicate the date the sample was collected in question 173. If “no” or “unknown,” continue with question 177.

#### Question 174: Cellularity

Cellularity describes the percentage of bone marrow occupied by hematopoietic cells compared to other tissues, such as adipose (fat) cells. In MDS, the percentage of hematopoietic cells is likely increased (hypercellular) due to proliferation of immature cells. In other cases, the cellularity may be normal (normocellular) or decreased (hypocellular). This distinction is made on the pathology report of a bone marrow examination.

Indicate whether the bone marrow examination revealed “decreased (hypocellular),” “normal (normocellular),” or “increased (hypercellular)” cellularity at the last evaluation. If the degree of cellularity is not addressed in the report, select “unknown.”

#### Question 175: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented on the pathology report, select “known,” continue with question 176. If the pathology report is not available and the grade is documented in a physician note, then this would be sufficient.

If the myelofibrosis grade is not documented in the pathology report, select “unknown,” continue with question 177.

#### Question 176: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with local bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 177: Were molecular tests for molecular markers performed (e.g., PCR)

Molecular assessment involves testing blood or bone marrow for the presence of known molecular markers associated with the recipient’s disease. Molecular assessments are the most sensitive test for genetic abnormalities and involve amplifying regions of cellular DNA by polymerase chain reaction (PCR), typically using RNA to generate complementary DNA through reverse transcription (RT-PCR). The amplified DNA fragments are compared to a control, providing a method of quantifying log increase of genetic mutation transcripts. Each log increase is a 10-fold increase of gene transcript compared to control. Molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

Indicate if molecular studies were obtained at the last evaluation.

If molecular studies were performed, select “yes” and continue with question 178.

If no molecular studies were obtained or it is unknown if molecular studies were performed, indicate “no” or “unknown” and continue with question 185.

#### Question 178: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker was identified at the last evaluation.

If a positive molecular marker was identified, select “yes” and continue with question 179.

If there were no molecular markers identified, select “no” and continue with question 184.

#### Question 179: Date sample collected

Report the date the sample was collected for molecular testing. If multiple studies were performed prior to the start of the preparative regimen, report the last assessment prior to the start of the preparative regimen.

#### Questions 180-181: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 182. If a positive marker is detected, but not listed as an option, select “Other molecular marker” and specify the positive molecular marker in question 181.

#### Questions 182-183: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

Figure 1. Molecular disease assessment with amino acid changes documented (highlighted in yellow).

For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 182 indicate if the amino acid change is “known” or “unknown” for the positive molecular marker reported in questions 180-181. If known, report the amino acid change in question 183. If unknown, continue with question 184.

Copy questions 180-183 to report more than one positive molecular marker.

#### Question 184: Was documentation submitted to the CIBMTR?

Indicate if the molecular report(s) is attached to support the molecular findings reported in questions 180-183. For further instructions on how to attach documents in FormsNet3SM, refer to the Training Guide.

#### Question 185: Was flow cytometry performed?

Flow Cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

Indicate if flow cytometry was performed on peripheral blood and / or bone marrow sample immediately prior to the start of the preparative regimen.

If flow cytometry was performed, select “yes” and continue with question 186.

If flow cytometry was not performed or it is unknown if flow cytometry was performed, indicate “no” or “unknown” and continue with question 194.

#### Questions 186-187: Blood:

Indicate if flow cytometry peripheral blood immediately prior to the start of the preparative regimen. If there were multiple flow assessments completed prior to the start of the preparative regimen, report most recent assessment.

If flow cytometry was performed on a peripheral blood sample, select “yes” and report the date the sample was collected in question 187.

If flow cytometry was not performed on peripheral blood, indicate “no” and continue with question 190.

#### Question 188: Was disease detected?

Indicate if evidence of disease was detected in the peripheral blood sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the patient’s disease.

If flow cytometry results were consistent with disease, select “yes” and continue with question 189.

If flow cytometry results were not consistent with continued evidence of disease, select “no” and continue with question 190.

#### Question 189: Specify percent disease:

Specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report and continue with question 190.

#### Questions 190-191: Bone marrow:

Indicate if flow cytometry was performed on bone marrow immediately prior to the start of the preparative regimen. If there were multiple flow assessments completed prior to the start of the preparative regimen, report most recent assessment.

If flow cytometry was performed on a bone marrow sample, select “yes” and report the date the sample was collected in question 191.

If flow cytometry was not performed, indicate “no” and continue with question 194.

#### Question 192: Was disease detected?

Indicate if evidence of disease was detected in the bone marrow sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the patient’s disease.

If flow cytometry results were consistent with evidence of disease, select “yes” and continue with question 193.

If flow cytometry results were not consistent with continued evidence of disease, select “no” and continue with question 194.

#### Question 193: Specify percent disease:

Specify the percentage of disease detected (to the nearest thousandth) in the bone marrow as documented in the pathology report and continue with question 194.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)