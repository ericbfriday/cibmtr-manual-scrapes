#### Questions 13-14: Specify the disease / study for which non-cellular therapy was given

Indicate the disease or study for why the non-cellular therapy was given.

If the recipient is participating in the BMT CTN 17-02 study, select **BMT CTN**.

If the recipient is receiving the non-cellular therapy as treatment for disease, specify the disease.

If the recipient is enrolled in a study or receiving therapy for a disease that is not on the form, specify the disease or study.

#### Question 15: Enrollment date (date of consent)

Report the date of consent for enrollment on the non-cellular therapy protocol.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Jul 29, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)