Review this section for various GVHD reporting examples.

Example 1: Diagnosis of Acute GVHD with a Flare Over Multiple Reporting Periods


- A recipient receives a HCT on 1/1/2015 and develops acute GVHD which is clinically diagnosed on 2/1/2015. At least one of their symptoms, attributed to acute GVHD, persists beyond the 100-day date of contact which is 4/5/2015. Treatment continues and symptoms completely resolve on 5/1/2015. Immunosuppression is tapered until a flare of acute GVHD is diagnosed on 5/25/2015. Immunosuppression is given and symptoms quickly resolve with no active acute GVHD beginning 6/10/2015. The six-month date of contact is 6/20/2015. Another flare of acute GVHD is clinically diagnosed on 8/15/2015.
- Day 100: Report
**Yes**, acute GVHD developed in the reporting period and the diagnosis date as 2/1/2015.- The ‘persistence’ of acute GVHD question will be disabled.
- Report the overall grade and organ staging at diagnosis based on the assessments performed at the time of diagnosis (2/1/2015).

- Six Month: Report
**No**, acute GVHD did not develop in the reporting period as the notes indicate the flare of acute GVHD was < 30 days from symptom resolution. This does not count as a new reportable episode.- Report
**Yes**, acute GVHD persisted into the current reporting period. - The overall grade and organ staging at diagnosis data fields will be disabled.

- Report
- One Year: Report
**Yes**, acute GVHD developed in the reporting period since the flare of acute GVHD occurred > 30 days after resolving in a prior reporting period and the diagnosis date as the date of the flare (8/15/2015).- The ‘persistence’ of acute GVHD question will be disabled.
- Report the overall grade and organ staging at diagnosis based on the assessments performed at the time of diagnosis of the acute GVHD flare (8/15/2015).


- Day 100: Report

Example 2: Reporting the Overall Grade with Multiple Organs Involved and Transaminitis


- A recipient developed stage 2 skin involvement and elevated liver function tests (LFTs) attributed to acute GVHD; however, there was no total bilirubin manifestation.
- Report the overall maximum grade I acute GVHD since the staging / grading can be determined using the GVHD Grading and Staging table above.


Example 3: Isolated Transaminitis


- A recipient developed acute liver GVHD with elevated LFTs (i.e., transaminases) with no total bilirubin manifestation. The progress notes indicate stage 1 (grade II overall) acute GVHD of the liver.
- Acute GVHD should not be reported as there was only transaminitis.


Example 4: Reporting the Overall Grade with Multiple Organs Involved


- A recipient developed stage 2 skin involvement, which showed improvement in response to topical steroids. However, the recipient then developed hyperbilirubinemia attributed to stage 1 liver involvement; the skin involvement at that time was stage 1.
- Report grade II as the overall grade (assuming this was the extent of the recipient’s acute GVHD in the reporting period).


Example 5: Acute GVHD Followed by Chronic GVHD


- A recipient developed stage 2 skin involvement which resolved in response to topical steroids. Later in the reporting period, the recipient was diagnosed with mild chronic eye GVHD. Shortly thereafter, they were diagnosed with a stage 3 flare of acute skin GVHD.
- Report the overall acute GVHD grade as grade I. Do not consider any new or persistent acute GVHD symptoms occurring after the onset of chronic GVHD when completing the acute GVHD section of the form.


Example 6: Reporting the Maximum Organ Staging and Overall Grade


- A recipient developed stage 1 skin involvement and stage 1 liver involvement (overall grade II) on 1/1/2019 which resolved in response to topical steroids and tacrolimus. Later in the reporting period, on 2/14/2019, they have a flare of the skin GVHD, this time at stage 3, along with GI stage 1 (overall grade II).
- Report grade II would be reported as the
*maximum overall grade of acute GVHD*with the maximum date reported as 1/1/2019 the*first date of maximum overall grade of acute GVHD*. Additionally, the organ staging should be reported as skin stage 3, liver stage 1, and GI stage 1. The maximum organ staging during the reporting period is captured, not the maximum organ staging at the time of the maximum overall grade.

- Report grade II would be reported as the

Example 7: Diagnosis and Resolution of Acute and Chronic GVHD with Acute GVHD Flare


- A recipient receives a HCT on 1/1/2015 and develops acute skin GVHD on 2/1/2015 and then chronic eye GVHD on 3/1/2015. Both acute and chronic symptoms resolved by the 100-day date of contact (4/5/2015). While tapering their immunosuppression, the recipient has a flare of their acute skin GVHD on 5/30/2015. Treatment continues and symptoms completely resolve by the six-month date of contact (6/20/2015).
- Day 100 Reporting Period
- Report
**Yes**, acute GVHD developed in the reporting period and the diagnosis date as 2/1/2015.- The ‘persistence’ of acute GVHD question will be disabled.
- Report the overall grade and organ staging at diagnosis based on the assessments performed at the time of diagnosis (2/1/2015).
- Report the maximum overall grade and organ staging based on any symptoms and treatment documented from the onset of acute GVHD (2/1/2015) until the diagnosis of chronic GVHD (3/1/2015).

- Report
**No**, chronic GVHD did not develop in the reporting period.

- Report
- Six Month Reporting Period
- Report
**No**, acute GVHD did not develop in the reporting period. - Report
**No**, acute GVHD persisted into the current reporting period.- The overall grade and organ staging at diagnosis data fields will be disabled.

- Report
**Yes**, chronic GVHD developed in the reporting period and the diagnosis date as 5/30/2015.

- Report

- Day 100 Reporting Period

Example 8: Chronic GVHD Organ Scoring


- A recipient developed a maculopapular rash covering 25% BSA as well as deep sclerotic features. Both features are attributed to chronic GVHD.
- Report
**Yes**for skin involvement and specify the score as 3 based on the findings of deep sclerotic features.

- Report

Example 9: Scoring Chronic GVHD Involvement with Acute GVHD Symptoms


- A recipient developed a maculopapular rash covering 25% as well as dry eyes. Both findings were identified and diagnosed at the same time. The skin rash was attributed to acute GVHD while the dry eyes were entirely attributed to chronic GVHD.
- Report
**Yes**for skin involvement and score 2 and**Yes**for eye involvement with a score of 1.- Any acute findings identified on or after the date of chronic GVHD diagnosis must be reported in the chronic GVHD section. The skin rash is not reported in the acute GVHD section unless it was identified and diagnosed prior to the diagnosis of chronic GVHD.


- Report

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)