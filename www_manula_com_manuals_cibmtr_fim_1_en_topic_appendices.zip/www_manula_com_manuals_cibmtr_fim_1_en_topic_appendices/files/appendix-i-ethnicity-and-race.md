## Ethnicity

Ethnicity is the heritage or nationality of a group, but it is not connected to a specific race. For the purposes of the NMDP Consent for Participation Form and general NMDP work, ethnicity is viewed as an environmental influence on a person, versus a genetic trait. People who identify themselves as Spanish, Hispanic or Latino may be of any race.

**Hispanic or Latino**

Hispanic or Latino refers to people whose ancestors or descendants originated in Central and South America and in the Caribbean, who follow the customs and cultures of these areas and who may speak Spanish.

The phrase Hispanic or Latino excludes people born in Europe whose language is Spanish or Portuguese, and non-Spanish speaking people born in Brazil, Belize, French Guyana, Guyana, Surinam and other non-Spanish speaking territories.

- Chicano – Includes people born in the United States with Mexican ancestry.
- Latino – This term can be used by individuals who live throughout the United States. Many Latinos have come from Puerto Rico, Dominican Republic, Cuba and/or South America.
- Mexican – Includes all citizens of Mexico regardless of race.
- Puerto Rican – Includes all persons of Puerto Rican descent.

**Not Hispanic or Latino**

A member of any ethnicity, other than Hispanic.

## Race

Race is the descendants of a common ancestor, or a group of people with distinct physical and genetic traits or characteristics that are passed on through birth.

**American Indian or Alaska Native**

Includes persons having origins in any of the original peoples of North, South or Central America.

- Alaska Native – Includes persons who originated from Alaska.
- Aleut – Includes persons who ancestors were Aleut, Alutiiq, Egegik or Pribilovian.
- North American Indian – Includes persons who indicate their race as American Indian, Canadian Indian, French-American Indian or Spanish-American Indian.
- Eskimo – Includes persons who indicate their origin as Eskimo, Arctic Slope, Inupiat and Yupik.
- South or Central American Indian – Includes persons who have origins from any of the original people of South or Central America such as Mayans or Incas.

**Asian**

Includes persons with ancestors in any of the original peoples of the Far East, the Indian subcontinent including Cambodia, China, India, Japan, Korea, Malaysia, Pakistan, Philippine Islands, Thailand, Vietnam, Hmong, East India, Laos, Bangladesh, Indonesia, Sri Lanka, Nepal, Bhutan, Sikh, Burma and other South and Southeast Asian.

- Chinese – Includes persons who indicated their race as Chinese, or who identified themselves as Cantonese, Tibetan, or Chinese American. In standard census reports, persons who reported as Taiwanese or Formosan are included here with Chinese.
- Filipino – Includes persons who indicated their race as Filipino, Pilipino, or Philipine.
- Japanese – Includes persons who indicated their race as Japanese, Nipponese or Japanese American.
- Korean – Includes persons who indicated their race as Korean or Korean American.
- Vietnamese – Includes persons who indicated their race as Vietnamese or Vietnamese American.
- Other Southeast Asian – Includes persons from one of the Southeast Asian countries or groups including Laos, Hmong, Laohmong, Mong, Cambodia, Thailand, Siamese, Malaysia.
- South Asian – Includes persons from one of the South Asian countries including Afghanistan, India, Pakistan, Bangladesh, Nepal and Sri Lanka.
- Other Asian – Includes persons from or considering themselves to be Burmese, Indonesian, Bengali, Bharat, Dravidian, East India, Goanese or Asian Indian.

**Black or African American**

Includes persons having origins in any of the Black racial groups of Africa, including Black Americans, Africans, Haitians, and residents of Caribbean Islands of African descent.

- African – Includes people from countries such as Ghana, Nigeria, Niger, Liberia, etc.
- African American – All persons having origins in any of the Black racial groups of Africa and born or living in the United States.
- Caribbean – Includes persons who indicated their race from the area of the Caribbean.
- Black South or Central American – Includes people indicating Black with their origins from South or Central America. Includes countries such as Honduras, Cuba, Guatemala, Nicaragua, Panama, Costa Rica, Chile, Peru, Brazil, Colombia, Venezuela, and Bolivia.

**Native Hawaiian and Other Pacific Islander**

Native Hawaiian refers to persons having origins in any of the original peoples of the Hawaiian Islands, Guam or Samoa. Pacific Islander refers to persons having origins in any of the peoples of the Pacific Islands.

This category also includes the following groups: Carolinian, Fijian, Guamanian,

Kosraean, Marshallese, Melanesian, Micronesian, New Guinean, Northern Mariana Islander, Palauan, Papua, Polynesian, Ponapean (Pohnpelan), Samoan, Solomon Islander, Tahitian, Tarawa Islander, Tokelauan, Tongan, Trukese (Chuukese) and Other Pacific Islanders.

This category does not include individuals who consider themselves “native” to the state of Hawaii simply by virtue of being born there.

- Hawaiian – Includes persons who identify their origins from the Hawaiian Islands chain in the Pacific Ocean.
- Guamanian – Includes persons who identify their origins as being from Guam.
- Samoan – Includes persons who identify their origins as being from Samoa.
- Other Pacific Islander – Includes persons who identify their origins as being from any other island in the Pacific Ocean.

**White**

Includes persons who indicate their race as White such as Canadian, German, Italian, Lebanese, Near Easterner, Arabian, Eastern European, etc.

- North American – Includes persons whose ancestors came from the continent of Europe, the Middle East or North Africa.
- White South or Central American – Includes persons who ancestors came from Europe to South Central American countries such as Argentina, Brazil and Mexico.
- White Caribbean – Includes persons who ancestors came from Europe to Puerto Rico, Cuba or consider themselves Chicano.
- Mediterranean – Includes persons who identify their origins from countries such as Italy, Greece, Turkey and Bulgaria.
- Northern European – Includes persons who are Belgian, Danish, German Austrian, Swiss, Scandinavian or British.
- Eastern European – Includes persons who identify their origins from countries such as the Czech Republic, Slovakia, Poland, Croatia, Hungary, Slovenia, former Soviet Union or Finland. Also includes persons who call themselves Gypsies from this region.
- Western European – Includes persons who identify their origins from countries such as Spain, Portugal and France.
- Middle East or Near East – A region of southwest Asia, between the India subcontinent and Europe, includes Kuwait, Turkey, Lebanon, Israel, Iraq, Iran, Jordan, Saudi Arabia, lands west of Pakistan and the other countries of the Arabian Peninsula. Also includes people of Jewish ethnicity including Sephardic and Ashkenazic.
- North Coast of Africa– Includes the northern countries of Africa such as Egypt, Sudan, Libya, Algeria, Morocco and Tunisia.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)