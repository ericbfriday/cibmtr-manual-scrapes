#### Question 11: Was a CBC differential performed?

A CBC with differential is also known as a blood differential test, white blood differential count, or leukocyte differential count. It may be performed as part of a CBC test or as a follow-up to a CBC that reveals an abnormally high white blood cell count.

While a CBC measures the total number of red blood cells (erythrocytes), white blood cells (leukocytes), platelets, hemoglobin, and hematocrit, a CBC with differential goes one step further to identify and count the number of each type of white blood cell in the blood.

Indicate if a CBC differential test was performed at the time of or near the CBC date reported in the Complete Blood Count (CBC) section.

If a CBC with differential was not performed or unknown if performed, select **No**.

#### Questions 12 – 28: CBC with differential results

For each value below, specify the result as a percentage, unless otherwise specified. When necessary, convert the lab value to the unit available listed on the form.

If the value is not known, leave the value blank and override the FormsNet3SM error.

**Neutrophils:**Also known as polymorphonuclear leukocytes (PMNs). A subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage or an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage.**Segs:**Segmented neutrophils are also referred to as segs, polymorphonuclear leukocytes, polys, and PMNs. Segmented neutrophils are the most mature neutrophilic granulocytes present in circulating blood.**Bands:**A band cell, also called band neutrophil, is a type of white blood cell. The test may be used to confirm bacterial infection and sepsis.**Absolute neutrophil count (ANC):**The absolute neutrophil count (ANC) is the total number of neutrophils in the white blood cell (WBC) count. Indicate the unit of measurement as listed on the lab report.**Lymphocytes:**Another subtype of white blood cell that fights infection. The two main lymphocytes are B lymphocytes and T lymphocytes.**Absolute lymphocyte count:**The absolute lymphocyte count (ALC) is the total number of lymphocytes. Indicate the unit of measurement as listed on the lab report.**Monocytes:**The largest type of white blood cell.**Basophils:**A type of white blood cell that plays a part in the immune system. This cell is one of the three kinds of granulocytes.**Eosinophils:**A type of white blood cell, that is one of the three kinds of granulocytes. Eosinophils are a part of the immune system.**Blasts in the blood:**Immature blood cells.**Myelocytes:**Precursors to neutrophils and are typically only found in the bone marrow; however, maybe found in the blood in certain situations.**Metamyelocytes:**A type of immature white blood cell that is in a stage of neutrophil development.**Prolymphocytes:**A type of white blood cell that is in an intermediate stage of development, between a lymphoblast and a lymphocyte.**Plasma cells in blood by morphologic assessment:**The presence of circulating plasma cells (CPCs) is an important laboratory indicator for the diagnosis, staging, risk stratification, and progression monitoring of abnormal cells.**Absolute plasma cell count:**The absolute plasma cell count measures the total number of plasma cells. Indicate the unit of measurement as listed on the lab report.**Reticulocyte:**Newly produced, relatively immature red blood cells. Reticulocyte counts help to determine the number and / or percentage of reticulocytes in the blood and reflect recent bone marrow function or activity.**Absolute reticulocyte count:**The absolute reticulocyte count (ARC) measures the total number of reticulocytes. Indicate the unit of measurement as listed on the lab report.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)