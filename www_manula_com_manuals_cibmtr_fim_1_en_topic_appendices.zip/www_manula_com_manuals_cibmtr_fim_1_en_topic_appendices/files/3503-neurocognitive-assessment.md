The Neurocognitive Assessment (3503) Form must be completed when neurocognitive testing is reported on Leukodystrophies Pre-Infusion (2037) form or Leukodystrophies Post-Infusion (2137) form. An assessment is captured “at infusion” and during each follow up period.

Neurocognitive testing is a way to measure brain function non-invasively. Neurocognitive assessment is a performance-based method to assess the many aspects of cognitive functioning. Included in this assessment are measurements of reaction time, processing speed, and memory.

Links to Sections of Form:

Q1 – 69: Clinical Status Prior to Mobilization

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, you can reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 9/27/2024 | Neurocognitive Assessment | Add | Version 1 of the Neurocognitive Assessment section of the Forms Instruction Manual released. Version 1 corresponds to revision 1 of the Form 3503. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)