This section provides explanatory text for each question on the Pre-CTED, Pre-CTED Baseline, Cellular Therapy Product, Cellular Therapy Infusion, Post-CTED, and Post-CTED Follow-up forms.

[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000)

[4001: Pre-Cellular Therapy Baseline Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4001-pre-cellular-therapy-baseline-data)

[4003: Cellular Therapy Product](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4003)

[4006: Cellular Therapy Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4006)

[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100)

[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4101-post-cellular-therapy-follow-up)

**Cell therapy reporting tracks and follow up schedule**

Beginning Summer 2022 and updated in Summer 2023, a reporting track is set for all cell therapy infusions reported to the CIBMTR. The track will be set by the center reporting preference and infusion details and will determine which forms come due. There are five cellular therapy reporting tracks:

- 15 years (CRF)
- Forms: 4000, 4001, 4003, 4006, 4100, 4101, 2402 + disease forms (when applicable)


- Standard follow up TED
- Forms: 4000, 4003, 4006, 4100, 2402


- 100 day only (TED)
- Forms: 4000, 4003, 4006, single 4100 at 100d, 2402


- CTRM
- Forms: 4000, 4003, 4006


- No follow up
- Forms: 4000, 2402


See the [Data Management Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/cell-therapy-reporting-tracks) for a full description of each track and follow up schedule.

**Cell therapy reporting preferences:**

As part of the Summer 2022 release, every center will have a reporting preference. The options are:


- Do Not Perform
- Perform Do Not Report
- Research Level
- Regulatory Level

Please see the [Data Management Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/cell-therapy-reporting-preferences) for a full description of the different levels, including which forms will come due.

**Follow up tracks as set by reporting preference**

As part of the Summer 2022 release, the center reporting preference is now used in determining the cell therapy reporting track, and subsequently which forms are required.

| TED (Standard & 100 day only) | CRF (15 years) | CTRM |
|---|---|---|
| Commercial CAR-T on study, no consent, REMS/RGL center (Standard follow up TED) | Commercial CAR-T on study (15 years) |
_Indication = Cardiovascular disease, Musculoskeletal disorder, Neurologic disease, Ocular disease, Pulmonary disease |
| Commercial CAR-T not on study (Standard follow up TED) | BMT CTN (15 years) | Non-commercial genetically modified non-CAR-T products |
| Non-commercial CAR-T products (Standard follow up TED) | Genetically modified products (other than CAR-T) either stand alone or post-HCT (15 years) | |
| Stand-alone non-genetically modified cell therapy infusions without a history of HCT (Standard follow up TED) | Commercial CAR-T not on study (Standard follow up CRF) | |
| Post-HCT non-genetically modified cell therapy infusions (100 day only) | Registry Partners |

Commercial CAR-T = Kymriah®, Yescarta®, TecartusTM, Abecma®, BreyanziTM, CarvyktiTM

**When to report cellular therapy infusions to the CIBMTR**

Please see the [Data Management Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/cibmtr-guidance-document-for-reporting-autologous-cellular-therapies) for a full description the guidance when determining whether to report a cellular therapy to the CIBMTR.

**Donor cellular infusion (DCI)**

Donor cellular infusions (DCIs) are a subtype of cellular therapy.

An infusion can be classified as a “DCI” when:


- The intent is something other than to restore hematopoiesis
- The infusion must be post-HCT, often by the same donor as the HCT
- Indication is suboptimal donor chimerism, immune reconstitution, GVHD treatment, prevent or treat disease relapse (as reported on F4000)
- Composition of cells include mesenchymal cells, peripheral blood mononuclear cells, NK cells, etc.

Donor Lymphocyte Infusions (DLIs) are a subset of DCIs. DLIs meet the same criteria above but are infusions of just a lymphocyte product. DLIs are reported on the Donor Lymphocyte Infusion (2199) form. See the [F2199 manual](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2199-donor-lymphocyte-infusion) for the definition of DLI.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/3/2024 |
|

[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000)[4001: Pre-Cellular Therapy Baseline Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4001-pre-cellular-therapy-baseline-data)[4100: Cellular Therapy Essential Data Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4100)[4101: Post-Cellular Therapy Follow-Up](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4101-post-cellular-therapy-follow-up)[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000q253-311)[4000: Cellular Therapy Essential Data Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/4000)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)