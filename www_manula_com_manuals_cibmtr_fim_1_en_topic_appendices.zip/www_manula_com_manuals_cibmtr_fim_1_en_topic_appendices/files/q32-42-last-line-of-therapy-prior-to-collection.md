#### Question 32: Did the recipient receive any IV chemotherapy? (prior to collection)

Indicate **Yes** or **No** whether the recipient received any IV chemotherapy as the last line of therapy prior to cell product collection. See *Specify therapy* below for examples.

#### Question 33: Date therapy started:

Report the date the IV chemotherapy started.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 34: Date therapy stopped:

If the IV chemotherapy is being given in cycles, report the date the recipient **started the last cycle**. Otherwise, report the final administration date for the therapy being reported.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 35-36: Specify therapy (check all that apply)

Select all chemotherapy drugs administered as part of the last line of therapy prior to collection. If drug is not listed, select **Other therapy** and specify the therapy. Report the generic name of the agent, not the name brand.

#### Question 37: Did the recipient receive any targeted agents? (prior to collection)

Targeted therapy works by stopping or slowing the growth or spread of cancer. Targeted therapies are designed to interfere with, or *target*, these molecules or the cancer-causing genes that create them. Indicate if a targeted agent was received.

Indicate **Yes** or **No** whether the recipient received any targeted agents as the last line of therapy prior to cell product collection.

#### Question 38: Date therapy started

Report the date the targeted therapy started.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 39-40: Is therapy ongoing?

Indicate if the targeted therapy is ongoing continued after cell product collection. If **No**, report the date the targeted therapy stopped.

#### Questions 41-42 Specify targeted therapy

Select all targeted therapy agents administered as part of the last line of therapy prior to collection. If the therapy is not listed in the, select **Other targeted therapy** and specify the targeted therapy. Report the generic name of the agent, not the name brand.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)