#### Question 253: Specify the recipient’s current hematologic status

Indicate the recipient’s current hematologic status at the time of evaluation for this reporting period. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

The percentage of plasma cells in the bone marrow aspirate may also be identified on a flow cytometry report. A flow cytometry report may be used to confirm CR (e.g., < 5% plasma cells in the bone marrow) as long as the method was high sensitivity or next generation flow.

If the disease response prior to transplant is unknown, select **Unknown** and continue with question 256.

#### Questions 254 – 255: Date current hematologic status assessed

Indicate if the assessment date that reflects the recipient’s current hematologic status was **Known** or **Unknown**. If **Known**, enter the date of the most recent disease evaluation. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathological evaluation. A PET scan may be used if a PET scan was previously obtained and only in limited circumstances (e.g., plasmacytomas, lytic lesions). If **Unknown**, continue with question 256.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 256: Specify the recipient’s current cardiac response

Indicate the recipient’s current cardiac status at the time of evaluation for this reporting period. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

If the recipient’s cardiac status was not assessed during the reporting period, select **Not assessed** and continue with question 290. If the recipient never had evidence of cardiac involvement in their disease, select **Not applicable** and continue with question 290.

#### Questions 257 – 258: Date current cardiac response assessed

Indicate if the date of current cardiac assessment is **Known** or **Unknown**. If the date of assessment for cardiac status is **Known**, report the date. If the date is **Unknown**, continue with question 259.

#### Questions 259 – 261: Was the left ventricular ejection fraction measured?

The left ventricular ejection fraction (LVEF) is a percentage that represents the volume of blood pumped from the left ventricle into the aorta (also known as stroke volume) compared to the volume of blood in the ventricle just prior to the heart contraction (also known as end diastolic volume). Indicate **Yes** or **No** if the left ventricular ejection fraction (LVEF) was measured.

If **Yes**, report the left ventricular ejection fraction at the time of evaluation for this reporting period and specify the method of testing. Most imaging reports will report the LVEF. If the LVEF is not explicitly documented it should be determined by dividing the stroke volume (SV, the volume of blood pumped into the aorta from the left ventricle) by the end diastolic volume (EDV, the volume of blood in the left ventricle just prior to contraction) of the left ventricle. For example, if the stroke volume was 75 ml and the end diastolic volume was 150ml, the ejection fraction would be 50%. continue with question 260.

If **No**, continue with question 262.

#### Question 262: Was diastolic dysfunction present?

Diastole is the period in which chambers of the heart fill with blood. Diastolic dysfunction may be characterized by the difficulty of the ventricles to expand and contract appropriately due to stiffening of the heart walls by amyloid deposits. Indicate if diastolic dysfunction was present. Specify **Yes**, **No**, or **Unknown**.

#### Questions 263 – 264: Specify the intraventricular septal wall thickness measured by echocardiogram

The heart is divided into the right and left sides by the septum. The area between the left and right ventricles is the intraventricular septum. Indicate if the intraventricular septal thickness is **Known** or **Unknown**. If **Known**, based on evaluation by echocardiogram, indicate the thickness of the intraventricular septal wall. If **Unknown**, or not measured by echocardiogram, continue with question 265.

#### Questions 265 – 266: Specify left ventricular (LV) strain percentage

A strain pattern, as determined by electrocardiography, is a well-recognized marker of hypertrophy of the left ventricular (LVH) and is characterized by ST depression and T wave inversion on a resting ECG / EKG. The LV strain percentage is typically a negative percentage. The normal range for the LV global longitudinal strain (LV GLS) is -15.9% to -22.1%. Indicate if the left ventricular strain percentage is **Known** or **Unknow**. If **Known**, based on evaluation by electrocardiogram, indicate the strain percentage. If **Unknown**, or not measured by electrocardiogram, continue with question 267.

#### Questions 267 – 268: Were any serum cardiac biomarkers assessed?

Assessment of cardiac biomarkers helps determine if injury to cardiac tissue has occurred. Cardiac biomarkers include brain natriuretic peptide (BNP), N-terminal prohormone brain natriuretic peptide (NT-proBNP), troponin I, troponin T, and high-sensitivity troponin T. Indicate if serum cardiac biomarkers were assessed at the last evaluation. If **Yes**, report the date assessed. If **No** or **Unknown**, continue with question 284.

#### Questions 269 – 271: Brain natriuretic peptide (BNP)

Indicate if the BNP was assessed at the last evaluation. If **Yes**, report the value (in pg/mL) and specify the upper limit of normal. If **No**, continue with question 272.

#### Questions 272 – 274: N-terminal prohormone brain natriuretic peptide (NT-proBNP)

Indicate if the NT-proBNP was assessed at the late evaluation. If **Yes**, report the value (in pg/mL) and specify the upper limit of normal. If **No**, continue with question 275.

#### Questions 275 – 277: Troponin I

Indicate if the Troponin I was assessed at the last evaluation. If **Yes**, report the value (in µg/L) and specify the upper limit of normal. If **No**, continue with question 278.

#### Questions 278 – 280: Troponin T

Indicate if the Troponin T was assessed at the last evaluation. If **Yes**, report the value (in µg/L) and specify the upper limit of normal. If **No**, continue with question 281.

#### Questions 281 – 283: High-sensitivity troponin T

Indicate if the high-sensitivity troponin T was assessed at the last evaluation. If **Yes**, report the value (in ng/L) and specify the upper limit of normal. If **No**, continue with question 284.

#### Questions 284 – 285: Was a 6-minute walk test performed?

A 6-minute walk test is used to assess total distance walked within 6 minutes to determine aerobic capacity and endurance. Indicate if a 6-minute walk test was performed at the last evaluation. If **Yes**, report the total distance walked and specify the unit of measure. If **No**, continue with question 286.

#### Question 286: Specify the recipient’s New York Heart Association functional classification of heart failure: (Symptoms may include dyspnea, chest pain, fatigue, and palpitations; activity level should be assessed with consideration for patient’s age group)

Indicate the recipient’s [New York Heart Association functional classification](https://www.cibmtr.org/manuals/fim/1/en/topic/new-york-heart-association-function-classification) at the last evaluation using the following guidelines:


**Class I**– Able to perform ordinary activities without symptoms; no limitation of physical activity**Class II**– Ordinary physical activity produces symptoms; slight limitation of physical activity**Class III**– Less-than-ordinary physical activity produces symptoms; moderate limitation of physical activity**Class IV**– Symptoms present even at rest; severe limitation of physical activity

If the recipient’s NYHA functional classification it not known, select **Unknown**, and continue with question 287.

#### Questions 287 – 289: Recipient blood pressure

Indicate if the recipient’s blood pressure was assessed at the last evaluation. If **Known**, report the blood pressure at the last evaluation and indicate in which body position the measurement was taken, If **Unknown**, continue with question 290.

#### Question 290: Specify the recipient’s current renal response

Indicate the recipient’s best renal response to HCT to date. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

If the recipient’s renal status was not assessed during the reporting period, select **Not assessed** and continue with question 293.If the recipient never had evidence of renal involvement in their disease, select **Not applicable** and continue with question 293.

#### Questions 291 – 292: Date current renal response assessed

Indicate if the date the current renal response to transplant was assessed is **Known** or **Unknown**. If the date of current renal response is **Known**, report the date. If the date is **Unknown**, continue with question 293.

#### Question 293: Specify the recipient’s current hepatic response

Indicate the recipient’s best hepatic response to HCT to date. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

If the recipient’s hepatic status was not assessed during the reporting period, select **Not assessed** and continue with question 300. If the recipient never had evidence of hepatic involvement in their disease, select **Not applicable** and continue with question 300.

#### Questions 294 – 295: Date current hepatic response assessed

Indicate if the date the current hepatic response was assessed is **Known** or **Unknown**. If the date of current hepatic response is **Known**, report the date. If the date is **Unknown**, continue with question 296.

#### Question 296: Was hepatomegaly present on radiographic imaging (liver span > 15 cm) or on examination (liver edge palpable > 3 cm below right costal margin)?

At the last evaluation, indicate if the liver spanned more than 15 cm (by radiographic imaging) or the edge of the liver was palpable more than 3 cm below the right costal margin (by physical examination). Indicate **Yes** if hepatomegaly was present at the last evaluation. Indicate **No** if hepatomegaly was not present at the last evaluation. Indicate **Unknown** if it was not possible to determine the presence or absence of hepatomegaly at the last evaluation

#### Questions 297 – 299: Specify the level of serum alkaline phosphatase

Indicate whether the alkaline phosphatase (ALP) level at the time of evaluation for this reporting period is **Known** or **Unknown**. If **Known**, report the laboratory count, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 300.

#### Question 300: Was there clinical improvement in GI involvement since the date of last report?

Indicate if there was clinical improvement of GI involvement to date. Judgment is required by a clinician to determine if there is evidence of improvement. If **Yes** or **No**. If **Unknown** or **Not applicable**, continue with question 303. Report **Not applicable** if the recipient never had evidence of GI involvement in their disease.

#### Questions 301 – 302: Date GI involvement assessed

Indicate if the date the GI involvement was assessed is **Known**, **Unknown**, or **Previously reported**. If the date the GI response was assessed is **Known**, report the date. If the date is **Unknown**, continue with question 303. If the best response to transplant was already reported in a previous reporting period, select **Previously reported** and continue with question 303.

#### Question 303: Specify the recipient’s current peripheral nervous system response

Indicate the recipient’s best peripheral nervous system response to HCT to date. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

If the recipient’s peripheral neuropathy was not assessed during the reporting period, select **Not assessed** and continue with question 306. If the recipient never had evidence of disease-related peripheral neuropathy, select **Not applicable** and continue with question 306.

#### Questions 304 – 305: Date peripheral nervous system response assessed

Indicate if the date the current peripheral neuropathy response to transplant was assessed is **Known** or **Unknown**. If the date of current peripheral neuropathy response is **Known**, report the date. If the date is **Unknown**, continue with question 306.

#### Question 306: Did the recipient display any other clinical organ involvement?

Indicate if any other system was assessed for response to HCT. If the recipient had other site involvement reported in questions 116-118 of the Pre-HCT Plasma Cell Disorder form (Form 2016) and that site was assessed, the response to HCT must be reported here, even if there was no response. If any other system was assessed, report **Yes**. If no other systems were assessed at the time of best response, report **No** and continue with question 312.

#### Questions 307 – 308: Specify the evidence of other organ involvement (check all that apply)

For each option, indicate if there was evidence of other organ involvement at the last evaluation. Check all that apply. If there was other organ involvement not listed in this section, select **Other organ involvement** and specify the other organ.

Examples may include:


- Arthropathy is a disease of the joints. An example of a common arthropathy in patients with amyloidosis is carpal tunnel-like symptoms.
- Amyloid deposits may be found in the lung, impairing their function. Examples of lung involvement may be alveolar-septal disease, nodular disease, intra- and extra-thoracic adenopathy, pleural disease, and diaphragm deposition.
[5](#fn2280792768596a9d38b88-1) - Soft tissue involvement, other than those already listed, may include glandular involvement (such as submandibular glands).
- Any additional organ involvement, other than those already listed, may be reported in this section as
**Other organ involvement**. The other organ involved will then be specified.

5 Berk JL, O’Regan A, Skinner M. Pulmonary and tracheobronchial amyloidosis. Semin Respir Crit Care Med. 2002;23(2):155-65.

#### Question 309: Specify the current status of this system

Indicate if the site’s / system’s current status to transplant was **Improved response**, **Progression**, or **No response / stable disease**.

#### Questions 310 – 311: Date assessed

Indicate if the date the other site’s/system’s current status was assessed is **Known** or **Unknown**. If the other site’s/system’s response is **Known**, report the date. If the date is **Unknown**, continue with question 312.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)