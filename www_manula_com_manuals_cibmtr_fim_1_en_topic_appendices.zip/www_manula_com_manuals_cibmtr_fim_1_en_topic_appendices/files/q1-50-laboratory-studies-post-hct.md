**Report the most recent findings since the date of the last report. For questions 1-3 and 6-7, also report CBC results in the Form 2100 – 100 Days Post-HCT Data, or in the Form 2200 – Six Months to Two Years Post-HCT Data.**

#### Question 1: Date of most recent hematologic testing

Report the date of the most recent hematologic testing since the date of last report. Continue with question 2.

#### Question 2: WBC

Report the white blood cell (WBC) count and unit of measure as documented on the laboratory report. If the WBC is unknown leave the count and unit fields blank and select “WBC not tested.” Continue with question 9.

#### Question 3: Lymphocytes

Report the percentage of lymphocytes. If lymphocytes were not tested leave the count field blank and select “Lymphocytes not tested.” Continue with question 4.

#### Question 4: Eosinophils

Report the percentage of eosinophils. If eosinophils were not tested leave the count field blank and select “Eosinophils not tested.” Continue with question 5.

#### Question 5: Polymorphonuclear leukocytes (PMN)

Polymorphonuclear leukocytes are white blood cells containing cytoplasmic granules. PMNs are also referred to as granulocytes and include neutrophils, basophils, and eosinophils; however, this question refers to **neutrophils**. Report the percentage of neutrophils. If neutrophils were not tested leave the count field blank and select “Polymorphonuclear leukocytes (PMN) not tested.” Continue with question 6.

#### Question 6: Hemoglobin

Report the hemoglobin count and the unit of measure as documented on the laboratory report. If the hemoglobin was not tested leave the count and unit fields blank and indicate “Hemoglobin not tested.”

Indicate if red blood cells (RBC) were transfused ≤ 30 days from date of test. Continue with question 7.

#### Question 7: Platelets

Report the platelet count and unit of measure as documented on the laboratory report. If the platelet count was not tested leave the count and unit fields blank and indicate “Platelets not tested.”

Indicate if platelets were transfused ≤ 7 days from date of test. Continue with question 8.

#### Question 8: Mean platelet volume

Report the mean platelet volume in femtoliters (fl). If the mean platelet volume was not tested leave the count field blank and indicate “Mean platelet volume not tested.” Continue with question 9.

#### Question 9: What was the platelet size at the date of the most recent follow-up?

Platelet size can be evaluated using platelet volume indices, including mean platelet volume and platelet deviation width. Indicate if the platelet size at the date of the most recent follow-up was “decreased,” “normal,” or “unknown.” Continue with question 10.

## Immunoglobulin Analysis

Specify the following quantitative immunoglobulins measured since the date of the last report. Also report immunoglobulins and IVIG in the Form 2100 – 100 Days Post-HCT Data, or in the Form 2200 – Six Months to Two years Post-HCT Data.

#### Question 10: IgG

Report the IgG level and the unit of measure documented on the laboratory report. Continue with question 11. If IgG was not tested leave the value and unit fields blank and indicate “IgG not tested,” and continue with question 12.

#### Question 11: Date tested

Report the date of IgG testing and continue with question 12.

#### Question 12: IgM

Report the IgM level and the unit of measure documented on the laboratory report. Continue with question 13. If IgM was not tested leave the value and unit fields blank and indicate “IgM not tested,” and continue with question 14.

#### Question 13: Date tested

Report the date of IgM testing and continue with question 14.

#### Question 14: IgA

Report the IgA level and the unit of measure documented on the laboratory report. Continue with question 15. If IgA was not tested leave the value and unit fields blank and indicate “IgA not tested,” and continue with question 16.

#### Question 15: Date tested

Report the date of IgA testing and continue with question 16.

#### Question 16: IgE

Report the IgE level in international units per milliliter (IU/ml). Continue with question 17. If IgE was not tested leave the value field blank and indicate “IgE not tested,” and continue with question 18.

#### Question 17: Date tested

Report the date of IgE testing and continue with question 18.

#### Question 18: Did the recipient receive supplemental intravenous immunoglobulins (IVIG) (since the date of the last report)?

IVIG is a product made from pooled human plasma that primarily contains IgG. It is used to provide immune-deficient recipients with antibody function to help prevent infection.

Indicate whether the recipient received IVIG since the date of last report. If “yes” continue with question 19. If “no” or “unknown” continue with question 20.

#### Question 19: Was therapy ongoing within one month of immunoglobulin testing?

Indicate whether the recipient received IVIG within one month prior to the immunoglobulin testing. If IVIG is given within one month of immunoglobulin testing, the IgG level would not represent the recipient’s native IgG. Continue with question 20.

## Lymphocyte Analysis

Specify the most recent lymphocyte assessment measured since the date of the last report. For questions 21 and 23-27, also report lymphocytes in the Form 2100 – 100 Days Post-HCT Data, or in the Form 2200 – Six Months to Two Years Post-HCT Data.

#### Question 20: Were lymphocyte analyses performed?

Lymphocyte analyses include quantifying specific types of T cells, B Cells, and natural killer (NK) cells. Cells can be identified by cell-specific surface molecules using the clusters of differentiation (CD) nomenclature. For example, T cells can be classified as helper (CD4+) or cytotoxic (CD8+) cells depending on their cell surface markers designated with CD notation.

Indicate if lymphocyte analyses were performed. If “yes” continue with question 21. If “no” continue with question 30.

#### Question 21: Date of most recent testing performed

Report the date of most recent lymphocyte testing since the date of the last report. Continue with question 22.

#### Question 22: Absolute lymphocyte count

Report the absolute lymphocyte count in cells per microliter (cells/µL). Continue with question 23.

#### Question 23: CD3 (T cells)

T cells are a type of lymphocyte that can be characterized by CD3. If the laboratory quantifies CD3 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD3 cells as an absolute value, then report the value in the count field and specify the count units. If CD3 cells were not tested, select the “CD3 (T cells) not tested” option. Continue with question 24.

#### Question 24: CD4 (T helper cells)

T helper cells are a subset of T cells characterized by CD4, sometimes reported as CD3+CD4+. If the laboratory quantifies CD4 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4 cells as an absolute value, then report the value in the count field and specify the count units. If CD4 cells were not tested, select the “CD4 (T cells) not tested” option. Continue with question 25.

#### Question 25: CD8 (cytotoxic T cells)

Cytotoxic T cells are a subset of T cells characterized by CD8, sometimes reported as CD3+CD8+. If the laboratory quantifies CD8 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD8 cells as an absolute value, then report the value in the count field and specify the count units. If CD8 cells were not tested, select the “CD8 (T cells) not tested” option. Continue with question 26.

#### Question 26: CD20 (B lymphocyte cells)

B cells are a type of lymphocyte that can be characterized by CD20. If the laboratory quantifies CD20 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD20 cells as an absolute value, then report the value in the count field and specify the count units. If CD20 cells were not tested, select the “CD20 (B lymphocyte cells) not tested” option. Continue with question 27.

#### Question 27: CD56 (natural killer (NK) cells)

NK cells are a type of lymphocyte that can be characterized by CD56. If the laboratory quantifies CD56 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD56 cells as an absolute value, then report the value in the count field and specify the count units. If CD56 cells were not tested, select the “CD56 (natural killer (NK) cells) not tested” option. Continue with question 28.

#### Question 28: CD4+/CD45RA+ (naïve T cells)

Naïve T cells are a type of T cell that can be characterized by CD4+/CD45RA+. T cells are considered naïve prior to encountering an antigen. If the laboratory quantifies CD4+/CD45RA+ cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4+/CD45RA+ cells as an absolute value, then report the value in the count field and specify the count units. If CD4+/CD45RA+ cells were not tested, select the “CD4+/CD45RA+ (naïve T cells) not tested” option. Continue with question 29.

#### Question 29: CD4+/CD45RO+ (memory T cells)

Memory T cells are a type of T cell that can be characterized by CD4+/CD45RO+. If the laboratory quantifies CD4+/CD45RO+ cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4+/CD45RO+ cells as an absolute value, then report the value in the count field and specify the count units. If CD4+/CD45RO+ cells were not tested, select the “CD4+/CD45RO+ (memory T cells) not tested” option. Continue with question 30.

#### Questions 30-38: Antibody Response

The immune system produces antibodies in response to antigens. Tests that measure the antibody response to different antigens help determine if the immune system is properly functioning.

Specify the most recent antibody responses measured since the date of the last report.

For each of the antigens in questions 31-36, indicate if the antibody response was “Absent”, “Low”, “Normal”, or “Not Tested.”

**Unconjugated pneumococcal polysaccharide**

The term unconjugated indicates that the pneumococcal capsule contains polysaccharides without the modification of proteins added to the surface to enhance the immune response.

Specify the number of serotypes producing a protective level out of the total serotypes tested from the vaccine. For example, if the Pneumococcal 23-valent vaccine was used for the test, then report the number of reactive serotypes out of the 23 serotype total.

**Conjugated pneumococcal polysaccharide**

The term conjugated indicates that the pneumococcal capsule contains polysaccharides that have been conjugated with proteins to enhance the immune response.

Specify the number of serotypes producing a protective level out of the total serotypes tested from the vaccine.

#### Questions 39-46: Lymphocyte function

Lymphocyte function tests assess immune function by measuring immune cell responses to antigens and mitogens relative to control responses.

Specify the date of the most recent lymphocyte function assessment since the date of last report at question 39.

For each of the lymphocyte function tests listed in questions 40-45, indicate whether the lymphocyte response was “Absent (<10% of control)” “Low (10-30% of control)” “Normal (>30% of control)” or “Not tested.”

Natural killer cell function can be assessed by quantifying cytolysis of NK-sensitive target cells, e.g. K562. At question 46, indicate if NK cell function is “absent (≤10% of control),” “decreased (11-50% normal response),” “normal,” or “unknown.” Continue with question 47.

#### Question 47: Did a new malignancy, lymphoproliferative or myeloproliferative disorder appear that is different from the disease for which the HSCT was performed?

Indicate whether a new or secondary malignancy, lymphoproliferative disorder, or myeloproliferative disorder has developed. If “yes” continue with question 48, if “no” continue with question 51. Do not report recurrence, progression, or transformation of the recipient’s primary disease (disease for which the transplant was performed), or relapse of a prior malignancy.

Also report malignancy in the Form 2100 – 100 Days Post-HCT Data, Form 2200 – Six Months to Two Years Post-HCT Data, or Form 2300 – Yearly Follow-Up for Greater Than Two Years Post-HSCT Data.

Add additional instances for questions 48-50 to report more than one secondary malignancy. If submitting a paper form copy questions 48-50 and check the box corresponding to “Check here if additional pages are attached.”

#### Question 48: Specify second malignancy

Specify if the second malignancy was an “EBV-associated lymphoproliferative disorder” “other second malignancy” or “unknown.” If other malignancy is selected continue with question 49, otherwise continue with question 50 to specify the date of second malignancy diagnosis.

#### Question 49: Specify other second malignancy

The following should not be reported as new malignancy:


- Recurrence of primary disease
- Relapse of malignancy from recipient’s pre-HSCT medical history
- Breast cancer found in other (i.e., opposite) breast
- Post-HSCT cytogenetic abnormalities associated with the pre-HSCT diagnosis
- Transformation of MDS to AML post-HSCT

Continue with question 50 to specify the date of second malignancy diagnosis.

#### Question 50: Specify the date of diagnosis

Indicate the date of second malignancy diagnosis.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)