#### Question 3: Does the product(s) infused contain CD34+ cells with the intent to establish / restore hematopoiesis?

The intent of this question is to separate HCT/CD34+ boosts/gene therapy infusions from cellular therapy (e.g., genetically modified or non-genetically modified, or DLI) infusions. This question is answered for all infusion types.

The intent of CD34+ products is generally to restore hematopoiesis by replacing or repopulating the recipient marrow.

Specify if the product(s) infused contain CD34+ cells *and* the intent is to establish and / or restore hematopoiesis. If intent of the CD34+ cells is unclear, confirm with the physician.

For more information on infusion types, review [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

#### Questions 4-5: What was the primary indication for this infusion?

The intent of this question is to determine whether a new Pre-TED is required for the subsequent infusion. This question is answered for subsequent HCT and gene therapy infusions only.

Indicate the reason for the subsequent infusion (check only one).

**Graft failure:**Additional stem cells are required because the ANC did not recover following HCT (primary graft failure), or hematopoietic recovery indefinitely declined after the initial hematopoietic recovery or hematopoietic recovery (secondary graft failure)**Autologous infusion:**If autologous cells are infused for this reason, this is considered an autologous rescue; in this case, reporting will continue under the prior HCT date, and a new Pre-TED form is not required.**Allogeneic infusion:**If allogeneic cells are infused, this would be considered a subsequent HCT, and a new Pre-TED is required, and a new set of follow-up forms will come due, as applicable.

**Poor graft function / insufficient donor chimerism:**Additional stem cells are required because hematopoietic recovery was deemed insufficient or too slow for survival following previous high-dose therapy and HCT.- If autologous cells are infused for this reason, this is considered an autologous rescue; in this case, reporting will continue under the prior HCT date, and a new Pre-TED form is not required. If allogeneic cells are infused, this would be considered a subsequent HCT, and a new Pre-TED is required, and a new set of follow-up forms will come due, as applicable.
- In the case of a stable, mixed donor chimerism, the infusion of additional cells (usually lymphocytes and not mobilized stem cells) is typically classified as a DCI. Verify with the transplant physician that the cells given should be reported as a subsequent transplant and that stable, mixed chimerism is the reason for the transplant. However, in the case of declining chimerism – when the percentage of donor cells is sequentially decreasing on several studies, indicating possible impending graft failure – additional stem cells are required. Usually, the donor chimerism has fallen below 30-50%.

**Persistent primary disease:**Additional stem cells are required because of the persistent presence of disease pre- and post-infusion (i.e., clinical / hematologic complete remission was never achieved following the previous infusion, clinical / hematologic complete remission was achieved but disease persisted by other methods of assessments (molecular, flow cytometry, cytogenetics)).**Recurrent primary disease:**Additional stem cells are required because of relapse of the primary disease by any method of assessment (i.e., clinical / hematologic complete remission was achieved pre- or post-infusion, but the disease relapsed following the previous infusion, clinical / hematologic and molecular complete remission was achieved pre- or post-infusion, but the disease relapsed by molecular assessments following the previous infusion).**Planned subsequent HCT, per protocol:**Additional stem cells are given as defined by the protocol for a subsequent transplant / infusion. This infusion is not based upon recovery, disease status, or any other assessment.**New malignancy (including PTLD and EBV lymphoma):**Additional stem cells are required because the recipient developed a new malignancy. This does not include a transformation or progression of the original malignancy for which the recipient was transplanted (i.e., MDS progressed to AML). If New malignancy is selected, also complete the New Malignancy, Lymphoproliferative or Myeloproliferative Disorder section of the appropriate follow-up form.**Other:**If additional stem cells are given for a reason other than the options listed, select**Other**and specify.

#### Question 6: Are any of the products associated with this infusion genetically modified?

The intent of this question is to separate genetically modified products from non-genetically modified products to determine the follow up schedule. This question is answered for all infusion types.

A genetically modified product consists of cells genetically modified outside the body after pheresis (i.e., product collection). Genetically modified products include any product where the cells are manipulated via either:

- Gene transfer: a process by which copies of a gene are inserted into living cells in order to induce synthesis of the gene’s product; or
- Transduction: a process by which foreign DNA is introduced into a cell by a virus or viral vector

Indicate if the product(s) associated with the infusion was genetically modified. If more than one product is being infused, indicate if any of the products are genetically modified.

#### Question 7: Was genetic modification performed to repair or correct a genetic defect?

The intent of this question is to determine if the infusion is a gene therapy. This question is answered for HCT or gene therapy infusions.

There are two general approaches to gene therapy:


- Gene addition: Correct copies of genes are inserted into the DNA of the stem cells using a vector system.
- Gene editing: defective DNA sequences at a specific location are removed or replaced with the correct sequence.

Indicate if genetic modification was performed to repair or correct a genetic defect. For more information on gene therapy, review [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d).

#### Question 8: Was the infusion a donor lymphocyte infusion (DLI)?

The intent of this question is to determine if the if the cellular therapy is a Donor Lymphocyte Infusion (DLI).

DLIs are considered a type of cellular therapy. These infusions are not intended to promote hematopoiesis. If the recipient received additional cells due to engraftment issues, or if they received an infusion of unmanipulated CD34+ cellular product (stimulated peripheral blood stem cells, bone marrow, or cord blood), this question should not be answered.

An infusion is a donor lymphocyte infusion when all the following criteria are met:


- The intent of the infusion is something other than to restore hematopoiesis
- The infusion must be post-Allogenic HCT, often by the same donor as the HCT
- The product must be a lymphocyte product
- The product cannot be genetically modified

Specify if *all* the criteria listed above were me (indicating this infusion is a DLI).

For more information on DLIs, review [Donor Lymphocyte Infusion (2199) manual](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2199-donor-lymphocyte-infusion).

#### Question 9: Number of DLIs in this reporting period

Report the number of Donor Lymphocyte Infusions (DLI) the recipient received in the current reporting period. This question is used to make the correct number of Donor Lymphocyte Infusion (2199) Forms come due.

#### Question 10: Specify donor

This question is answered for subsequent HCT and DLIs.

Indicate the donor type for this infusion.

• **Autologous:** The product has cells collected from the recipient for his / her own use. This option cannot be selected for DLIs.

• **Allogeneic, unrelated:** An unrelated donor who shares no known ancestry with the recipient. Include adoptive parents / children or stepparents / children.

• **Allogeneic, related:** A related donor, a blood-related relative. This includes monozygotic (identical twins), non-monozygotic (dizygotic, fraternal, non-identical) twins, siblings, parents, aunts, uncles, children, cousins, half-siblings, etc.

#### Question 11: Has this donor already provided cells for this recipient for a prior infusion?

The intent of this question is to determine if the same donor was used for a prior infusion.

Indicate if the current donor for this infusion was used for any prior infusions for this recipient. If this is the recipient’s first infusion, select **No**.

#### Question 12: Date of infusion

This question is answered for all infusion types except for autologous rescues and DLIs.

Report the planned date of transplant. An approximate date is fine to report if the date is not yet on the hospital schedule. When or if the approximated or planned date of infusion changes, the form should be updated in FormsNet3SM, as this data field is used to populate the date of infusion on the recipient’s other data collection forms.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)