#### General Reporting Guidelines

- Use the multiple myeloma response criteria when determining the disease status for multiple myeloma and solitary plasmacytoma.
- Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.
- When determining disease status, the difference between the involved and uninvolved free light chain levels should only be used when both the serum (SPEP)
*and*urine (UPEP) levels are not measurable (**Non-Measurable Disease**). If either value is measurable (serum M-protein ≥ 1 g/dL or urine ≥ 200 mg/24 hours), then the disease status should be tracked using the measurable M-protein, either the SPEP or the UPEP. - Review
[Appendix G](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-g)for examples of how to determine disease status for Multiple Myeloma.

Image 1. Urine Studies Requirement


**Example 1**: Pre-Infusion Disease Status

1/26/2017: Recipient’s serum and urine M-protein is detectable by immunofixation but not on electrophoresis (one of each assessment were performed; however, the results were not confirmed).

2/1/2017: Recipient received an autologous HCT

2/21/2017: Recipient’s serum and urine M-protein is detectable by immunofixation but not on electrophoresis (confirmatory assessment)

The recipient’s pre-infusion serum and urine immunofixation results met the criteria for VGPR; however, these assessments were not performed again pre-infusion and the results were not confirmed. The assessments performed immediately post-infusion confirmed the pre-infusion assessments. Therefore, the recipient’s disease status can be reported as VGPR at the pre-infusion timepoint, as the disease response identified prior to infusion was subsequently confirmed.

**Example 2**: Post-Infusion Disease Status

6/1/2018: Recipient received an autologous HCT (pre-infusion disease status was VGPR)

9/1/2018: Recipient met all criteria for Complete Response (CR) and their serum and urine M-protein was not detectable by immunofixation or electrophoresis (one of each assessment were performed; however, these results were not confirmed)

9/9/2018: 100 date of contact

9/28/2018: Recipient’s serum and urine M-protein was not detectable by immunofixation or electrophoresis (confirmatory assessment)

This recipient’s 100-day serum and urine immunofixation results met the criteria for CR; however, these assessments were not performed again within the 100-day reporting period and the results were not confirmed. The assessments performed within the 6-month reporting period confirmed the 100-day assessments. Therefore, the recipient’s disease status can be reported as CR during the 100-day reporting period, as the disease response identified during the 100-day reporting period was subsequently confirmed.

#### Stringent Complete Response (sCR)

Follows criteria for CR as defined below, **plus all of the following**:


- Normal free light chain ratio,
- See blue box above regarding Free Light Chain Ratios

- Absence of clonal cells in the bone marrow by immunohistochemistry or immunofluorescence (confirmation with repeat bone marrow biopsy not needed). (κ/λ ratio ≤ 4:1 or ≥ 1:2 for κ and λ patients, respectively, after counting ≥ 100 plasma cells)

sCR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy sCR requirements.

#### Complete Response (CR)

**Measurable and Non-Measurable Multiple Myeloma**

A treatment response where **all** the following criteria are met:


- Negative immunofixation on serum and urine samples
- Disappearance of any soft tissue plasmacytomas
- < 5% plasma cells in the bone marrow (confirmation with repeat bone marrow biopsy not needed)

**Light Chain Only Myeloma**

A treatment response where **all** the follow criteria are met:


- Normal serum free light chain ratio
- See blue box above regarding Free Light Chain Ratios

- Negative immunofixation on serum and urine samples
- Disappearance of any soft tissue plasmacytomas
- < 5% plasma cells in the bone marrow (confirmation with repeat bone marrow biopsy not needed)

**Non-Secretory Myeloma**

A treatment response where **all** the following criteria are met:


- Disappearance of all soft tissue plasmacytomas
- < 5% plasma cells in the bone marrow (confirmation with repeat bone marrow biopsy not needed)

CR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy CR requirements.

The method of the two consecutive assessments may be any of the biochemical tests (urine/serum testing) listed in the disease status criteria available in the manual. Though it is preferable the biochemical confirmatory testing include both the urine & serum, this disease status does not require two consecutive assessments by each method.

**Example 3**: A recipient with IgG kappa myeloma receives therapy and has assessments performed on April 1, which appear to show resolution of disease. These include negative serum and urine immunofixations, a bone survey and PET/CT without evidence of active disease, and a negative bone marrow with 2% plasma cells. On May 1, the recipient has another negative serum immunofixation prior to proceeding with transplant on May 12. This recipient would be in complete response at transplant, as they meet all specified CR criteria and have two consecutive negative serum immunofixation studies; additional imaging and bone marrow studies are not required.

#### Very Good Partial Response (VGPR)

**Measurable Myeloma**

**One or more** of the following must be present:


- Heavy Chain Myeloma (e.g., IgG kappa, IgG lambda, IgG only, etc.)
- Serum and urine M-protein detectable by immunofixation but not on electrophoresis
- ≥ 90% reduction in serum M-protein and urine M-protein level < 100 mg/24 hours


- Light Chain Only Myeloma (e.g., kappa or lambda only)
- Serum and urine M-protein detectable by immunofixation but not on electrophoresis
- ≥ 90% reduction in serum M-protein and urine M-protein level < 100 mg/24 hours
- ≥ 90% decrease in the difference between involved and uninvolved free light chain levels (applicable to Light Chain Only Myeloma)


**Non-Measurable Myeloma**

If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria at the time of diagnosis):


- Serum M-protein ≥ 1 g/dL
- Urine M-protein ≥ 200 mg/24 hours

then a ≥ 90% decrease in the difference between involved and uninvolved free light chain levels is required in place of the M-protein criteria (provided the serum free light chain assay shows involved > 10 mg/dL (> 100 mg/L) and the serum free light chain ratio is abnormal).

For recipients with **non-secretory myeloma**, VGPR cannot be reported as a disease response.

VGPR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy VGPR requirements.

#### Partial Response (PR)

**Measurable Myeloma**

**One or more** of the following criteria must be met:


- Heavy Chain Myeloma (e.g., IgG kappa, IgG lambda, IgG only, etc.)
- ≥ 50% reduction in serum M-protein
- Reduction in 24-hour urinary M-protein by ≥ 90% or to < 200 mg/24 hours


- Light Chain Only Myeloma (e.g., kappa or lambda only)
- ≥ 50% reduction in serum M-protein
- Reduction in 24-hour urinary M-protein by ≥ 90% or to < 200 mg/24 hours
- ≥ 50% decrease in the difference between the involved and uninvolved free light chain levels (applicable to Light Chain Only Myeloma)


**Non-Measurable Myeloma**

If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria at time of diagnosis):


- Serum M-protein ≥ 1 g/dL
- Urine M-protein ≥ 200 mg/24 hours;

then a ≥ 50% decrease in the difference between involved and uninvolved free light chain levels is required in place of the M-protein criteria (provided the serum free light chain assay shows involved level > 10 mg/dL (> 100 mg/L) and the serum free light chain is abnormal).

**Non-Secretory Myeloma**

The following criteria must be met:


- ≥ 50% reduction in bone marrow plasma cells is required in place of M-protein (provided the baseline bone marrow plasma cell percentage was ≥ 30%)

In addition, for recipients who had **soft tissue plasmacytoma(s) present at baseline**, a ≥ 50% reduction in their size is also required.

PR requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy PR requirements.

#### Stable Disease (SD)

Does not meet the criteria for CR, VGPR, PR, or PD.

SD requires two consecutive assessments (by the same method) made at any time before the institution of any new therapy. If radiographic studies were performed, there must be no known evidence of new or progressive bone lesions. Radiographic studies are not required to satisfy SD requirements.

#### Progressive Disease (PD)

**Measurable Myeloma**

**One or more** of the following criteria must be met:


- Heavy Chain Myeloma (e.g., IgG kappa, IgG lambda, IgG only, etc.)
- Increase of ≥ 25% from the lowest response value achieved in one or more of the following:
- Serum M-protein with an absolute increase ≥ 0.5 g/dL (for progressive disease, serum M-protein increases of ≥ 1 g/dL are sufficient if the starting M-protein is ≥ 5 g/dL)
- Urine M-protein with an absolute increase ≥ 200 mg/24 hours
- Bone marrow plasma cell percentage with an absolute increase of at least 10% plasma cells

- Definite development of new bone lesions or soft tissue plasmacytomas, or definite increase in the size of any existing bone lesions or soft tissue plasmacytomas (≥ 50% increase from nadir in size of > 1 lesion, or a ≥ 50% increase in the longest diameter of a previous lesion > 1 cm in short axis);
*and/or* - ≥ 50% increase in circulating plasma cells (minimum of 200 cells per µL) if this is the only measure of disease

- Increase of ≥ 25% from the lowest response value achieved in one or more of the following:

- Light Chain Only Myeloma (e.g., kappa or lambda only)
- Increase of ≥ 25% from the lowest response value achieved in one or more of the following:
- Urine M-protein with an absolute increase of ≥ 200 mg/24 hours
- The difference between involved and uninvolved free light chain levels with an absolute increase > 10 mg/dL (> 100 mg/L) (applicable to Light Chain Only Myeloma)
- Bone marrow plasma cell percentage with an absolute increase of at least 10% plasma cells

- Definite development of new bone lesions or soft tissue plasmacytomas, or definite increase in the size of any existing bone lesions or soft tissue plasmacytomas (≥ 50% increase from nadir in size of >1 lesion, or a ≥ 50%
- ≥ 50% increase in circulating plasma cells (minimum of 200 cells per µL) if this is the only measure of disease

- Increase of ≥ 25% from the lowest response value achieved in one or more of the following:

**Non-Measurable Myeloma**

**One or more** of the following criteria must be met:


- Increase of ≥ 25% from the lowest response value achieved in one or more of the following:
- The difference between involved and uninvolved free light chain levels with an absolute increase > 10 mg/dL (> 100 mg/L)
- Bone marrow plasma cell percentage with an absolute increase of at least 10% plasma cells

- Definite development of new bone lesions or soft tissue plasmacytomas, or definite increase in the size of any existing bone lesions or soft tissue plasmacytomas (≥ 50% increase from nadir in size of >1 lesion, or a ≥ 50% increase in the longest diameter of a previous lesion >1 cm in short axis); and/or
- ≥ 50% increase in circulating plasma cells (minimum of 200 cells per µL) if this is the only measure of disease

**Non-Secretory Myeloma**

**One or more** of the following criteria must be met:


- Increase of ≥ 25% from the lowest response value achieved in one or more of the following:
- Bone marrow plasma cell percentage (irrespective of baselines status) with an absolute increase of at least 10% plasma cells

- Definite development of new bone lesions or soft tissue plasmacytomas, or definite increase in the size of any existing bone lesions or soft tissue plasmacytomas (≥ 50% increase from nadir in size of >1 lesion, or a ≥ 50% increase in the longest diameter of a previous lesion >1 cm in short axis); and/or
- ≥ 50% increase in circulating plasma cells (minimum of 200 cells per µL) if this is the only measure of disease

PD requires two consecutive assessments (by the same method) made at any time before classification as disease progression, and/or the start of any new therapy.

#### Relapse from CR

**One or more** of the following criteria must be met:


- Reappearance of serum or urine M-protein by immunofixation or electrophoresis; and/or
- Development of ≥ 5% plasma cells in the bone marrow; and/or
- Appearance of any other sign of progression such as:
- Development of new soft tissue plasmacytomas or bone lesions (osteoporotic fractures do not constitute progression)
- Hypercalcemia (> 11mg/dL)
- Decrease in hemoglobin of ≥ 2 g/dL not related to therapy or other non-myeloma-related conditions
- Rise in serum creatinine by 2 mg/dL or more from the start of therapy and attributable to myeloma
- Hyperviscosity related to serum paraprotein

- Abnormal free light chain ratio
[1](#fn180751041068596ab5c0bd7-1)- Recipient with normal creatinine (i.e., < 2 mg / dL): Kappa / lambda ratio is outside the normal range of 0.26 – 1.65
- Recipient with elevated creatinine (i.e., ≥ 2 mg / dL): Kappa / lambda ratio is outside the range of 0.37 – 3.1


1 This criterion only applies to recipient’s with light chain only myeloma (e.g., kappa or lambda only)

Relapse requires two consecutive assessments (by the same method) made at any time before classification as relapse, and/or the start of any new therapy.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/12/2024 |
|

**Urine Immunofixation and Electrophoresis**: The sample for the urine immunofixation and electrophoresis criteria must be a 24-hour urine and not a random urine.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*Absence of clonal cells in the bone marrow by immunohistochemistry or immunofluorescence (confirmation with repeat bone marrow biopsy not needed). (κ/λ ratio ≤ 4:1 or ≥ 1:2 for κ and λ patients, respectively, after counting ≥ 100 plasma cells)*[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*When determining disease status, the difference between*~~free light chain ratios~~ the involved and uninvolved free light chain levels should only be used when both the serum (SPEP) and urine (UPEP) levels are not measurable (Non-Measurable Disease). If either value is measurable (serum M-protein ≥ 1 g/dL or urine ≥ 200 mg/24 hours), then the disease status should be tracked using the measurable M-protein, either the SPEP or the UPEP.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*Abnormal free light chain ratio**Recipient with normal creatinine (i.e., < 2 mg / dL): Kappa / lambda ratio is outside the normal range of 0.26 – 1.65**Recipient with elevated creatinine (i.e., ≥ 2 mg / dL): Kappa / lambda ratio is outside the range of 0.37 – 3.1*

[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Light Chain Only Myeloma**added to PR:*Light Chain Only Myeloma (e.g., kappa or lambda only)**≥ 50% reduction in serum M-protein**Reduction in 24-hour urinary M-protein by ≥ 90 % or to < 200 mg/24 hours**≥ 50% decrease in the difference between the involved and uninvolved free light chain levels (applicable to Light Chain Only Myeloma)*

**Measurable Myeloma**was updated. Both criteria are not required to be met, only one more is needed: **Both**

**One or more**of the following criteria must be met:In addition, the following sentence was removed from the Partial Response criteria:

~~Transplant centers may not perform urine studies on a regular basis. In that case, only the ≥ 50 % reduction in the serum M-protein is required for Heavy Chain and Light Chain Only Myeloma~~[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Measurable Myeloma**:**Measurable Myeloma** **Both**

**One or more**of the following criteria must be met*:*Heavy Chain Myeloma (e.g., IgG kappa, IgG lambda, IgG only, etc.)**≥ 50% reduction in serum M-protein**Reduction in 24-hour urinary M-protein by ≥ 90% or to < 200 mg/24 hours*

*Light Chain Only Myeloma (e.g., kappa or lambda only)**≥ 50% reduction in serum M-protein**Reduction in 24-hour urinary M-protein by ≥ 90% or to < 200 mg/24 hours**≥ 50% decrease in the difference between the involved and uninvolved free light chain levels (applicable to Light Chain Only Myeloma)*

~~*Transplant centers may not perform urine studies on a regular basis. In that case, only the ≥ 50 reduction in the serum M-protein is required for Heavy Chain and Light Chain Only Myeloma~~


[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Light Chain Only Myeloma**added to VGPR and Progressive Disease:*VGPR**Serum and urine M-protein detectable by immunofixation but not on electrophoresis**≥ 90 reduction in serum M-protein and urine M-protein level < 100 mg/24 hours**≥ 90% decrease in the difference between involved and uninvolved free light chain levels (applicable to Light Chain Only Myeloma)*

*Progressive Disease**Increase of ≥ 25% from the lowest response value achieved in one or more of the following:**Urine M-protein with an absolute increase ≥ 200 mg/24 hours**The difference between involved and uninvolved free light chain levels with an absolute increase > 10 mg/dL (applicable to Light Chain Only Myeloma)**Bone marrow plasma cell percentage with an absolute increase of at least 10% plasma cells*


[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*Partial Response – Measurable Myeloma:*~~One or more~~ Both of the following criteria must be met *; *Transplant centers may not perform urine studies on a regular basis. In that case, only the ≥ 50 reduction in the serum M-protein is required for Heavy Chain and Light Chain Only Myeloma.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Complete Response**section providing guidance on Serum or Urine Immunofixation.[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**serum**to criteria).[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Relapse from CR***Requires one or more of the following:**Reappearance of serum or urine M-protein by immunofixation or electrophoresis; and/or**Development of ≥ 5% plasma cells in the bone marrow; and/or**Appearance of any other sign of progression (e.g., new plasmacytoma, lytic bone lesion, hypercalcemia).*

~~Positive immunofixation alone in a patient previously classified as achieving a complete response should~~**not**be considered a relapse.

[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)**Relapse from CR***Requires one or more of the following:**Reappearance of serum or urine M-protein by*~~immunofixation or~~electrophoresis; and/or*Development of ≥ 5% plasma cells in the bone marrow; and/or**Appearance of any other sign of progression (e.g., new plasmacytoma, lytic bone lesion, hypercalcemia).*

*Positive immunofixation alone in a patient previously classified as achieving a complete response should***not**be considered a relapse.

[Multiple Myleoma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[Multiple Myleoma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)< 5% plasma cells in bone marrow (confirmation with repeat bone marrow biopsy not needed).

[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)*Definite development of new bone lesions or soft tissue plasmacytomas, or definite increase in the size of any existing bone lesions or soft tissue plasmacytomas (≥ 50%increase from nadir in size of >1 lesion, or a ≥ 50%increase in the longest diameter of a previous lesion >1 cm in short axis).**Use the multiple myeloma response criteria when determining the disease status for multiple myeloma and solitary plasmacytoma.**Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.*

*A treatment where***all**of the following criteria met:*Serum and Urine M-protein detectable by immunoelectrophoresis*(immunofixation, IFE) but not on electrophoresis (SPEP and UPEP)[1](#fn180751041068596ab5c0bd7-1)~~≤~~< 5% plasma cells in bone marrow.

If the serum and urine M-protein are not measurable (i.e., do not meet the following criteria

*at time of diagnosis*):**Urine Studies**:In order to report a Stringent Complete Remission

*(sCR)*or Complete Remission*(CR)*, urine studies MUST be performed and agree with the international*myeloma*working group*(IMWG)*criteria provided above.*As long as the negative serum electrophoresis and immunofixation studies have been confirmed, only one set of negative urine studies needs to be documented to report sCR or CR.**IMWG*criteria for the disease status being reported. In any case, serum studies MUST be performed and agree with the international working group criteria for the disease status being reported*(excluding non-secretory myeloma)*.**Urine Studies**In order to report a Stringent Complete Remission or Complete Remission, urine studies MUST be performed and agree with the international working group criteria provided above. Urine electrophoresis and immunofixation studies may not be performed in all cases. The disease response options below (Near Complete Remission, Very Good Partial Response, and Partial Response) may still be reported even if urine studies were never obtained or were only obtained at diagnosis. If urine studies were performed following the most recent line of therapy, the results must agree with the international working group criteria for the disease status being reported. In any case, serum studies MUST be performed and agree with the international working group criteria for the disease status being reported.

The method of the two consecutive assessments may be any of the biochemical tests (urine/serum testing) listed in the disease status criteria available in the manual. Though it is preferable the biochemical confirmatory testing include both the urine & serum, this disease status does not require two consecutive assessments by each method. As an example: [see in text]

Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.

[VGPR](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria#VGPR):… then a ≥ 90% decrease in the difference between involved and uninvolved free light chain levels is required in place of the M-protein criteria

**.**
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)