Hemophagocytic Lymphohistiocytosis (HLH) is a rare condition characterized by immune dysregulation, which generally manifests as an exaggerated immune response to a trigger (such as infection). Based on genetics and family history, the disease is divided into “primary” and “secondary” HLH. Those with a genetic component or clear family history are classified as “primary” and have “familial hemophagocytic lymphohistiocytosis” (FHL). Subtypes of FHL are numbered one through five. They are often diagnosed in infancy with molecular, hematologic, and clinical assessments. Those who are diagnosed as older children or adults have “secondary” HLH and may not have a genetic component or family history of the disease. HLH may be triggered by an infection, malignancy, or other autoimmune condition. Manifestations of HLH include prolonged fever, hepatosplenomegaly, bleeding, skin rash, central nervous system (CNS) abnormalities (such as seizures), jaundice, cytopenia(s), coagulopathy, hyperlipidemia, hypofibrinogenemia, hyperferritinemia, transaminitis, hyperbilirubinemia, hypoalbuminemia, and hyponatremia.[1](#fn113805710368596b76419cb-1)[2](#fn113805710368596b76419cb-2)

1 Weitzman S. Difficult Pediatric Consultations: Consultative Hematology II “Approach to Hemophagocytic Disorders.” *ASH Education Book*. 2011;2011(1):178-83.

2 Gholam C, Grigoriadou S, Gilmour KC, Gaspar HB. Familial haemophagocytic lymphohistiocytosis: advances in the genetic basis, diagnosis and management. *Clin Exp Immunol*. 2011;163(3):271-83.

[2039: Hemophagocytic Lymphohistiocytosis Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2039-hemophagocytic-lymphohistiocytosis-pre-hct)

[2139: Hemophagocytic Lymphohistiocytosis Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2139-hemophagocytic-lymphohistiocytosis-post-hct)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)