#### Question 1: Specify the multiple myeloma / plasma cell disorder (PCD) classification

Specify the indication for transplant. This question will be auto-populated from the Pre-TED Disease Classification and Characteristics (2402) Form.

#### Question 2: Specify preceding / concurrent disorder (check all that apply)

Indicate if the recipient had a concurrent or preceding plasma cell disorder. Many recipients progress to symptomatic myeloma from a preceding condition or have a concurrent plasma cell disorder, such as amyloidosis. This question will be auto-populated from the Disease Classification (2402) Form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Apr 30, 2021

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)