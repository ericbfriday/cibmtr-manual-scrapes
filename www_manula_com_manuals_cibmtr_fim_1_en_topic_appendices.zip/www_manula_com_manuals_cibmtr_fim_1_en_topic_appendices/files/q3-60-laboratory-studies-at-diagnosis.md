For questions 3-60, report values obtained at diagnosis or prior to the first treatment for the plasma cell disorder for which the transplant was performed. If testing is performed multiple times prior to the start of the first treatment, report the testing performed closest to the diagnosis date.

#### Questions 3-4: Hemoglobin

Indicate whether the hemoglobin was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. If **Known**, report the value and unit of measure documented. If **Unknown,** continue with question 5.

#### Questions 5-6: Serum calcium

Indicate whether the serum calcium was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. If **Known**, report the value and unit of measure documented. If **Unknown,** continue with question 7.

#### Questions 7-9: Serum creatinine

Indicate whether the serum creatinine was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. If **Known**, report the laboratory value, unit of measure, and specify the upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 10.

#### Questions 10-11: Serum monoclonal protein (M-spike) (only from electrophoresis)

Monoclonal gammopathy is defined as the increased production of abnormal immunoglobulins. The abnormal protein produced is called paraprotein or M-protein.

Indicate whether the serum monoclonal immunoglobulin was **Known** or **Unknown** at the time of the plasma cell disorder diagnosis. If **Known**, report the value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 12. Report **Not applicable** for recipients with non-secretory myeloma.

Do not report immunofixation results here

#### Questions 12-13: Serum immunofixation

Indicate whether the serum paraprotein was detected on serum immunofixation. If detected, report **Known** and indicate the M-spike type, including both the heavy and light chain distinctions. The involved heavy chain and light chain can be identified but not quantified using this test.

If the heavy chain is IgM, ensure that the disease subtype is not Waldenstrom’s Macroglobulinemia. If the disease subtype is Waldenstrom’s Macroglobulinemia, complete Form 2019 and update the Pre-TED form to indicate that Waldenstrom’s is the transplant indication.

If multiple M-spike types are involved, select each that are present in question 13 (e.g. IgG Kappa and IgA Lambda). Report **No bands present** if serum immunofixation was performed but no paraprotein was identified. Report **Not applicable** for recipients with non-secretory myeloma.

**Table 2.** Concept of Clonality in Multiple Myeloma


| Type of Myeloma | M-Proteins Expressed |
|---|---|
Plasma Cell Myeloma |
One heavy chain (IgG, IgA, etc.) and one light chain (either kappa or lambda) |
Bi-Clonal Myeloma |
Two different M-proteins (e.g., IgG Kappa and IgA Lambda) |

#### Questions 14 – 16: Serum free light chains – κ (kappa)

Indicate whether the serum κ (kappa) free light chain level was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. This value should reflect the quantity of serum free light chains, not a quantification of total light chains. If **Known**, report the value, unit of measure, the upper limited of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 17. Report **Not applicable** for recipients with non-secretory myeloma. Do not report total light chains as serum free light chains.

#### Questions 17 – 19: Serum free light chains – λ (lambda)

Indicate whether the serum λ (lambda) free light chain level was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. This value should reflect the quantity of serum free light chains, not a quantification of total light chains. If **Known**, report the value, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 20. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 20 – 34: Specify serum quantitative immunoglobulins

Indicate if the following serum immunoglobulins were **Known** or **Unknown** at the time of the plasma cell disorder diagnosis.


- IgG
- IgA
- IgM
- IgD
- IgE

If **Known**, report the value, units of measure, and specify the upper limit of normal, as documented on the on the laboratory report.

#### Questions 35 – 36: Urinary monoclonal protein (M-spike) / 24 hours

Indicate whether the amount of urinary monoclonal protein was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable,** continue with question 37. Report **Not applicable** for recipients with non-secretory myeloma.

**Example:**

(total in g/dL of monoclonal protein) x (total urine volume) = **urinary M-protein/24 hours**

(0.145 g/dL of monoclonal protein) x (1500 mL total urine) x (1 dL/100 mL)= **2.175 g/24 hours**

#### Question 37: Urine light chain

Indicate the involved light chain in the plasma cell disorder detected on urine immunofixation. The involved light chain can be identified, but not quantified, using this test. Select **Not applicable** for recipients with non-secretory myeloma.

#### Questions 38 – 39: Total urine protein in 24 hours

Indicate whether the total amount of urinary protein was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown** or **Not applicable**, continue with question 44. Report **Not applicable** for recipients with non-secretory myeloma.

#### Questions 40 – 41: Urine albumin / creatinine ratio

Indicate whether the urinary albumin / creatinine ratio was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 42. This question is only required if the primary disease (question 1) is MGRS or Amyloidosis or if there is evidence / history of (question 2) MGRS or Amyloidosis.

#### Questions 42 – 43: Urine protein / creatinine ratio

Indicate whether the urinary protein / creatinine ratio was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. The value reported here should be based on a 24-hour urine collection. If **Known**, report the laboratory value and unit of measure documented on the laboratory report. If **Unknown**, continue with question 44. This question is only required if the primary disease (question 1) is MGRS or Amyloidosis or if there is evidence / history of (question 2) MGRS or Amyloidosis.

#### Questions 44 – 45: Plasma cells in bone marrow aspirate by flow cytometry

Indicate whether the percentage of plasma cells in the bone marrow aspirate by flow cytometry was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the flow cytometry pathology report. If **Unknown**, continue with question 46.

#### Questions 46 – 47: Plasma cells in bone marrow aspirate by morphologic assessment

Indicate whether the percentage of plasma cells in the bone marrow aspirate was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. If **Known**, report the percentage of plasma cells in the bone marrow aspirate documented on the pathology report. If **Unknown**, continue with question 48.

#### Questions 48 – 49: Plasma cells in bone marrow biopsy

Indicate whether the percentage of plasma cells in the bone marrow biopsy was **Known** or **Unknown** at the time of plasma cell disorder diagnosis. If **Known**, report the percentage of plasma cells in the bone marrow biopsy. If **Unknown**, continue with question 50.

#### Questions 50 – 52: Were immunohistochemical stains obtained (bone marrow biopsy)?

Immunohistochemical staining (IHC) is a process where tissue samples are treated with antibodies and dye. The antibodies bind to specific antigens on the surface of the cells, allowing for the identification of those cell surface markers under microscopy. Testing is often documented in the pathology report from the tissue sample on which IHC was used.

Indicate whether immunohistochemical stains were obtained. Report **Positive**, **Negative**, or **Unknown** for each marker in questions 51-52. If the report documents “dim” for a particular marker, report this as **Positive**. Report **Unknown** for markers which were not tested or were tested, but the results are not known.

#### Question 53: Was a gene expression profile performed?

Gene expression profiling (GEP) allows for the analysis of thousands of genes at once, creating a global picture of cell function. GEP can distinguish cells that are actively dividing and show how cells react to specific treatments.[2](#fn165091566368596b821f8c4-1)

If gene expression profiling was performed at the time of plasma cell disorder diagnosis or prior to the start of first therapy, indicate **Yes**. If gene expression was not performed, select **No** and continue with question 56.

2 Brunner J, Dispenzieri A. “Forms Revision: Myeloma Changes.” 2013 Tandem Meetings: CIBMTR Clinical Research Professionals/Data Manager Annual Meeting. Accessed at http://www.cibmtr.org/Meetings/Materials/CRPDMC/Documents/2013/Feb2013/Feb13FormRevMM-6up.pdf.

#### Question 54: Were results considered high-risk myeloma?

Based on the opinion of a physician, indicate if the results of the gene expression profile are considered high-risk myeloma. Indicate **yes** or **No**.

#### Question 55: Was documentation submitted to the CIBMTR (e.g., gene expression profile report)?

Indicate if a copy of the gene expression profile report is attached to support the data reported in questions 53-54. Attaching a copy of the report may prevent additional queries. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/SystemApplications/FormsNet3/Documents/FN3%20Guide%20090920.pdf) .

#### Question 56: Was a PET / CT scan performed?

A PET / CT combines the results of the PET (Positron Emission Tomography) scan along with the results of a CT (Computed Tomography) scan. If a PET / CT scan was performed at the time of plasma cell diagnosis or prior to the start of first therapy, indicate **Yes**. If a PET / CT scan was not performed, select **No** and continue with question 61.

#### Questions 57 – 58: Was the PET / CT scan positive for myeloma involvement at any disease site?

Indicate if the PET / CT scan was positive for myeloma involvement at any disease site. If positive at any site, report **Yes** and specify which area(s) show involvement. If the PET / CT scan was negative for myeloma involvement, report **No** and continue with question 59.

#### Questions 59 – 60: Date of PET / CT scan

Indicate if the date of the PET / CT scan was **Known** or **Unknown** at the time of plasma cell diagnosis or prior to the start of first therapy. If **Known**, report the assessment date. If **Unknown**, continue with question 61.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q3 | 5/1/2023 | Modify | Instructions above Q3 updated: For questions 3-60, report values obtained at diagnosis or prior to the first treatment for the plasma cell disorder for which the transplant was performed. If testing is performed multiple times prior to the start of the first treatment, report the |
To ensure more consistent reporting, all labs for the “at diagnosis” timepoint were clarified to reflect the values obtained closest to the date of diagnosis, prior to the start of any therapy. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)