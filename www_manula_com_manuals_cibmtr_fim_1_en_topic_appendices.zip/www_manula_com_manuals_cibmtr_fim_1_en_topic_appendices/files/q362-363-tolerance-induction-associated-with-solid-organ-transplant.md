#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy). Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms).

#### Questions 522 – 523: Specify transplanted organ: (check all that apply)

In an effort to achieve organ tolerance and potentially avoid long term systemic immunosuppression, a recipient may receive an infusion of cells prior to a subsequent solid organ transplant. Indicate the transplanted organ, if organ is not listed, report as **Other organ** and specify.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)