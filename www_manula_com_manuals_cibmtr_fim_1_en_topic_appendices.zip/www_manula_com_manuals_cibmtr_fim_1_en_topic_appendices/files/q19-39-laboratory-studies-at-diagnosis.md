If multiple studies were performed prior to the start of therapy, report the assessment closest to the diagnosis date of the primary disease for infusion. If the recipient’s MDS transformed, report the studies from the original diagnosis.

#### Questions 2-3: Specify prior disease

Agents such as radiation or systemic therapy used to treat other diseases (e.g., Hodgkin lymphoma, non-Hodgkin lymphoma, or breast cancer) can damage the marrow and lead to a secondary malignancy, such as MDS. If the diagnosis of MDS is therapy-related, select the prior disease from the listed options. If the recipient had a prior disease not listed above, select “other disease (malignant or nonmalignant)” and specify the disease in question 3.

#### Questions 4-5: Date of diagnosis of prior disease

Specify if the date of diagnosis of the prior disease is “known” or “unknown.” If the date is “known,” continue with question 5 and report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the prior disease. Enter the date the sample was collected for examination. Do not report the date symptoms first appeared. This date must be prior to the MDS diagnosis date. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported.

If the date is “unknown,” continue with question 6.

#### Questions 6-7: Specify therapy for prior disease

Indicate if the recipient received treatment for their prior disease, this includes systemic chemotherapy, intrathecal therapy, radiation therapy, immune therapy and cellular therapies. Check all therapies that apply. If the recipient received a therapy which is not listed, select “Other therapy” and specify the treatment in question 7. Do not report a prior HCT or any surgery for a prior disease.

#### Question 8: Specify transfusion dependence at the time of diagnosis

Report the recipient’s transfusion status at the time of diagnosis.

“At diagnosis” is defined as from diagnosis until the start of treatment. If there are multiple transfusion dependence statuses, report the closest status to the date of diagnosis as possible.

Indicate the transfusion dependence for the recipient at the time of diagnosis and continue with question 9.

Select “Non-transfused (NTD)” if the recipient has not received any RBC transfusions within a period of 16 weeks prior to the time of diagnosis.

Select “Low-transfusion burden (LTB)” if the recipient had 3-7 RBC transfusions within a period of 16 weeks or at least 2 transfusion episodes with a maximum of 3 RBC transfusions in 8 weeks prior to the time of diagnosis.

Select “High-transfusion burden (HTB)”- if the recipient had ≥8 RBCs transfusions within a period of 16 weeks or ≥4 within 8 weeks prior to the time of diagnosis.

#### Question 9: Did the recipient have constitutional symptoms in six months before diagnosis? (symptoms are >10% weight loss in 6 months, night sweats, or unexplained fever higher than 37.5°C)

Indicate if systemic symptoms were present at the time of diagnosis. Systemic symptoms are often called “B” symptoms and include unexplained fever greater than 37.5°C (99.5°F), night sweats, or unexplained weight loss in the six months prior to diagnosis. Indicate “yes” if any systemic symptoms were present at diagnosis (or in the case of unexplained weight loss, within the six months prior to diagnosis). Indicate “no” if systemic symptoms were not present at diagnosis.

Indicate “unknown” if it is not possible to determine the presence or absence of systemic symptoms at diagnosis.

#### Question 10: Did the recipient have splenomegaly at the time of diagnosis?

Indicate if the recipient had splenomegaly at the time of diagnosis. Splenomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI. Indicate “yes” if splenomegaly was present at the time of diagnosis and continue with question 11. Indicate “no” if splenomegaly was not present at diagnosis and continue with question 14.

Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at diagnosis and continue with question 14.

Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy or congenital asplenia) and continue with question 14.

#### Question 11: Specify the method used to measure spleen size

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 12. If the method selected is “ultrasound” or “CT / MRI” continue with question 13. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 12: Specify the spleen size in centimeters below the left coastal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by a physical exam and continue with question 14.

#### Question 13: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) and continue with question 14.

#### Question 14: Did the recipient have hepatomegaly at the time of diagnosis?

Indicate if the recipient had hepatomegaly at the time of diagnosis. Hepatomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Indicate “yes” if hepatomegaly was present at the time of diagnosis and continue with question 15. Indicate “no” if hepatomegaly was not present at diagnosis and continue with question 18.

Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at diagnosis and continue with question 18.

#### Question 15: Specify the method used to measure liver size

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 16. If the method selected is “ultrasound” or “CT / MRI” continue with question 17. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 16: Specify the liver size in centimeters below the right coastal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam and continue with question 18.

#### Question 17: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) and continue with question 18.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q2 | 4/19/2025 | Add | ET or PCV to MDS Transformation and Disease Assessments at Diagnosis blue note box added: ET or PCV to MDS Transformation and Disease Assessments at Diagnosis: If MDS transformed from ET or PCV, report assessments from the time of the MDS transformation. Do not report assessments from the time of ET or PCV diagnosis. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)