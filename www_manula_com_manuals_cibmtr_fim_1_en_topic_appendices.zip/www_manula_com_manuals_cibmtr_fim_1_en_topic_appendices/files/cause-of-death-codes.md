#### Recurrence / persistence / progression of disease for which the HCT or cellular therapy was performed

If the disease is present at death, but not the underlying cause of death, “Recurrence/persistence/progression of disease for which the HCT or cellular therapy was performed” should be reported as a contributing cause of death. For example, if a recipient’s disease had been stable for months and the recipient died by accidental means, this option should be used as a contributing cause of death (not the primary cause of death).

#### Acute GVHD

If reported as a primary or contributing cause of death, acute GVHD should also be reported on the appropriate Post-Infusion Follow-Up (2100) form.

#### Chronic GVHD

If reported as a primary or contributing cause of death, chronic GVHD should also be reported on the appropriate Post-Infusion Follow-Up (2100) form..

#### Graft rejection or failure

The recipient had no hematopoietic recovery or had graft failure following initial hematopoietic recovery. If secondary graft failure is due to GVHD or infection, also report GVHD or infection as causes of death.

#### Cytokine release syndrom (CRS)

CRS occurs when there is a systemic inflammatory response as the result of immunotherapy (i.e. CAR T-cell therapy). In severe cases, it’s also known as “Cytokine storm.”

#### Hemorrhage

If the recipient died with evidence of hemorrhage, use the cause of death options to report its location. If the hemorrhage was in an organ system that does not have a cause of death option, use **Other hemorrhage**, and report the organ or location of the hemorrhage.

Pulmonary hemorrhages should also be reported in the “Pulmonary Function” sections on the appropriate Post-Infusion Follow-Up (2100) form.

Stroke should also be reported in the “Other Organ Impairment/Disorder” section on the appropriate Post-Infusion Follow-Up (2100) form.

Hemorrhagic cystitis should also be reported in the “Other Organ Impairment/Disorder” section on the appropriate Post-Infusion Follow-Up (2100) form.

#### Infection

Report the etiology of the infection as Bacterial, Fungal, Viral, Protozoal, or Other infection, specify. If the organism was not identified, but evidence of infection was present based on clinical opinion, select “Infection, organism not identified.” Also report infections in the “Infection” section on the Post-Infusion Follow-Up (2100) form.

Do not report interstitial pneumonitis (IPn) using this cause of death code. IPn is collected in the “pulmonary” section.

#### Malignancy

The recipient died with evidence of a new malignancy post-infusion. If the recipient develops a **New malignancy** after transplant, it should also be reported in the “New Malignancy” section on the appropriate Post-Infusion Follow-Up (2100) form.

If there was a *history of malignancy prior to infusion* (i.e., not the primary disease for infusion) and the recipient died with evidence of recurrence, persistence, or progression of the previous malignancy, it should be reported by selecting **Prior malignancy (malignancy initially diagnosed prior to infusion, other than the malignancy for which the infusion was performed).**

#### Organ failure (not due to GVHD or infection)

If the recipient died with organ failure (not due to GVHD or infection), it should be reported as a cause of death. If the organ system that has failed is not specified, but present at death based on clinical opinion, use **Other organ failure**, and specify the organ involved in question 5 or 7.

**Liver failure (not VOD)**: If a cause of death was liver failure, except for veno-occlusive disease/sinusoidal obstruction syndrome (use VOD/SOS) or GVHD (use Acute GVHD or Chronic GVHD). Liver abnormalities should also be reported in the “Liver Function” sections on the appropriate Post-Infusion Follow-Up (2100) form.

**Veno-occlusive disease (VOD) / sinusoidal obstruction syndrome (SOS)**: If a cause of death was VOD or SOS. Pulmonary veno-occlusive disease should be reported using this cause of death code. Do not report other types of liver failure using this cause of death code. Liver VOD/SOS should also be reported in the “Liver Function” sections of the appropriate Post-Infusion Follow-Up (2100) form.

**Cardiac failure**: If a cause of death was cardiac failure. Congestive heart failure and myocardial infarctions should also be reported in the ‘Cardiac’ section of the appropriate Post-Infusion Follow-Up (2100).

**Pulmonary failure**: If a cause of death was pulmonary failure from non-infectious causes such as bronchiolitis obliterans (BO) or cryptogenic organizing pneumonia (COP). BO and COP should also be reported in the “Pulmonary Function” section of the appropriate Post-Infusion Follow-Up (2100) form.

Do not report pulmonary hemorrhage using this cause of death (use **Pulmonary hemorrhage** option).

**Central nervous system (CNS) failure**: If a cause of death was due to central nervous system failure. CNS failure may include radiation-induced atrophy, brain stem dysfunction, or encephalitis of unknown origin.


- Do not report death due to brain infection (e.g., meningitis) using this cause of death code (Use
**Infection**). - Do not report hemorrhagic stroke using this cause of death code (use
**Intracranial hemorrhage**).

**Renal failure**: If a cause of death was due to renal failure. Renal failure that was severe enough to warrant dialysis (or the recommendation of dialysis) should also be reported on the appropriate Post-Infusion Follow-Up (2100) form.

**Gastrointestinal (GI) failure (not liver)**: If the cause of death was due to gastrointestinal failure (such as intestinal obstruction or perforation).


- Do not report gastrointestinal hemorrhage using this cause of death code (use gastrointestinal hemorrhage).
- Do not report liver failure using this cause of death code (use Liver failure (not VOD)).
- Do not report graft-versus-host disease (GVHD) using this cause of death code (use Acute GVHD or Chronic GVHD).

**Multiple organ failure**: If the cause of death is due to failure of more than one organ, provide additional detail and specify in question. Do not select this option if there is a root cause of the multiple organ failure (i.e., infection).

If multiple organ failure was due to sepsis, report the **Infection** as a cause of death. The infectious organism should be also reported in the “Infection” section of the Post-Infusion Follow-Up (2100) form.

**Other organ failure**: If a cause of death was not due to a specific organ or organ system listed above. Specify the organ or organ system involved.

#### Pulmonary

**Adult Respiratory Distress Syndrome (ARDS) (other than IPS)**: also called acute respiratory distress syndrome, has acute onset, infiltrative respiratory distress. It is considered to be adult respiratory distress syndrome, rather than IPS/IPn. Also report adult respiratory distress syndrome in the “Pulmonary Function” section on the appropriate Post-Infusion Follow-Up (2100) form.

**Diffuse alveolar damage (without hemorrhage)**: describes histological changes found in lung disease. It’s associated with acute respiratory distress syndrome (ARDS) and transfusion related acute lung injury (TRALI).

**Idiopathic pneumonia syndrome (IPS)** describes non-infectious lung injuries that occur early after infusion (within 100-120 days). Also report idiopathic pneumonia syndrome in the “Pulmonary Function” section on the appropriate Post-Infusion Follow-Up (2100) form.

**Pneumonitis due to Cytomegalovirus (CMV)**: Pneumonitis can result from infection by cytomegalovirus, adenovirus, respiratory syncytial virus, influenza, or Pneumocystis jirovecii (PCP). Select this option if interstitial pneumonitis resulted from cytomegalovirus. Also report interstitial pneumonitis in the “Pulmonary Function” section on the appropriate Post-Infusion Follow-Up (2100) form.

**Pneumonitis due to other virus**: Pneumonitis can also result from infection by, adenovirus, respiratory syncytial virus, influenza, or Pneumocystis jirovecii (PCP). Select this option if pneumonitis was caused by a virus. Also report interstitial pneumonitis in the “Pulmonary Function” section on the appropriate Post-Infusion Follow-Up (2100) form

**Other pulmonary syndrome (excluding pulmonary hemorrhage)**: Select this option to report any other pulmonary syndrome, excluding pulmonary hemorrhage. Additionally, select this option for pneumonitis due to any other organism and specify IPn and the organism in question 5 or 7. Also report interstitial pneumonitis in the “Pulmonary Function” section on the appropriate Post-Infusion Follow-Up (2100) form

#### Toxicity

**Neurotoxicity (ICANS)**: is the development of different neurologic signs and symptoms reported after the infusion of genetically modified lymphocytes.

**Tumor lysis syndrome**: disorder characterized by metabolic abnormalities that result from a spontaneous or therapy-related cytolysis of tumor cells.

#### Vascular

If the recipient died with evidence of vascular dysfunction, use the cause of death options to report the specific disorder. If the vascular disorder does not have a cause of death code, use **Other vascular** and report the vascular abnormality.

#### Other

**Accidental death**: The recipient’s death was caused by accidental or unintentional means.

**Suicide**: The recipient intentionally caused their own death.

In states where physician-assisted suicide is used to hasten death in terminally ill recipients, the cause of death should be reported as the underlying condition (primary cause of death) and suicide as a contributing cause of death.

**Other cause**: If the recipient has a cause of death that is not captured using any of the above categories, provide detailed information on the cause of death in question 5 or 7.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)