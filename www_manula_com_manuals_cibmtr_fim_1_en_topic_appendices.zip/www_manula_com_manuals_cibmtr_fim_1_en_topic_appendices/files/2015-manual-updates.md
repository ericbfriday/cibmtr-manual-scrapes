[December 2015](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-manual-updates#December2015)

[September 2015](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-manual-updates#September2015)

[August 2015](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-manual-updates#August2015)

[July 2015](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-manual-updates#July2015)

[June 2015](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-manual-updates#June2015)

[May 2015](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-manual-updates#May2015)

**December 2015**

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 12/9/15 |
|

[question 62](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/donor-information#62):Stem cells do not typically circulate in the bloodstream. Therefore, in order to increase the quantity of cells for collection, an agent is frequently given to the allogeneic donor or autologous recipient. The purpose of the agent is to move the stem cells from the bone marrow into the peripheral blood. This practice is often referred to as

*mobilization*or*priming*. Indicate if the donor received plerixafor at any time prior to the*start of stem cell collection.*[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[questions 73-95](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q57-108-product-processing-manipulation#73):**Steps in Manipulation**If the manipulation consists of several steps, individual steps do not need to be reported as separate manipulations. For example, washing that is part of CD34+

*selection*does not need to be reported as a separate manipulation. Similarly, T-cell depletion that is part of expansion does not need to be reported.*If dilution is performed as part of washing, dilution does not need to be reported.*In the cases above, if T-cell depletion and/or washing are done as stand-alone manipulations, they should be reported.

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[MDS/MPN Disease specific section](#404):If the recipient is being transplanted for AML that has transformed from MDS/

*MPN*, the primary disease for HCT must be reported as AML. Disease Classification questions must be completed for both AML and MDS/*MPN*.[Appendix Z: Primary Disease and Disease Inserts Due](#404)[Severe Aplastic Anemia](#404)table to read that dykeratosis congenita does not require a disease insert.[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 420](#404)to refer to all tyrosine kinase inhibitors:*There is currently an issue on this form. Question 420 should say “e.g. imatinib mesylate.” Report any tyrosine kinase inhibitors, rather than just imatinib mesylate.*Report if the recipient

*received any tyrosine kinase inhibitors (TKI). Examples of TKIs include Imatinib mesylate (Gleevec, Glivec, STI-571, or CGP57148B), dasitinib (Sprycel), and nilotonib.*Indicate “yes” or “no.”[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 158](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q155-315-pre-hct-preparative-regimen-conditioning#158):Based on the CIBMTR operational guidelines below, report if the regimen was myeloablative, reduced intensity, or non-myeloablative. The determination of whether the intent of the regimen was reduced intensity or non-myeloablative should be based either on the protocol at your center or the opinion of the physician overseeing the care of the recipient at your center.

*However, if there’s a protocol utilized at your center that doesn’t fall within CIBMTR operational guidelines for regimen intensity, you may report the regimen intensity based on the protocol intent.*[2450: Post-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[Questions 118-119](#404):From the list provided, indicate the reason the cells were infused.

*If there was more than one reason for the DCI, check all applicable indications.*If multiple DCIs were given within the 10-week period, check all applicable indications.

[2010: AML Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2010)[question 12](#404):If the patient is suspected to have had a preceding hematologic disorder, but it was not definitively documented or diagnosed, indicate “suspected” and continue with question

*14.*[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[questions 366-401](#404):If question 365 indicates that abnormalities were identified, each of questions 366-400 must be answered as “yes” or “no.” Do not leave any response blank. Indicate “yes” for each cytogenetic abnormality identified at any time prior to the start of the preparative regimen. Indicate “no” for all options not identified by cytogenetic assessment at any time prior to the start of the preparative regimen.

*For cases where AML has transformed from MDS, only report “yes” for cytogenetic abnormalities identified on or after the date of diagnosis for AML.*If one or more abnormalities are best classified as “other abnormality,” specify in question 401.[2800: Log of Appended Documents](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2800)**cibmtrrecipientforms@nmdp.org**.[2005: Confirmation of HLA Typing](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2005-confirmation-of-hla-typing)[question 4](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-12-donor-cord-blood-unit-identification#4):Indicate if the maternal HLA typing is available and continue with question 7; if yes, also complete Form 2005 reporting maternal HLA typing.

*The form will not come due on its own, so must be added by the data manager.***September 2015**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 9/27/15 |
|

[2100](#404)] [[2200](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q74-engraftment-syndrome)] Section:If this was an autologous or syngeneic HCT, continue with the Infection section at question 201.

[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)Immunofixation (IFE) and immunoelectrophoresis (IEP) are essentially measuring the same thing and either may be used to determine CR. Electrophoresis (SPEP and UPEP) are, however, different assessments.

[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)Does not meet the criteria for at least HI, but no evidence of disease progression

**to AML.**[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[MPN](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#MPN)criteria[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[2014: MDS/MPN Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)[2400](#404)] [[2014](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation#123)] to include RA, 5q- syndrome, MDS-U, and chronic eosinophilia transformations[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[myeloablative, reduced intensity, and non-myeloablative regimens table](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q155-315-pre-hct-preparative-regimen-conditioning#158)for**thiopeta.**Thiotepa ≥ (greater than or equal to) 10 mg/kg is myeloablative, and thiotepa < (less than) 10 mg/kg is non-myeloablative.[2450: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[65](#404):Cause of death is considered the main disease, complication, or injury that leads to death. Do not report the mode of death (e.g., cardiopulmonary arrest). Only one primary cause of death may be specified; however,

**under “HSCT-related causes,**” multiple contributing causes may be listed if relevant.[2450: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)However, if the recipient receives an autologous HCT as a result of a poor graft or graft failure, the TED form sequence

**will not**start over again. Generally this type of infusion (autologous rescue) is used to treat the recipient’s poor graft response, rather than to treat the recipient’s disease,[2028/2128: Aplastic Anemia](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/apl)[2028](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2028-aplastic-anemia-pre-hct)and[2128](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2128-aplastiv-anemia-post-hct)Aplastic Anemia Pre- and Post-HCT[2033/2133: Wiskott Aldrich Syndrome](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2033-2133-wiskott-aldrich-syndome-was)**Published new manual for**[2033](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2033-was-pre-hct-data)&[2131](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2133-was-post-hct-data)WAS Pre- and Post-HCT.**August 2015**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 8/28/15 |
|

**Published new manual for**[2031](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2031-immune-deficiencies-pre-hct)&[2131](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2131-immune-deficiencies-post-hct)Pre- and Post-HCT Immune Deficiencies Data[2047/2147: Hepatitis Serology](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2047-2147-hepatitis-serology)**Published new manual for**[2047](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2047-hepatitis-serology-pre-hct)&[2147](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2147-hepatitis-serology-post-hct)Hepatitis Serology Pre- and Post-HCT Data.[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[158](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q158-195-product-analysis-all-products#158):To assist centers in reporting product analysis timepoints, the CIBMTR has developed guidelines specific to the product type being reported.

…

This may be different than the date testing for cell counts or cell viability was performed.

*[see text for full detail]*[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[158](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q158-195-product-analysis-all-products#158):**This instruction is under review.**

If the product is thawed, but not retested prior to infusion, you can report the values prior to cryopreservation as “at infusion.” If a viability assessment is completed, ensure that it is reported accurately for the at infusion time point.

**July 2015**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/24/15 |
|

**Appendix M has been revised and combined with the former appendix U. Appendix U has been retired.**[Appendix O: How to Distinguish Infusion Types](#404)**A new revision of Appendix O has been published.****June 2015**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/26/15 | Modify | Updated/Added language to warnings in Chimerism Studies [
|

[525 [2400]](#404),[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#prog),[121](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q40-122-pre-hct-therapy#121)&[123 [2014]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q123-126-transformation#123),[30 [2114]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q21-31-relapse-or-progression-post-hct#30), and[63 [2015]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q63-64-transformation#63)to include the following concept:≥ 20% blasts in the

**blood or**bone marrow[2000: Recipient Baseline](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2000)[256-263](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q248-264-socioeconomic-information#256):Report the recipient’s source of health insurance as of the date of HCT. If the recipient carries more than one source, select “yes” for all that apply. For each option, select “yes” or “no” and do not leave any options blank. U.S.-based, government-sponsored health insurance should be reported in question(s) 256 and/or 257. Non-U.S.-based, government-sponsored health insurance (such as the National Health Service in the United Kingdom) should be reported in question 258.

*Insurance purchased through an U.S. Affordable Care Act Government Exchange should report this in questions 262-263.*If the recipient has a health insurance that is not listed, select “yes” for “other” and specify the health insurance in question 263.[AML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria)[AML CR](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/aml-response-criteria#CR):Alternative post-transplant CR criteria are accepted in the setting of

**pediatric**AML when the center does*not*routinely perform bone marrow biopsies post-transplant and the patient was in CR pre-transplant. These criteria are not used for pre-transplant AML disease status. The criteria are as follows:- Complete donor chimerism (≥ 95% donor chimerism without recipient cells detected)
- No extramedullary disease (e.g., CNS, soft tissue disease)
- Neutrophils ≥ 1,000/µL
- Platelets ≥ 100,000/µL
- Transfusion independent

[2118: LYM Post-HCT](#404)**METHOD**and**DATE**reporting in the[Q55-65: Disease Status at the Time of Evaluation for this Reporting Period](#404)section.*See text for full detail.*[2116: PCD Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2116-pcd-post-hct)**METHOD**and**DATE**reporting in the[Q102-136: Disease Status at the Time of Evaluation for this Reporting Period](#404)section just prior to[question 126](#404).*See text for full detail.*[2111: ALL Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111)**METHOD**and**DATE**reporting in the[Q73-96: Disease Status at the Time of Evaluation for This Reporting Period](#404)section.*See text for full detail.*[2110: AML Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2110)**METHOD**and**DATE**reporting in the[Q186-107: Disease Status at Last Evaluation Prior to the Start of the Preparative Regimen](#404)section.*See text for full detail.*[2450: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2450)[question 106](#404):The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). Indicate the date the sample was collected for examination for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments, or the date of physical examination.

[2100: 100 Days Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2100)[question 110](#404):*before*Day 0 as GVHD prophylaxis should be reported in the preparative regimen section on the Baseline Form (questions 107-111) and on the Pre-TED form (questions 168-172).

Report ATG given

*after*Day 0 as GVHD prophylaxis in the acute GVHD prophylaxis section on the 100 Day Post-HCT Data Form (questions 111-113) and on the Pre-TED form (questions 317-319).

Please note, ATG given pre and post transplant for GVHD prophylaxis would be reported in both the preparative regimen and GVHD prophylaxis sections of the Pre-TED form.

For ATG, Campath, and Cyclophosphamide: If these agents are given for GVHD prophylaxis both prior to and after Day 0, they must be reported in separate sections of the Pre-TED form, and Recipient Baseline Forms. Report doses given prior to Day 0 in the preparative regimen section of the Pre-TED (questions 168-315) and Recipient Baseline (107-242). If given after Day 0 as planned GVHD prophylaxis, report in the GVHD prophylaxis section of the Pre-TED (questions 316-341) and below.

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 168](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q155-315-pre-hct-preparative-regimen-conditioning#168)and before[question 316](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q316-341-gvhd-prophylaxis#316):[2000: Recipient Baseline](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2000)[question 105](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q76-247-pre-hct-preparative-regimen-conditioning#105):*given for GVHD prophylaxis prior to Day 0*should be reported in the preparative regimen section of the Baseline Form. If ATG, alemtuzumab, or cyclophosphamide is given

*after Day 0 for GVHD prophylaxis*, it should be reported in the acute GVHD prophylaxis section on the 100 Day Post-HCT Data form.

[151 [2100]](#404),[92 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q81-128-acute-graft-vs-host-disease-gvhd#92), and[22 [2300]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-58-acute-graft-vs-host-disease-gvhd#22):Indicate the maximum grade of acute GVHD present during this reporting period [including acute GVHD that persists from a previous HCT or donor cellular infusion (DCI)].

If acute GVHD was present, but the maximum grade was not documented nor is it able to be determined from the grading and staging table, leave the maximum overall grade blank and override the error as “Unknown.”

**Example 1:**A recipient developed stage 2 skin involvement and elevated liver function tests (LFTs) attributed to acute GVHD; however, there was no total bilirubin manifestation. In this case, overall maximum grade I acute GVHD should be reported since the staging/grading can be determined using Table 4 [2100, 2200] or 1 [2300].**Example 2:**A recipient developed acute liver GVHD with elevated LFTs with no total bilirubin manifestation. The progress notes indicate stage 1 (grade II overall) acute GVHD of the liver. In this case, the clinical manifestations do not fit the criteria used in Table 1; “present, grade unknown” would be the best option to report.[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[question 96](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q57-108-product-processing-manipulation#96):If antibodies were used during product manipulation, select “yes” and continue with question 97.

**However, it is not necessary to report antibody use as part of CD34+ enrichment using the CliniMacs, Isolex, or Miltenyi devices.**If antibodies were not used, select “no” and continue with question 109.[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[http://www.timeanddate.com/time/dst/](http://www.timeanddate.com/time/dst/)[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 97](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q94-154-comorbid-conditions#97):Hepatic (mild): Chronic hepatitis, bilirubin > upper limit of normal to 1.5x upper limit of normal, or AST/ALT > upper limit of normal to 2.5x upper limit of normal

*See note in question 96.*[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[question 6](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/recipient-data#6):There is an exception to this guidance.

**Do not report a 10-CBA recipient’s participation using this question**; select “no” for question 6 if the patient is enrolled in 10-CBA.[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[451](#404):Assessments for other molecular markers known or believed to be associated with ALLmay be performed. If these studies are performed, indicate

**“positive” or “negative”**and specify**the marker**in question 454.**If another molecular marker was not performed, select “not done.”**[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[403](#404):Assessments for other molecular markers known or believed to be associated with AML may be performed. If these studies are performed, indicate

**“positive” or “negative”**and specify**the marker**in question 411.**If another molecular marker was not performed, select “not done.”**[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[HI-P](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#hi):- For pre-
~~transplant~~**treatment**platelet count of > 20 ×109, platelet absolute increase of ≥ 30 ×109 - For pre-
~~transplant~~**treatment**platelet count of < 20 ×109, platelet absolute increase of ≥ 20 ×109and ≥ 100% increase from pre-treatment level

[15 [2450]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#15),[151 [2100]](#404),[92 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q81-128-acute-graft-vs-host-disease-gvhd#92), and[22 [2300]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-58-acute-graft-vs-host-disease-gvhd#22). See table for details.[291-295 [2100]](#404)and[231-235 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q201-237-infection#231):**Organism:**From the**drop down menu**, select the code corresponding to the identified or suspected organism ……

**Site:**From the**drop down menu**, select the code corresponding to the site of the infection…[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[451](#404):Assessments for other molecular markers known or believed to be associated with ALLmay be performed. If these studies are performed, indicate

**“positive” or “negative”**and specify**the marker**in question 454.**If another molecular marker was not performed, select “not done.”**[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[403](#404):Assessments for other molecular markers known or believed to be associated with AML may be performed. If these studies are performed, indicate

**“positive” or “negative”**and specify**the marker**in question 411.**If another molecular marker was not performed, select “not done.”**[83 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q81-128-acute-graft-vs-host-disease-gvhd#83),[137 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q129-200-chronic-graft-vs-host-disease-gvhd#137),[13 [2300]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-58-acute-graft-vs-host-disease-gvhd#13), and[67 [2300]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q59-130-chronic-graft-vs-host-disease-gvhd#67):Do not report the results of a biopsy performed in an earlier reporting period; only report histologic confirmation during the reporting period in which the specimen was collected.

**May 2015**


| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/29/15 | Modify | Modified text in questions
Report the total number of cells infused and specify the exponent for each cell type. If the cells were cryopreserved, report the totals after processing, but before cryopreservation. If multiple cellular infusions were given within the 10-week period, report the cumulative total of all cells infused; submit a log of appended documents showing the product analyses for each individual DCI product. |

[42 [2016]](#404),[249 [2016]](#404),[18 [2116]](#404), and[114 [2116]](#404):(total in g/dL of monoclonal protein) x (total urine volume) = urinary M-protein/24 hours

(0.145 g/dL of monoclonal protein) x (1500 mL total urine) x

**(1 dL/100 mL)**= 2.175 g/24 hours[2116: PCD Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2116-pcd-post-hct)[30](#404)and[126](#404):Flow cytometry is a technique that can be performed on blood, bone marrow, or tissue preparations where cell surface markers can be quantified on cellular material. Currently the CIBMTR forms do not contain fields to capture flow cytometry data. Since the sensitivity of flow cytometry is similar to that of FISH assays, flow cytometry data should be reported in question 31 [or 127].

**An exception to the note above applies to multiple myeloma.**If the flow cytometry assessment has < 5% malignant plasma cells, this result should not be reported because the result is not reliable; if no other cytogenetic or FISH assessments were performed, report “no.” However, if the flow cytometry assessment found ≥ 5% malignant plasma cells, this should be reported as evidence of disease.[2119: WM Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2119-wm-post-hct)[22-23](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q18-58-post-hct-therapy#22):**Indicate if the number of cycles is “known” or “unknown.” If known, report the number of cycles the recipient received during the reporting period for the line of therapy reported in question 23. If the therapy is not given in cycles or the number of cycles is not known, select “unknown” and continue with question 24.**[2116: PCD Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2116-pcd-post-hct)[67-68](#404):Indicate if the number of cycles is “known” or “unknown.” If known, report the number of cycles the recipient received

**during the reporting period**for the line of therapy being reported in question 68. If the therapy is not given in cycles or the number of cycles is not known, select “unknown” and continue with question 69.[2016: PCD Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)[363](#404)for clarity:**Example 1:**A 62-year-old man is diagnosed with IgG Kappa multiple myeloma. He receives initial therapy with 6 cycles of bortezomib and lenalidomide/dexamethasone; and achieves a near complete remission (nCR).**The comparison values used to determine disease status at transplant are the values obtained at diagnosis.**[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)[VGPR](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria#VGPR):… then a ≥ 90% decrease in the difference between involved and uninvolved free light chain levels is required in place of the M-protein criteria

**.**[619 [2400]](#404),[229 [2016]](#404),[363 [2016]](#404),[96 [2116]](#404), and[135 [2116]](#404):If the recipient had amyloidosis

**or POEMS syndrome,**but no evidence of myeloma, select “Not Applicable (**POEMS or**Amyloidosis with no evidence of myeloma)”[2016: PCD Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)[subsequent transplant text](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct#subs):If this is a report of a second or subsequent transplant for a

**different disease**(e.g., patient was previously transplanted for a disease other than Plasma Cell Disorder/Multiple Myeloma),**select “no” and**begin at question 1.[2000: Recipient Baseline](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2000)[question 4:](#404)If the recipient is White, Southeast Asian, or Pacific Islander, but a more specific Race Detail is not available, report the patient is “Other [White, Southeast Asian, or Pacific Islander respectively].

[2804: CIBMTR Research ID Assignment form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2804-cibmtr-research-id-assignment-form)[question 14](#404):- The National MDS Study: The National MDS Study refers to an NHLBI-sponsored study looking at the natural history of MDS; this is not the same as 10-CMSMDS-1, the HCT for MDS Medicare Study. If the individual’s data are being reported to the National MDS Study, continue with question 17.

[161-187 [2100]](#404),[102-128 [2200]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q81-128-acute-graft-vs-host-disease-gvhd#102), and[32-58 [2300]](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-58-acute-graft-vs-host-disease-gvhd#32):“Systemic” refers to drugs given by mouth, intramuscularly (IM), or intravenously (IV). “Topical” refers to drugs applied to the skin, eye drops, or inhalation therapy. An exception to this guidance would be the drugs budesonide

**and oral beclomethasone**. They are drugs given by mouth for treatment of gut GVHD, but considered a “topical” since they’re not absorbed.[MDS/MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[CR](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria#CR):In some cases, there may not be a four-week interval between completion of therapy and the pre-transplant disease assessment. In this case, CR should still be reported as the status at transplant since it represents the “best assessment” prior to HCT. This is an exception to the criteria that CR be durable beyond four weeks; the pre-transplant disease status should not be changed based on early relapse or disease assessment post-transplant.

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[main page](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400):and added information about autologous reporting:

“Centers are required to complete a Pre-TED Form (F2400) for all autologous transplant recipients, whether or not they agree to have their data used in research.

…

- Pre-TED data will make federally required annual Center Volumes report more complete and better able to inform the public about the types of HCTs occurring in the United States.”

[2400: Pre-TED](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2400)[Q159](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q155-315-pre-hct-preparative-regimen-conditioning#159):and added information about autologous reporting:

“Use the earliest date from questions 163, (radiation), or 170-236, 253-311 (systemic therapy) and 314. Additional radiation and/or intrathecal chemotherapy start dates may be prior to the date the preparative regimen began.”

[2000: Recipient Baseline](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2000)[Q78:](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q76-247-pre-hct-preparative-regimen-conditioning#78)and added information about autologous reporting:

“Use the earliest date from questions 82 (radiation), or 109-176 and 193-241 (systemic therapy). Additional radiation and/or intrathecal chemotherapy start dates may be prior to the date the preparative regimen began.”

[2006: Hematopoietic Stem Cell Transplant (HCT) Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2006-hematopoietic-stem-cell-transplant-hct-infusion)[questions 73-95:](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q57-108-product-processing-manipulation#73)**If the product is expanded, also report the expansion protocol under “other” in addition to checking “cultured.”**[2004: Infectious Disease Markers](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2004-infectious-disease-markers)[question 20:](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q10-46-infectious-disease-markers#20)“Non-U.S. centers should answer this question, regardless of FDA licensure.”

[2814: Indication for CRID Assignment](#404)[2804: CIBMTR Research ID Assignment form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2804-cibmtr-research-id-assignment-form)
Last modified:
Sep 10, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)