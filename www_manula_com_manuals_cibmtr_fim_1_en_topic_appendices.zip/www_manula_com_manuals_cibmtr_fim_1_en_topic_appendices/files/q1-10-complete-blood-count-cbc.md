#### Question 1: Date of complete blood count

Report the sample collection date of the complete blood count (CBC).

- Cellular therapy
- Post-infusion: Report the CBC date closest to the Day 30 evaluation.


- Gene therapy
- Pre-infusion: Report the CBC date closest to the marrow evaluation completed at the last evaluation prior to the preparative regimen / infusion (i.e., the closest CBC to the marrow evaluation reported on the corresponding Marrow Surveillance (3506) Form).
- Post-infusion: Report the CBC date closest to the marrow evaluation(s) completed in the current reporting period (i.e., the closest CBC to the marrow evaluation(s) reported on the corresponding Marrow Surveillance (3506) Form).


If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 2 – 10: CBC results

For each value below, specify the result and applicable units of measurement from the CBC date listed above. When necessary, convert the lab value to the unit available listed on the form.

If the value is not known, leave the value blank and override the FormsNet3SM error.

**WBC:**The white blood cell count (WBC) is a value that represents all the white blood cells in the blood. If the count is too high or too low, the ability to fight infection may be impaired.**RBC:**Red blood cell count (RBC) is a blood test that measures the number of erythrocytes circulating in your blood. Indicate if the recipient received RBC transfusion within 30 days prior to the date of the CBC test.**Hemoglobin:**A molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level.**Hematocrit:**The percentage (sometimes displayed as a proportion) of red blood cells relative to the total blood volume. A low hematocrit may require red blood cell transfusions or growth factors.**Platelets:**Platelets are formed elements within the blood that help with coagulation. A low platelet count, called thrombocytopenia, may lead to easy bleeding or bruising. Thrombocytopenia may require platelet transfusions. Indicate if the recipient received a platelet transfusion within 7 days prior to the CBC test.**Mean platelet volume:**The measurement of the average size of platelets. Report the mean platelet volume in femtoliters (fl).**Mean corpuscular volume (MCV):**The measurement of the average size of red blood cells.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Oct 27, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)