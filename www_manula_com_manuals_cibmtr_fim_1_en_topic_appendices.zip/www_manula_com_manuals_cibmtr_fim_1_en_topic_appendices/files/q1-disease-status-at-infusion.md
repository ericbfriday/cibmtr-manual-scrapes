#### Question 1: Disease status

A metastatic solid tumor is a cancer that has spread from its original location to another part of the body.

Locally advanced refers to a cancerous tumor that has grown significantly within its original site in the body but has not yet become metastatic.

An unresectable solid tumor is a malignant solid tumor that cannot be removed by surgery.

Indicate if the tumor treated with Tecelra® (afamitresgene autoleucel) was either **Metastatic** or **Locally advanced / unresectable** prior to the start of the preparative regimen. This will be documented in a note by the physician.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Last modified:
Jan 27, 2025

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)