#### Questions 142 – 148: Were any other genetically related family members affected?

Indicate **Yes** or **No** if any other genetically related family members have been diagnosed with Fanconi Anemia. This includes a sibling, cousin, parent, aunt / uncle, or other genetically related family member as specified in questions 143 – 148.

If any genetically related family member has been diagnosed with Fanconi Anemia, select **Yes** and specify the family member in questions 143 – 148 by reporting **Yes** or **No**. If a genetically related family member is not listed as an option on the form, select **Yes** for “other relative” (question 147) and specify the family member in question 148.

If the recipient does not have a genetically related family member that has been diagnosed with Fanconi Anemia or it is not known if any genetically family members have been diagnosed with Fanconi Anemia, select **No** or **Unknown**, respectively, and proceed to question 149.

#### Question 149: Is the recipient genetically related to his / her parents?

Indicate if the recipient is genetically related to his / her parents.

If it is not known and/or cannot be determined if the recipient is biologically related to the mother and / or father, select **Unknown**.

#### Questions 150 – 151: Were the donor’s blood or bone marrow cells tested for sensitivity to cross-linking agents? (Related donors only)

Studies that measure the sensitivity of a recipient’s cells to cross-linking agents (i.e., chromosome breakage studies) are often performed for patients with anemia.

If the related donor’s cells were tested for sensitivity to these agents, at any time prior to the start of the preparative regimen, select **Yes** and specify the date the sample was collected for analysis. Do not report the date of testing as the question indicates.

If tests for sensitivity to cross-linking agents were not performed prior to the start of the preparative regimen or it is not known if these tests were performed, report **No** or **Unknown**, respectively and continue with question 163.

#### Questions 152 – 153: Specify the type of cross-linking agents used (on the related donor’s blood or bone marrow)

Cells from patients with Fanconi Anemia are hypersensitive to bifunctional alkylating agents, such as diepoxybutane and mitomycin C (MMC).

Indicate if **Diepoxybutane** or **Mitomycin C (MMC)** was used as the cross-linking agent. If another cross-linking agent was used (such as CIS platinum) select **Other agent** and specify the type of cross-linking agent in question 153.

#### Question 154: Were chromatid aberrations present on an unstressed preparation? (of the related donor’s blood or bone marrow)

Chromatid aberrations may be noted on the *donor’s* karyotype report. There are four major types of chromosomal aberrations as described below:

- Deletion: The loss of genetic material. It can be as small as a single missing DNA base pair or as large as missing a piece of a chromosome.
- Duplication: The production of one or more copies of a gene or region of a chromosome.
- Inversion: A chromosome rearrangement in which a segment of a chromosome is reversed end to end.
- Translocation: The movement of a portion of one chromosome to another.

If any of the above aberrations were present on an unstressed preparation, select **Yes** and proceed to question 155 – 157.

If chromatid aberrations were not present on an unstressed preparation, select **No** and continue with question 158.

If the sample was not evaluable, select **Not evaluable** and proceed to question 158.

#### Questions 155 – 157: Specify results

Indicate the total number of cells studied, the total number of cells with aberrations, and the total number of cells without aberrations as indicated on the pathology report.

report.

#### Question 158: Were chromatid aberrations present on a stressed preparation?

A chromosomal breakage test is an important tool in the diagnosis of Fanconi Anemia and is performed by confirming an increased chromosomal breakage rate in peripheral blood lymphocytes in the presence of an alkylating agent such as Mitomycin C (MMC), which interferes with the cell’s DNA. This test is also known as the MMC stress test. While it can be a helpful tool in distinguishing idiopathic aplastic anemia from Fanconi Anemia, these tests have largely been replaced by molecular marker mutation panels.

Chromatid aberrations may be noted on the donor’s karyotype report. There are four major types of chromosomal aberrations as described below:


- Deletion: The loss of genetic material. It can be as small as a single missing DNA base pair or as large as missing a piece of a chromosome.
- Duplication: The production of one or more copies of a gene or region of a chromosome.
- Inversion: A chromosome rearrangement in which a segment of a chromosome is reversed end to end.
- Translocation: The movement of a portion of one chromosome to another.

If any of the above aberrations were present on a stressed preparation, select **Yes** and proceed to question 159 – 161.

If chromatid aberrations were not present on a stressed preparation, select **No** and continue with question 161.

If the sample was not evaluable, select **Not evaluable** and proceed to question 162.

#### Questions 159 – 161: Specify results

Indicate the total number of cells studied, the total number of cells with aberrations, and the total number of cells without aberrations as indicated on the pathology report.

#### Question 162: Is a copy of the report attached?

Indicate if a report is attached to support the reported chromatid aberrations present in questions 150 – 161. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Question 163: Was the recipient treated with androgens prior to HCT?

Androgens are male hormones that stimulate production of red blood cells, white blood cells, and platelets in those who have been diagnosed with Fanconi Anemia. While not a permanent cure, androgens can prolong the life of a patient when treatment is started at an early stage.

Indicate **Yes** or **No** if the recipient was given androgens at any time prior to the start of the preparative regimen / infusion. Examples of androgens include, but are not limited to the following:


- Danazol (Danacrine) ®)
- Fluoxymestrone (Halotestin®)
- Oxymetholone
- Stanazolol (Winstrol®)
- Testosterone

If it is not known if the recipient was treated with androgens at any time prior to the start of the preparative regimen / infusion, select **Unknown**.

#### Question 164: Was the recipient treated with corticosteroids prior to HCT?

Corticosteroids are synthetic drugs that are used to treat a wide variety of disorders, including asthma, arthritis, skin conditions, and autoimmune disease. The drug mimics cortisol, a hormone that’s naturally produced by the adrenal glands in healthy individuals.

Indicate **Yes** or **No** if the recipient was treated with systemic corticosteroids within six months of HCT. Do not report topical steroids.

If it is not known if the recipient was treated with corticosteroids within six months prior to the start of the preparative / regimen, select **Unknown**.

#### Questions 165 – 173: Did the recipient receive growth factors prior to HCT?

Growth factors are secreted biologically active molecules that can affect the growth of cells. Specifically, hematopoietic growth factors are hormone-like substances that stimulate the bone marrow to produce blood cells.

Indicate **Yes** or **No** if the recipient was given growth factors at any time prior to the start of the preparative regimen / infusion. Examples of growth factors include, but are not limited to the following:


- Granulocyte colony-stimulating factor (G-CSF)
- Eltrombopag (Promacta) ®)

If it is not known if the recipient was treated with growth factors at any time prior to the start of the preparative regimen / infusion, select **Unknown**.

#### Questions 174 – 175: Did the recipient receive red blood cell transfusions between diagnosis and the start of the preparative regimen?

If the recipient received any red blood cell transfusions between the diagnosis of Fanconi Anemia and start of the preparative regimen / infusion, select **Yes** and based on best estimate, specify the total number of donor exposures.

**Example**: If a progress notes from a referring physician states the recipient received one red blood cell transfusion a month for one year and then two transfusions monthly for six months before arriving at your center for HCT (i.e., 24 RBC transfusions prior to the preparative regimen), indicate that the recipient had 21-30 donor exposures between diagnosis and the start of the preparative regimen.

If the recipient did not receive red blood cell transfusions between diagnosis and prior to the preparative regimen, indicate **No** and continue with question 176.

#### Question 176: Did the recipient receive platelet transfusions in the four weeks prior to the preparative regimen?

Indicate **Yes** or **No** if the recipient received any platelet transfusions in the four weeks prior to the start of the preparative regimen.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)