Tepadina® Supplemental post-HCT Data Collection Form, Form 2540, must be completed for recipients who are enrolled onto CIBMTR study SC17-03. This is a multi-center, prospective, observational post-authorization long-term study of the use of thiotepa as part of a high-dose chemotherapy regimen followed by hematopoietic stem cell transplantation (HCT) in Canadian and American recipients. U.S. recipients are eligible if they have received an autologous HCT for primary CNS lymphoma or any lymphoma with CNS involvement. Canadian recipients are eligible after allogeneic or autologous HCT and have received Tepadina.

This supplemental data form, Form 2540, will come due for participating centers when thiotepa is reported as part of the conditioning regimen, and the Recipient Eligibility Form, Form 2500, indicates that “Adienne Tepadina®” was the brand of thiotepa given to the recipient. Supplemental data collection form will be completed at the 100 day through 5-year time points post-HCT.

Links to Sections of the Form:

[Q1-2: Tepadina® Stop Date](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-2-tepadina-stop-date)

[Q3-35: Hematologic Findings](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q3-35-hematologic-findings)

[Q36-82: Organ Function](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q36-82-organ-function)

[Q83-88: Data from Post-HSCT Follow-Up Form](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q83-88-data-from-post-hsct-follow-up-form-2100)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please click [here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals webpage](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx).

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/26/19 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)