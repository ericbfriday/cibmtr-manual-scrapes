The Neuroblastoma Post-HCT Data Form is one of the Comprehensive Report Forms. This form captures neuroblastoma (NEU) post-HCT data for the reporting period.

This form must be completed for all recipients whose primary disease, as reported on the Pre-TED Disease Classification (2402) Form, is **Neuroblastoma** (NEU) under **Solid tumors**. The Post-HCT Neuroblastoma (2126) Form must be completed in conjunction with each Post-HCT Follow-up (2100) Form. This form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100; between day 100 and the six-month date of contact for six-month follow-up; and between the date of contact for the six-month follow-up and the date of contact for the one-year follow-up, etc

Links to Sections of Form

[Q1 – 159: Disease Assessments at Time of Best Response to HSCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-159-disease-assessments-at-time-of-best-response-to-hsct)

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Pages/index.aspx) webpage.

| Date | Manual Section | Add/ Remove/Modify | Description |
|---|---|---|---|
| 1/25/2021 | 2126: Neuroblastoma Post-Infusion | Add | Version 1 of the Neuroblastoma Post-Infusion section of the Forms Instructions Manual released. Version 1 corresponds to revision 2 of the Form 2126. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)