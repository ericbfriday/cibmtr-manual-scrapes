The Thalassemia Post-Infusion (2158) Form is one of the Comprehensive Report Forms. This form captures thalassemia-specific post-infusion data such as the recipient’s thalassemia diagnosis, donor related information, transfusion, hepatic, cardiac, renal, iron overload assessment prior to the start of the preparative regimen, hematologic labs, organ impairment, and pre-infusion therapy.

This form must be completed for all transplant and gene therapy recipients, randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported as **Hemoglobinopathies – Transfusion dependent thalassemia: Transfusion beta dependent thalassemia** or **Other transfusion dependent thalassemia** on the Disease Classification (2402) Form.

Links to Sections of Form:

[Q1 – 15: Post-Infusion Disease Testing](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-15-post-infusion-disease-testing)

[Q16 – 17: Transfusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q16-17-transfusion-therapy)

[Q18 – 29: Treatment](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q18-29-treatment)

[Q30 – 31: Splenic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q30-splenic-assessments)

[Q32 – 55: Hepatic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q31-54-hepatic-assessments)

[Q56 – 68: Cardiac Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q63-67-cardiac-assessments)

[Q67 – 73: Renal Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q64-66-renal-assessments)

[Q74 – 76: Avascular Necrosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q74-76-avascular-necrosis)

[Q77: Other Symptoms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q77-other-symptoms)

[Q78 – 92: Additional Iron Overload Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q67-81-additional-iron-overload-assessments)

[Q93 – 101: Additional Hematologic Labs](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q82-90-additional-hematologic-labs)

[Q102 – 113: Specify Existing Other Organ Impairments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q91-102-specify-existing-organ-impairments)

[Q114 – 121: Disease Modifying Therapies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q103-110-disease-modifying-therapy)

[Q122: Marrow Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q122-marrow-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/25/2024 |
|

*This section is only completed for*~~gene therapy~~ Zynteglo® infusions.[2158: Thalassemia Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2158-thalassemia-post-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)