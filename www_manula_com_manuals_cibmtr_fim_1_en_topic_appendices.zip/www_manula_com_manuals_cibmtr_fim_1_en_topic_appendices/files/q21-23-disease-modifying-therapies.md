#### Question 21-23: Hemoglobin

The intent of this question is to capture the hemoglobin level and date PRIOR TO the *first* disease modifying therapy administered as reported on the corresponding Thalassemia Post-Infusion (2158) Form for the same reporting period.

Indicate if the hemoglobin level PRIOR TO the first disease modifying therapy is **Known**

or **Unknown**.

If **Known**, report the hemoglobin count and the unit of measure as documented on the laboratory report and the date (YYYY-MM-DD). If there are multiple hemoglobin assessments prior to starting the first disease modifying therapy, report the most recent assessment.

If the exact date is not known report an estimated date and check the **Date Estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

If disease modifying therapy was started in a prior reporting period, select **Previously reported**, regardless of if the hemoglobin value was known prior to treatment.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)