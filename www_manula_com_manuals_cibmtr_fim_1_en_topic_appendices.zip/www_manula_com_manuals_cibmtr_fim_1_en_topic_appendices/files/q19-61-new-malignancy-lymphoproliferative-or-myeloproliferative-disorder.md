#### Question 47. Did a new malignancy, myeloproliferative, or lymphoproliferative disease / disorder occur that is different from the disease / disorder for which the HCT or cellular therapy was performed? (include clonal cytogenetic abnormalities, and post-transplant lymphoproliferative disorders)

Indicate whether a new or secondary malignancy, lymphoproliferative disorder, or myeloproliferative disorder has developed. Do not report recurrence, progression, or transformation of the recipient’s primary disease (disease for which the transplant was performed), or relapse of a prior malignancy.

New malignancies, lymphoproliferative disorders, or myeloproliferative disorders include but are not limited to:


- Skin cancers (basal, squamous, melanoma)
- New leukemia
- New myelodysplasia
- Solid tumors
- PTLD (post-transplant lymphoproliferative disorder) (report as NHL)

The following should **not** be reported as new malignancy:


- Recurrence of primary disease (report as relapse or disease progression)
- Relapse of malignancy from recipient’s pre-HCT medical history
- Breast cancer found in other (i.e., opposite) breast (report as relapse)
- Post-HCT cytogenetic abnormalities associated with the pre-HCT diagnosis (report as relapse)
- Transformation of MDS to AML post-HCT (report as disease progression)

If a new malignancy, lymphoproliferative disorder, or myeloproliferative disorder was diagnosed during the reporting period, report **Yes** and complete the Subsequent Neoplasms (3500) Form, which will come due.

The **Previously reported** option should only be used if the same malignancy has already been reported on a Subsequent Neoplasms (3500) form that was made do on demand. See examples below. If it is unclear whether or not to use this option, contact CIBMTR Center Support if there are questions.

Example 1. A recipient developed a new malignancy at Day +68 and is reported at the time the Day 100 Post-Infusion Follow-up (2450) form is completed. In this scenario, report Yes, the recipient developed a new malignancy, and a Subsequent Neoplasms (3500) form will be completed to report the new malignancy information. For all future reporting periods, select **No**.

Example 2. A recipient developed a new malignancy during the seven-year reporting period and the transplant center decided to create the Subsequent Neoplasms (3500) form as an unscheduled form in FormsNet3SM to report the new malignancy information immediately since a Post-Infusion Follow-Up for seven-year reporting period will not come due. When the eight-year Post-Infusion Follow-Up (2450) form is completed, **Previously reported**, will be reported since a prior Subsequent Neoplasms (3500) form has already been submitted for the new malignancy.

Example 3. A recipient was diagnosed with basal cell skin cancer on the neck in the one-year reporting period and two months later, within the same reporting period, there was a diagnosis of basal cell located on the nose. The lesion on the nose is not considered a metastasis from the neck, but a new discreet lesion. Report **Yes**, there was a new malignancy on the Post-HCT Follow-Up (2450), and a single Subsequent Neoplasms (3500) form will come due to report one of the basal cell malignancies. Create a second Subsequent Neoplasms (3500) form to report the other basal cell malignancy as these are discreet episodes.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)