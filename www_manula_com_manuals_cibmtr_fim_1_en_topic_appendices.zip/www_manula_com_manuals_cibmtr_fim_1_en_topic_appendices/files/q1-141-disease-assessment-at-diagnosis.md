#### Question 1: What was the date of diagnosis of Fanconi Anemia?

Report the date of first pathological evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear) that determined the diagnosis of Fanconi anemia. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared. The date of diagnosis is important because the interval between diagnosis and HCT is often a significant indicator for the recipient’s prognosis post-HCT.

If the recipient was diagnosed prenatally (in utero), report the date of birth as the date of diagnosis.

If the exact pathological diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 2 – 7: Was the diagnosis made in utero?

Indicate if the diagnosis was made in utero (i.e., prior to birth). If the diagnosis was made in utero, report **Yes** and specify the test(s) performed (see below).


**Amniocentesis**: A hollow needle is inserted into the uterus to collect a sample of amniotic fluid in order to screen for developmental abnormalities in a fetus.**Chorionic villous sampling (CVS)**: In early pregnancy a tissue sample is taken from the villi of the chorion (this forms the fetal part of the placenta) in order to detect congenital abnormalities in the fetus**Fibroblasts**: In utero chromosome analysis of skin fibroblasts.**Other test**: If a test was used and is not listed above, select Yes and specify the testing method in question 7. This option should rarely be used as many of the diagnostic tests used in utero are listed above.

If the diagnosis was not made in utero, select **No** and proceed to question 8.

#### Questions 8 – 29: Was the recipient diagnosed with any congenital abnormalities?

Report if the recipient was diagnosed with any congenital abnormalities, which includes structural or functional anomalies that occur during intrauterine life.

For each question in this section, indicate if the recipient was diagnosed with any congenital abnormality(ies). Examples of congenital abnormalities listed in each question may include, but are not limited to those listed below:

**Abnormal facies**such as snub nose, thick upper lip, epicanthic folds, or hypertelorism (an increased distance between two body parts (i.e., eyes).**Ear abnormalities**such as any abnormal ear anatomy and function. This also includes hearing loss or congenital ear malformations such as undeveloped/small external auditory canal, hypoplastic tympanic membrane, bony plate under the eardrum, or dysmorphic ear ossicles.**Eye abnormalities**such as strabismus, cataract, microphthalmia, short or almond shaped palpebral fissures, epicanthic folds, microcornea, ptosis, steep corneal curvatures, small optic discs, and delay in visual processing skills.**Other neurologic abnormalities**such as hydrocephalus, Bell’s palsy, CNS arterial malformations, abnormal pituitary, absent septum pellucidum/corpus callosum, hyperreflexia, neural tube defection, Arnold-Chiari malformation, Moyamoya disease, or single ventricle.**Microcephaly**which includes smallness of the head that may be associated with incomplete brain development.**Palate or jaw abnormalities**such as cleft lip and / or palate, Pierre Robin syndrome, small jaw or mouth.**Abnormal neck**such as short or webbed neck.**Cardiac abnormalities**which includes a patent ductus arteriosus, ventricular septal defect, pulmonic or aortic stenosis, coarctation of the aorta, double aortic arch, cardiomyopathy, tetralogy of Fallot, or pulmonary atresia.**Exocrine pancreatic deficiency**such as associated with steatorrhea and growth failure / failure to thrive.**Gastrointestinal abnormalities**which includes esophageal atresia, duodenal atresia, anal atresia, tracheoesophageal fistula, annular pancreas, intestinal malrotation, intestinal obstruction, duodenal web, biliary atresia, foregut, or duplication cyst.**Genital abnormalities**:- Males: Micropenis, penile / scrotal fusion, undescended or atrophic or absent testes, hypospadias, chordee, phimosis, or azoospermia.
- Females: Bicornate uterus, aplasia or hypoplasia of vagina and uterus, atresia of vagina, hypoplastic uterus, hypoplastic / absent ovary, or hypoplastic/fused labia.

**Kidney or urinary tract abnormalities**such as ectopic, horseshoe, rotated, hypoplastic or absent, dysplastic, hydronephrosis, hydroureter, urethral stenosis, or reflux.**Thumb abnormalities**which may include underdeveloped, missing, or duplicate thumb(s).**Radius abnormalities**which may include shortened or missing radius or curved forearm.**Other skeletal abnormalities**such as syndactyly, clinodactyly, abnormal ribs, metaphyseal dyschondroplasia, hand that develops perpendicular to the forearm, or impaired movement in the wrist, fingers, and elbow.**Café au lait spots**such as flat patches anywhere on the skin that are darker than the surrounding area.**Other skin abnormalities**include congenital skin abnormalities not already listed above. If the recipient had other skin abnormalities such as irregular skin coloring (i.e. hypopigmentation), select**Yes**for question 26 and specify the other skin abnormality.**Other congenital abnormalities**: If the recipient was diagnosed with a congenital abnormality that was not listed above, select**Yes**in question 28 and specify the congenital abnormality in question 29. This option should rarely be used as the most pertinent congenital abnormalities are listed above.

#### Question 30: Specify the date that abnormal blood results were first observed

Report the first date the blood sample was collected and showed abnormal blood results. Abnormal blood results include cytopenias such thrombocytopenia (decrease platelet count), leukopenia (decreased white count), or anemia (decreased hemoglobin/hematocrit). Seek physician clarification, as needed, if the date of the first abnormal blood results is unclear.

#### Questions 31 – 35: Specify the presenting hematologic disorder

Specify the recipient’s presenting hematologic disorder from the following options: acute leukemia, cytopenia, myelodysplasia, or other disorder.

If the recipient’s presenting hematologic disorder was a deficiency of red blood cells, white blood cells, or platelets, select **Cytopenia** and specify the cytopenia.

**Anemia**: Hemoglobin value of < 10 g / dL**Thrombocytopenia**: Low platelet count measuring < 100, 000 / mm3**Neutropenia**: Absolute neutrophil count (ANC) < 1,000 / mm3

If the recipient had a different hematologic disorder not listed, select **Other disorder** and specify the other hematologic disorder is question 35.

#### Questions 36 – 37: Was the bone marrow examined at diagnosis?

Indicate whether a bone marrow examination was performed at diagnosis of Fanconi Anemia. If a bone marrow examination was performed, select **Yes** and report the date of the bone marrow biopsy. If multiple bone marrow examinations were performed prior to the start of therapy, report the date of the most recent bone marrow assessment prior to the initiation of the first line of therapy.

If a bone marrow examination was not performed at diagnosis or it is not known if one was performed, report **No** or **Unknown**, respectively, and continue with question 41.

#### Question 38: Specify cellularity

Cellularity describes the percentage of bone marrow occupied by hematopoietic cells compared to other tissues, such as adipose (fat) cells. Cellularity may be increased (hypercellular), normal (normocellular), or decreased (hypocellular). This distinction is made on the pathology report of a bone marrow examination.

Indicate whether the diagnostic bone marrow examination (reported in question 37) revealed **Decreased**, **Normal**, or **Increased** cellularity.

If the degree of cellularity is not addressed in the report, select **Unknown**.

#### Question 39: Were dysplastic features present at diagnosis?

Indicate **Yes** if dysplastic features were present at diagnosis as listed on bone marrow biopsy report (reported in question 37) obtained at diagnosis of Fanconi Anemia.

If the bone marrow biopsy report does not indicate dysplastic features, indicate **No** or if the report is not clear if dysplastic features were present, select **Unknown**.

#### Question 40: Blasts in marrow

Report the percentage of blasts in the bone marrow as indicated on the bone marrow pathology report (reported in question 37).

If multiple methods were used to detect the percentage of blasts in the bone marrow, the aspirate differential is the most preferred method followed by flow cytometry and IHC.

#### Question 41: Was the bone marrow karyotyping present at diagnosis?

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.cibmtr.org/manuals/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

If karyotyping was performed on the bone marrow at diagnosis of Fanconi Anemia, indicate **Yes** and continue with question 42.

If bone marrow karyotyping was performed, but the sample was inadequate, indicate **No evaluable metaphases**, and proceed to question 79.

If karyotyping was not performed on the diagnostic bone marrow of Fanconi Anemia, indicate **No** and proceed to question 79.

If it is not known whether any bone marrow karyotyping studies were performed, indicate **Unknown** and proceed to question 79. This option should be used sparingly and only when there is no documentation to confirm if karyotyping was or was not performed at diagnosis.

#### Question 42: Was karyotype normal?

Indicate if the results of the karyotype performed on the diagnostic bone marrow were normal, either [46,XX] or [46,XY]. If the karyotype did not detect any abnormalities, select **Yes** and proceed to question 77.

If the results of the diagnostic bone marrow karyotyping detected abnormalities, indicate **No**.

#### Questions 43 – 76: Specify abnormalities identified

Specify all cytogenetic abnormalities detected in the diagnostic bone marrow biopsy (reported in question 37). Indicate **Yes** for each cytogenetic abnormality identified at diagnosis / prior to the start of first therapy. Indicate **No** for all options not identified on cytogenetic assessment at diagnosis / prior to the start of first therapy. If an abnormality is detected but not listed as an option, select **Yes** for “other abnormality” and specify the abnormality in question 76.

If multiple “other abnormalities” were detected, report “see attachment” in question 76 and attach the final report(s) for any other abnormalities detected at diagnosis. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Questions 77 – 78: Date of karyotyping

Report the date the sample was collected for bone marrow karyotyping and indicate if documentation was submitted to the CIBMTR. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Questions 79 – 89: Was complementation group testing performed at any time prior to the preparative regimen?

Complementation testing is performed to identify if two mutations occur on the same gene. If the mutations are located on the same gene then the mutations are not complementary. Eight complementation groups have been identified in Fanconi Anemia, each of which is thought to be related to a distinct Fanconi Anemia (FA) gene.

Select **Yes** if complementation testing was performed at any time prior to the preparative regimen / infusion and indicate **Yes** or **No** to specify the group(s) identified. If a group was identified but not listed as an option, select **Yes** for “other group” and specify the group type in question 88.

In addition, indicate if documentation was submitted to the CIBMTR to support the complementation group testing reported in questions 79 – 88. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

Select **No** if complementation testing was not performed at any time prior to the start of the preparative regimen / infusion and proceed to question 90.

#### Questions 90 – 92: Were any genetic mutations identified?

Indicate **Yes** or **No** if any genetic mutations (as listed in Q80-88) were identified at diagnosis of Fanconi Anemia. If any genetic mutations were identified, specify the mutation origin.

If a maternal mutation was detected, questions 105-116 will be required to be answered. If a paternal mutation was identified, questions 117- 128 will be required to be answered.

If genetic mutations were not identified, select **No** and, proceed to question 93 and, proceed to question 93.

#### Questions 93 – 94: Was a mutation analysis of cloned Fanconi Anemia genes performed at any time prior to the preparative regimen?

Oftentimes, at the diagnosis of Fanconi Anemia, a mutation analysis is performed to detect a specific variant or mutation, panel of variants, or type of variant. This type of analysis may be performed by Multiplex Ligation-Dependent Amplification or PCR-Based Sanger Sequencing.

If a mutation analysis was performed at any time prior to the start of the preparative regimen / infusion, select **Yes** and specify the date the sample was collected for analysis (not the date of the analysis) in question 94.

If a mutation analysis was not performed or if it unknown whether this analysis was performed prior to the start of the preparative regimen / infusion, select **No** or **Unknown**, respectively.

#### Questions 95 – 104: Specify mutation(s) and specify value

Specify the mutation(s) identified by the mutation analysis reported in questions 93 – 94 by indicating **Yes** or **No**. If the mutation was identified, specify the value and mutation type. For questions 95 – 103, indicate **Yes** or **No** for each mutation type.


**Exon**: An exon is part of a gene sequence that’s expressed in a protein. A mutation occurs when pieces of the gene are deleted. Deletions of one or more exons are the most common type of mutation.**Intron**: An intron is part of a gene sequence that does not code for amino acids (i.e., proteins).**Nucleotide change**: The type of mutation involving a nucleotide change is known as a point mutation. They occur when a nucleotide is switched for another nucleotide, the nucleotide is deleted, or a single nucleotide is inserted into a DNA sequence that causes the DNA to be different from normal.**Amino acid change**: The type of mutation involving an amino acid change is known as a missense mutation. The amino acid mutation may have no effect or may render the protein nonfunctional.**Specify**if the mutation type was a substitution, deletion, or insertion.**Substitution**: A type of mutation that exchanges one base for another (e.g., switching Alanine (A) to Glycine (G)).**Deletion**: A type of mutation involving the loss of genetic material. It can be small, involving a single missing DNA base pair, or large, involving a piece of a chromosome.**Insertion**: A type of mutation involving the addition of genetic material. It can be small, involving a single extra DNA base pair, or large, involving a piece of a chromosome.


Lastly, indicate in question 104, if documentation was submitted to the CIBMTR to support the mutation analysis reported in questions 93 – 103. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Questions 105: Maternal Mutation Analysis – Was a mutation analysis of cloned Fanconi Anemia genes performed at any time prior to the preparative regimen?

If a mutation analysis was performed at any time prior to the start of the preparative regimen / infusion, select **Yes** and specify the date the sample was collected for analysis (not the date of analysis as the question indicates) in question 106.

If a mutation analysis was not performed or if it unknown whether this analysis was performed prior to the start of the preparative regimen / infusion, select **No** or **Unknown**, respectively.

#### Question 106: Specify the date the analysis was performed

Report the date the sample was collected for analysis (not the date of analysis as the question indicates).

#### Questions 107 – 116: Specify maternal mutation(s) and specify value

For questions 107 – 115, indicate **Yes** or **No** for each mutation type.


**Exon**: An exon is part of a gene sequence that’s expressed in a protein. A mutation occurs when pieces of the gene are deleted. Deletions of one or more exons are the most common type of mutation.**Intron**: An intron is part of a gene sequence that does not code for amino acids (i.e., proteins).**Nucleotide change**: The type of mutation involving a nucleotide change is known as a point mutation. They occur when a nucleotide is switched for another nucleotide, the nucleotide is deleted, or a single nucleotide is inserted into a DNA sequence that causes the DNA to be different from normal.**Amino acid change**: The type of mutation involving an amino acid change is known as a missense mutation. The amino acid mutation may have no effect or may render the protein nonfunctional.**Specify**if the mutation type was a substitution, deletion, or insertion.**Substitution**: A type of mutation that exchanges one base for another (e.g., switching Alanine (A) to Glycine (G)).**Deletion**: A type of mutation involving the loss of genetic material. It can be small, involving a single missing DNA base pair, or large, involving a piece of a chromosome.**Insertion**: A type of mutation involving the addition of genetic material. It can be small, involving a single extra DNA base pair, or large, involving a piece of a chromosome.


Lastly, in question 116, indicate if documentation was submitted to the CIBMTR to support the mutation analysis reported in questions 105 – 115. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Question 117: Paternal Mutation Analysis – Was a mutation analysis of cloned Fanconi Anemia genes performed at any time prior to the preparative regimen?

If a mutation analysis was performed at any time prior to the start of the preparative regimen, select **Yes** and proceed to question 118.

If a mutation analysis was not performed or if it unknown whether this analysis was performed, select the appropriate response and proceed to question 129.

#### Question 118: Specify the date the analysis was performed

Report the date the sample was collected for analysis (not the date of analysis as the question indicates).

#### Questions 119 – 128: Specify paternal mutation(s) and specify value

For questions 119 – 127 indicate **Yes** or **No** for each mutation type.

**Exon**: An exon is part of a gene sequence that’s expressed in a protein. A mutation occurs when pieces of the gene are deleted. Deletions of one or more exons are the most common type of mutation.**Intron**: An intron is part of a gene sequence that does not code for amino acids (i.e., proteins).**Nucleotide change**: The type of mutation involving a nucleotide change is known as a point mutation. They occur when a nucleotide is switched for another nucleotide, the nucleotide is deleted, or a single nucleotide is inserted into a DNA sequence that causes the DNA to be different from normal.**Amino acid change**: The type of mutation involving an amino acid change is known as a missense mutation. The amino acid mutation may have no effect or may render the protein nonfunctional.**Specify**if the mutation type was a substitution, deletion, or insertion.**Substitution**: A type of mutation that exchanges one base for another (e.g., switching Alanine (A) to Glycine (G)).**Deletion**: A type of mutation involving the loss of genetic material. It can be small, involving a single missing DNA base pair, or large, involving a piece of a chromosome.**Insertion**: A type of mutation involving the addition of genetic material. It can be small, involving a single extra DNA base pair, or large, involving a piece of a chromosome.


Lastly, in question 128, indicate if documentation was submitted to the CIBMTR to support the mutation analysis reported in questions 117 – 127. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Question 129: Were the recipient’s bone marrow cells or peripheral blood mononuclear cells tested for sensitivity to cross-linking agents?

Studies that measure the sensitivity of a recipient’s cells to cross-linking agents (i.e., chromosome breakage studies) are often performed for patients with anemia.

If the recipient’s cells were tested for sensitivity to these agents at any time prior to the start of the preparative regimen / infusion, select **Yes** and specify the date of testing. Report the date the sample was collected for analysis.

If tests for sensitivity to cross-linking agents were not performed at any time prior to the start of the preparative regimen / infusion or it is not known if these tests were performed, report **No** or **Unknown**, respectively and continue with question 142.

#### Question 130: Specify the date the testing was performed

Report the date the sample was collected for analysis (not the date of testing as the question indicates).

#### Questions 131 – 132: Specify the type of cross-linking agent used

Cells from patients with Fanconi Anemia are hypersensitive to bifunctional alkylating agents, such as diepoxybutane and mitomycin C (MMC).

Indicate if **Diepoxybutane** or **Mitomycin C (MMC)** was used as the cross-linking agent. If another cross-linking agent was used (such as CIS platinum) select **Other agent** and specify the type of cross-linking agent in question 132.

#### Question 133: Were chromatid aberrations present on an unstressed preparation?

Chromatid aberrations may be noted on the recipient’s karyotype report. There are 4 major types of chromosomal aberrations as described below:


- Deletion: The loss of genetic material. It can be as small as a single missing DNA base pair or as large as missing a piece of a chromosome.
- Duplication: The production of one or more copies of a gene or region of a chromosome.
- Inversion: A chromosome rearrangement in which a segment of a chromosome is reversed end to end.
- Translocation: The movement of a portion of one chromosome to another.

If any of the above aberrations were present on an unstressed preparation, select **Yes** and proceed to question 134 – 136.

If chromatid aberrations were not present on an unstressed preparation, select **No** and continue with question 137.

If the sample was not evaluable, select **Not evaluable** and proceed to question 137.

#### Questions 134 – 136: Specify results

Indicate the total number of cells studied, the total number of cells with aberrations, and the total number of cells without aberrations as indicated on the pathology report.

#### Question 137: Were chromatid aberrations present on a stressed preparation?

A chromosomal breakage test is an important tool in the diagnosis of Fanconi Anemia and is performed by confirming an increased chromosomal breakage rate in peripheral blood lymphocytes in the presence of an alkylating agent such as Mitomycin C (MMC), which interferes with the cell’s DNA. This test is also known as the MMC stress test. While it can be a helpful tool in distinguishing idiopathic aplastic anemia from Fanconi Anemia, these tests have largely been replaced by molecular marker mutation panels.

Chromatid aberrations may be noted on the recipient’s karyotype report. There are 4 major types of chromosomal aberrations as described below:

- Deletion: The loss of genetic material. It can be as small as a single missing DNA base pair or as large as missing a piece of a chromosome.
- Duplication: The production of one or more copies of a gene or region of a chromosome.
- Inversion: A chromosome rearrangement in which a segment of a chromosome is reversed end to end.
- Translocation: The movement of a portion of one chromosome to another.

If any of the above aberrations were present on a stressed preparation, select **Yes** and proceed to question 138 – 140.

If chromatid aberrations were not present on a stressed preparation, select **No** and continue with question 141.

If the sample was not evaluable, select **Not evaluable** and proceed to question 141.

#### Questions 138 – 141: Specify results

Indicate the total number of cells studied, the total number of cells with aberrations, and the total number of cells without aberrations as indicated on the pathology report.

#### Question 141: Is a copy of the report attached?

Indicate if a report is attached to support the reported chromatid aberrations present in questions 129 – 140. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)