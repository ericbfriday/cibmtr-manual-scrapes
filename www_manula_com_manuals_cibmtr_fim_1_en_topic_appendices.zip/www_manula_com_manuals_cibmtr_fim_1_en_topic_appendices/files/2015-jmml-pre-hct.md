The Juvenile Myelomonocytic Leukemia Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures JMML-specific pre-HCT data such as: the recipient’s hematologic and cytogenetic findings at the time of diagnosis and prior to the start of the preparative regimen, pre-HCT treatments administered, and disease status prior to the start of the preparative regimen.

This form must be complete for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as Myelodysplastic (MDS)/myeloproliferative (MPN) diseases and the subtype is reported as Juvenile Myelomonocytic Leukemia (JMML/JCML); also for all recipients with AML whose disease transformed from JMML.

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype and **this baseline disease insert was not completed for the previous transplant** (e.g., patient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), begin at question 1.

If this is a report of a second or subsequent transplant for a **different disease** (e.g., patient was previously transplanted for a disease other than Juvenile Myelomonocytic Leukemia), begin at question 1.

If this is a report of a second or subsequent transplant for the **same disease and this baseline disease insert has previously been completed**, check the indicator box and continue with question 63.

[Q1-6: Clinical Features at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-6-clinical-features-at-diagnosis)

[Q7-48: Laboratory Values at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q7-48-laboratory-values-at-diagnosis)

[Q49-62: Pre-HCT Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q49-62-pre-hct-therapy)

[Q63-64: Transformation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q63-64-transformation)

[Q65-91: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q65-91-laboratory-studies-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

[Q92-93: Disease Status at Last Evaluation Prior to the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q92-93-disease-status-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/21/2023 |
|

[2015: JMML Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-jmml-pre-hct)**Lines of Therapy and Subsequent Infusions***If this is a subsequent infusion and a 2015 was completed for the previous infusion, lines of therapy do not need to be reported in duplication on the subsequent 2015. Please report from post previous infusion to time of preparative regimen / infusion for the current infusion. If a 2015 was not previously completed, all lines of therapy from diagnosis to the current preparative regimen / infusion must be completed.*[2015: JMML Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2015-jmml-pre-hct)[63](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q63-64-transformation#63)to include the following concept:Progression to AML: ≥ 20% blasts in the

**blood or**bone marrow
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)