#### Question 1: Name of Product: (for most recent cell therapy infusion)

The name of the product reported will be auto populated with the value reported on the Pre-Cellular Therapy Essential Data (4000) form. If the cellular therapy product infused is a commercially available or pre- commercial product, this question is used to enable questions related to toxicities and disable questions that do not apply.

**Combined follow up**

In scenarios where both HCT and cellular therapy forms are being completed, and the recipient has received the HCT after the cellular therapy, the product name should be for the prior cellular therapy product.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Jul 29, 2023

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)