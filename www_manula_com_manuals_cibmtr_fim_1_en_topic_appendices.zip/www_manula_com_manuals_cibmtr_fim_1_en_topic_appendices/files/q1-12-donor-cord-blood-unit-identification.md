#### Question 1: Specify the person for whom this typing is being done

Indicate whether the reported HLA typing is the final **Recipient – final typing** or the final **Donor** typing for this transplant.

The CIBMTR no longer collects “optional typing” on relatives that were not the donor for this transplant.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Sep 23, 2022

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)