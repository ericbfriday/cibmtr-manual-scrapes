Best response is based on response to the HCT or cellular therapy infusion, but does not include response to any therapy given for disease relapse or progression post-HCT or post-cellular therapy. When determining the best response to HCT or cellular therapy infusion, compare the post-HCT or post-cellular therapy disease status to the status immediately prior to the preparative regimen or infusion, regardless of time since HCT or cellular therapy. This comparison is meant to capture the best disease status in response to HCT or cellular therapy that occurred during the same reporting interval, even if a subsequent disease relapse or progression occurred during the same reporting interval. If a recipient already achieved their best response in a previous reporting interval, confirm the best response and indicate that the date was previously reported (question 5).

#### Question 1: Compared to the disease status prior to the preparative regimen, what was the best response to HCT or cellular therapy since the date of the last report? (Include response to any therapy given for post-HCT or post-cellular therapy maintenance or consolidation, but exclude any therapy given for relapsed, persistent, or progressive disease)

The intent of this question is to determine the best response to HCT or cellular therapy overall. This is assessed in each reporting period. When evaluating the best response, determine the disease status within the reporting period and compare it to all previous post-HCT or post-cellular therapy reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status.

Any specified therapy administered post-HCT to prolong remission or for minimal residual disease, is considered part of the HCT and should be included when assessing the recipient’s response to transplant. Treatment given post-HCT for relapsed or persistent disease is not considered part of the HCT and should be excluded when assessing the response to HCT. If treatment was given post-HCT for relapsed or persistent disease, assess the recipient’s best response prior to the start of therapy. If therapy was given for reasons other than relapsed or persistent disease, assess the recipient’s best response throughout the entire duration of the reporting period.

If the recipient was in remission at the start of the preparative regimen, indicate “continued complete remission” and continue with question 87.

If the recipient’s best response to HCT or cellular therapy was “clinical improvement,” continue with question 2.

For all other responses, continue with question 5. See [MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria) for disease status definitions.

#### Question 2: Was an anemia response achieved?

Specify if an anemia response has been achieved at the time of best response to infusion and continue with question 3.

An anemia response is characterized by a ≥20 g/L (or >2.0 g/dL) increase in hemoglobin level (for transfusion-independent recipients) or by becoming transfusion-independent (transfusion-dependent recipients).

#### Question 3: Was a spleen response achieved?

Specify if a spleen response has been achieved at the time of best response to infusion and continue with question 4.

A spleen response is achieved when a baseline splenomegaly that is palpable at 5-10 cm below the left costal margin (LCM) becomes not palpable or baseline splenomegaly that is palpable at >10 cm below the LCM, decreases by ≥50%. A baseline splenomegaly that is palpable at <5 cm, below the LCM, is not eligible for spleen response.

A spleen response can be documented by a physician but should be confirmed by MRI / computed tomography showing ≥35% spleen volume reduction.

#### Question 4: Was a symptom response achieved?

Specify if a symptom response has been achieved at the time of best response to infusion and continue with question 5.

A symptom response is achieved when there is a ≥50% reduction in the Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS).

The Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS) is used to evaluate the recipient’s symptom response. The MPN-SAF TSS is used to provide an accurate assessment of MPN symptom burden. The evaluation tool allows recipients with MPN to report their symptom severity at the worst level. They rate their symptom severity on a scale from zero to ten, zero being absent to ten being the worst imaginable. Adding the scores for all symptoms together will result in the recipient’s MPN-SAF TSS. See Table 1 below for an example of this assessment:

**Table 1**. Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS)


#### Question 5: Was the date of best response previously reported?

If the best response to HCT / cellular therapy was first documented during the current reporting period, report “no” and go to question 6. If the best response was achieved during a previous reporting period (and therefore reported on a previous MPN Post-Infusion Data Form), report “yes” and go to question 87.

Do not report “yes” if completing this form for the 100 day reporting period.

#### Question 6: Date assessed:

Indicate the date the best response was achieved. Report the date of the pathological evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluations. This should be the earliest date when all international working group criteria for the response reported in question 1 were met.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

## Disease Assessments at the Time of Best Response

For reporting purposes, the definition of “at the time of best response” depends on the reporting period. See Disease Assessment Time Windows below. Only consider assessments with samples collected within the time window which corresponds to the follow-up form being completed. If assessments were performed during the reporting period, but the samples were not collected within the indicated time window, consider them not done and report “no” when completing questions 7-72.

**Table 2**. Disease Assessment Time Windows


| Follow-Up Form | Approximate Time Window |
|---|---|
| 100 Day | + / – 15 days of date of best response (Question 6) |
| 6 Month | + / – 15 days of date of best response (Question 6) |
| Annual | + / – 30 days of date of best response (Question 6) |

#### Questions 7-8: Did the recipient have splenomegaly? (at the time of best response)

Indicate if the recipient had splenomegaly at the time of best response. Splenomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate “yes” if splenomegaly was present at the time of best response and report the date of assessment in question 8. Indicate “no” if splenomegaly was not present at the time of best response and continue with question 13. Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at the time of best response and continue with question 13. Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy) and continue with question 13.

#### Question 9: Specify the method used to measure spleen size:

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 10. If the method selected is “ultrasound” or “CT / MRI” continue with question 11. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 10: Specify the spleen size in centimeters below the left costal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 12.

#### Question 11: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 12.

#### Question 12: Was this considered a disease relapse?

If the physician believes the size of the spleen indicates a disease relapse, report “yes.” If the recipient had an enlarged spleen, but the physician does not believe the result represents disease relapse, report “no.” Continue with question 13.

#### Questions 13-14: Did the recipient have hepatomegaly? (at the time of best response)

Indicate if the recipient had hepatomegaly at the time of best response. Hepatomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Indicate “yes” if hepatomegaly was present at the time of best response and report the date of assessment in question 14. Indicate “no” if hepatomegaly was not present at the time of best response and continue with question 19. Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at the time of best response and continue with question 19.

#### Question 15: Specify the method used to measure liver size:

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 16. If the method selected is “ultrasound” or “CT / MRI” continue with question 17. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Questions 16: Specify the liver size in centimeters below the right costal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 18.

#### Question 17: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 18.

#### Question 18: Was this considered a disease relapse?

If the physician believes the size of the liver indicates a disease relapse, report “yes.” If the recipient had an enlarged liver, but the physician does not believe the result represents disease relapse, report “no.” Continue with question 19.

#### Questions 19-29: Were tests for driver mutations performed?

Testing for driver mutations may be performed by different methods including next generation sequencing (NGS), polymerase chain reaction (PCR), microarray, and fluorescence in situ hybridization (FISH).

If testing by any / all of these methods was performed at the time of best response to assess JAK2, CALR, MPL and CSF3R, report “yes” for question 19 and continue with question 20.

If tests for driver mutations were not performed at the time of best response, or it is unknown if testing was done, report “no” or “unknown” respectively and go to question 32.

#### Question 30: Was this considered disease relapse?

Indicate “Yes” or “No” if the driver mutations detected were considered disease relapse.

If testing for all of the listed driver mutations are negative, select “Not applicable (negative results).”

#### Question 31: Was documentation submitted to the CIBMTR (e.g. pathology report, FISH report)?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 32: Were molecular tests for molecular markers performed (e.g., PCR)? (please do not include driver mutations JAK2, CALR, MPL, and CSF3R as previously captured above) (at time of best response)

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. **FISH testing for molecular markers should not be reported here**.

Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If molecular testing for molecular markers was performed at the time of best response (see Table 1 ), report “yes” and go to question 33.

If molecular testing for molecular markers was not performed at the time of best response, or it is unknown if testing was done, report “no” or “unknown” respectively and go to question 41.

#### Question 33: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker was identified at the time of best response.

If a positive molecular marker was identified, select “yes” and continue with question 34.

If there were no molecular markers identified, or it is unknown whether molecular markers were identified, select “no” or “unknown” respectively, and continue with question 40.

#### Question 34: Date sample collected

Report the date the sample was collected for molecular testing.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 35-36: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 37. If a positive marker is detected, but not listed as an option, select “other molecular marker” and specify the positive molecular marker in question 36.

#### Questions 37-38: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

**Figure 1**. Molecular disease assessment with amino acid changes documented (highlighted in yellow).


For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 37, indicate if the amino acid change is “known “or “unknown” for the positive molecular marker reported in questions 35-36. If known, report the amino acid change in question 38. If unknown, continue with question 39.

Copy questions 35-38 to report more than one positive molecular marker.

#### Question 39: Was this considered a disease relapse?

Indicate if the molecular abnormalities were considered a disease relapse. Criteria for molecular relapse are established by clinical judgment, and should reflect the clinical decision of the transplant physician. A recipient may be reported to have molecular relapse even in the setting of hematologic CR; criteria for complete remission are based on hematologic and pathologic characteristics and are independent of molecular markers of disease.

If the recipient has molecular abnormalities that the physician considers to be consistent with disease relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form.

If the recipient has molecular abnormalities that the physician does not consider to be consistent with molecular relapse, select “no.”

#### Question 40: Was documentation submitted to the CIBMTR?

Indicate if the molecular report is attached to support the molecular findings reported in questions 34-38. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 41: Was the disease status assessed via flow cytometry? (at the time of best response)

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

Indicate if flow cytometry was performed on peripheral blood and/or bone marrow sample at the time the recipient achieved their best response post-HCT.

If flow cytometry was performed, select “yes” and continue with question 42.

If flow cytometry was not performed, flow cytometry sample was inadequate, or it is unknown if flow cytometry was performed, select “no” and continue with question 52.

#### Question 42-43: Blood

Indicate if flow cytometry was performed on the peripheral blood at the time of best response. If multiple assessments were performed, report the assessment performed closest to the date of the best response.

If flow cytometry was performed on a peripheral blood sample, select “yes” and report the date the sample was collected in question 43. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a peripheral blood sample, select “no” and continue with question 47.

#### Questions 44-45: Was disease detected?

Indicate if evidence of disease was detected in the peripheral blood sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the recipient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 45.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 47.

#### Question 46: Was the status considered a disease relapse?

Indicate if the peripheral blood flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with flow cytometric relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 47.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select “no.” Continue with question 47.

#### Question 47-48: Bone Marrow

Indicate if flow cytometry was performed on the bone marrow at the time of best response. If multiple assessments were performed, report the assessment performed closest to the date of the best response.

If flow cytometry was performed on a bone marrow sample, select “yes” and report the date the sample was collected in question 48. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a bone marrow sample, select “no” and continue with question 52.

#### Questions 49-50: Was disease detected?

Indicate if evidence of disease was detected in the bone marrow sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the recipient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 50.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 52.

#### Question 51: Was the status considered a disease relapse?

Indicate if the bone marrow flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with flow cytometric relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 52.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select “no.” Continue with question 52.

#### Question 52: Were cytogenetics tested (karyotyping or FISH)? (at time of best response)

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence *in situ* hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the recipient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the recipient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic (karyotyping or FISH) studies were obtained at the time of best response (see Table 1 ), report “yes” and continue with question 53.

If cytogenetic studies were attempted at the time of best response, but there were not adequate cells (metaphases), report “no” and go to question 73.

If no cytogenetic studies were obtained at the time of best response, indicate “no” and continue with question 73.

If it is not known whether any cytogenetic studies were obtained at the time of best response, indicate “unknown” and go to question 73.

#### Question 53: Were cytogenetics tested via FISH?

If FISH studies were performed at the time of best response (see Table 1 ), report “yes” for question 53 and go to question 54. If FISH studies were not performed, report “no” for question 53 and go to question 63. Examples of this include: FISH study not performed or FISH sample was inadequate.

#### Questions 54-55: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 55. Continue with question 56. If multiple sources were used to test FISH, the most preferred sample is the bone marrow.

#### Question 56: Results of test

If FISH assessments identified abnormalities, indicate “abnormalities identified” and continue with question 57.

If FISH assessments were unremarkable, indicate “no abnormalities” and continue with question 61.

#### Questions 57-60: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 57, then continue with question 58.

Report the number of abnormalities detected by FISH at the time of best response (see Table 1 ) in question 58. After indicating the number of abnormalities in question 58, select all abnormalities detected in questions 59-60.

If an abnormality is detected, but not listed as an option in question 59, select “other abnormality” and specify the abnormality in question 60. If multiple “other abnormalities” were detected, report “see attachment” in question 60 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 61: Was this considered a disease relapse?

Indicate if the FISH results were considered consistent with disease relapse. Criteria for FISH relapse are established by clinical judgment. If the recipient has abnormalities detected by FISH that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 62.

If the recipient has residual disease by FISH that the physician does not consider to be consistent with relapse, select “no.” Continue with question 62.

#### Question 62: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if the FISH report is attached to support the findings reported in questions 57-60. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 63: Were cytogenetics tested via karyotyping?

If karyotyping studies were performed at the time of best response (see Table 1 ), report “yes” for question 63 and go to question 64. If karyotyping studies were not performed, report “no” for question 63 and go to question 73. Examples of this include: karyotyping study not performed or karyotyping sample was inadequate.

#### Question 64-65: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 65. Continue with question 66. If multiple sources were used for karyotyping analysis, the preferred sample is the bone marrow.

#### Question 66: Results of test

If karyotyping assessments identified abnormalities, indicate “abnormalities identified” and continue with question 67.

If karyotyping assessments were unremarkable, indicate “no abnormalities” and continue with question 71.

If karyotyping assessment yielded an inadequate result, indicate “no evaluable metaphases” and continue with question 71.

#### Questions 67-70: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 67, then continue with question 68.

Report the number of abnormalities detected by karyotyping at the time of best response (see Table 1 ) in question 68. After indicating the number of abnormalities in question 68, select all abnormalities detected in questions 69-70.

If an abnormality is detected, but not listed as an option in question 69, select “other abnormality” and specify the abnormality in question 70. If multiple “other abnormalities” were detected, report “see attachment” in question 70 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 71: Was this considered a disease relapse?

Indicate if the karyotyping results were considered consistent with disease relapse. Criteria for karyotyping relapse are established by clinical judgment. If the recipient has abnormalities detected by karyotyping that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 72.

If the recipient has residual disease by karyotyping that the physician does not consider to be consistent with relapse, select “no.” Continue with question 72.

#### Question 72: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if the karyotyping report is attached to support the cytogenetic findings reported in questions 67-70. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Questions 73-74: Was a bone marrow examination performed? (at the time of best response)

If a bone marrow examination was performed at the time of best response, select “yes” for question 73 and report the date the sample was collected in question 74.

If a bone marrow examination was not performed or it is unknown if completed at the time of best response, select “no” or “unknown” and continue with question 80.

#### Questions 75-76: Blasts in the bone marrow

Indicate wither the percentage of blasts in the bone marrow was “known” or “unknown” at the time of best response. If “known” report the percentage documented on the laboratory report in question 76. If “unknown” continue with question 77.

#### Question 77: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This is evident in MDS diseases such as chronic idiopathic myelofibrosis. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented in the pathology report or stated in a physician note, select “known,” continue with question 78.

If the myelofibrosis grade is not documented, select “unknown,” continue with question 80.

#### Question 78: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with focal bundles of thick fibers mostly consistent with collagen, and / or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 79: Was this considered a disease relapse?

Indicate if the myelofibrosis grade by WHO classification was considered a disease relapse. Criteria for myelofibrosis relapse are established by clinical judgment. If the recipient has a myelofibrosis grade by WHO classification that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 80.

If the recipient has residual myelofibrosis that the physician does not consider to be consistent with relapse, select “no.” Continue with question 80.

#### Questions 80-81: Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma) (at the time of best response)

Indicate if the recipient had extramedullary disease indicative of AML at the time of best response. An example of extramedullary disease would be a myeloid sarcoma. Indicate “yes” if extramedullary disease indicative of AML was present at the time of best response and report the date of assessment in question 81. Indicate “no” if extramedullary disease indicative of AML was not present at the time of best response and continue with question 82.

#### Questions 82-84: Was disease status assessed by other assessment? (at the time of best response)

Indicate if the recipient’s disease status was assessed by any other assessment at the time of best response. Indicate “yes” if the disease status was assessed by other assessment at the time of best response, report the date of assessment in question 83, and specify the name of the other assessment in question 84. Indicate “no” if the disease status was not assessed by other assessment at the time of best response and continue with question 87.

#### Question 85: Was disease detected?

If the other disease assessment indicated the presence of disease, select “yes” and continue with question 86.

If the other disease assessment did not indicate the presence of disease, select “no” and continue with question 87.

#### Question 86: Was this considered a disease relapse?

Indicate if the result of the other disease assessment was considered a disease relapse. Criteria for disease relapse are established by clinical judgment. If the recipient has another disease assessment that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 87.

If the recipient has another disease assessment that the physician does not consider to be consistent with relapse, select “no.” Continue with question 87.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q3 | 5/6/2022 | Modify | Clarified instructions on how to report spleen response: A spleen response can be documented by a physician |
Update for clarification: A spleen response can be documented by the physician or confirmed by an MRI or CT |
| Q73 – 74 | 9/20/2022 | Modify | If a |
Updated to be consistent with the question text |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)