#### Complete Hematologic Remission (CR)

Hematologic complete remission is defined as a treatment response where all of the following criteria are met:

- White blood count is < 10 × 10
9/L, without immature granulocytes and with < 5% basophils - Platelet count < 450 × 10
9/L - Non-palpable spleen

#### Chronic Phase

Characterized by relatively few blasts (<10%) present in the blood and bone marrow. Symptoms are often not present. The chronic phase may last several months to years, depending on the recipient and the treatment they receive.

#### Accelerated Phase

One or more of the following must be present:

- 10%-19% blasts in blood or marrow
- ≥ 20% basophils in peripheral blood
- Clonal marrow cytogenetic abnormalities in addition to the single Philadelphia chromosome (clonal evolution)
- Increasing spleen size, unresponsive to therapy
- Increasing WBC, unresponsive to therapy
- Thrombocytopenia (platelets < 100,000), unrelated to therapy
- Thrombocytosis (platelets > 1,000,000), unresponsive to therapy

#### Blast Phase

Characterized by having ≥ 20% blasts (formerly ≥ 30%) in the peripheral blood or bone marrow. Having extramedullary blastic infiltrates (i.e., myeloid sarcoma, granulocytic sarcoma, or chloroma) also qualifies as blast phase. The red cell, platelet, and neutrophil counts may decrease and episodes of infection and bleeding may result. Symptoms such as fatigue, shortness of breath, abdominal pain, bone pain, and spleen enlargement may occur.

When tiredness, fever, and an enlarged spleen occur during the blast phase, it is called blast crisis.1 Blast crisis is similar to acute leukemia in its signs and its effects on the recipient, and can involve lymphoid or myeloid lineages (so-called lymphoid blast crisis or myeloid blast crisis). For reporting purposes, blast crisis should be reported as blast phase on the CIBMTR data collection forms.

#### Relapse

For reporting purposes, relapse is defined as recurrence of disease after complete hematologic remission. In general, relapse should be confirmed by a clinical / hematologic assessment (e.g., pathology, CBC, or clinical exam).

Do not report recurrence of disease by molecular, cytogenetic (karyotype / FISH), or flow cytometry assessment as relapse unless the findings are documented as such by the primary care provider. If the findings are not addressed in the available notes, request documentation from the primary care provider.

#### Progression

For reporting purposes, progression is defined as any of the following changes in disease status:

• Advancement from chronic phase to accelerated phase.

• Advancement from chronic phase to blast phase.

• Advancement from accelerated phase to blast phase.

1 Chronic Myelogenous Leukemia Treatment. National Cancer Institute Available at: https://www.cancer.gov/types/leukemia/patient/cml-treatment-pdq#section/_31. (Accessed: 30th December 2016)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please click [here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 5/13/2020 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)