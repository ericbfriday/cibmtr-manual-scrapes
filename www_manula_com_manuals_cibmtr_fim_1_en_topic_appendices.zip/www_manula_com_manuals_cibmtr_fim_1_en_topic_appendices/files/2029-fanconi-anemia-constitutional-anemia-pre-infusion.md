The Fanconi Anemia / Constitutional Anemia Pre-HCT Form is one of the Comprehensive Report Forms. This form captures Fanconi Anemia-specific pre-infusion data such as: disease assessment at diagnosis, laboratory studies at diagnosis, pre-infusion therapy, most recent disease assessments, laboratory studies, familial history of Fanconi Anemia, and disease status prior to the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track and whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as **Inherited Bone Marrow Failure Syndrome** with a sub classification of **Fanconi anemia**.

Links to Sections of Form:

[Q1 – 141: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-141-disease-assessment-at-diagnosis)

[Q142 – 176: Familial History of Disease](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q142-176-familial-history-of-disease)

[Q177: Clinical Features Just Prior to the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q177-clinical-features-just-prior-to-the-preparative-regimen)

[Q178 – 215: Hematologic Parameters Immediately Prior to the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q178-215-hematologic-parameters-immediately-prior-to-the-preparative-regimen)

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/25/2021 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)