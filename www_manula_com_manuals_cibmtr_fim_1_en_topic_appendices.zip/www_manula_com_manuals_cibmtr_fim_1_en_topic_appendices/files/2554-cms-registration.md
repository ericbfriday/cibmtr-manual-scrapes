This form must be completed to determine eligibility for either Medicare clinical trials or CMS Innovation Center’s Cell and Gene Therapy (CGT) Access Model for Sickle Cell Disease (SCD).

Recipients with Medicare are eligible for coverage of HCT for multiple myeloma, myelofibrosis, or sickle cell disease if they participate in a CED clinical trial. For more information on the trials, click here [https://cibmtr.org/CIBMTR/Studies/Research-Programs/Clinical-Trials-Support/Medicare-Clinical-Trials](https://cibmtr.org/CIBMTR/Studies/Research-Programs/Clinical-Trials-Support/Medicare-Clinical-Trials).

The Centers for Medicare & Medicaid Services (CMS) Innovation Center’s Cell and Gene Therapy (CGT) Access Model study will use long term follow-up data of Medicaid patients who receive, or plan to receive, gene therapy for Sickle Cell Disease (SCD). For more information, click here [Cell and Gene Therapy (CGT) Access Model | CMS](https://www.cms.gov/priorities/innovation/innovation-models/cgt)

Links to Sections of Form:

[Q1-8: Registration and Confirmation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-8-registration-and-confirmation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/DataCollectionForms/Pages/Retired.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)