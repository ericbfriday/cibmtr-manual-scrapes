The following questions are only completed for 100 Day follow-up forms. If this VOD/SOS Form is being completed for the six month follow-up, skip this section and submit the form (or continue to signature line if submitting a paper form).

#### Question 154: Was the intent to complete the HCT procedure (conditioning, infusion, and period of recovery from neutropenia) as an outpatient?

Indicate whether the plan for transplant was to perform all conditioning, infusion, and recovery in the outpatient setting. The recipient may be admitted after the start of the preparative regimen or infusion due to complications; however, centers should answer question 154 based on the plan at the time the transplant orders were created.

If the intent was to complete the entire HCT procedure in the outpatient setting, report “yes” and continue with question 155.

If any of part of the HCT procedure was planned to be done inpatient, report “no” and continue with question 156.

#### Question 155: Did the recipient require an unplanned admission?

Report “yes” if the recipient had to be admitted to the hospital for any reason during the reporting period. Otherwise, report “no” and submit the form (or continue to signature lines if submitting a paper form).

#### Question 156-158: Was the recipient admitted to ICU during their hospital stay?

Indicate whether the recipient was admitted to the ICU during their unplanned admission reported in question 155. If yes, report the date the patient was admitted to the ICU in question 157 and the date they were discharged from the ICU in question 158. If the patient had multiple ICU stays during their unplanned admission, report the start and end dates based on their first admission to the ICU.

If the recipient died prior to discharge from the ICU, leave question 158 blank and override the error using the code “Unable to Answer.”

#### Question 159-160: Was the recipient discharged prior to the date of contact?

Indicate whether the recipient was discharged from the hospital after HCT. If “yes,” continue with question 160 and report the discharge date. If “no,” skip question 160 and continue with question 161.

If the recipient died without ever being discharged from the hospital, report “no” for question 159 and submit the form (or continue to signature lines if submitting a paper form).

#### Question 161: Total number of inpatient days (day 0 to day 100) in first 100 days post-HCT

Enter the total number of inpatient days (starting from day 0). If the recipient was discharged and readmitted during the first 100 days, the total should include days hospitalized after being readmitted. When counting the total number of inpatient days, count either the day of admission or the day of discharge; do not count both.

#### Question 162-163: Discharge status

Questions 162-163 should only be completed if the center has reported “yes” for question 159. If the center has reported “no” for question 159, skip questions 162-163 and submit the form (or continue to signatures lines if submitting a paper form).

Indicate the recipient’s discharge status following their first inpatient stay. If reporting “other” as the discharge status, specify the other status in question 163.

#### Signature Lines:

The FormsNet3SM application will automatically populate the signature data fields, including name and email address of person completing the form and date upon submission of the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)