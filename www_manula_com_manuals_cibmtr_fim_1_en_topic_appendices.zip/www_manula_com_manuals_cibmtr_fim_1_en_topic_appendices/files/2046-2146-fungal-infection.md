Fungal infections are significant opportunistic infections affecting transplant recipients. Because these infections are quite serious, it is important to collect additional information on them. Fungal infection specific forms (Form 2046 and 2146) collect more detailed information about infections reported on the comprehensive report forms and cellular therapy forms.

[2046: Fungal Infection Pre-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2046)

[2146: Fungal Infection Post-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2146)

Last modified:
Jun 26, 2019

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)