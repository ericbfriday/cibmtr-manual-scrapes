#### Question 105: Specify the status of HLH

If the patient previously had HLH at any time during their disease course, specify if it was “active” or “inactive” (quiescent) at the last evaluation prior to the start of the preparative regimen. If the patient never had HLH at any time during their disease course, indicate “not applicable.”

#### Question 106: Was colitis active?

If the patient previously had colitis at any time during their disease course, specify if it was active at last evaluation prior to the start of the preparative regimen. If the colitis was inactive, status of colitis is unknown, or the patient never had colitis at any time during their disease course (not applicable), continue with question 108.

#### Question 107: Was the recipient receiving therapy for colitis?

Indicate if the patient was receiving treatment for active colitis at time of last evaluation prior to the start of the preparative regimen.

#### Question 108: Was the CNS vasculitis active?

If the patient previously had CNS vasculitis at any time during their disease course, specify if it was active at last evaluation prior to the start of the preparative regimen. If the CNS vasculitis was inactive, status of CNS vasculitis is unknown, or the patient never had CNS vasculitis at any time during their disease course (not applicable), continue with question 110.

#### Question 109: Was the recipient receiving therapy for CNS vasculitis?

Indicate if the patient was receiving treatment for active CNS vasculitis at time of last evaluation prior to the start of the preparative regimen.

#### Question 110: Was pulmonary vasculitis active?

If the patient previously had pulmonary vasculitis at any time during their disease course, specify if it was active at last evaluation prior to the start of the preparative regimen. If the pulmonary vasculitis was inactive, status of pulmonary vasculitis is unknown, or the patient never had pulmonary vasculitis at any time during their disease course (not applicable), continue with question 112.

#### Question 111: Was the recipient receiving therapy for pulmonary vasculitis?

Indicate if the patient was receiving treatment for active pulmonary vasculitis at time of last evaluation prior to the start of the preparative regimen.

#### Question 112: Was the other vasculitis active?

If the patient previously had other vasculitis at any time during their disease course, specify if it was active at last evaluation prior to the start of the preparative regimen. If the other vasculitis was inactive, status of other vasculitis is unknown, or the patient never had other vasculitis at any time during their disease course (not applicable), continue with question 114.

#### Question 113: Was the recipient receiving therapy for other vasculitis?

Indicate if the patient was receiving treatment for active other vasculitis at time of last evaluation prior to the start of the preparative regimen.

Specify the clinical and laboratory features assessed at last evaluation prior to the preparative regimen: These questions are intended to determine the immunological status of the recipient prior to the preparative regimen. Testing may be performed multiple times within the pre-transplant work-up period (approximately 30 days) prior to the start of the preparative regimen; report the most recent laboratory value. Laboratory values obtained on the first day of the preparative regimen may be reported as long as the sample was taken before any radiation or systemic therapy was administered.

#### Questions 114-116: Serum ferritin

Indicate whether serum ferritin level was “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the value and unit of measure documented on the laboratory report in question 115; indicate the date sample was collected in question 116. If “unknown,” continue with question 117.

#### Questions 117-119: Soluble interleukin-2 receptor (sIL-2R)

Indicate whether soluble interleukin-2 receptor levels were “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the value and unit of measure documented on the laboratory report in question 118; indicate the date sample was collected in question 119. If “unknown,” continue with question 120.

#### Questions 120-122: Triglycerides

Indicate whether triglyceride levels were “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the value and unit of measure documented on the laboratory report in question 121; indicate the date sample was collected in question 122. If “unknown,” continue with question 123.

#### Questions 123-125: Fibrinogen antigen assay (factor I; fibrinogen activity; functional fibrinogen; fibrinogen antigen)

Indicate whether fibrinogen antigen levels were “known” or “unknown” immediately prior to the start of the preparative regimen. If “known,” report the value and unit of measure documented on the laboratory report in question 124; indicate the date sample was collected in question 125. If “unknown,” continue with question 126.

#### Question 126: Bone marrow aspirate/biopsy evidence of hemophagocytosis

Bone marrow aspirate and biopsy evidence of hemophagocytosis typically includes hypercellularity with markedly increased histiocytes and cytotoxic T-cells. Indicate if the pathologist interpretation of the marrow indicated the presence or absence of findings consistent with hemophagocytosis. If bone marrow evaluation was not performed, indicate “not done.”

#### Questions 127-128: Specify the cerebrospinal fluid (CSF) findings

Indicate if protein and WBC count were elevated or normal in questions 127 and 128, respectively. If CSF evaluation was not performed, indicate “not done.”

#### Question 129: Was donor testing for XLP done prior to HCT?

Indicate if the donor was tested for XLP during their donor selection work-up. This is most applicable for related male donors. If the donor was tested, continue with question 130. If the donor was not tested for XLP or testing is not applicable because the donor is unrelated or female, continue with the signature section.

#### Question 130: Was there evidence of XLP?

Indicate if testing revealed evidence of XLP in the donor.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)