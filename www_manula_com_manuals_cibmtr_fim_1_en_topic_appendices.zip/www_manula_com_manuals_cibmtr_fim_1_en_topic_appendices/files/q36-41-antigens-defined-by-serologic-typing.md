Complete this section for all serologic typing. If serologic typing was not performed, leave this section blank. Report broad antigens only when your laboratory was not able to confirm typing for a known split antigen.

Each HLA locus has a serologically defined “X” antigen specificity: AX, BX, CX, DRX, DPX, and DQX. At this time, an “X” specificity is defined as “unknown but known to be different from the other antigen at that locus.” This is different from a blank specificity, which is assumed to be the same as the other antigen at that locus.” When comparisons between recipient and donor antigens involve an “X” or “blank” specificity, the “X” or “blank” is assumed to be homozygous for the antigen reported at the locus. In other words, the search algorithm treats typing containing “blank” or “X” antigens in the same manner as known homozygous typing.

#### Questions 25-27: Number of A antigens provided

Indicate if **One** or **Two** HLA-A antigens were identified. If one antigen was identified, report the first antigen specificity in *Specificity – 1st antigen*.

If two antigens were identified, report the first antigen specificity in *Specificity – 1st antigen* and the second antigen specificity in *Specificity – 2nd antigen*.

#### Questions 28-30: Number of B antigens provided

Indicate if **One** or **Two** HLA-B antigens were identified. If one antigen was identified, report the first antigen specificity in *Specificity – 1st antigen*.

If two antigens were identified, report the first antigen specificity in *Specificity – 1st antigen* and the second antigen specificity in *Specificity – 2nd antigen*.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)