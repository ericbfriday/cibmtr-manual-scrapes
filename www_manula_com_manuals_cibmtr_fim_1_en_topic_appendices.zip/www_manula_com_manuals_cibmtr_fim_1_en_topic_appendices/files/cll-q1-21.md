#### Question 2: Specify hematologic autoimmune disorder(s) (check all that apply)

Autoimmune cytopenias appear in 5-10% of patients with CLL1. Treatment for these disorders may include corticosteroids or even splenectomy if unresponsive. Indicate if any of the following hematologic autoimmune disorders were present at diagnosis:

**Cold agglutinin disease (CAD)**: A type of autoimmune hemolytic anemia where the red blood cells are destroyed by the immune system after being activated by cold temperatures.**Immune neutropenia**: The destruction of neutrophils by the immune system. The destruction of neutrophils is caused by antineutrophil antibodies produced by autoimmune disorders. A clinical diagnosis should be confirmed if the provider notes are unclear.**Immune thrombocytopenia**: The destruction of platelets by the immune system. This is typically a clinical diagnosis and platelet specific antibodies are not routinely ordered due to their low sensitivity and specificity. However, if platelet specific antibodies were tested for and found to be present this would support a diagnosis of immune thrombocytopenia. A clinical diagnosis should be confirmed if the provider notes are unclear.

If hematologic autoimmune disorders were not present at the time of CLL diagnosis, report None.

1 Hodgson K, Ferrer G, Pereira A, et al. Autoimmune cytopenia in chronic lymphocytic leukaemia: Diagnosis and treatment. Br J Haematol 2011;154:14–22.

#### Questions 3 – 4: Rai stage

Specify if the Rai stage is **Known** at diagnosis, using the criteria listed below. If the Rai stage at diagnosis is not clear from the available documentation, seek physician clarification.

**Stage 0 – Low risk**: Lymphocytosis (> 15,000 × 109/L) in blood or bone marrow only without lymphadenopathy, hepatosplenomegaly, anemia or thrombocytopenia**Stage I – Intermediate risk**: Lymphocytosis plus enlarged lymph nodes (lymphadenopathy) without hepatosplenomegaly, anemia or thrombocytopenia**Stage II – Intermediate risk**: Lymphocytosis plus enlarged lymph nodes (lymphadenopathy) without hepatosplenomegaly, anemia or thrombocytopenia**Stage III – High risk**: Lymphocytosis plus anemia (Hgb < 11.0 g/dL) with or without enlarged liver, spleen, or lymph nodes**Stage IV – High risk**: Lymphocytosis plus thrombocytopenia (platelet count < 100 × 109/L) with or without anemia or enlarged liver, spleen, or lymph nodes

If the Rai stage at diagnosis cannot be determined, select **Unknown**.

#### Question 5: Were systemic symptoms (B symptoms) present? (unexplained fever > 38° C ; or night sweats; unexplained weight loss of > 10% of body weight in six months before diagnosis)

Systemic symptoms or B symptoms (also known as constitutional symptoms) include unexplained fever > 38˚ C (100.4˚ F), night sweats, and / or unexplained weight loss of >10% of body weight in six months before diagnosis.

Specify if the recipient had B symptoms within six months prior to the diagnosis. If it is unclear if symptoms were present within six months prior to the diagnosis, seek physician clarification.

#### Questions 6 – 8: Was extranodal disease present?

Extranodal disease involves sites other than the lymph nodes, spleen and thymus. Common areas of extranodal involvement include the **Bone marrow**, **Central nervous system**, and **Lung**. Extranodal involvement is most often detected utilizing imaging techniques or pathologic findings.

Specify if extranodal disease was present at diagnosis. If Yes, specify all sites of involvement. If **Other site** is selected, specify the site.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q5 | 4/19/2025 | Modify | Clarification: Systemic symptoms or B symptoms (also known as constitutional symptoms) include unexplained fever > 38˚ C (100.4˚ F), night sweats, and / or unexplained weight loss of >10% of body weight in six months before |
Corrected typo for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)