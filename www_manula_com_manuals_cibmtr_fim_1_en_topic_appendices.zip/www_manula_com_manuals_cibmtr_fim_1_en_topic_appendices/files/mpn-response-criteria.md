**MPN Response Criteria**[1](#fn154296593268596bbd4d8d7-1)

#### CR (requires each of the following)

*Requires all of the following maintained for a minimum of 12 weeks. When reporting the CR achievement date, report the first date when CR was achieved (not the 12 week date in which CR was maintained).*


- Bone marrow with ≤ 5% myeloblasts (including monocytic blast equivalents in CMML) with normal maturation of all cell lines and return to normal cellularity
- Myelofibrosis absent or ≤ grade 1 fibrosis (mild reticulin fibrosis)
- Peripheral blood counts showing:
- WBC ≤ 10 × 10
9/L - Hgb ≥ 11 g/dL
- PLT ≥ 100 × 10
9/L; ≤ 450 × 109/L - Blasts 0%
- Neutrophilic precursors* reduced to ≤ 2% (*neutrophilic precursors include
*myeloblasts, promyelocytes, myelocytes, and metamyelocytes*) - Monocytes ≤ 1 × 10
9/L

- WBC ≤ 10 × 10
- Resolution of any extramedullary disease present prior to therapy; this includes cutaneous disease, disease-related serous effusions, and palpable hepatosplenomegaly

*Myelofibrosis CR*[2](#fn154296593268596bbd4d8d7-2)

[2](#fn154296593268596bbd4d8d7-2)

*Requires all of the following maintained for a minimum of 12 weeks. When reporting the CR achievement date, report the first date when CR was achieved (not the 12 week date in which CR was maintained).*


- Bone marrow with ≤ 5% myeloblasts with normal maturation of all cell lines
- Myelofibrosis absent or ≤ grade 1 fibrosis (mild reticulin fibrosis)
- Peripheral blood counts showing:
- ANC ≥ 1.0 × 10
9/L and < upper limit of normal - Hgb ≥ 11 g/dL and < upper limit of normal
- PLT ≥ 100 × 10
9/L and < upper limit of normal - Neutrophilic precursors* reduced to ≤ 2% (*neutrophilic precursors include
*myeloblasts, promyelocytes, myelocytes, and metamyelocytes*)

- ANC ≥ 1.0 × 10
- Resolution of disease symptoms and no palpable hepatosplenomegaly; no evidence of extramedullary hematopoiesis

#### Partial Response

*Requires all of the following maintained for a minimum of 12 weeks. When reporting the date when partial response was achieved, report the first date when the criteria for partial response was met (not the 12 week date in which partial response was maintained).*


- Peripheral blood counts showing:
- ANC ≥ 1.0 × 10
9/L and < upper limit of normal - Hgb ≥ 10.0 g/dL and < upper limit of normal
- PLT ≥ 100 × 10
9/L and < upper limit of normal - Neutrophilic precursors* reduced to ≤ 2% (*neutrophilic precursors include
*myeloblasts, promyelocytes, myelocytes, and metamyelocytes*)

- ANC ≥ 1.0 × 10
- Resolution of disease symptoms and no palpable hepatosplenomegaly; no evidence of extramedullary hematopoiesis

**or**

- Bone marrow with ≤ 5% myeloblasts with normal maturation of all cell lines
- Myelofibrosis absent or ≤ grade 1 fibrosis (mild reticulin fibrosis)
- Peripheral blood counts showing:
- ANC ≥ 1.0 × 10
9/L and < upper limit of normal - Hgb ≥ 8.5 g/dL but <10.0 g/dL and < upper limit of normal
- PLT ≥ 50 × 10
9/L but <100 × 109/L and < upper limit of normal - Neutrophilic precursors reduced to ≤ 2%

- ANC ≥ 1.0 × 10
- Resolution of disease symptoms and no palpable hepatosplenomegaly; no evidence of extramedullary hematopoiesis

#### Clinical Improvement

*Requires one of the following maintained for a minimum of 12 weeks. When reporting the date when clinical improvement was achieved, report the first date when the criteria for clinical improvement was met (not the twelve-week date in which clinical improvement was maintained).*


- The achievement of any of the following responses without progressive disease or increase in severity of anemia, thrombocytopenia, or neutropenia
**Anemia Response**- Transfusion-independent patients: a ≥ 2.0 g/dL increase in hemoglobin level
- Transfusion-dependent patients: becoming transfusion independent

**Spleen Response**- A baseline splenomegaly that is palpable at 5-10 cm, below the LCM, becomes not palpable
*or* - A baseline splenomegaly that is palpable at > 10 cm, below the LCM, decreases by ≥ 50%
- A baseline splenomegaly that is palpable at < 5 cm, below the LCM, is not eligible for spleen response
- A spleen response requires confirmation by MRI or computed tomography showing ≥ 35% spleen volume reduction

- A baseline splenomegaly that is palpable at 5-10 cm, below the LCM, becomes not palpable
**Symptoms Response**- A ≥ 50% reduction in the MPN-SAF TSS



#### Stable disease

- Does not meet any of the other response categories

#### Progressive Disease

- Appearance of a new splenomegaly that is palpable at least 5 cm below the LCM
*or* - A ≥ 100% increase in palpable distance, below LCM, for baseline splenomegaly of 5-10 cm
*or* - A 50% increase in palpable distance, below LCM, for baseline splenomegaly of > 10 cm
*or* - Leukemic transformation confirmed by a bone marrow blast count of ≥ 20%
*or* - A peripheral blood blast content of ≥ 20% associated with an absolute blast count of ≥ 1 × 10
9/L that lasts for at least 2 weeks

#### Relapse from CR

- No longer meeting criteria for at least CI after achieving CR, PR, or CI,
*or* - Loss of anemia response persisting for at least 1 month
*or* - Loss of spleen response persisting for at least 1 month

1 Savona, M. R., Malcovati, L., Komrokji, R., Tiu, R. V., Mughal, T. I., Orazi, A., … & List, A. F. (2015). An international consortium proposal of uniform response criteria for myelodysplastic/myeloproliferative neoplasms (MDS/MPN) in adults. Blood, 125(12), 1857-1865.

2 Tefferi, A., Cervantes, F., Mesa, R., Passamonti, F., Verstovsek, S., Vannucchi, A. M., … & Barosi, G. (2013). Revised response criteria for myelofibrosis: international Working Group-Myeloproliferative Neoplasms Research and Treatment (IWG-MRT) and European LeukemiaNet (ELN) consensus report. Blood, 122(8), 1395-1398.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/20/2022 |
|

**Determining Post-Infusion Baseline Assessments**When determining the post-infusion disease status, the most recent lab values prior to the start of the preparative regimen should be used as the baseline assessments. However, if relapse or progression occurs after infusion, the labs from relapse / progression should be used.[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)**Determining Pre-Infusion Baseline Assessments**When determining the pre-infusion disease status, use the lab values from diagnosis of the primary disease for infusion as the baseline assessments. However, if relapse or progression occurs prior to infusion, the labs from relapse / progression should be used.[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)*Requires*~~all~~ one of the following maintained for a minimum of 12 weeks. When reporting the date when clinical improvement was achieved, report the first date when the criteria for clinical improvement was met (not the twelve-week date in which clinical improvement was maintained).[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)*Neutrophilic precursors* reduced to ≤ 2% (*neutrophilic precursors include myeloblasts, promyelocytes, myelocytes, & metamyelocytes)*[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)*Requires all of the following maintained for a minimum of 12 weeks*[MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)