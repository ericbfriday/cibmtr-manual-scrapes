#### Questions 1-2: Did the recipient receive more than one cycle of Inotuzumab Ozogamicin (Besponsa™)? (1 cycle = 3 doses)

Indicate “Yes” if more than one cycle (1 cycle = 3 doses) of Inotuzumab Ozogamicin was given.

If “Yes” provide the number of cycles in question 2. Complete questions 3 – 17 for each cycle.

If only one cycle of Inotuzumab was given, then answer “No” and continue with question 3.

#### Questions 3-4: Date of first dose for cycle

Indicate if the date of the first dose for the cycle being reported in this instance is “Known” or “Unknown” in question 3.

If “Known”, report the date of first dose for the cycle of Inotuzumab Ozogamicin in question 4.

If the date of first dose is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If date for first dose for cycle is “Unknown”, continue with question 5.

#### Questions 5-6: Date of last dose for cycle

Indicate if the date of the last dose for the cycle being reported in this instance is “Known” or “Unknown” in question 5.

If “Known” report the date of last dose for the cycle in question 6.

If the date for last dose is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If date for last dose for cycle is “Unknown”, continue with question 7.

#### Questions 7-8: Combined dose per cycle (e.g. If patient received 3 doses in cycle 1 at 0.8 mg/m 2 on day 1, 0.5 mg/m 2 on day 8 and 14 then total dose is 1.8 mg/m 2)

Indicate actual combined dose that was given to recipient.

According to the guidelines of the drug, a recipient should not receive more than 1.8 mg/m2 of Inotuzumab Ozogamicin per cycle.

Indicate if the combined total dose per cycle is “Known” or “Unknown” in question 7.

If “Known”, provide the combined total dose for the cycle of Inotuzumab Ozogamicin reported in this instance in question 8.

If the combined total dose per cycle is “Unknown”, continue with question 9.

#### Question 9: Were three doses given in this cycle?

A cycle of Inotuzumab Ozogamicin consists of three doses. Indicate if all three doses were given for the cycle being reported in this instance.

#### Question 10: Best response to this cycle of therapy:

Indicate the best response to the cycle of therapy using the international working group criteria provided in the Acute Lymphoblastic Leukemia (ALL) Response Criteria section of the Forms Instructions Manual. The best response is determined by a disease assessment, such as hematologic testing, pathology study, and / or physician assessment.

#### Question 11: Was recipient MRD status assessed following this cycle of therapy?

Minimal residual disease (MRD) can be assessed by different methods including, but not limited to, the following:


- Next generation sequencing
- Sanger sequencing
- Polymerase chain reaction (PCR) testing
- Chromosomal / genomic microarray analysis
- Flow cytometry (high sensitivity or next generation flow cytometry)

If any MRD testing was performed following the cycle of therapy being reported, answer question 11 based on the results of the testing performed within 30 days after the date therapy was stopped and prior to any new therapy being initiated.

If MRD status was assessed continue with question 12 to report results.

If MRD status was not assessed or it is not known if MRD status was assessed, submit the form.

#### Questions 12-13: Was MRD assessed by flow cytometry?

If MRD status was assessed by PCR indicate “Yes” and provide the status of the MRD in question 15.

If MRD status was not assessed by PCR indicate “No” or “Unknown” and continue with question 16.

#### Questions 16-17: Was MRD assessed by NGS?

If MRD status was assessed by Next Generation Sequencing (NGS) indicate “Yes” and provide the status of the MRD in question 17.

If MRD status was not assessed by NGS indicate “No” or “Unknown” and submit the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)