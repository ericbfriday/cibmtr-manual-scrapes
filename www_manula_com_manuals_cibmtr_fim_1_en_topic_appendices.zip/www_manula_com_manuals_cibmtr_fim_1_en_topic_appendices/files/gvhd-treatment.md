This section provides an overview of reporting GVHD treatment on the Post-TED (2450) and Post-Infusion Follow-Up (2100) Forms.

Reporting of GVHD treatment is separated into two categories:

- Systemic steroids
- Immunosuppression

Review the information below to determine when to report **Yes**, **No**, **Not applicable**, and **Unknown** for the systemic steroids and immunosuppression GVHD treatment data fields.

### Systemic Steroids

The Post-TED (2450) and Post-Infusion Follow-Up (2100) Forms capture if the recipient is still taking systemic steroids on the contact date to treat or prevent GVHD, excluding steroids for adrenal insufficiency. Steroids are considered ‘systemic’ if the dose of steroids are > 10 mg / day for adults and > 0.1 mg / kg / day for children.


Report **Yes**, the recipient is taking systemic steroids in the following scenarios:

- The recipient is still taking systemic steroids (> 10 mg / day for adults and > 0.1 mg / kg / day for children) to treat or prevent GVHD on the contact date.
- The recipient died prior to discontinuation of systemic steroids used to treat or prevent GVHD.

Report **No**, the recipient is not taking systemic steroids in the following scenarios:


- Systemic steroids (dose > 10 mg / day for adults and > 0.1 mg / kg / day for children) were administered in the current reporting period and discontinued on or before the contact date.
- Systemic steroid (> 10 mg / day for adults and > 0.1 mg / kg / day for children) were administered in the current reporting period and the dose of steroids were decreased to < 10 mg / day for adults or < 0.1 mg / kg / day for children on or before the contact date.

If completing the Post-Infusion Follow-Up (2100) Form and the recipient is no longer taking systemic steroids on the contact date, the date when steroids were discontinued is also captured. This date should be the date when the dose of systemic steroids was decreased to < 10 mg / day for adults or < 0.1 mg / kg / day for children.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Report **Not applicable** in the following scenarios:

- The recipient has never received systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD in the current reporting period.
- This form is being completed for a subsequent HCT and the recipient has never received systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD since the start of the preparative regimen for the most recent infusion (or since the date of the most recent infusion if no preparative regimen is given).
- The recipient stopped taking systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD in a previous reporting period and did not restart systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) during the current reporting period.

The **Unknown** option should be used sparingly and only when there is no information, and no judgement can be made to determine if the recipient is still taking systemic steroids on the contact date.

**Systemic Steroids Examples**


- Example 1: In the Day 100 reporting period, a recipient was started on 60 mg / day of Prednisone to treat GVHD. The recipient’s GVHD improved and began weaning the dose of Prednisone. On the Day 100 contact date, the dose of steroids was decreased to 5 mg / day which was continued into the 6-month reporting period, without any dose increases, and eventually discontinued by the end of the 6-month reporting period.
- Day 100: Report
**No**, the recipient is not taking systemic steroids since the dose of steroids is < 10 mg on the contact date. - 6-month: Report
**Not applicable**since the dose of systemic steroids was never > 10 mg / day during the entire reporting period.

- Day 100: Report
- Example 2: At the beginning of the 6-month reporting period, a recipient is on 20 mg / day of Prednisone. After three months, the dose is decreased to 10 mg per day and is maintained at that level until the end of the reporting period. In this scenario, report
**No**since the dose of systemic steroids was ≤ 10 mg / day on the day of contact. - Example 3: Throughout the Day 100 reporting period, a recipient is on 30 mg / day Methylprednisolone given every other day to treat GVHD. The recipient continues the same dose on the Day 100 contact date. In this scenario the average daily dose is approximately 15 mg / day and therefore,
*Is the recipient still taking systemic steroids*should be answered as**Yes**, as the dose of systemic steroids is > 10 mg / day. - Example 4: At the beginning of the 6-month reporting period, a recipient is only on Budesonide for mild GI GVHD. In this scenario, report
**Not applicable**when capturing steroids as Budesonide is considered to be a topical agent and should not be considered when answering*Is the recipient still taking systemic steroids*. - Example 5: At the beginning of the reporting period, a recipient is started on 40 mg / day Prednisone for acute GVHD on 3/1/2021. After two weeks, the recipient’s steroid dose is tapered using the following schedule:
- 3/14/2021: Prednisone tapered to 30 mg / day
- 3/20/2021: Prednisone tapered to 20 mg / day
- 3/25/2021: Prednisone tapered to 10 mg / day
- 3/30/2021: Prednisone tapered to 5 mg/ day


At the end of the reporting period for the question, *Is the recipient still taking systemic steroids* should be answered as **No**. If the recipient is on the CRF reporting track, on the Post-Infusion Follow-up (2100) Form, the date of final steroid administration should be captured as 3/25/2021 as this was the date the recipient’s steroid dose fell below the systemic steroid dose threshold of > 10 mg / day.

### Immunosuppression

The Post-TED (2450) and Post-Infusion Follow-Up (2100) Forms capture if the recipient is still taking immunosuppression on the contact date to treat or prevent GVHD, excluding steroids for adrenal insufficiency. Immunosuppression includes any non-steroidal immunosuppressive agents, including PUVA. Review the list below or examples of immunosuppressive agents.


Report **Yes**, the recipient is immunosuppression in the following scenarios:


- The recipient is still immunosuppression to treat or prevent GVHD on the contact date.
- The recipient died prior to discontinuation of immunosuppression used to treat or prevent GVHD.

Report **No**, the recipient is not taking immunosuppression in the following scenarios:


- Immunosuppression was administered in the current reporting period and discontinued on or before the contact date.

If completing the Post-Infusion Follow-Up (2100) Form and the recipient is no longer taking immunosuppression on the contact date, the date when immunosuppression was discontinued is also captured. This date should be the date when immunosuppression was discontinued.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Report **Not applicable** in the following scenarios:

- The recipient has never received non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD.
- This form is being completed for a subsequent HCT and the recipient has never received non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD since the start of the preparative regimen for the most recent infusion (or since the date of the most recent infusion if no preparative regimen was given).
- The recipient stopped taking non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD in a previous reporting period and did not restart non-steroidal immunosuppressive agents (including PUVA) during the current reporting period.

The **Unknown** option should be used sparingly and only when there is no information, and no judgement can be made to determine if the recipient is still taking immunosuppression on the contact date.

**Immunosuppressive Agents Examples**


- Example 1: Going into transplant, a recipient was taking Tacrolimus and MMF. In the Day 100 reporting period, both drugs were discontinued. In the 6-month reporting period, no new immunosuppressive agents were started.
- Day 100: Report
**No**, for*Is the recipient still taking immunosuppressive agents*as both immunosuppressive drugs were discontinued in the reporting period. - 6-month: Report
**Not applicable**for*Is the recipient still taking immunosuppressive agents*since the recipient never received immunosuppressive agents within the reporting period.

- Day 100: Report

**Immunosuppressive Agents**

Below are examples of possible immunosuppressive agents:


- Aldesleukin (Proleukin): Increases production of several white blood cells including regulatory T-cells. This drug is also known as interleukin-2.
- ALG (Anti-Lymphocyte Globulin), ALS (Anti-Lymphocyte Serum), ATG (Anti-Thymocyte Globulin) ATS (Anti-Thymocyte Serum): Serum or gamma globulin preparations containing polyclonal immunoglobulins directed against lymphocytes. These drugs are usually prepared from animals immunized against human lymphocytes.
- Azathioprine (Imuran): Azathioprine inhibits purine synthesis. Usually it is used at low doses in combination with other treatments.
- Bortezomib (Velcade): A proteasome inhibitor.
- Cyclosporine (CSA, Neoral, Sandimmune): Calcineurin inhibitor which decreases cytokine production by T-cells. Usually given for ≥ 3 months.
- Cyclophosphamide (Cytoxan): Given in high doses near the date of infusion as single agent prophylaxis.
- Extra-corporeal photopheresis (ECP): The recipient’s blood is removed from the body, exposes to psoralen and ultraviolet light, and re-infused.
- FK 506 (Tacrolimus, Prograf): Inhibits the production of interleukin-2 by T-cells.
- Hydroxychloroquine (Plaquenil): Hydroxychloroquine inhibits transcription of DNA to RNA and is commonly used as an anti-malarial drug.
- Interleukin Inhibitor: Interleukin inhibitors suppress production of white blood cells and are grouped according to their target. Examples of IL-2 inhibitors include daclizumab (Zynbryta) and basiliximab (Simulect). Examples of IL-6 inhibitors include tocilizumab (Actemra) and siltuximab (Sylvant).
- In vivo monoclonal antibody: Antibody preparations that are infused in the recipient following HSCT.
- In vivo immunotoxin: Antibody preparations linked to a toxin that is infused in the recipient following HCT.
- Janus Kinase 2 Inhibitors: Suppress function of T-effector cells. Examples: ruxoloitinib (Jakafi, Jakavi) and tofacitinib (Xeljanz, Jakvinus).
- Methotrexate (MTX) (Amethopterin): Inhibits the metabolism of folic acid. It is most often used with cyclosporine and is usually for a short duration of time.
- Mycophenolate mofetil (MMF) (CellCept, Myfortic): Inhibits the de novo pathway used for lymphocyte proliferation and activation.
- Pentostatin (Nipent): Inhibits adenosine deaminase, which blocks DNA (and some RNA) synthesis.
- Sirolimus (Rapamycin, Rapamune): Inhibits the response to interleukin-2, blocking the activation of T-cells.
- Tyrosine Kinase Inhibitor (TKI): Suppress function of tyrosine kinases thereby downregulating the function of many other cellular proteins / processes including fibrosis and inflammation. Examples: imatinib (Gleevec, Glivec), nilotinib (Tasigna), and dasatinib (Sprycel).
- UV Therapy: UVA or UVB radiation administered to affected areas of the skin in order to suppress proliferation of cells responsible for GVHD.
- PUVA (Psoralen and UVA): Psoralen is applied or taken orally to sensitize the skin, and then the skin is exposed to UVA radiation.
- UVB: Broadband- or Narrowband-UVB radiation is applied to the affected areas of the skin.


**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)