#### Question 1: Compared to the disease status prior to the preparative regimen what was the best response since the date of the last report? (Include response to any post-HSCT treatment planned as of day 0)

The intent of this question is to determine the best overall response to HCT. This is assessed in each reporting period. When evaluating the best response, determine the disease status within the reporting period and compare it to all previous post-HCT reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status.

Any specified therapy administered post-HCT to prolong remission or for minimal residual disease is considered part of the HCT and should be included when assessing the recipient’s best response. Treatment given post-HCT for relapsed or persistent disease is not considered part of the HCT and should be excluded when assessing the response to HCT. If treatment was given post-HCT for relapsed or persistent disease, assess the patient’s best response prior to the start of that treatment. If therapy was only given for reasons other than relapsed or persistent disease, assess the patient’s best response throughout the entire duration of the reporting period.

If the disease status was not assessed in the reporting period by any method, report **Not assessed**. This option is not commonly used, as this would indicate that no tests (radiological, laboratory, or a clinical assessment) were performed to assess the disease status at any time during the reporting period.

If the disease status is not known in the reporting period, indicate **Unknown**. This option should be used sparingly and only when there is no information to determine if disease assessments were or were not performed in the reporting period.

#### Questions 2 – 17: Specify the site(s) of persistent tumor

If the best response to HCT is reported as either **Partial response**, **Minimal response**, or **No response**, indicate **Yes** or **No** if persistent tumor(s) was identified in the sites listed in questions 2-17

If a tumor persisted at a site not listed, indicate **Yes**, for “Other site” (question 16) and specify the anatomical location.

#### Question 18: Specify the date best response was determined

Report the date the best response was established. This should be the earliest date when all international working group criteria for the response reported in question 1 were met. If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

If the best response is the same as the pre-transplant disease status, report the date of the first assessment(s) that confirmed the ongoing disease status post-HCT.

Check **Previously reported**, if the date was already reported on a previous form. This option is not applicable on the day 100 follow-up form.

Example 1: A recipient receives a transplant on 1/1/2015 for neuroblastoma, the pre- transplant disease status is complete remission. During the 100-day reporting period, the recipient had radiologic testing performed 3/12/15 which confirmed the recipient to be in continued complete remission. The 100-day date of contact is 4/15/2015. In this instance, the best response to transplant should be reported as “complete remission” on the 100 Day Follow-Up form, with the date best response determined of “3/12/15” (date of labs / assessments first confirming a continued CR).

In the 6-month reporting period the recipient relapses; however, the best response to transplant will still be reported as “complete” remission, with the date best response determined as “previously reported.” This will be reported in the 6-month reporting period and for all subsequent reporting periods. See Table 1 below.

Table 1.


| Reporting Period | Disease Status | Q1. Best Response | Q18. Date Best Response Determined |
|---|---|---|---|
| Pre-Transplant | CR | —- | —- |
| 100-Day Reporting Period | CR | CR | 3/12/2015 (date of labs / assessments first confirmed continued CR |
| 6-Month Reporting Period | Relapse | CR | Previously reported |
| 1-Year Reporting Period | CR | CR | Previously reported |

Example 2: A recipient receives a transplant on 2/5/15 for neuroblastoma, the pre-transplant disease status is partial remission. During the 100-day reporting period the recipient maintained a partial remission, confirmed with radiology performed on 4/1/15. The 100-day date of contact is 4/22/15. In this instance, the best response to transplant should be reported as “partial remission” on the 100 Day Follow-Up form, with a date best response determined of “4/1/15” (date of labs/assessments first confirming a continued PR).

During the 6-month reporting period, the recipient has disease progression and starts treatment on 6/1/2015. In this case, the recipient’s best response to transplant should still be reported as “partial remission” with the date of best response determined as “previously reported.”

In the 1-year reporting period, the recipient achieves a complete remission; however, the best response to transplant should still be reported as “partial remission” with the date of best response determined as “previously reported.” The best response to transplant (partial remission) occurred during the 100-day reporting period and response to unplanned therapy should not be captured within the best response to transplant data fields. See Table 2 below:

Table 2.


| Reporting Period | Disease Status | Q1. Best Response | Q18. Date Best Response Determined |
|---|---|---|---|
| Pre-Transplant | PR | —- | —- |
| 100-Day Reporting Period | PR | PR | 4/1/2015 (date of labs / assessments first confirmed continue PR |
| 6-Month Reporting Period | Disease Progression | PR | Previously reported |
| 1-Year Reporting Period | CR | PR | Previously reported |

#### Questions 19 – 34: Were tumor markers evaluated for the best response post-HCT determination?

Tumor markers, also known as biomarkers, are substances produced by cancer tissue or by the body in response to cancer at higher than normal levels. In certain situations, these substances can be used to detect and monitor disease due to their elevated presence in blood, urine, and/or tissue. The substances listed in questions 20-34 have been identified as potential tumor markers for neuroblastoma.

For each substance, indicate if tumor marker analyses were performed post-HCT to determine the recipient’s best response to transplant. If the analysis was performed, select **Known**, specify the value. If the analysis was performed or it is unknown if performed, select **Not known**.


- Homovanillic acid (HVA): Catecholamines (e.g. epinephrine/adrenaline) are secreted as hormones from the adrenal medulla. Neuroblastomas typically produce excessive levels of these catecholamines. After catecholamines are secreted they are broken down into metabolites including Homovanillic acid (HVA) and Vanillylmandelic acid (VMA). Both HVA and VMA are excreted in the urine. As a result, elevated levels of HVA and VMA detected by urinary analysis can be indicative of neuroblastoma.
- Neuron specific enolase (NSE): A glycolytic enzyme (enolase) specific to neuronal-type tissues. NSE may be excessively expressed by neuroblastomas and indicative of disease.
- Serum ferritin: Ferritin is a blood protein that contains iron. A ferritin level indicates how much iron a person’s body is storing. If the ferritin level is lower than normal, it indicates the body’s iron stores are low (iron deficiency). If the ferritin level is higher than normal it could indicate hemochromatosis, a condition that causes the body to store too much iron. Other causes of an elevated ferritin level include liver disease, acute and chronic inflammatory conditions, malignancy (neuroblastoma) to name a few.
- Vanillylmandelic acid (VMA): Both HVA and VMA are excreted in the urine. As a result, elevated levels of HVA and VMA detected by urinary analysis can be indicative of neuroblastoma.
- Other tumor marker analysis: If testing for a tumor marker was performed at diagnosis and is not listed above, select Known, and specify the other tumor marker, value and units of measurements in questions 33 – 34.Examples of other testing can include Chromogranin A (CgA) or Neuropeptide Y (NpY).

#### Question 35: Was the recipient given planned therapy per protocol post-HCT treatment for neuroblastoma?

Complete questions 35 – 76 for all the lines of therapy administered during the reporting period for reasons other than relapse, progression, or new MRD identified post-HCT. Separate instances / lines cannot be reported for this section therefore, all treatment given in the reporting period for reasons other than relapse, progression, or new MRD should be reported in questions 36 – 76 even if administered in separate lines.

Indicate **Yes** or **No if the recipient received planned treatment post-HCT since the date of last report. If the recipient did not receive planned post-HCT therapy, report *No** and continue with question 77.

#### Questions 36 – 40: Was radiotherapy given?

Radiation therapy utilizes high-energy radiation to kill cancer cells. Indicate whether radiotherapy was given as planned post-HCT therapy. If radiotherapy was given, report **Yes** and specify the site(s) of radiation. If radiotherapy was given to a site not listed, indicate **Yes**, for “Other site” (question 39) and specify the site.

#### Question 41: Specify the date radiotherapy was started

Report the date when the planned post-HCT radiotherapy began. If multiple sites received radiotherapy, report the *first* date when radiation was administered.

#### Question 42: Number of fractions given

Specify the total number of fractions (treatments) given. If radiation was administered to multiple sites, report the number of fractions for the *first* site.

#### Question 43: Dose per fraction

Specify the dose per fraction in centigrays (cGy / rads). If radiation was administered to multiple sites, report the dose per fraction of the *first* site.

#### Questions 44 – 48: Was MIBG given?

Meta-iodobenzylguanidine (MIBG) is a radioisotope that is readily absorbed by neuroblastoma cells, preferentially concentrating in areas of disease. At lower doses, MIBG can be used for imaging purposes. At higher doses, MIBG provides selective antitumor radiotherapy.

Indicate whether MIBG was given as planned post-HCT therapy since the date of last report. If MIBG therapy was given as part of the planned post-HCT therapy, report **Yes**, specify the radioisotope administered, and the MIBG therapy start date. If a radioisotope other than 131 I-MIBG was given, select **Yes** for “Other” (question 46) and specify the radioisotope type.


- 131 I-MIBG: Iodine-131 meta-iodobenzylguanidine (I-131 MIBG), commonly known as Azedra is a radiopharmaceutical used for treating certain types of neuroendocrine tumors, including neuroblastomas.
- Other : Targeted radiotherapy such as peptide receptor radionuclide therapy (PRRT).

If MIBG therapy was not given as part of the planned post-HCT therapy in the current reporting period, report**No**and continue with question 49.

#### Questions 49 – 53: Were retinoids given?

Retinoids are vitamin A derivatives that can affect cellular function. Studies have shown that retinoid therapy can result in an antitumor effect.3

Indicate if retinoids were given as planned post-HCT therapy since the date of the last report. If retinoids were given as part of the planned post-HCT therapy, report **Yes**, specify the retinoid administered, and the retinoid therapy start date. If a retinoid other than isotretinoin was given, select **Yes** for “Other” (question 51) and specify the retinoid type. Report the generic name and not the brand name.


- Isotretinoin:13-cis-retinoic acid (Isotretinoin) is a retinoid that has been shown to improve survival for high risk neuroblastoma.
- Other: Other types of retinoids given to treat neuroblastoma include: N-4-hydroxyphenyl retinamide (Fenretinide),

If retinoids were not given as part of the planned post-HCT therapy in the reporting current reporting period, report **No** and continue with question 54.

#### Questions 54 – 60: Was immunotherapy given?

Immunotherapy is typically given to stimulate the body’s own immune system to detect and destroy cancer cells.

Indicate if immunotherapy was given as planned post-HCT therapy since the date of the last report. If immunotherapy was given as part of the planned post-HCT therapy, report **Yes**, specify the immunotherapy administered, and the immunotherapy therapy start date. If an immunotherapy was given but is not listed as an option, select **Yes** for “Other” (question 58) and specify the immunotherapy type. Report the generic name and not the brand name.


- α – interferon: Interferon alfa is a cytokine. Common names include: Intron® A (interferon alfa-2b), Roferon®-A (interferon alfa-2a).
- Anti-GD2 antibody CH14.18: Anti-GD2 antibody ch14.18/CHO (dinutuximab beta) is a chimeric monoclonal antibody.
- Interleukin-2 (IL-2): Interleukin-2 is s a cytokine. Common names include: Aldesleukin and PROLEUKIN®.
- Other: Other types of immunotherapies given to treat neuroblastoma include: Granulocyte macrophage colony-stimulating factor (GM-CSF).

If immunotherapy was not given as part of the planned post-HCT therapy in the reporting current reporting period, report **No** and continue with question 61.

#### Questions 61 – 73: Was chemotherapy given?

Indicate if chemotherapy was given as planned post-HCT therapy since the date of the last report. If chemotherapy was given as part of the planned post-HCT therapy, report **Yes**, specify the chemotherapy administered, and the chemotherapy therapy start date. If a chemotherapy was given but is not listed as an option, select **Yes** for “Other” (question 71) and specify the chemotherapy type. Report the generic name and not the brand name.

If chemotherapy was not given as part of the planned post-HCT therapy in the reporting current reporting period, report **No** and continue with question 74.

Enter the date the chemotherapy began. If the start date is partially known (i.e., the recipient started treatment in mid- July 2010), use the process described for reporting partial or unknown dates in” General Instructions, Guidelines for Completing Forms”:https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms.

#### Questions 74 – 76: Was other treatment given?

If treatment other than radiotherapy, MIBG, retinoids, immunotherapy, or chemotherapy was given as planned post-HCT therapy for neuroblastoma, indicate **Yes** and specify the other treatment and start date.

Examples of other therapy may include intrathecal therapy or surgery.

#### Questions 77 – 106: Did the neuroblastoma recur or progress since the date of the last report?

Indicate if the neuroblastoma recurred or progressed (see Table 2 for criteria) during the current reporting period. If recurrence or progression occurred, report **Yes** and specify the site(s) and date of disease recurrence / progression in questions 78 – 104. Enter the date the sample was collected for pathological and laboratory evaluation or enter the date the imaging took place. If the physician determined evidence of disease recurrence or progression in a clinical assessment during an office visit, report the date of the office visit. If the exact date is not known but can be estimated, then use the process for reporting estimated dates as described in the General Instructions, Guidelines for Completing Forms .

If disease recurrent or progression occurred at a site not listed, indicate **Yes**, for “Other site” (question 104), report the date of disease progression and specify the other site.

If recurrence or progression did not occur in the current reporting period, report **No** and continue with question 116.

#### Questions 107 – 115: Specify the methods used to examine sites of disease recurrence / persistence / progression

Specify the methods used to examine the sites of possible disease recurrence, persistence, and / or progression. If the method was performed in the current reporting period, report **Yes** and specify if the assessment was **Positive** or **Negative** to indicate if disease recurrence / persistence / progression was present.

If a method was used to examine sites of possible disease recurrence / persistence / progression in the current reporting period is not listed as an option, report **Yes** for “Other method” (question 113), indicate the disease status as **Positive** or **Negative**, and specify the method. Examples of “other methods” can include laboratory testing such as blood and urine tests (e.g., HMA, VMA) for neuroblastoma.

#### Question 116: Was the recipient given treatment for post-HCT persistent, progressive or recurrent disease since the date of the last report?

Indicate whether the recipient received therapy in the current reporting period for persistent, progressive, or recurrent disease. If therapy for persistent, progressive, or recurrent disease was given, report **Yes**.

If therapy for persistent, progressive, or recurrent disease was not given, report **No** and continue with question 158.

#### Questions 117 – 121: Was radiotherapy given?

Radiation therapy utilizes high-energy radiation to kill cancer cells. Indicate whether radiotherapy was given as treatment for post-transplant persistent, progressive, or recurrent disease. If radiotherapy was given, report **Yes** and specify the site(s) of radiation. If radiotherapy was given to a site not listed, indicate **Yes**, for “Other site” (question 120) and specify the site.

#### Question 122: Specify the date radiotherapy was started

Report the date when the radiotherapy began as treatment for post-transplant persistent, progressive, or recurrent disease. If multiple sites received radiotherapy, report the *first* date when radiation was administered.

#### Question 123: Number of fractions given

Specify the total number of fractions (treatments) given. If radiation was administered to multiple sites, report the number of fractions for the *first* site.

#### Question 124: Dose per fraction

Specify the dose per fraction in centigrays (cGy / rads). If radiation was administered to multiple sites, report the dose per fraction of the *first* site.

#### Questions 125 – 129: Was MIBG given?

Meta-iodobenzylguanidine (MIBG) is a radioisotope that is readily absorbed by neuroblastoma cells, preferentially concentrating in areas of disease. At lower doses, MIBG can be used for imaging purposes. At higher doses, MIBG provides selective antitumor radiotherapy.

Indicate whether MIBG was given as post-transplant therapy for persistent, progressive, or recurrent disease since the date of last report. If MIBG therapy was given, report **Yes**, specify the radioisotope administered, and the MIBG therapy start date. If a radioisotope other than 131 I-MIBG was given, select **Yes** for “other” (question 127) and specify the radioisotope type.


- 131 I-MIBG: Iodine-131 meta-iodobenzylguanidine (I-131 MIBG), commonly known as Azedra is a radiopharmaceutical used for treating certain types of neuroendocrine tumors, including neuroblastomas.
- Other: Targeted radiotherapy such as peptide receptor radionuclide therapy (PRRT).

If MIBG therapy was not given as part of the planned post-HCT therapy in the current reporting period, report **No** and continue with question 130.

#### Questions 130 – 134: Were retinoids given?

Retinoids are vitamin A derivatives that can affect cellular function. Studies have shown that retinoid therapy can result in an antitumor effect.5

Indicate if retinoids were given as post-transplant therapy for persistent, progressive, or recurrent disease since the date of last report. If retinoids were given, report **Yes**, specify the retinoid administered, and the retinoid therapy start date. If a retinoid other than isotretinoin was given, select **Yes** for “other” (question 132) and specify the retinoid type. Report the generic name and not the brand name.


- Isotretinoin: 13-cis-retinoic acid (Isotretinoin) is a retinoid that has been shown to improve survival for high risk neuroblastoma.
- Other: Other types of retinoids given to treat given to treat neuroblastoma include: N-4-hydroxyphenyl retinamide (Fenretinide).

If retinoids were not given as part of the planned post-HCT therapy in the reporting current reporting period, report **No** and continue with question 135.

#### Questions 135 – 141: Was immunotherapy given?

Immunotherapy is typically given to stimulate the body’s own immune system to detect and destroy cancer cells.

Indicate if immunotherapy was given as post-transplant therapy for persistent, progressive, or recurrent disease since the date of last report. If immunotherapy was given, report **Yes**, specify the immunotherapy administered, and the immunotherapy therapy start date. If an immunotherapy was given but is not listed as an option, select **Yes** for “other” (question 139) and specify the immunotherapy type. Report the generic name and not the brand name.


- α – interferon: Interferon alfa is a cytokine. Common names include: Intron® A (interferon alfa-2b), Roferon®-A (interferon alfa-2a).
- Anti-GD2 antibody CH14.18: Anti-GD2 antibody ch14.18/CHO (dinutuximab beta) is a chimeric monoclonal antibody.
- Interleukin-2 (IL-2): Interleukin-2 is s a cytokine. Common names include: Aldesleukin and PROLEUKIN®.
- Other: Other types of immunotherapies given to treat neuroblastoma include: Granulocyte macrophage colony-stimulating factor (GM-CSF).

If immunotherapy was not given as part of the planned post-HCT therapy in the reporting current reporting period, report **No** and continue with question 142.

#### Questions 142 – 154: Was chemotherapy given?

If the recipient received chemotherapy as post-transplant therapy for persistent, progressive, or recurrent disease since the date of last report, then indicate **Yes**, and continue with question 143. If chemotherapy was given, specify the chemotherapy administered, and the chemotherapy therapy start date. If a chemotherapy was given but is not listed as an option, select **Yes** for “other” (question 152) and specify the chemotherapy type. Report the generic name and not the brand name.

Enter the date the chemotherapy began. If the start date is partially known (i.e., the recipient started treatment in mid- July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

If chemotherapy was not given as part of the planned post-HCT therapy in the reporting current reporting period, report **No** and continue with question 155.

#### Questions 155 – 157: Was other treatment given

If a treatment other than radiotherapy, MIBG, retinoids, immunotherapy, or chemotherapy was given as post-transplant therapy for persistent, progressive, or recurrent disease, then indicate **Yes** and specify the treatment and treatment start date. Examples may include intrathecal therapy or surgery.

#### Question 158: What is the current disease status?

Determine the disease status as of the last evaluation in the reporting period using the international working group criteria provided in the Neuroblastoma Response Criteria of the Forms Instructions Manual. Molecular or cytogenetic evidence of disease should not be considered when determining the current disease status.

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 159: Specify the date the current disease status was determined

Report the date of the pathological evaluation or radiographic assessment (e.g., bone marrow biopsy, CT scan, etc.). If no pathologic/radiographic evaluation was reported, report the date of blood / serum / urine assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological, radiographic and / or laboratory evaluations. If the recipient was treated for extramedullary disease and a radiological assessment (e.g., X-ray, CT scan, MRI scan, PET scan) was performed to assess disease response, enter the date the imaging took place for radiologic assessments. If no pathological, radiographic, or laboratory assessment was performed to evaluate the disease status, report the office visit in which the physician clinically assessed the recipient’s response.

#### Signature Lines

The FormsNet3SM application will automatically populate the signature data fields, including name and email address of person completing the form and date upon submission of the form.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)