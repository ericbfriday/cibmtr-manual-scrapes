#### Question 172: Does the current disease status reflect the disease detected in this reporting period section (as captured in questions 89-152), without subsequent therapy?

This section of the form is intended to capture the most recent disease assessments performed in the reporting period. The most recent disease assessments may have already been reported in questions 88-151 (Disease Detection Since the Date of Last Report) and, if that is the case, it is not necessary to report those same disease assessments in questions 172-232 (Disease Status at the Time of Evaluation for this Reporting Period). Refer to the instructions below to determine how to complete this section of the form. Reporting scenarios have also been provided below.

Report “Yes” for question 172 and go to question 233 in any of the following scenarios:


- Disease was detected by any method in the reporting period (reported in the Disease Detected Since the Date of Last Report, questions 88 – 151) and no therapy was given to treat disease between the date(s) of the assessments reported in the Disease Detection Since the Date of Last Report (questions 88 – 151) for the form and the date of contact for this reporting period
- Disease was detected by any method in the reporting period (reported in the Disease Detection Since the Date of Last Report, questions 88 – 151), therapy was administered, but no assessments were performed after the initiation of therapy

Report “No” for question 172 and report the most recent disease assessments in the reporting period in questions 173 – 232 any of the following scenarios:


- Disease was not detected by any method of assessment during the reporting period
- Disease was detected in the reporting period (reported in the Disease Detected Since the Date of Last Report, questions 88 – 151), therapy was administered, and additional assessment(s) were performed after therapy


Report “Not applicable” for question 172 and submit the form if no disease assessments were performed during the current reporting period. This option should not commonly be used as it would indicate that the recipient did not have **any** disease assessments, including a physical exam by their primary care provider, performed during the reporting period.

Contact the CIBMTR Customer Service Center if there are questions regarding whether a visit or test should be reported as a disease assessment.

#### Questions 173-174: Did the recipient have splenomegaly? (at the time of evaluation for this reporting period)

Indicate if the recipient had splenomegaly at the time of evaluation for this reporting period. Splenomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate “yes” if splenomegaly was present at the time of evaluation for this reporting period and report the date of assessment in question 174.

Indicate “no” if splenomegaly was not present at the time of evaluation for this reporting period and continue with question 178.

Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at the time of evaluation for this reporting period and continue with question 178.

Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy or congenital asplenia) and continue with question 178.

#### Question 175: Specify the method used to measure spleen size:

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 176. If the method selected is “ultrasound” or “CT / MRI” continue with question 177. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 176: Specify the spleen size in centimeters below the left costal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 178.

#### Question 177: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 178.

#### Questions 178-179: Did the recipient have hepatomegaly? (at the time of evaluation for this reporting period)

Indicate if the recipient had hepatomegaly at the time of evaluation for this reporting period. Hepatomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding.

Indicate “yes” if hepatomegaly was present at the time of evaluation for this reporting period and report the date of assessment in question 179.

Indicate “no” if hepatomegaly was not present at the time of evaluation for this reporting period and continue with question 183.

Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at the time of evaluation for this reporting period and continue with question 183.

#### Question 180: Specify the method used to measure liver size:

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 181. If the method selected is “ultrasound” or “CT / MRI” continue with question 182. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Questions 181: Specify the liver size in centimeters below the right costal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 183.

#### Question 182: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 183.

#### Question 183: Were molecular tests for molecular markers performed (e.g., PCR)? (at time of evaluation for this reporting period)

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. FISH testing for molecular markers should NOT be reported here.

Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If molecular testing for molecular markers was performed at the time of evaluation for this reporting period, report “yes” and go to question 184.

If molecular testing for molecular markers was not performed at the time of evaluation for this reporting period, or it is unknown if testing was done, report “no” or “unknown” respectively and go to question 191.

#### Question 184: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker associated with the recipient’s primary disease was identified at the time of evaluation for this reporting period.

If a positive molecular marker associated with the recipient’s primary disease was identified at the time of evaluation for this reporting period, select “yes” and continue with question 185.

If there were no molecular markers associated with the recipient’s primary disease identified, no positive molecular markers identified, or it is unknown whether molecular markers were identified, select “no” and continue with question 190.

#### Question 185: Date sample collected

Report the date the sample was collected for molecular testing.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 186-187: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 188. If a positive marker is detected, but not listed as an option, select “other molecular marker” and specify the positive molecular marker in question 187.

#### Questions 188-189: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

Figure 1. Molecular disease assessment with amino acid changes documented (highlighted in yellow).

For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 188, indicate if the amino acid change is “known “or “unknown” for the positive molecular marker reported in questions 186-187. If known, report the amino acid change in question 189. If unknown, continue with question 190.

Copy questions 186-189 to report more than one positive molecular marker.

#### Question 190: Was documentation submitted to the CIBMTR?

Indicate if the pathology report is attached to support the molecular findings reported in questions 186-189. For further instructions on how to attach documents in FormsNet3SM, refer to the Training Guide.

#### Question 191: Was the disease status assessed via flow cytometry? (at the time evaluation for this reporting period)

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

Indicate if flow cytometry was performed on peripheral blood and/or bone marrow sample at the time of evaluation for this reporting period.

If flow cytometry was performed, select “yes” and continue with question 192.

If flow cytometry was not performed, flow cytometry sample was inadequate, or it is unknown if flow cytometry was performed, select “no” and continue with question 200.

#### Question 192-193: Blood

Indicate if flow cytometry was performed on the peripheral blood at the time of evaluation for this reporting period. If multiple assessments were performed, report the assessment performed closest to the date of contact.

If flow cytometry was performed on a peripheral blood sample, select “yes” and report the date the sample was collected in question 193. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a peripheral blood sample, select “no” and continue with question 196.

#### Questions 194-195: Was disease detected?

Indicate if evidence of disease was detected in the peripheral blood sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the patient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 195.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 196.

#### Question 196-197: Bone Marrow

Indicate if flow cytometry was performed on the bone marrow at the time of evaluation for this reporting period. If multiple assessments were performed, report the assessment performed closest to the date of contact.

If flow cytometry was performed on a bone sample, select “yes” and report the date the sample was collected in question 197. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a bone marrow sample, select “no” and continue with question 200.

#### Questions 198-199: Was disease detected?

Indicate if evidence of disease was detected in the bone marrow sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the patient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 199.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 200.

#### Question 200: Were cytogenetics tested (karyotyping or FISH)? (at time of evaluation for this reporting period)

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses large numbers of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic (karyotyping or FISH) studies were obtained at the time of evaluation for this reporting period, report “yes” and continue with question 201.

If no cytogenetic studies were obtained at the time of evaluation for this reporting period, indicate “no” and continue with question 219.

If it is not known whether any cytogenetic studies were obtained at the time of evaluation for this reporting period, indicate “unknown” and go to question 219.

#### Question 201: Were cytogenetics tested via FISH?

If FISH studies were performed at the time of evaluation for this reporting period, report “yes” for question 201 and go to question 202. If FISH studies were not performed, report “no” for question 201 and go to question 210. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Question 202-203: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 203. Continue with question 204. If multiple sources were used to test FISH, the preferred sample is the bone marrow

#### Question 204: Results of test

If FISH assessments identified abnormalities associated with the recipient’s primary disease, indicate “abnormalities identified” and continue with question 205.

If FISH assessments were unremarkable, indicate “no abnormalities” and continue with question 209.

#### Questions 205-208: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 205, then continue with question 206.

Report the number of abnormalities detected by FISH at the time of evaluation for this reporting period in question 206. After indicating the number of abnormalities in question 206, select all abnormalities detected in questions 207-208.

If an abnormality is detected, but not listed as an option in question 207, select “other abnormality” and specify the abnormality in question 208. If multiple “other abnormalities” were detected, report “see attachment” in question 208 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 209: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if the FISH report is attached to support the cytogenetic findings reported in questions 203-208. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 210: Were cytogenetics tested via karyotyping?

If karyotyping studies were performed at the time of evaluation for this reporting period, report “yes” for question 210 and go to question 211. If karyotyping studies were not performed, report “no” for question 210 and go to question 219. Examples of this include: no karyotyping study performed or karyotyping sample was inadequate.

#### Questions 211-212: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 212. Continue with question 213. If multiple sources were used for karyotyping analysis, the preferred sample is the bone marrow.

#### Question 213: Results of test

If karyotyping assessments identified abnormalities associated with the recipient’s primary disease, indicate “abnormalities identified” and continue with question 214.

If karyotyping assessments were unremarkable, indicate “no abnormalities” and continue with question 218.

If karyotyping assessment yielded an inadequate result, indicate “no evaluable metaphases” and continue with question 218.

#### Questions 214-217: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 214, then continue with question 215.

Report the number of abnormalities detected by karyotyping at the time of evaluation for this reporting period in question 215. After indicating the number of abnormalities in question 215, select all abnormalities detected in questions 216-217.

If an abnormality is detected, but not listed as an option in question 216, select “other abnormality” and specify the abnormality in question 217. If multiple “other abnormalities” were detected, report “see attachment” in question 217 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 218: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if the karyotyping report is attached to support the cytogenetic findings reported in questions 212-217. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Questions 219-220: Was disease detected via bone marrow examination? (at the time of evaluation for this reporting period)

If a bone marrow biopsy was performed at the time of evaluation for this reporting period, report “yes” for question 219 and report the date of the assessment in question 220. Continue with question 221.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If multiple bone marrow biopsies were performed during the reporting period, report the date of the assessment performed closest to the date of contact.

If bone marrow biopsies were not performed at any time during the reporting period, or it is unknown if any bone marrow biopsies were done, report “no” or “unknown” respectively and go to question 225.

#### Questions 221-222: Blasts in the bone marrow

Indicate wither the percentage of blasts in the bone marrow was “known” or “unknown” at the time of evaluation for this reporting period. If “known” report the percentage documented on the laboratory report in question 222. If “unknown” continue with question 223.

#### Question 223: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented in the pathology report, select “known,” continue with question 224. If the pathology report is not available and the grade is documented in a physician note, then this would be sufficient.

If the myelofibrosis grade is not documented on the pathology report, select “unknown,” continue with question 225.

#### Question 224: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist or documented in a physician note if the pathology report is not available.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with local bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Questions 225-226: Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma) (at the time of evaluation for this reporting period)

Indicate if the recipient had extramedullary disease indicative of AML at the time of evaluation for this reporting period. An example of extramedullary disease would be a myeloid sarcoma. Indicate “yes” if extramedullary disease indicative of AML was present at the time of evaluation for this reporting period and report the date of assessment in question 226. Indicate “no” if extramedullary disease indicative of AML was not present at the time of evaluation for this reporting period and continue with question 229.

#### Questions 227-228: Specify site(s) of disease (check all that apply)

Select each site where extramedullary disease indicative of AML was detected on the date reported in question 226. If extramedullary disease indicative of AML was detected at a site not specified in question 227, report “other site” and specify all other sites where extramedullary disease indicative of AML have been identified in question 228.

#### Questions 229-231: Was disease status assessed by other assessment? (at the time of evaluation for this reporting period)

Indicate if the recipient’s disease status was assessed by any other assessment at the time of evaluation for this reporting period. Indicate “yes” if the disease status was assessed by other assessment at the time of evaluation for this reporting period, report the date of assessment in question 230, and specify the name of the other assessment in question 231. Indicate “no” if the disease status was not assessed by other assessment at the time of evaluation for this reporting period and continue with question 233.

#### Question 232: Was disease detected?

If the other disease assessment indicated the presence of disease, select “yes” and continue with question 233.

If the other disease assessment did not indicate the presence of disease, select “no” and continue with question 233.

#### Question 233: What is the current disease status?

Report the disease status at the time of evaluation for this reporting period. Some judgment is required when evaluating if the recipient meets all specified CR criteria, specifically ANC and platelet criteria. If the recipient does not meet these parameters, the underlying cause should be assessed. If the cause for a low ANC or a low platelet count is related to MDS, the disease status should not be reported as “complete remission.” If the cause for not meeting one of these parameters is due to something other than underlying hematologic disease, such as renal insufficiency, hemolysis, or drug-related causes, the disease status may still be reported as “complete remission.”

If the recipient’s current disease status was hematologic improvement, continue with question 234.

For all other disease statuses, continue with question 236. See [MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria) for disease status definitions.

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 234: Specify the cell line examined to determine HI status (check all that apply)

Indicate the cell line examined to determine hematologic improvement. To determine the cell line, review the Hematologic Improvement criteria listed in the [MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria) section of the Forms Instruction Manual.

If the cell lines examined to determine hematologic improvement included, “HI – E” continue with question 235.

If the cell lines examined to determine hematologic improvement only included, “HI – P” and / or “HI – N,” continue with question 236.

#### Question 235: Specify transfusion dependence

If the recipient’s current disease status included hematologic improvement – erythroid, indicate the transfusion dependence at the time of evaluation for this reporting period.

Select “Non-transfused (NTD)” if the recipient received zero RBC transfusions within a period of 16 weeks prior to the contact date and continue with question 236.

Select “Low transfusion burden (LTB)” if the recipient had between three and seven RBC transfusions within a period of 16 weeks prior to the contact date in at least two transfusion episodes with a maximum of three transfusion episodes in eight weeks and continue with question 236.

#### Question 236: Date assessed:

Enter the date of the most recent assessment establishing disease status within the reporting period. The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), laboratory assessment (e.g., CBC, peripheral blood smear), and clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations, the date the imaging took place for radiographic assessments, or the date of physical examination.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q229 | 4/19/2025 | Modify | Correct typo: Indicate if the recipient’s disease status was assessed by any other assessment at the time of evaluation for this reporting period. Indicate “yes” if the disease status was assessed by other assessment at the time of evaluation for this reporting period, report the date of assessment in question 230, and specify the name of the other assessment in question 231. Indicate “no” if the disease status was not assessed by other assessment at the time of |
Typo |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)