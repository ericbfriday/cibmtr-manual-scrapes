#### Question 142: Was therapy given since the date of last report for reasons other than relapse or progressive disease? (Include any maintenance and consolidation therapy prior to relapse as well as therapy given for persistent disease that has not progressed):

Indicate if the recipient received therapy post-transplant for any reason other than relapse or progressive disease since the date of last report. If **No** or **Unknown**, continue with question 167.

Recipients are generally transplanted under a specific protocol that defines the systemic therapy the recipient is intended to receive as a preparative regimen prior to the HCT; the infection and GVHD prophylaxis to be administered pre- and/or post-HCT; and any systemic therapy, radiation, and/or other treatments to be administered post-HCT as planned (or maintenance) therapy. Planned (maintenance or consolidation) therapy is given to help prolong a remission. This protocol may be either a research protocol or standard-of-care protocol and should be referred to when completing this section.

Additionally, if post-transplant therapy is given as prophylaxis or maintenance for recipients in CR, or as preemptive therapy for recipients with minimal residual disease, consider this “planned therapy” even if this was not documented prior to the transplant. However, bisphosphonate therapy (e.g., Zometa) should not be reported as a planned therapy since it is universally administered to myeloma patients.

Additionally, supportive care such as Denosumab (e.g. Prolia) should not be reported as planned therapy.

Do not include any treatment administered as a result of relapse or progression.

For the purposes of this question, a line of therapy is one or more cycles of a defined treatment program given to a patient with no progression of disease in between. A new line of therapy may be started for reasons including drug toxicities, planned changes to medications, etc. If a drug dose was changed due to toxicity, do not report this as a new line of therapy; however, if a drug is stopped and a new one started due to toxicity, report this as a new line of therapy.

**Example 1**: A recipient with myeloma goes into transplant having established VGPR prior to transplant and maintains the response throughout the 100-day reporting period. During the six-month reporting period, the recipient achieves a CR and is placed on maintenance lenalidomide therapy at 15 mg/day. The maintenance lenalidomide therapy can be reported in questions 142-166.

**Example 2**: A recipient with myeloma goes into transplant having established PR prior to transplant and achieves a VGPR in the 100-day reporting period. During the six-month reporting period, the recipient maintains the VGPR and is placed on maintenance lenalidomide therapy at 10 mg/day. During the one-year reporting period, the recipient progressed and unplanned treatment is initiated. Only the maintenance lenalidomide would be reported in questions 142-166.

#### Question 143: Systemic therapy

Systemic therapy may be injected into a vein or given orally and is delivered to the whole body via the blood stream. Indicate **Yes** or **No** if systemic therapy was given as part of this line. If **No**, continue with question 155.

#### Questions 144 – 145: Date systemic therapy started

Indicate if the date the therapy started was **Known** or **Unknown**. If **Known**, enter the date the recipient began this line of therapy. If the start date was reported on a previous report, report the same date again when the start / stop dates overlap reporting periods. If **Unknown**, continue with question 146.

If the start date is partially known (i.e., the recipient started treatment in mid-July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 146 – 147: Date therapy stopped

Indicate if the date the therapy stopped is **Known**, **Unknown**, or **Not applicable**. If the stop date is **Known** and the recipient is receiving therapy administered in cycles, report the date the recipient started the last cycle for this line of therapy. If **Unknown**, continue with question148. Report **Not applicable** if the recipient is still receiving therapy and continue with question 150.

If the recipient is receiving therapy administered on a daily basis (e.g., lenalidomide therapy at 10 mg/day) report the last date the recipient received the line of therapy.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 148-149: Reason stopped

Indicate the reason that this line of therapy stopped. If the reason the line of therapy was stopped is not listed in this section, select **Other** and report the specific reason.

#### Questions 150 – 151: Was a standard drug regimen given?

Systemic chemotherapy / immunotherapy may involve administration of multiple drugs / agents during the line of therapy. Rather than reporting each drug separately, standard combination regimens should be reported using the options in question 151 when available. Review the regimen options provided in question 151. If the recipient’s line of therapy includes one of the regimens listed, report **Yes** and indicate the regimen that was given. If the recipient did not receive one of the standard regimens provided in question 151 as part of the line of therapy being reported, indicate **No** and go to question 152.

Only one regimen may be reported for question 151. Generally, each regimen should be reported as a separate line of therapy. If the recipient received a regimen specified in question 151 as well as additional systemic therapy drugs as part of the line of therapy being reported, indicate the standard regimen in question 151 and report the additional drugs in 152-154.

#### Questions 152 – 154: Were systemic drugs given?

Questions 152-154 are intended to capture systemic therapy drugs / agents not already reported in questions 150-151. If part or all of the recipient’s regimen can be reported in questions 150-151, report them in those questions and do not report them again in questions 152-154. If all systemic therapy drugs given as part of the line of therapy being reported were included in the regimen indicated in question 151, report **No** and go to question 155.

If the recipient received systemic chemotherapy drugs not already reported in questions 150-151 as part of the line of therapy being reported, report **Yes** and specify the chemotherapy drug(s) in questions 153-154. Otherwise, report **No** and go to question 155.

If the center needs to report a systemic chemotherapy drug (or drugs) in question 153, but it is not listed as an option, report **Other systemic therapy** and specify any drugs not already reported. Only report systemic chemotherapy drugs in questions 152-154.

#### Question 155: Radiation therapy

Radiation therapy uses high-energy radiation to kill cancer cells. For multiple myeloma, external beam radiation is used most frequently. In this method, a beam of radiation is delivered to a specific part of the body, such as a lytic lesion or plasmacytoma. Indicate **Yes** or **No** if the recipient received radiation during this reporting period post-HCT or post-cellular therapy. If **No**, continue with question 162.

#### Questions 156 – 157: Date radiation therapy started

Indicate if the date the radiation therapy started is **Known** or **Unknown**. If **Known**, enter the date the line of radiation therapy began.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 158 – 159 Date therapy stopped

Indicate if the date the radiation therapy stopped is **Known**, **Unknown**, or **Not applicable**. If **Known**, enter the date the line of radiation therapy ended. Report **Not applicable** if the recipient is still receiving therapy. When **Not applicable** is selected, the radiation dose will not be reported in the next question. However, once radiation stops (i.e., the radiation stop date is **Known**), the dose will be reported.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 160 – 161: Dose of radiation therapy

Indicate if the dose of radiation administered was **Known** or **Unknown**. If **Known**, indicate the total dose of radiation given. If radiation was given as a single dose, the amount of radiation delivered in the single dose constitutes the total dose. If the radiation was given in fractionated doses, multiply the total number of fractions by the dose per fraction to determine the total dose. Enter the total dose of radiation in either grays (Gy) or centigrays (cGy). If **Unknown**, continue with question 162.

**Example A:**

Radiation order: TBI, 200 cGy/day for three days (3 doses)

Total dose: 200 cGy x 3 doses = 600 cGy

Report “Dose of radiation therapy” as 600 cGy

If radiation started in a previous reporting period (i.e., **Not applicable** was reported as the therapy end date for the prior reporting period) and continued into the current reporting period, report the total dose administered since radiation started (including the doses given in the previous reporting period).

**Example B**: A recipient started radiation at end of the Day 100 reporting period. 200 cGy for 3 doses were given (total dose in the Day 100 reporting period is 600 cGy). Radiation continued into the 6-month reporting period and an additional 200 cGy for 4 doses were given (total dose given in the 6-month reporting period is 800 cGy). The total dose of radiation should be reported as 1400 cGy (600 cGy + 800 cGy).

#### Question 162: Cellular therapy (e.g., CAR-T cells)

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR-T cells).

Report **Yes** if the recipient received cellular therapy as part of the line of therapy being reported. If not, report **No**. If yes was reported, a Pre-CTED (4000) Form should be completed for the cellular therapy infusion.

#### Question 163: Best hematologic response to line of therapy

Indicate the best response to the line of therapy. See the [Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria) section for multiple myeloma and solitary plasmacytoma disease status definitions. See [Plasma Cell Leukemia Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/pcl-response-criteria) for plasma cell leukemia disease status definitions.

For more information on determining what baseline values to use to determine best response, see [Appendix G](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-g).

The percentage of plasma cells in the bone marrow aspirate may also be identified on a flow cytometry report. A flow cytometry result may be used to confirm CR (e.g., < 5% plasma cells in the bone marrow) as long as the method was high sensitivity or next generation flow.

If the disease response following this line of therapy is unknown, select **Unknown**.

#### Question 164: Date best hematologic response to line of therapy assessed

Any response requires two consecutive assessments (of the same labs, where applicable based on response criteria) made at any time before the start of a new therapy. Enter the date the best response to the line of therapy was established. In other words, report the date of the first assessment, not the date of the second confirmatory assessment. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathological evaluation. If recipient is still receiving treatment, the date assessed should be the date of best response within the current reporting period.

#### Question 165: Best hematologic response to line of therapy (for Amyloid patients only)

Indicate the best response to the line of therapy. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for disease status definitions.

#### Question 166: Date best response to line of therapy assessed

Enter the date the best response was assessed. Report the date of the first assessment, not the date of the second confirmatory assessment. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathologic examination.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 167: Has the disease relapsed or progressed since the date of last report?

Indicate **Yes** if a relapse or progression occurred since the date of the last report. Documentation of relapse or progression requires two consecutive assessments (of the same labs, where applicable based on response criteria) made at any time before classification as relapse or progression, and/or the start of a new therapy.

Indicate **No** if the recipient did not experience a relapse or progression since the date of the last report and continue with question 169. If it is unknown if the recipient relapsed or progressed since the date of the last report, report **Unknown** and continue with question 169.

See [Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria) for progressive disease and Relapse from CR disease status definitions.

#### Question 168: Date of relapse / progression

Enter the date the relapse or progression occurred during the reporting period. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP / UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathological evaluation.

#### Question 169: Was treatment given for relapse or progression?

Indicate **Yes** or **No** if the recipient received treatment post-infusion for relapsed or progressive disease since the date of last report. If **No**, continue with question 190.

#### Question 170: Systemic therapy

Systemic therapy may be injected into a vein or given orally and is delivered to the whole body via the blood stream. Indicate **Yes** or **No** if systemic therapy was given as part of this line. If **No**, continue with question 182.

#### Questions 171 – 172: Date systemic therapy started

Indicate if the date the therapy started was **Known** or **Unknown**. If **Known**, enter the date the recipient began this line of therapy. If the start date was reported on a previous report, report the same date again when the start/stop dates overlap reporting periods. If **Unknown**, continue with question 173.

If the start date is partially known (i.e., the recipient started treatment in mid-July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 173 – 174: Date therapy stopped

Indicate if the date the therapy stopped is **Known**, **Unknown**, or **Not applicable**. If the stop date is **Known** and the recipient is receiving therapy administered in cycles, report the date the recipient started the last cycle for this line of therapy. If **Unknown**, continue with question 175. Report **Not applicable**, if the recipient is still receiving therapy and continue with question 177.

If the recipient is receiving therapy administered on a daily basis (e.g., lenalidomide therapy at 10 mg/day) report the last date the recipient received the line of therapy.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 175 – 176: Reason therapy stopped

Indicate the reason that this line of therapy stopped. If the reason the line of therapy was stopped is not listed in this section, select **Other** and report the specific reason.

#### Questions 177 – 178: Was a standard drug regimen given?

Systemic chemotherapy / immunotherapy may involve administration of multiple drugs / agents during the line of therapy. Rather than reporting each drug separately, standard combination regimens should be reported using the options in question 178 when available. Review the regimen options provided in question 178. If the recipient’s line of therapy includes one of the regimens listed, report **Yes** and indicate the regimen that was given in question 178. If the recipient did not receive one of the standard regimens provided in question 178 as part of the line of therapy being reported, indicate **No** for question 177 and go to question 179.

Only one regimen may be reported for question 178. Generally, each regimen should be reported as a separate line of therapy. If the recipient received a regimen specified in question 178 as well as additional systemic therapy drugs as part of the line of therapy being reported, indicate the standard regimen in question 178 and report the additional drugs in 179-181.

#### Questions 179 – 181: Were systemic drugs given?

Questions 179-181 are intended to capture systemic therapy drugs / agents not already reported in questions 177-178. If part or all of the recipient’s regimen can be reported in questions 177-178, report them in those questions and do not report them again in questions 179-181. If all systemic therapy drugs given as part of the line of therapy being reported were included in the regimen indicated in question 178, report **No**.

If the recipient received systemic chemotherapy drugs not already reported in questions 177-178 as part of the line of therapy being reported, report **Yes** specify the chemotherapy drug(s) in questions 180-181. Otherwise, report **No** and go to question 182.

If the center needs to report a systemic chemotherapy drug (or drugs) in question 180, but it is not listed as an option, report **Other systemic therapy** and specify any drugs not already reported. Only report systemic chemotherapy drugs in questions 179-181.

#### Question 182: Radiation therapy

Radiation therapy uses high-energy radiation to kill cancer cells. For multiple myeloma, external beam radiation is used most frequently. In this method, a beam of radiation is delivered to a specific part of the body, such as a lytic lesion or plasmacytoma. Indicate **Yes** or **No** if the recipient received radiation during this reporting period post-HCT or post-cellular therapy. If **No**, continue with question 189.

#### Questions 183 – 184: Date radiation therapy started

Indicate if the date the radiation therapy started is **Known** or **Unknown**. If **Known**, enter the date the line of radiation therapy began.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 185 – 186: Date therapy stopped

Indicate if the date the radiation therapy stopped is **Known**, **Unknown**, or **Not applicable**. If **Known**, enter the date the line of radiation therapy ended. Report **Not applicable** if the recipient is still receiving therapy and continue with question 189.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 187 – 188: Dose of radiation therapy

Indicate if the dose of radiation administered was **Known** or **Unknown**. If **Known**, indicate the total dose of radiation given. If radiation was given as a single dose, the amount of radiation delivered in the single dose constitutes the total dose. If the radiation was given in fractionated doses, multiply the total number of fractions by the dose per fraction to determine the total dose. Enter the total dose of radiation in either grays (Gy) or centigrays (cGy). If **Unknown**, continue with question 189.

**Example:**

Radiation order: TBI, 200 cGy/day for three days (3 doses)

Total dose: 200 cGy x 3 doses = 600 cGy

Report “Dose of radiation therapy” as 600 cGy

#### Question 189: Cellular therapy (e.g., CAR-T cells)

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR-T cells).

Report **Yes** if the recipient received cellular therapy as part of the line of therapy being reported. If not, report **No**. If **Yes** was reported, a Pre-CTED (4000) Form should be completed for the cellular therapy infusion.

Copy questions 170-189 to report more than one line of therapy.

#### Question 190: Was maintenance therapy given after treatment relapse / progression since the date of last report?

Indicate if the recipient received maintenance therapy *after* treatment for relapse / progression since the date of last report. If **No**, continue with question 211.

If it is not known or not possible to determine if the recipient was placed on subsequent maintenance therapy after treatment for relapse / progression, then select **Unknown** and proceed to question 211. This option should be used sparingly and only in cases when it is truly unknown as to whether maintenance therapy was given within the reporting period after treatment for relapse / progression.

Indicate **Not Applicable** if the recipient did not receive treatment for relapse / progression and continue with questions 211. See the example below:

**Example:** A recipient was in CR and was receiving maintenance Revlimid. Due to health issues, the maintenance therapy was briefly discontinued; however, the recipient’s IgG reappeared during this time. The patient was not treated for relapse and eventually continued on with the Revlimid maintenance. In this case, question 190 would be answered as “Not Applicable” because he was not treated for relapse but instead continued on with his maintenance therapy.

#### Question 191: Systemic therapy

Systemic therapy may be injected into a vein or given orally and is delivered to the whole body via the blood stream. Indicate **Yes** or **No** if systemic therapy was given as part of this line of therapy. If **No**, continue with question 203.

#### Questions 192 – 193: Date systemic therapy started

Indicate if the date the therapy started was **Known** or **Unknown**. If **Known**, enter the date the recipient began this line of therapy. If the start date was reported on a previous report, report the same date again when the start / stop dates overlap reporting periods. If **Unknown**, continue with question 194.

If the start date is partially known (i.e., the recipient started treatment in mid-July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 194 – 195: Date therapy stopped

Indicate if the date the therapy stopped is **Known**, **Unknown**, or **Not applicable**. If the stop date is **Known** and the recipient is receiving therapy administered in cycles, report the date the recipient started the last cycle for this line of therapy. If **Unknown**, continue with question 196. Report **Not applicable** if the recipient is still receiving therapy and continue with question 198.

If the recipient is receiving therapy administered on a daily basis (e.g., lenalidomide therapy at 10 mg/day) report the last date the recipient received the line of therapy.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 196 – 197: Reason stopped:

Indicate the reason that this line of therapy stopped. If the reason the line of therapy was stopped is not listed in this section, select **Other** and report the specific reason.

#### Questions 198 – 199: Was a standard drug regimen given?

Systemic chemotherapy / immunotherapy may involve administration of multiple drugs / agents during the line of therapy. Rather than reporting each drug separately, standard combination regimens should be reported using the options in question 199 when available. Review the regimen options provided in question 199. If the recipient’s line of therapy includes one of the regimens listed, report **Yes** and indicate the regimen that was given. If the recipient did not receive one of the standard regimens provided in question 199 as part of the line of therapy being reported, indicate **No** and go to question 200.

Only one regimen may be reported for question 199. Generally, each regimen should be reported as a separate line of therapy. If the recipient received a regimen specified in question 199 as well as additional systemic therapy drugs as part of the line of therapy being reported, indicate the standard regimen in question 199 and report the additional drugs in 200-202.

#### Questions 200 – 202: Were systemic drugs given?

Questions 200-202 are intended to capture systemic therapy drugs / agents not already reported in questions 198-199. If part or all of the recipient’s regimen can be reported in questions 198-199, report them in those questions and do not report them again in questions 200-202. If all systemic therapy drugs given as part of the line of therapy being reported were included in the regimen indicated in question 199, report “no” for question 200 and go to question 203.

If the recipient received systemic chemotherapy drugs not already reported in questions 198-199 as part of the line of therapy being reported, report **Yes** and specify the chemotherapy drug(s). Otherwise, report **No** and go to question 203.

If the center needs to report a systemic chemotherapy drug (or drugs) in question 201, but it is not listed as an option, report **Other systemic therapy** and specify any drugs not already reported. Only report systemic chemotherapy drugs in questions 200-202.

#### Question 203: Radiation therapy

Radiation therapy uses high-energy radiation to kill cancer cells. For multiple myeloma, external beam radiation is used most frequently. In this method, a beam of radiation is delivered to a specific part of the body, such as a lytic lesion or plasmacytoma. Indicate **Yes** or **No** if the recipient received radiation during this reporting period post-HCT or post-cellular therapy. If **No**, continue with question 210.

#### Questions 204 – 205: Date radiation therapy started

Indicate if the date the therapy started is **Known** or **Unknown**. If **Known**, enter the date the line of radiation therapy began.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 206 – 207: Date radiation therapy stopped

Indicate if the date the therapy started is **Known**, **Unknown**, or **Not applicable**. If **Known**, enter the date the line of radiation therapy ended. Report **Not applicable** if the recipient is still receiving therapy and continue with question 210.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 208 – 209: Dose of radiation therapy

Indicate if the dose of radiation administered was **Known** or **Unknown**. If **Known**, indicate the total dose of radiation given. If radiation was given as a single dose, the amount of radiation delivered in the single dose constitutes the total dose. If the radiation was given in fractionated doses, multiply the total number of fractions by the dose per fraction to determine the total dose. Enter the total dose of radiation in either grays (Gy) or centigrays (cGy). If **Unknown**, continue with question 210.

**Example:**

Radiation order: TBI, 200 cGy/day for three days (3 doses)

Total dose: 200 cGy x 3 doses = 600 cGy

Report “Dose of radiation therapy” as 600 cGy

#### Question 210: Cellular therapy (e.g., CAR-T cells)

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR-T cells).

Report **Yes** if the recipient received cellular therapy as part of the line of therapy being reported. If not, report **No**. If **Yes** was reported, a Pre-CTED (4000) Form should be completed for the cellular therapy infusion.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q158 | 5/20/2022 | Add | Clarification added that Q160 will not come due when NA is reported: Indicate if the date the radiation therapy stopped is Known, Unknown, or Not applicable. If Known, enter the date the line of radiation therapy ended. Report Not applicable if the recipient is still receiving therapy. When Not applicable is selected, the radiation dose will not be reported in the next question. However, once radiation stops (i.e., the radiation stop date is Known), the dose will be reported. |
Due to change in FormsNet validation |
| Q160 | 5/20/2022 | Add | Instructions added on how to report the total dose when radiation continued from the prior reporting period: If radiation started in a previous reporting period (i.e., Not applicable was reported as the therapy end date for the prior reporting period) and continued into the current reporting period, report the total dose administered since radiation started (including the doses given in the previous reporting period). Example B: A recipient started radiation at end of the Day 100 reporting period. 200 cGy for 3 doses were given (total dose in the Day 100 reporting period is 600 cGy). Radiation continued into the 6-month reporting period and an additional 200 cGy for 4 doses were given (total dose given in the 6-month reporting period is 800 cGy). The total dose of radiation should be reported as 1400 cGy (600 cGy + 800 cGy). |
Due to change in FormsNet validation |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)