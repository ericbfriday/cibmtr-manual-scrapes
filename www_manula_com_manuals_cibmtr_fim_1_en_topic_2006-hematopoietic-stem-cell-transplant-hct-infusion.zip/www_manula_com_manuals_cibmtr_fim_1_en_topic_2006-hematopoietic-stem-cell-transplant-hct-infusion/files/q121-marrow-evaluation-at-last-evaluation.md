#### Questions 121: Was a marrow aspirate and / or biopsy performed?

Indicate **Yes** or No if a marrow aspirate and or biopsy was performed in this reporting period. Additionally, complete the Laboratory Studies (3502) Form and Marrow Surveillance (3506) Form. The intent is to screen for and/or identify changes in the marrow such as dysplasia, MDS, or new hematologic malignancy

Report **Unknown** if not documented

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Oct 27, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)