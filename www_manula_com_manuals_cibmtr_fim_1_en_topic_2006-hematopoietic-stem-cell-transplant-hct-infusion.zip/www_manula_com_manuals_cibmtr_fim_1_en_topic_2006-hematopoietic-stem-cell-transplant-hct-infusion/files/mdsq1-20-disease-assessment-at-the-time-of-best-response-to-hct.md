Best response is based on response to the HCT or cellular therapy infusion, but does not include response to any therapy given for disease relapse or progression post-HCT or post-cellular therapy. When determining the best response to HCT or cellular therapy infusion, compare the post-HCT or post-cellular therapy disease status to the status immediately prior to the preparative regimen or infusion, regardless of time since HCT or cellular therapy. This comparison is meant to capture the best disease status in response to HCT or cellular therapy that occurred during the same reporting interval, even if a subsequent disease relapse or progression occurred during the same reporting interval. If a recipient already achieved their best response in a previous reporting interval, confirm the best response and indicate that the date was previously reported (question 5).

#### Question 1: Compared to the disease status prior to the preparative regimen, what was the best response to HCT or cellular therapy since the date of the last report? (Include response to any therapy given for post-HCT or post-cellular therapy maintenance or consolidation, but exclude any therapy given for relapsed, persistent, or progressive disease)

The intent of this question is to determine the best response to HCT or cellular therapy overall. This is assessed in each reporting period. When evaluating the best response, determine the disease status within the reporting period and compare it to all previous post-HCT or post-cellular therapy reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status.

Any specified therapy administered post-HCT to prolong remission or for minimal residual disease, is considered part of the HCT and should be included when assessing the recipient’s response to transplant. Treatment given post-HCT for relapsed or persistent disease is not considered part of the HCT and should be excluded when assessing the response to HCT. If treatment was given post-HCT for relapsed or persistent disease, assess the patient’s best response **prior** to the start of therapy. If therapy was given for reasons other than relapsed or persistent disease, assess the patient’s best response throughout the entire duration of the reporting period.

If the recipient was in remission at the start of the preparative regimen, indicate “continued complete remission” and continue with question 73.

If the recipient’s best response to HCT or cellular therapy was hematologic improvement, continue with question 2.

For all other responses, continue with question 4. See [MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria) for disease status definitions.

#### Question 2: Specify the cell line examined to determine HI status (check all that apply)

Indicate the cell line examined to determine hematologic improvement – select all that apply. To determine the cell line, review the Hematologic Improvement criteria listed in the MDS Response Criteria section of the Forms Instruction Manual.

If the cell lines examined to determine hematologic improvement included, “HI – E” continue with question 3.

If the cell lines examined to determine hematologic improvement only included, “HI – P” and / or “HI – N,” continue with question 4.

#### Question 3: Specify transfusion dependence (at the time of best response)

If the recipient’s disease status at the time of best response included hematologic improvement – erythroid, indicate the transfusion dependence at the time of best response to infusion.

Select “Non-transfused (NTD)” if the recipient received zero RBC transfusions within a period of 16 weeks prior to the date of the best response and continue with question 4.

Select “Low transfusion burden (LTB)” if the recipient had between three and seven RBC transfusion within a period of 16 weeks prior to the date of the best response in at least two transfusion episodes with a maximum of three transfusion episodes in eight weeks and continue with question 4.

#### Question 4: Was the date of best response previously reported?

If the best response to HCT / cellular therapy was first documented during the current reporting period, report “no” and go to question 5. If the best response was achieved during a previous reporting period (and therefore reported on a previous MDS Post-Infusion Data Form), report “yes” and go to question 73.

Do not report “yes” if completing this form for the 100 day reporting period.

#### Question 5: Date assessed:

Indicate the date the best response was achieved. Report the date of the pathological evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluations. This should be the earliest date when all international working group criteria for the response reported in question 1 were met.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Disease Assessments at the Time of Best Response**

For reporting purposes, the definition of “at the time of best response” depends on the reporting period. See Disease Assessment Time Windows below. Only consider assessments with samples collected within the time window which corresponds to the follow-up form being completed. If assessments were performed during the reporting period, but the samples were not collected within the indicated time window, consider them not done and report “no” when completing questions 6-72.

**Table 1.** Disease Assessment Time Windows

| Follow-up Form | Approximate Time Window |
|---|---|
| 100 Day | + / – 15 days of date of best response (Question 6) |
| 6 Month | + / – 15 days of date of best response (Question 6) |
| Annual | + / – 30 days of date of best response (Question 6) |

#### Questions 6-7: Did the recipient have splenomegaly? (at the time of best response)

Indicate if the recipient had splenomegaly at the time of best response. Splenomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate “yes” if splenomegaly was present at the time of best response and report the date of assessment in question 7. Indicate “no” if splenomegaly was not present at the time of best response and continue with question 12. Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at the time of best response and continue with question 12. Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy or congenital asplenia) and continue with question 12.

#### Question 8: Specify the method used to measure spleen size:

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 9. If the method selected is “ultrasound” or “CT / MRI” continue with question 10. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 9: Specify the spleen size in centimeters below the left costal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 11.

#### Question 10: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 11.

#### Question 11: Was this considered a disease relapse?

If the physician believes the size of the spleen indicates a disease relapse, report “yes.” If the recipient had an enlarged spleen, but the physician does not believe the finding represents disease relapse, report “no.” Continue with question 12.

#### Questions 12-13: Did the recipient have hepatomegaly? (at the time of best response)

Indicate if the recipient had hepatomegaly at the time of best response. Hepatomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Indicate “yes” if hepatomegaly was present at the time of best response and report the date of assessment in question 13. Indicate “no” if hepatomegaly was not present at the time of best response and continue with question 18. Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at the time of best response and continue with question 18.

#### Question 14: Specify the method used to measure liver size:

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 15. If the method selected is “ultrasound” or “CT / MRI” continue with question 16. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Questions 15: Specify the liver size in centimeters below the right costal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 17.

#### Question 16: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 17.

#### Question 17: Was this considered a disease relapse?

If the physician believes the size of the liver indicates a disease relapse, report “yes.” If the recipient had an enlarged liver, but the physician does not believe the finding represents disease relapse, report “no.” Continue with question 18.

#### Question 18: Were molecular tests for molecular markers performed (e.g., PCR)? (at time of best response)

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. FISH testing for molecular markers should **NOT** be reported here.

Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If molecular testing for molecular markers was performed at the time of best response (see Table 1), report “yes” and go to question 19.

If molecular testing for molecular markers was not performed at the time of best response, or it is unknown if testing was done, report “no” or “unknown” respectively and go to question 27.

#### Question 19: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker associated with the recipient’s primary disease was identified at the time of best response.

If a positive molecular marker associated with the recipient’s primary disease was identified, select “yes” and continue with question 20.

If there were no molecular markers associated with the recipient’s primary disease identified, no positive molecular markers identified, or it is unknown whether molecular markers were identified, select “no” and continue with question 27.

#### Question 20: Date sample collected

Report the date the sample was collected for molecular testing.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 21-22: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 23. If a positive marker is detected, but not listed as an option, select “other molecular marker” and specify the positive molecular marker in question 22.

#### Questions 23-24: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

Figure 1. Molecular disease assessment with amino acid changes documented (highlighted in yellow).

For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 23, indicate if the amino acid change is “known “or “unknown” for the positive molecular marker reported in questions 21-22. If known, report the amino acid change in question 24. If unknown, continue with question 25.

Copy questions 21-24 to report more than one positive molecular marker.

#### Question 25: Was this considered a disease relapse?

Indicate if the molecular abnormalities were considered a disease relapse. Criteria for molecular relapse are established by clinical judgment and should reflect the clinical decision of the transplant physician. A recipient may be reported to have molecular relapse even in the setting of hematologic CR; criteria for complete remission are based on hematologic and pathologic characteristics and are independent of molecular markers of disease.

If the recipient has molecular abnormalities that the physician considers to be consistent with disease relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form.

If the recipient has molecular abnormalities that the physician does not consider to be consistent with molecular relapse, select “no.”

#### Question 26: Was documentation submitted to the CIBMTR?

Indicate if the molecular report is attached to support the molecular findings reported in questions 20-24. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 27: Was the disease status assessed via flow cytometry? (at the time of best response)

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

Indicate if flow cytometry was performed on peripheral blood and / or bone marrow sample at the time the recipient achieved their best response post-HCT.

If flow cytometry was performed, select “yes” and continue with question 28.

If flow cytometry was not performed, the flow cytometry sample was inadequate, or it is unknown if flow cytometry was performed, select “no” and continue with question 38.

#### Question 28-29: Blood

Indicate if flow cytometry was performed on the peripheral blood at the time of best response. If multiple assessments were performed, report the assessment performed closest to the date of the best response.

If flow cytometry was performed on a peripheral blood sample, select “yes” and report the date the sample was collected in question 29. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a peripheral blood sample, select “no” and continue with question 33.

#### Questions 30-31: Was disease detected?

Indicate if evidence of disease was detected in the peripheral blood sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the patient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 31.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 33.

#### Question 32: Was the status considered a disease relapse?

Indicate if the peripheral blood flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with flow cytometric relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 33.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select “no.” Continue with question 33.

#### Question 33-34: Bone Marrow

Indicate if flow cytometry was performed on the bone marrow at the time of best response. If multiple assessments were performed, report the assessment performed closest to the date of the best response.

If flow cytometry was performed on a bone marrow sample, select “yes” and report the date the sample was collected in question 34. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, Guidelines for Completing Forms.

If flow cytometry was not performed on a bone marrow sample, select “no” and continue with question 38.

#### Questions 35-36: Was disease detected?

Indicate if evidence of disease was detected in the bone marrow sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the patient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the bone marrow as documented in the flow cytometry report in question 36.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 38.

#### Question 37: Was the status considered a disease relapse?

Indicate if the bone marrow flow cytometry results were considered consistent with disease relapse. Criteria for flow cytometric relapse are established by clinical judgment. If the recipient has abnormalities by flow cytometry that the physician considers to be consistent with flow cytometric relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 38.

If the recipient has residual disease by flow cytometry that the physician does not consider to be consistent with relapse, select “no.” Continue with question 38.

#### Question 38: Were cytogenetics tested (karyotyping or FISH)? (at time of best response)

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic (karyotyping or FISH) studies were obtained at the time of best response (see Table 1), report “yes” and continue with question 39.

If no cytogenetic studies were obtained at the time of best response, indicate “no” and continue with question 59.

If it is not known whether any cytogenetic studies were obtained at the time of best response, indicate “unknown” and go to question 59.

#### Question 39: Were cytogenetics tested via FISH?

If FISH studies were performed at the time of best response (see Table 1), report “yes” for question 39 and go to question 40. If FISH studies were not performed, report “no” for question 39 and go to question 49. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Questions 40-41: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 41. Continue with question 42. If multiple sources were used to test FISH, the most preferred sample is the bone marrow.

#### Question 42: Results of test

If FISH assessments identified abnormalities associated with the recipient’s primary disease, indicate “abnormalities identified” and continue with question 43.

If FISH assessments were unremarkable, indicate “no abnormalities” and continue with question 47.

#### Questions 43-46: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 43, then continue with question 44.

Report the number of abnormalities detected by FISH at the time of best response (see Table 1) in question 44. After indicating the number of abnormalities in question 44, select all abnormalities detected in questions 45-46.

If an abnormality is detected, but not listed as an option in question 45, select “other abnormality” and specify the abnormality in question 46. If multiple “other abnormalities” were detected, report “see attachment” in question 46 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 47: Was this considered a disease relapse?

Indicate if the FISH results were considered consistent with disease relapse. Criteria for FISH relapse are established by clinical judgment. If the recipient has abnormalities detected by FISH that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 48.

If the recipient has residual disease by FISH that the physician does not consider to be consistent with relapse, select “no.” Continue with question 48.

#### Question 48: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if the FISH report is attached to support the cytogenetic findings reported in questions 39-47. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 49: Were cytogenetics tested via karyotyping?

If karyotyping studies were performed at the time of best response (see Table 1), report “yes” for question 49 and go to question 50. If karyotyping studies were not performed, report “no” for question 49 and go to question 59. Examples of this include: no karyotyping study performed or karyotyping sample was inadequate.

#### Question 50-51: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 51. Continue with question 52. If multiple sources were used for karyotyping analysis, the preferred sample is the bone marrow.

#### Question 52: Results of test

If karyotyping assessments identified abnormalities associated with the recipient’s primary disease, indicate “abnormalities identified” and continue with question 53.

If karyotyping assessments were unremarkable, indicate “no abnormalities” and continue with question 57.

If karyotyping assessment yielded an inadequate result, indicate “no evaluable metaphases” and continue with question 57.

#### Questions 53-56: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 53, then continue with question 54.

Report the number of abnormalities detected by karyotyping at the time of best response (see Table 1) in question 54. After indicating the number of abnormalities in question 54, select all abnormalities detected in questions 55-56.

If an abnormality is detected, but not listed as an option in question 55, select “other abnormality” and specify the abnormality in question 56. If multiple “other abnormalities” were detected, report “see attachment” in question 56 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 57: Was this considered a disease relapse?

Indicate if the karyotyping results were considered consistent with disease relapse. Criteria for karyotyping relapse are established by clinical judgment. If the recipient has abnormalities detected by karyotyping that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 58.

If the recipient has residual disease by karyotyping that the physician does not consider to be consistent with relapse, select “no.” Continue with question 58.

#### Question 58: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if the karyotyping report is attached to support the cytogenetic findings reported in questions 50-56. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Questions 59-60: Was a bone marrow examination performed? (at the time of best response)

If a bone marrow examination was performed at the time of best response, select “yes” for question 59 and report the date the sample was collected in question 60.

If a bone marrow examination was not performed or it is unknown if performed at the time of best response, select “no” or “unknown” and continue with question 65.

#### Questions 61-62: Blasts in the bone marrow

Indicate wither the percentage of blasts in the bone marrow was “known” or “unknown” at the time of best response. If “known” report the percentage documented on the laboratory report in question 62. If “unknown” continue with question 63.

#### Question 63: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented in the pathology report, select “known,” continue with question 64. If the pathology report is not available and the grade is documented in a physician note, then this would be sufficient.

If the myelofibrosis grade is not documented on the pathology report, select “unknown,” continue with question 65.

#### Question 64: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist or may be found in the physician note.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with local bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Question 65: Was this considered a disease relapse?

Indicate if the myelofibrosis grade by WHO classification was considered a disease relapse. Criteria for myelofibrosis relapse are established by clinical judgment. If the recipient has a myelofibrosis grade by WHO classification that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 66.

If the recipient has residual myelofibrosis that the physician does not consider to be consistent with relapse, select “no.” Continue with question 66.

#### Questions 66-67: Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma) (at the time of best response)

Indicate if the recipient had extramedullary disease indicative of AML at the time of best response. An example of extramedullary disease would be a myeloid sarcoma. Indicate “yes” if extramedullary disease indicative of AML was present at the time of best response and report the date of assessment in question 67. Indicate “no” if extramedullary disease indicative of AML was not present at the time of best response and continue with question 68.

#### Questions 68-70: Was disease status assessed by other assessment? (at the time of best response)

Indicate if the recipient’s disease status was assessed by any other assessment at the time of best response. Indicate “yes” if the disease status was assessed by other assessment at the time of best response, report the date of assessment in question 69, and specify the name of the other assessment in question 70. Indicate “no” if the disease status was not assessed by other assessment at the time of best response and continue with question 73.

#### Question 71: Was disease detected?

If the other disease assessment indicated the presence of disease, select “yes” and continue with question 72.

If the other disease assessment did not indicate the presence of disease, select “no” and continue with question 73.

#### Question 72: Was this considered a disease relapse?

Indicate if the result of the other disease assessment was considered a disease relapse. Criteria for disease relapse are established by clinical judgment. If the recipient has another disease assessment that the physician considers to be consistent with relapse, select “yes.” Also report relapse or progression under the “Disease Detection Since the Date of Last Report” section of this form. Continue with question 73.

If the recipient has another disease assessment that the physician does not consider to be consistent with relapse, select “no.” Continue with question 73.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| .Q59 – 60 | 9/16/2022 | Modify | If |
Update to be consistent with the question text asks |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)