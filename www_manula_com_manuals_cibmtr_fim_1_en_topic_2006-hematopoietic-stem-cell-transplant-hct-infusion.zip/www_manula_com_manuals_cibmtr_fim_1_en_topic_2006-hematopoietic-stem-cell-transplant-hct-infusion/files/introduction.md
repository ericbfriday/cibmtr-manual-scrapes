The Center for International Blood and Marrow Transplant Research (CIBMTR) brings together the expertise and unique resources of two leaders in the field of blood and marrow transplant research: nmdp and the Medical College of Wisconsin’s International Bone Marrow Transplant Registry and Autologous Blood and Marrow Transplant Registry.

This partnership makes it easier to design, conduct and support clinical studies that involve large numbers of recipients from multiple transplant centers. The CIBMTR is committed to increasing application and access to cellular transplant therapy, as well as improving outcomes. The ultimate goal is to help more transplant recipients live longer, healthier lives.

**The CIBMTR will expand research activities to increase scientific knowledge of blood and marrow transplantation through:**


- Retrospective studies of the world’s largest blood and marrow transplant databases and tissue sample repositories to identify the most promising transplant approaches and the recipients most likely to benefit from this therapy.
- Research in immunobiology to better understand how transplantation works including how to harness the power of the immune system to control cancer.

Prospective, multi-center trials to increase the safety and success of transplantation. - Transplant-focused biostatistics expertise to assist researchers in accessing, analyzing and presenting scientific studies.
- Research to improve access to health care services.

**Specifically, the CIBMTR will:**


- Define key areas for future research in collaboration with leading scientists, physicians and others in the blood and marrow transplant community.
- Secure critical research funding through partnerships with government, industry and other private parties.
- Design and implement clinical studies.
- Offer expertise for the application of biostatistics, database development and study design in blood and marrow transplant.
- Make available research resources including the world’s largest clinical database of related blood and marrow transplants, along with repositories of thousands of matched tissue samples from transplant recipients and their donors – including significant numbers of samples for many rare diseases.

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)