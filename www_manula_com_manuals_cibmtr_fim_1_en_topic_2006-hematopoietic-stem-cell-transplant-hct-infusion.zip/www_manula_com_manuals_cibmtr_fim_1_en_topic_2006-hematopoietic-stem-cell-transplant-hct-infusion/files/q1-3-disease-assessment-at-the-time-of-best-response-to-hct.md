#### Question 1: Compared to the disease status prior to the preparative regimen, what was the best response to HCT since the date of the last report? (Include response to any therapy given for post-HCT maintenance or consolidation, but exclude any therapy given for relapsed, persistent, or progressive disease.)

Any specified therapy administered post-HCT to prolong remission or for minimal residual disease is considered part of the HCT and should be included when assessing the recipient’s response to transplant. Treatment given post-HCT for relapsed or persistent disease is not considered part of the HCT and should be excluded when assessing the response to HCT. If treatment was given post-HCT for relapsed or persistent disease, assess the patient’s best response prior to the start of that treatment. If therapy was only given for reasons other than relapsed or persistent disease, assess the patient’s best response throughout the entire duration of the reporting period.

If the recipient was in remission at the start of the preparative regimen, indicate “continued complete remission” and continue with question 4.

If the recipient did not achieve CR prior to the start of the preparative regimen, specify their best response following transplant and continue with question 2.

**See JMML Response Criteria for disease status definitions.**

#### Question 2: Was the date of best response previously reported?

If the patient achieved their best response in the current reporting period, indicate “no” and continue with question 3.

If the recipient achieved their best response during a previous reporting period, indicate “yes” and continue with question 4.

#### Question 3: Date assessed

Indicate the date best response was achieved. Report the date of the pathological evaluation (e.g., bone marrow biopsy), blood/serum assessment (e.g., CBC, peripheral blood smear), radiographic evaluation (e.g., abdominal CT), or physical examination (e.g., organomegaly on palpation). Enter the date the sample was collected for pathological and/or laboratory evaluations.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)