Veno-occlusive disease (VOD) or sinusoidal obstruction syndrome (SOS) may occur have HCT as a conditioning regimen injury to the hepatic venous endothelium, resulting in hepatic venous outflow obstruction due to occlusion of the hepatic venules and sinusoids. This typically results in a distinctive triad of clinical signs including hepatomegaly with right upper quadrant tenderness, third space fluid retention (e.g., sudden fluid weight gain (≥5%), ascites), and jaundice with a cholestatic picture. Ancillary features commonly seen include increased platelet transfusion needs, and coagulopathy. Pre-existing liver conditions may make development of VOD/SOS more likely. There is increased risk of development of VOD/SOS associated with prior history of hepatitis B, drug-induced hepatitis, or cirrhosis; second or greater hematopoietic cell transplant; ablative conditioning with high doses of radiation therapy or use of busulfan; and sirolimus given to recipients undergoing ablative conditioning. VOD/SOS may occur after autologous or allogeneic HCT. Agents such as low-dose heparin, ursodiol, or defibrotide may be given as prophylaxis against liver toxicities, including VOD/SOS. VOD/SOS occurs prior to D+100 post-transplant, and typically prior to D+30 post-transplant; diagnosis is based on clinical suspicion and supportive findings. Right upper quadrant (RUQ) ultrasound can be helpful to establish the diagnosis of VOD/SOS. The RUQ US is also helpful to rule out other causes of hyperbilirubinemia, such as bile duct obstruction and/or gall bladder disease. A liver biopsy is considered the gold standard for diagnosis VOD/SOS, but may be a risky procedure in patients with low platelets and is generally reserved for patients in whom a diagnosis of VOD/SOS is unclear and other diagnoses need to be excluded. Clinical diagnosis is generally based on the Seattle, modified Seattle, or Baltimore criteria.

**Seattle Criteria (1984)**


- Two or more of the following present prior to
**D+30**:- Bilirubin ≥ 2 mg/dL (34 μmol/L)
- Hepatomegaly and RUQ pain
- Ascites with or without unexplained weight gain > 2% over baseline


**Modified Seattle Criteria (1993)**


- Two or more of the following present prior to
**D+20**:- Bilirubin ≥ 2 mg/dL (34 μmol/L)
- Hepatomegaly and RUQ pain
- Ascites with or without unexplained weight gain > 2% over baseline


**Baltimore Criteria (1987)**


- Bilirubin ≥ 2 mg/dL (34 μmol/L) before
**D+21**and at least two of the following:- Hepatomegaly (generally painful)
- Ascites
- Weight gain > 5% over baseline


#### Question 1: Was the date of diagnosis of VOD previously reported?

Indicate whether the date of VOD diagnosis has already been reported on the 100 day VOD/SOS Form. Report “yes” and continue with question 43 if the initial diagnosis date was previously reported. If indicating “no,” continue to question 2 and report the date of diagnosis.

Centers must indicate “no” if completing this insert for the 100 day reporting period.

#### Question 2: Date of diagnosis:

Report the date of clinical diagnosis of VOD/SOS. This may be well after signs and symptoms were first noted, but should reflect the time at which the recipient’s primary clinician made the determination that signs and symptoms were related to VOD/SOS; this may be the time at which other diagnoses on the differential are ruled out.

The diagnosis date reported in question 2 must match the diagnosis date reported on the Post-TED Form (F2450) in question 47 or on the Post-HCT Follow-up Data Form (F2100) in question 479.

When completing the diagnosis questions below (questions 3-42), “at the time of diagnosis” refers to any testing performed within approximately 7 days of the date of diagnosis and prior to the initiation of any treatment. Only report assessments which were performed within the reporting period. If multiple assessments by the same method were performed at the time of diagnosis, report the assessment closest to the diagnosis date.

#### Question 3: Was ultrasonography (with Doppler) performed?

Ultrasound may be abnormal in patients with VOD/SOS, but it is unlikely to be diagnostic for it. Ultrasound findings that are more common in VOD/SOS than other liver disorders occurring during HCT include the presence of ascites, an abnormal portal waveform, and marked thickening of the gallbladder wall. Ultrasonography techniques are enhanced when done with Doppler measurements which assess the direction of blood flow in the portal venous system. Reversal of flow in the portal vein is a common finding in patients with severe VOD/SOS.

Report whether an ultrasound study with Doppler was performed as part of the diagnostic work-up for VOD/SOS. If “yes” continue with question 4. Centers should also attach a copy of the ultrasound study report to the form. Refer to the [FormsNet3 SM Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf) for more information on how to attach documents in FormsNet.

If no ultrasound studies with Doppler were performed at the time of diagnosis, report “no” for question 3 and continue with question 9.

#### Question 4: Date:

Enter the date the ultrasonography assessment was performed.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 5-8: Specify results:

Indicate whether the ultrasound study detected any abnormalities; these may include reversal of portal venous flow as well as hepatomegaly, ascites, and changes to gallbladder. If abnormalities were detected, indicated “yes” and continue with question 6. If “no,” continue with question 9.

#### Question 9: Was a liver biopsy performed?

A liver biopsy is not needed for the diagnosis of VOD/SOS. Report whether a liver biopsy was performed at the time of diagnosis.

If “yes,” specify the results in question 10. Centers should also attach a copy of the biopsy report to the form. Refer to the [FormsNet3 SM Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf) for more information on how to attach documents in FormsNet.

If “no,” continue with question 11.

#### Question 10: Specify biopsy result:

Report whether the liver biopsy was positive for signs of VOD/SOS. If the pathology report is not clear, refer to the progress notes to determine if the biopsy result is considered positive for signs of VOD/SOS.

#### Question 11: Was an autopsy performed?

Report “yes” if the diagnosis of VOD/SOS was made at the time of autopsy. The recipient’s survival status must be “Dead” on the Post-HCT Data Form if the center is reporting “yes.”

If an autopsy was performed, centers should attach a copy of the autopsy report to the form. Refer to the [FormsNet3 SM Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf) for more information on how to attach documents in FormsNet.

Indicate “no,” if the recipient started treatment for VOD/SOS prior to death. In this case, the autopsy would not have been performed “at the time of diagnosis” as defined in question 2.

#### Question 12-15: Specify signs and symptoms at diagnosis of VOD / SOS:

Report “yes” for any symptoms documented at the time of diagnosis.


**Ascites**: Accumulation of fluid in the space between the lining of the abdomen and the abdominal organs (peritoneal cavity). This may be detected clinically on exam or seen on ultrasound.**Hepatomegaly**: Enlargement of liver detected by physical exam or by RUQ ultrasound.**Right upper quadrant pain**: One of the clinical features that may be associated with the onset of VOD/SOS.**Weight gain (>2% over baseline at time of diagnosis of VOD / SOS)**: Greater than 2% increase in the recipient’s weight compared to their baseline weight. The baseline weight is considered the weight prior to the start of the preparative regimen.

#### Question 16: Was there concurrent organ dysfunction at the time of diagnosis?

Indicate whether the recipient was diagnosed with concurrent organ dysfunction which required treatment at the time of diagnosis of VOD/SOS. If indicating “yes,” continue with question 17. If indicating “no,” continue with question 27.

#### Question 17-26: Specify organ(s):

**Kidney**: Report “yes” for question 17 if the recipient has developed acute renal dysfunction with rising creatinine. If question 17 is “yes,” indicate whether the recipient required renal replacement therapy (e.g. dialysis) during the reporting period.**Lungs**: Report “yes” for question 19 if the recipient has developed any form of respiratory distress or requires new/additional oxygen supplementation.

If reporting “yes” for lungs, indicate the highest level of oxygen support required at the time of diagnosis. If mechanical ventilation was required, indicate the first date ventilation was started and whether the recipient was extubated during the reporting period, report the date the procedure was performed.

**Other organ**:**Central nervous system**: mental status changes, confusion, seizure, or encephalopathy that is deemed to be related to the VOD/SOS**Vascular**: Thrombotic microangiopathy, thrombotic thrombocytopenic purpura, or hemolytic uremic syndrome.


#### Question 27-28: Recipient weight (at diagnosis of VOD / SOS)

Report whether the recipient’s weight at the time of diagnosis is known. If “yes,” report the recipient’s weight in question 28. If “no,” continue with question 29.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)