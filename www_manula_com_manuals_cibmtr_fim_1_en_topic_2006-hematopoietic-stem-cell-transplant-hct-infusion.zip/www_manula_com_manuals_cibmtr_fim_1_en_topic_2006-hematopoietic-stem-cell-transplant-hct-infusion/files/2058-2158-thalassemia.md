Thalassemia is an inherited blood disorder involving decreased amounts of hemoglobin, an oxygen-carrying protein, and red blood cells, resulting in anemia. Mild forms of thalassemia may not require therapy whereas more severe forms may require blood transfusions and / or therapy.

[2058: Thalassemia Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2058-thalassemia-pre-infusion)

[2158: Thalassemia Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2158-thalassemia-post-infusion)

Last modified:
Apr 24, 2022

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)