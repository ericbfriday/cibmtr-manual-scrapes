This section is intended to provide general information about reporting pre-infusion lines of therapy, along with disease-specific lines of therapy information. The disease-specific lines of therapy information will be posted over time.

[General Reporting](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/lines-of-therapy-general-reporting)[Lines of Therapy: Acute Lymphoblastic Leukemia](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-lines-of-therapy)[Lines of Therapy: Plasma Cell Disorders](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-lines-of-therapy)

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspxwebpage).

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/2024 |
|

Last modified:
Apr 21, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)