The FormsNet3SM application allows questions 83-157 to be reported multiple times. Complete these questions for each line of therapy administered on or after the date of diagnosis of MDS and prior to the start of the preparative regimen (or prior to infusion if no preparative regimen was given). When submitting the paper version of the form for more than one line of therapy, copy the “Pre-HCT / Pre-Infusion Therapy” section and complete a copy of the section for each line of therapy administered.

A single line of therapy refers to any agents administered during the same time period with the same intent (induction, consolidation, etc.). If a recipient’s disease status changes resulting in a change to treatment, a new line of therapy should be reported. Additionally, if therapy is changed because a favorable disease response was not achieved, a new line of therapy should be reported.

#### Question 82: Was therapy given?

Indicate if the recipient received treatment for MDS after the time of diagnosis and before the start of the preparative regimen. If “yes,” continue with question 83. If “no,” continue with question 158.

#### Question 83: Date CBC with differential tested:

Report the date the sample was collected for testing and continue with question 84. If multiple studies were performed prior to the start of therapy, report the most recent lab immediately prior to this line of therapy.

#### Questions 84-85: WBC:

Indicate whether the white blood cell (WBC) count was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 85. If “unknown,” continue with question 86.

#### Questions 86-87: Neutrophils:

Indicate whether the neutrophil percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the value documented on the laboratory report in question 87. If “unknown,” continue with question 88.

#### Questions 88-89: Bands:

Indicate whether the band percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 89. If “unknown,” continue with question 90.

#### Questions 90-91: Metamyelocytes:

Indicate whether the percentage of metamyelocytes in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 91. If “unknown,” continue with question 92.

#### Questions 92-93: Myelocytes:

Indicate whether the myelocyte percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 93. If “unknown,” continue with question 94.

#### Questions 94-95: Lymphocytes:

Indicate whether the lymphocyte percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 95. If “unknown,” continue with question 96.

#### Questions 96-97: Monocytes:

Indicate whether the monocyte percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 97. If “unknown,” continue with question 98.

#### Questions 98-99: Basophil:

Indicate whether the basophils percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 99. If “unknown,” continue with question 100.

#### Questions 100-101: Eosinophil:

Indicate whether the eosinophil percentage in the blood was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 101. If “unknown,” continue with question 102.

#### Questions 102-103: Blasts in blood:

Indicate whether the percent blasts in the peripheral blood is “known” or “unknown” prior to the start of this line of therapy. This may be determined by an automated differential, a manual count, or flow cytometry. If “known,” report the percentage documented on the laboratory report in question 103. Note, blasts are only reported on the differential if present. If there is no documentation of blasts, one can report 0%. If “unknown,” continue with question 104.

#### Questions 104-105: Hemoglobin:

Indicate whether the hemoglobin was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 105. If “unknown,” continue with question 107.

#### Question 106: Were RBCs transfused ≤ 30 days before date of test?

Transfusions temporarily increase the red blood cell count. It is important to distinguish between a recipient whose body is creating these cells and a recipient who received these cells from a transfusion.

Indicate if red blood cells were transfused less than or equal to 30 days prior to the testing.

#### Questions 107-108: Platelets:

Indicate whether the platelet count was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the laboratory count and unit of measure documented on the laboratory report in question 108. If “unknown,” continue with question 110.

#### Question 109: Were platelets transfused ≤ 7 days before date of test:

Transfusions temporarily increase the platelet count. It is important to distinguish between a recipient whose body is creating the platelets and a recipient who received these cells from a transfusion.

Indicate if platelets were transfused less than or equal to 7 days prior to the testing.

#### Questions 110-112: Blasts in bone marrow:

Indicate whether the percentage of blasts in the bone marrow was “known” or “unknown” prior to the start of this line of therapy. If “known,” report the percentage documented on the laboratory report in question 111 and the date of sample collection in question 112. If “unknown,” continue with question 113.

#### Question 113: Were cytogenetics tested (karyotyping or FISH)?:

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic (karyotyping or FISH) studies were obtained prior to the start of this line of therapy, report “yes” and continue with question 114.

If no cytogenetic studies were obtained prior to the start of this line of therapy, indicate “no” and continue with question 132.

If it is not known whether any cytogenetic studies were obtained prior to the start of this line of therapy, indicate “unknown” and go to question 132.

#### Question 114: Were cytogenetics tested via FISH?

If FISH studies were performed prior to the start of this line of therapy, report “yes” for question 114 and continue with question 115. If FISH studies were not performed prior to the start of this line of therapy, report “no” for question 114 and go to question 132. Examples include: no FISH study performed, or FISH sample was inadequate.

See [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c), for assistance interpreting FISH results.

#### Questions 115-116: Sample source

Indicate if the sample was from “bone marrow” or from “peripheral blood” and report the date the sample was collected in question 116. If multiple sources were used to test FISH, the most preferred sample is the bone marrow.

#### Question 117: Results of tests:

If FISH assessments identified abnormalities, indicate “abnormalities identified” and continue with question 118.

If FISH assessments were unremarkable, indicate “no abnormalities” identified, continue with question 122.

#### Questions 118-121: Specify cytogenetic abnormalities (FISH):

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 118, then continue with question 119.

Report the number of abnormalities detected by FISH prior to this line of therapy in question 119. After indicating the number of abnormalities in question 119, select all abnormalities detected in questions 120-121.

If an abnormality is detected, but not listed as an option in question 120, select “other abnormality” and specify the abnormality in question 121. If multiple “other abnormalities” were detected, report “see attachment” in question 121 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 122: Was documentation submitted to the CIBMTR?

Indicate if FISH testing report is attached to support the cytogenetic findings reported in questions 118-119 For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 123: Were cytogenetics tested via karyotyping?

If karyotyping was performed prior to this line of therapy report “yes” for question 123 and continue with question 124. If karyotyping was not performed prior to this line of therapy, indicate “no” and go to question 132. Examples of this include: karyotyping was not performed, or karyotyping sample was inadequate.

#### Questions 124-125: Sample source

Indicate if the sample was from “bone marrow” or from “peripheral blood” and report the date the sample was collected in question 125. If multiple sources were used for karyotyping, the most preferred sample is the bone marrow.

#### Question 126: Results of tests:

If karyotyping assessments identified abnormalities, indicate “abnormalities identified” and continue with question 127.

If karyotyping assessments were unremarkable, indicate “no abnormalities” and continue with question 131.

If karyotyping assessment yielded an inadequate result, indicate “no evaluable metaphases” and continue with question 131.

#### Questions 127-130: Specify cytogenetic abnormalities (karyotyping):

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 127, then continue with question 128.

Report the number of abnormalities detected by karyotyping prior to this line of therapy question 128. After indicating the number of abnormalities in question 128, select all abnormalities detected in questions 129-130.

If an abnormality is detected, but not listed as an option in question 129, select “other abnormality” and specify the abnormality in question 130. If multiple “other abnormalities” were detected, report “see attachment” in question 130 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 131: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping testing report is attached to support the cytogenetic findings reported in questions 129-130. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 132: Systemic Therapy:

Systemic therapy refers to a delivery mechanism where a therapeutic agent is delivered orally or intravenously to the whole body. These drugs enter the bloodstream and are distributed throughout the body.

Indicate “yes” if the patient received systemic therapy and continue with question 133. If the patient did not receive systemic therapy, indicate “no” and continue with question 141.

#### Questions 133-134: Date therapy started:

Indicate whether the therapy start date is “known” or “unknown.” If the therapy start date is known, report the date the recipient first began this line of therapy in question 134. If the start date is partially known (e.g. the recipient started in mid-July 2010), use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy started is “unknown,” go to question 135.

#### Questions 135-136: Date therapy stopped:

Indicate if therapy stop date is “known” or “unknown.” If the therapy is being given in cycles, report the date the recipient started the last cycle for this line of therapy in question 136. If the therapy is administered in a single line or single administration, report the last day systemic therapy was administered. If the stop date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy stopped is “unknown,” go to question 137.

#### Questions 137-138: Specify reason therapy stopped:

Indicate the reason the line of therapy was stopped using one of the following options:


**Toxicity (e.g. cytopenia)**: The recipient developed a toxicity in response to therapy.**Not tolerable**: The therapy was stopped due to intolerability (adverse events)**Lack of response**: The course of treatment stopped due to lack of a complete response.**Disease progression**: The recipient’s disease progressed from HI; Requires at least one of the following in the absence of another explanation (e.g., infection, bleeding, ongoing chemotherapy, etc.):

p((. ≥ 50% reduction from maximum response levels in granulocytes or platelets

p((. Reduction in hemoglobin by ≥ 1.5 g/dL

p((. Transfusion dependence**Other**: Use this option choice for any reason not included above and specify the reason in question 138.**Unknown**: Use this option when the reason therapy was stopped is unknown.

#### Questions 139-140: Specify systemic therapy (check all drugs given as part of this line of therapy):

Treatments vary based on protocol. A treatment may consist of a single drug or a combination of drugs. Additionally, the drugs may be administered on one day, over consecutive days, or continuously.

Select all chemotherapy drugs administered as part of this line of therapy. If the recipient received a systemic therapy which is not listed, select “Other systemic therapy” and specify the treatment in question 140. Report the generic name of the agent, not the name brand.

#### Questions 141-142: Supportive treatment:

If the patient received supportive treatment, report “yes” and select all supportive treatment given in question 142. If the patient did not receive supportive treatment, report “no” and continue with question 143.

#### Question 143: Cellular Therapy (e.g. CAR-T cells):

Cellular therapy refers to the infusion of human or animal derived cells, which may or may not be modified or processed to achieve a specific composition. Examples include T-cell, NK cell, and mesenchymal cell infusions as well as donor cellular infusions.

Report “yes” if the recipient received a cellular therapy as part of the line of therapy being reported. If not, report “no.”

#### Questions 144-145: Blinded randomized trial:

Indicate whether treatment was administered as part of a blinded randomized trial. Consult the physician overseeing treatment if it is not clear whether the therapy is being given as part of a blinded randomized trial. If “yes,” report the clinicaltrials.gov number in question 145. Otherwise, go to question 146.

If the clinical trial number (NCT number) is not clearly documented, it can be looked up using the Find a Study feature on [www.clinicaltrials.gov](http://www.clinicaltrials.gov).

If the recipient is participating in a clinical trial that is not registered with clinicaltrials.gov, but is registered elsewhere, leave question 145 blank and override the validation error using the code “Unable to answer.” Also, attach documentation which displays the clinical trial number and corresponding registry to the form in FormsNet3SM. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 146: Splenic Radiation:

Report whether the recipient received splenic radiation and continue with question 147.

#### Questions 147-148: Splenectomy:

Indicate if the recipient underwent a splenectomy. If the recipient had a splenectomy, report the splenectomy date in question 148. If the recipient did not have a splenectomy, continue with question 149.

If the recipient has congenital asplenia, report “no,” and continue with question 149.

#### Questions 149-150: Other therapy:

Report whether the recipient received additional therapy which does not fit into the previous form categories. Examples may include intrathecal therapy or surgery. Specify the other therapy given in question 150.

#### Questions 151: Best response to line of therapy:

Indicate the disease response of MDS to each line of therapy using the definitions found in the text on FormsNet3SM. These definitions are also located in the [MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria).

If the recipient’s disease status was “Complete remission (CR),” “No response (NR)/stable disease (SD),” “Progression from hematologic improvement (Prog from HI),” “Relapse from complete remission (Rel from CR),” or “Progression to AML (AML),” continue with question 155.

If the recipient’s disease status was “Hematologic improvement (HI),” continue with question 152.

If the disease status was “unknown” or “not assessed,” continue with question 156.

#### Question 152: Specify the cell line examined to determine HI status (check all that apply):

Specify all cell line(s) examined to determine hematologic improvement. Review the Hematologic Improvement criteria on the MDS Response Criteria section to determine the cell line.

If the cell lines examined to determine hematologic improvement included “Hematologic Improvement – Erythroid (HI-E)” continue with question 153. If the cell lines examined to determine hematologic improvement only included “Hematologic Improvement -Platelets (HI-P)” and / or “Hematologic Improvement – Neutrophils (HI-N)” continue with question 154.

#### Questions 153: Specify transfusion dependence:

If the recipient’s best response to this line of therapy included hematologic improvement – erythroid, indicate the transfusion dependence at the time of determining the best response to therapy.

Select “Non-transfused (NTD)” if the recipient was without RBC transfusions as supportive care for the disease within a period of 16 weeks and continue with question 154.

Select “Low-transfusion burden (LTB)” if the recipient had 3-7 RBC transfusions within a period of 16 weeks in at least 2 transfusion episodes with a maximum of 3 RBC transfusions in 8 weeks and continue with question 154.

#### Questions 154: Date assessed:

Enter the date the best response to the line of therapy was established. Report the date of the pathological evaluation (e.g., bone marrow biopsy). If no pathologic evaluation was reported, report the date of blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and/or laboratory evaluations. If the recipient was treated for extramedullary disease and a radiological assessment (e.g., X-ray, CT scan, MRI scan, PET scan) was performed to assess disease response, enter the date the imaging took place for radiologic assessments. If no pathological, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically assessed the recipient’s response.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 155: Did disease relapse/progress following this line of therapy?

Refer to the MDS Response Criteria section when determining the recipient’s disease status. Indicate if the disease relapsed from CR or progressed from hematologic improvement. If the disease relapsed, progressed, or transformed to AML (see red box below) answer “Yes” and go to question 156. If “No,” go to question 157.

#### Questions 156: Date of relapse / progression:

Enter the date of the assessment that established relapse following the line of therapy. Report the date of the pathological evaluation (e.g., bone marrow) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluations. If extramedullary disease is detected upon radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), enter the date the imaging took place. If the physician determines cytogenetic or molecular relapse, enter the date of sample collection for cytogenetic or molecular evaluation. If the physician determines evidence of relapse following a clinical examination during an office visit, report the date of assessment.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Copy questions 83 – 156 if needed for multiple lines of therapy.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q143 | 6/28/2023 | Add | The Reporting Prior Cellular Therapy as a Line of Therapy blue information box added: As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form |
Due to change in FormsNet3 validation |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)