#### Question 1: Date of evaluation

Report the date of the most recent physical evaluation where both the abdominal girth and blood pressure were assessed in the reporting period. This evaluation will be used to answer *Abdominal girth* and *Blood pressure*.

#### Questions 2 – 3: Abdominal girth

Indicate if the recipient’s abdominal girth was measured on the date of evaluation specified in the question above. If **Known**, specify the recipient’s abdominal measurement in centimeters. If the recipient’s abdominal girth was not measured or if no information is available, select **Unknown**.

#### Questions 4 – 5: Blood pressure

Indicate if the recipient’s blood pressure was assessed on the date of evaluation specified above. If assessed, report **Known** and provide the recipient’s blood pressure. If the recipient’s blood pressure was not measured or if no information is available to determine if the recipient’s blood pressure was measured, select **Unknown**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q2 | 1/24/2025 | Modify | Abdominal Girth red warning box above Q2 updated: p(banner important). Abdominal girth : Abdominal girth |
Due to change in form validation |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)