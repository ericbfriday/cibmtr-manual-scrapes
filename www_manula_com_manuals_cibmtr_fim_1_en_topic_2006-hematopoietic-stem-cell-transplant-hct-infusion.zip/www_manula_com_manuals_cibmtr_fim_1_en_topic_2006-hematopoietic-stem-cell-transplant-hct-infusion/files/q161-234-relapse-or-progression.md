Report if the recipient has experienced a clinical/hematologic relapse or progression post-HCT. If the relapse or progression was detected in a previous reporting period indicate that and continue on. If the first clinical/hematologic relapse occurred since the date of the last report, indicate the date it was first detected in this reporting period.

#### Question 98: Did the recipient experience a clinical / hematologic relapse or progression post-HCT?

Clinical / hematologic assessment is the least sensitive method of disease detection. Examples include circulating blasts in the bloodstream for AML, or enlargement of a malignant mass for lymphoma or a solid tumor. Every recipient who has an evaluation by a physician has a “clinical” assessment. Include radiographic evidence of relapse or progression as clinical/hematologic relapse or progression. Disease specific criteria for establishing relapse or progression are published as part of the CIBMTR Forms Instructions Manual. If the recipient dies, and the relapse or progression of disease is discovered by autopsy, the date of assessment should be reported as the date of death, not the autopsy date.

If clinical / hematologic evidence of relapse / progressive disease was found at any time post-transplant, check **Yes**.

If clinical / hematologic evidence of relapse / progressive disease was not found at any time post-transplant, check **No**.

#### Question 99: Was the date of clinical / hematologic relapse or progression previously reported?

Only the date of first clinical / hematologic relapse or progression post-transplant needs to be reported. Therefore, if the recipient experienced clinical / hematologic relapse or progression in a prior reporting period and it was reported on the prior form, report **Yes**. If this is the report of first instance of clinical/hematologic relapse or progression, indicate **No**.

#### Question 100: Date first seen

Indicate the date relapse/progressive disease was determined by clinical / hematological evaluation. If exact date is not known, refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates.

#### Question 101: Was intervention given for relapsed, persistent or progressive disease since the date of last report?

Indicate whether therapy was given during the reporting period for persistent or relapsed / progressive disease. Do not include therapy given for maintenance or planned post-transplant consolidation. Any post-transplant therapy included as part of the initial transplant protocol should not be reported in this area of the form.

If treatment for relapse / progression started after the reporting period in which relapse / progression was first reported in, the *intervention for relapse / persistent / progressive disease* data fields are disabled and relapse / progression treatment is not captured.

See the *Intervention reporting scenarios* provided below for further clarification.

#### Question 102: Specify reason for which intervention was given

Indicate whether therapy was given for persistent or relapsed / progressive disease. If therapy continued from a prior reporting period and a new therapy was started for a different reason during the current reporting period, report the reason the new therapy was started. See the *Intervention reporting scenarios* provided below for further clarification.

#### Question 103: Specify the method(s) of detection for which intervention was given (check all that apply)

Indicate the methods detecting the reason for which therapy for persistent disease or relapsed / progressive disease was given (as reported above). Indicate all methods of disease assessment in which disease was detected; given that the assessment was performed prior to the start of the intervention(s) and was consistent with the rationale reported above. There may be some cases for which an assessment by a particular method was last performed in the prior reporting period but was still consistent with the justification reported; in this case, the method of disease assessment should be indicated.

For example, in the 100-day reporting period, the last cytogenetic assessment detected a new abnormality associated with the recipient’s primary transplant disease. In this case, monosomy 7 was identified on a peripheral blood sample for a recipient transplanted for AML in CR1 with normal cytogenetics prior to transplant. In the 6-month reporting period, relapse was detected in the bone marrow morphology (clinical assessment) and concurrent flow cytometry (flow cytometry) and therapy was initiated for relapsed / progressive disease. In this case, each of these methods should be indicated on the Post-TED (2450) Form in the 6-month reporting period.

If multiple therapies were given during the reporting period for different reasons (e.g., the recipient initially receives treatment for persistent disease and subsequently receives different treatment for progressive disease during the same reporting period), indicate any methods of detection confirming the reason above. See the *Intervention reporting scenarios* provided below for further clarification.

If assessment by that method was not performed or was performed and not consistent with the reason for which intervention was given reported above, do not indicate it in this question.

See below for definitions and examples of each method of detection:

**Clinical / hematologic:**Clinical / hematologic assessment is the least sensitive method of disease detection. Examples include circulating blasts in the bloodstream for AML, or enlargement of a malignant mass for lymphoma or a solid tumor. Every recipient who has an evaluation by a physician has a “clinical” assessment. Examples of clinical/hematologic assessments include: bone marrow biopsy / morphologic evaluation, complete blood count, serum protein electrophoresis, etc.**Radiologic (e.g., PET, MRI, CT):**Radiologic assessments are imaging techniques used to assess disease response. Imaging techniques used to evaluate disease response typically include PET, CT, or MIBG, but may include x-ray, skeletal survey, or ultrasound in some cases.**Cytogenetic:**Cytogenetic studies involve the study of chromosomes, typically through one of two methods: karyotyping or fluorescence in situ hybridization (FISH). Blood, bone marrow, or tissue preparations may be tested by either of these two methods. Karyotyping is both less sensitive and less specific than FISH testing; FISH studies identify only abnormalities detectable by the employed probe set and cannot provide information about the presence or absence of chromosomal abnormalities or markers outside the specific probe set utilized.**Flow cytometry:**Flow cytometry is a technique that can be performed on blood, marrow, or tissue preparations where the cell surface markers can be quantified on cellular material. This allows for the detection of abnormal cell populations for some diseases. Flow cytometry may also be referred to as immunophenotyping.**Disease specific molecular marker:**Molecular assessment involves determining whether a molecular marker for the disease exists in the blood or bone marrow. Molecular assessment is the most sensitive method of detection and can indicate known genetic abnormalities associated with the disease for which the HCT was performed.

#### Question 104: Date intervention started

Report the date therapy was started for the reason specified above; if multiple instances, cycles, or lines of therapy are administered, report the date of the first treatment. If treatment was started in a prior reporting period and continues into the current reporting period, report the original therapy start date (prior to the start of the current reporting period) and override the validation error in FormsNet3SM using the code “verified correct.” If therapy was stopped in a prior reporting period and restarted (or a new therapy was started) during the current reporting period, report the earliest date treatment was administered during the current reporting period. See the *Intervention reporting scenarios* provided below for further clarification.

**Intervention Reporting Scenarios**

**A.** A recipient with NHL in complete remission at the time of HCT has a relapse during the 100 day reporting period. Relapse was detected by a PET scan and a lymph node biopsy. Following these assessments, rituximab was started on 5/1/2016. The disease did not respond to this therapy prompting a switch to brentuximab on 6/1/2016. The 100 Day date of contact is 6/15/2016.

*100 Day Post-TED Form:*

*Was intervention given for relapsed, persistent or progressive disease since the date of last report*: Report “Yes” to indicate therapy was given for relapsed disease during this reporting period.

*Specify reason for which intervention was given*: Report “Relapsed / progressive disease.”

*Specify the method(s) of detection for which intervention was given*: Check the boxes to indicate that disease was detected by both clinical/hematologic (lymph node biopsy) and radiological (PET Scan) assessments. All other methods of detection must be left blank.

*Date intervention started*: Report “5/1/2016” to reflect the date of the first treatment given for relapsed disease.

*Specify therapy*: Report both rituximab and brentuximab as treatments for relapsed disease given during the reporting period.

**B.** A recipient with multiple myeloma in VGPR at the time of HCT was started on maintenance lenalidomide during the six month reporting period. Later in the reporting period, progression was detected by serum protein electrophoresis on 9/15/2014 and so the recipient stopped lenalidomide and started bortezomib as well as dexamethasone on 9/20/2014 The recipient continued bortezomib and dexamethasone treatment into the one year reporting period.

*Six Month Post-TED Form:*

*Was intervention given for relapsed, persistent or progressive disease since the date of last report*: Report “Yes” to indicate therapy was given for progressive disease during this reporting period.

*Specify reason for which intervention was given*: Report “Relapsed / progressive disease.”

*Specify the method(s) of detection for which intervention was given*: Check the box to indicate that disease was detected by clinical/hematologic (serum protein electrophoresis) assessment. All other methods of detection must be left blank.

*Date intervention started*: Report “9/20/2014” to reflect the date of the first treatment given for progressive disease.

*Specify therapy*: Report bortezomib as treatment for progressive disease given during the reporting period. Dexamethasone is no longer captured on the Post-TED (2450) Form. The lenalidomide therapy should not be reported in this section of the form. This medication was given as maintenance therapy and will therefore be reported under Post-HCT Therapy.

*One Year Post-TED Form:*

*Intervention given for relapse, persistent, or progressive disease* questions: These questions will be disabled in FormsNet3. Starting with Revision 5 of the Post-TED 2450, therapy given for relapsed or progressive disease will only be captured in the reporting period in which treatment first started.

**C.** A recipient with multiple myeloma in PR at the time of HCT was started on lenalidomide during 100 day reporting period (started 3/15/2012) due to persistent disease (detected by serum electrophoresis testing). This treatment was not planned and was given due to an unsatisfactory disease response to HCT. Thirty days after lenalidomide was started, a karyotype assessment confirmed persistent cytogenetic abnormalities present in a bone marrow sample. Lenalidomide was continued into the six month reporting period, during which, there was disease progression (detected by serum electrophoresis). Lenalidomide was stopped and carfilzomib was started on 5/30/2012. By the end of the six month reporting period, the recipient achieved a complete remission in response to carfilzomib and was switched to a lower maintenance dose of carfilzomib which was continued into the one year reporting period.

*100 Day Post-TED Form:*

*Was intervention given for relapsed, persistent or progressive disease since the date of last report*: Report “Yes” to indicate therapy was given for persistent disease during this reporting period.

*Specify reason for which intervention was given*: Report “Persistent disease.”

*Specify the method(s) of detection for which intervention was given*: Check the box to indicate that disease was detected by clinical/hematologic (serum protein electrophoresis) assessment. All other methods of detection must be left blank. The karyotype test would not be reported as a method of detection since it was performed after treatment was started and, therefore, did not inform the decision to start lenalidomide.

*Date intervention started*: Report “3/15/2012” to reflect the date of the first treatment for persistent disease.

*Specify therapy*: Report lenalidomide as the only treatment given during the reporting period.

*Six Month Post-TED Form:*

*Was intervention given for relapsed, persistent or progressive disease since the date of last report*: Report “Yes” to indicate therapy was given for persistent and progressive disease during this reporting period.

*Specify reason for which intervention was given*: Report “relapsed / progressive disease.” If therapy continued from a prior reporting period and a new therapy was started for a different reason during the current reporting period, report the reason the new therapy was started.

*Specify the method(s) of detection for which intervention was given*: Check the box to indicate that disease was detected by clinical/hematologic (serum protein electrophoresis) assessment. All other methods of detection must be left blank.

*Date intervention started*: Report “5/30/2012” to reflect the date of the first treatment for progressive disease.

*Specify therapy*: Report the lenalidomide and carfilzomib as treatments received during the reporting period

*One Year Post-TED Form:*

*Was intervention given for relapsed, persistent or progressive disease since the date of last report*: Report “No” to indicate therapy was not given for persistent or relapsed / progressive disease during this reporting period. The lower dose carfilzomib given as maintenance (to keep the recipient in CR) must be reported in the Post-HCT Therapy Section of the Post-TED Form. Reporting “No” will disable questions the remaining *intervention for relapse, persistent, or progressive disease* questions.

#### Question 105: Specify therapy (check all that apply)

Indicate which therapies were given since the date of the last report for relapsed, persistent, or progressive disease.

**Systemic therapy**: refers to a delivery mechanism where a therapeutic agent is delivered orally or intravenously, enters the bloodstream, and is distributed throughout the body. Indicate whether systemic therapy was given during the reporting period for relapsed, persistent, or progressive disease and report the systemic therapy.

**Radiation**: Radiation therapy uses high-energy radiation to kill cancer cells. External beam radiation is one of the more frequently used types of radiation. In this method, a beam of radiation is delivered to a specific part of the body, such as the mediastinum. Radiation may be planned if bulky disease was present just prior to transplant for a recipient with lymphoma or a solid tumor. Indicate whether radiation therapy was given during the reporting period for relapsed, persistent, or progressive disease.

**Cellular therapy**: Cellular therapy refers to the infusion of human or animal derived cells, which may or may not be modified or processed to achieve a specific composition. Examples include CAR T-cell, NK cell, and mesenchymal cell infusions as well as donor cellular infusions. Select this option if the recipient received any form of cellular therapy for relapse, persistent, or progressive disease; hematopoietic cell transplantation should not be reported as cellular therapy. Indicate whether a cellular therapy was infused during the reporting period for relapsed, persistent, or progressive disease.

**Blinded randomized trial**: A blinded, randomized trial refers to a research treatment protocol in which the participant is assigned to the control arm or investigational group, and the researcher or clinician is not informed whether the subject is receiving the placebo or standard of care versus the investigational therapy. This makes it impossible to report agents or therapies the recipient is receiving. Indicate whether the recipient is receiving therapy on a randomized, blinded clinical trial during the reporting period for relapsed, persistent, or progressive disease.

**Other therapy**: Indicate whether the recipient received additional therapy for relapsed, persistent, or progressive disease which does not fit into the previous categories. Examples may include intrathecal therapy or surgery. Specify the other therapy given.

#### Questions 106 – 107: Specify systemic therapy (check all that apply)

Systemic therapy agents and treatment regimens vary based on disease, prognosis, and protocol. Treatment may consistent of one or multiple drugs and may be given in an inpatient or outpatient setting; additionally, drugs may be administered on a single day, over consecutive days, or continuously.

Form options are arranged alphabetically. Indicate which systemic therapy agents were administered during the current reporting period for relapse, persistent, or progressive disease. If the recipient received a chemotherapy agent that is not listed (e.g. cyclophosphamide), **Chemotherapy** should be selected. If the recipient received a therapeutic agent, other than chemotherapy, that is not listed, select **Other systemic therapy** and specify the systemic therapy.

#### Question 108: Specify other therapy

Specify other therapy the recipient received additional therapy for reasons other than relapsed, persistent, or progressive disease which does not fit into the previous form categories. Examples may include intrathecal therapy or surgery.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)