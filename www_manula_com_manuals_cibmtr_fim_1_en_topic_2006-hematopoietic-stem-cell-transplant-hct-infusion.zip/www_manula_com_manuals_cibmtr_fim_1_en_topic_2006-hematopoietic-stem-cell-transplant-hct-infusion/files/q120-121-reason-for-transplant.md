#### Questions 119 – 120: What was the primary reason for infusion?

Specify the recipient’s *primary* reason for the infusion. If the indication for transplant is not listed, report **Other** and specify the reason.

If there are multiple indications for which the recipient is receiving the infusion, confirm with the physician the primary reason; only one indication may be reported.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Oct 27, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)