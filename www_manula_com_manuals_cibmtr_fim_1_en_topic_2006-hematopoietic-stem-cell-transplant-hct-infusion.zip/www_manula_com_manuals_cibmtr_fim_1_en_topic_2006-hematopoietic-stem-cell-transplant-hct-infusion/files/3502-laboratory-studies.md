The Laboratory Studies (3502) Form is a cellular therapy and gene therapy registry form which captures complete blood count (CBC) and CBC differential data pre- and/or post-infusion.

**Cellular Therapy**

This form will come due post-infusion for recipients enrolled onto CIBMTR study CS21-177. This is a cellular therapy prospective multi-annual post authorization safety study for recipients treated with Afamitresgene Autoleucel (afami-cel).

The Pre-Cell Therapy Essential Data (4000) Form will confirm study eligibility, this includes event date, and cellular therapy product infused. Once eligibility is confirmed the Laboratory Studies (3502) Form will come due for all enrolled recipients at the “30 day” timepoint only.

**Gene Therapy**

This form will come due both pre-infusion and post-infusion for recipients enrolled onto CIBMTR study CS20-51 (Skysona®) or CS22-24 (Zyntelgo®). These are post-marketing prospective, multicenter, observational, long-term safety and effectiveness registry studies of recipients with cerebral adrenoleukodystrophy treated with Elivaldogene Autotemcel (Skysona ®) or beta-thalassemia treated with Betibeglogene Autotemcel (Zynteglo®).

The Pre-Transplant Essential Data (2400) Form will confirm study eligibility, this includes event date, genetic modification, and gene therapy product infused.

Pre-Infusion

Once eligibility is confirmed, The Laboratory Studies (3502) Form will be paired with the Marrow Surveillance (3506) Form for the *last evaluation prior to the start of the preparative regimen / lymphodepleting therapy* (or ‘at infusion’) timepoint with the Leukodystrophies Pre-Infusion (2037) Form for CS20-51, or Thalassemia Pre-Infusion (2058) Form for CS22-24.

Post-Infusion

The Laboratory Studies (3502) Form and Marrow Surveillance (3506) Form will come due when the Leukodystrophy Post-Infusion (2137) Form for CS20-51 or Thalassemia Post-Infusion (2158) Form for CS22-24 indicates a marrow biopsy and/or aspirate was performed in the reporting period.

For every marrow evaluation reported on the Marrow Surveillance (3506) Form, a corresponding Laboratory Studies (3502) Form must be completed to report the CBC and differential results closest to the marrow evaluation date.

Links to Sections of Form:

[Q1 – 10: Complete Blood Count](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-10-complete-blood-count-cbc)

[Q11 – 28: CBC Differential](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-28-cbc-differential)

[Q29 – 56: Additional Labs](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q29-56-additional-labs)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/25/2024 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)