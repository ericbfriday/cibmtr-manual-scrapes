**MDS Response Criteria**

#### Complete Remission (CR)

*Requires all of the following maintained for a minimum of four weeks. When reporting the CR achievement date, report the first date when CR was achieved (not the four week date in which CR was maintained).*

Bone marrow evaluation:


- < 5% myeloblasts with normal maturation of all cell lines

Peripheral blood evaluation:


- Hemoglobin ≥ 11 g/dL untransfused without erythropoietic support
- ANC ≥ 1000/mm
3without myeloid growth factor support - Platelets ≥ 100,000/mm
3without thrombopoietic support - 0% blasts in blood

Alternative CR criteria are accepted in the setting of **pediatric** MDS and are as follows:


- Complete donor chimerism (≥ 95% donor chimerism without recipient cells detected)
- Hemoglobin ≥ 11 g/dL untransfused without erythropoietic support
- ANC ≥ 1000/mm
3without myeloid growth factor support - Platelets ≥ 100,000/mm
3without thrombopoietic support

In some cases, there may not be a four-week interval between completion of therapy and the pre-transplant disease assessment. In this case, CR should still be reported as the status at transplant since it represents the “best assessment” prior to HCT. This is an exception to the criteria that CR be durable beyond four weeks; the pre-transplant disease status should not be changed based on early relapse or disease assessment post-transplant.

#### Hematologic Improvement (HI)

*Requires one measurement of the following maintained for at least eight weeks without ongoing cytotoxic therapy. When reporting the date when hematologic improvement was achieved, report the first date when the criteria for hematologic improvement was met (not the eight week date in which hematologic improvement was maintained).*

Hematologic improvement – erythropoietic (HI-E):


- Hemoglobin increase of ≥ 1.5 g/dL untransfused

or - For RBC transfusions performed for hemoglobin ≤ 9.0: reduction in RBC units transfused in 8 weeks by ≥ 4 units compared to the number of units transfused in the 8 weeks prior to treatment

Hematologic improvement – platelets (HI-P):


- For pre-treatment platelet count of ≥ 20 ×10
9, platelet absolute increase of ≥ 30 ×109 - For pre-treatment platelet count of < 20 ×10
9, platelet absolute increase of ≥ 20 ×109and ≥ 100% increase from pre-treatment level

Hematologic improvement – neutrophils (HI-N):


- Neutrophil count increase of ≥ 100% from pre-treatment level and an absolute increase of ≥ 500/mm
3

#### No Response (NR)/Stable Disease (SD)

Does not meet the criteria for at least HI, but no evidence of disease progression to AML

#### Progression from Hematologic Improvement (Prog from HI)

*Requires at least one of the following in the absence of another explanation (e.g., infection, bleeding, ongoing chemotherapy, etc.):*


- ≥ 50% reduction from maximum response levels in granulocytes or platelets
- Reduction in hemoglobin by ≥ 1.5 g/dL
- Transfusion dependence

*Note: declining donor chimerism does not meet the criteria for progression. If the above criteria for progression have been met, but a hematologic improvement was not previously achieved, report “No Response (NR) / Stable Disease (SD)”.*

#### Relapse from Complete Remission (Rel from CR)

*Requires at least one of the following:*


- Return to pre-treatment bone marrow blast percentage
- Decrease of ≥ 50% from maximum response levels in granulocytes or platelets
- Transfusion dependence or hemoglobin level ≥ 1.5 g/dL lower than prior to therapy

*Note: declining donor chimerism does not meet the criteria for relapse.*

#### Progression to AML

≥ 20% blasts in the blood or bone marrow

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2014.MDS%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/20/2022 |
|

**Determining Post-Infusion Baseline Assessments**When determining the post-infusion disease status, the most recent lab values prior to the start of the preparative regimen should be used as the baseline assessments. However, if relapse or progression occurs after infusion, the labs from relapse / progression should be used.[MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)**Determining Pre-Infusion Baseline Assessments**When determining the pre-infusion disease status, use the lab values from diagnosis of the primary disease for infusion as the baseline assessments. However, if relapse or progression occurs prior to infusion, the labs from relapse / progression should be used.[MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)[MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)