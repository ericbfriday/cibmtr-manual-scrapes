#### Question 157: Was therapy given?

Indicate if the recipient received treatment for the plasma cell disorder between the time of diagnosis and the start of the preparative regimen. If **Yes**, continue with question 158. If **No**, continue with question 188.

#### Question 158: Systemic therapy

Systemic therapy (e.g., chemotherapy) may be injected into a vein or given orally and is delivered to the whole body via the bloodstream. Indicate **Yes** or **No** if systemic therapy was given. If **No**, continue with question 174.

#### Questions 159 – 160: Date systemic therapy started

Indicate if the therapy start date is **Known** or **Unknown**. If the therapy start date is **Known**, enter the date the recipient began this line of therapy in question 160. If the start date is partially known (i.e., the recipient started treatment in mid-July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 161 – 162: Date systemic therapy stopped

Indicate if therapy stop date is **Known** or **Unknown**. If the therapy stop date is **Known** and the recipient received therapy administered in cycles, report the date the recipient started the last cycle for this line of therapy. If the recipient is still receiving therapy at the time of their transplant, report **Not applicable (still receiving therapy)** and go to question 165.

If the recipient received therapy administered on a daily basis (e.g., lenalidomide therapy at 10 mg/day) report the last date the recipient received the line of therapy.

#### Questions 163 – 164: Reason stopped

Indicate the reason that this line of therapy stopped. If the reason the line of therapy was stopped is not listed in this section, select **Other** and report the specific reason in question 164.

#### Questions 165 – 166: Was a standard drug regimen given? (as part of this line of therapy) (with or without additional therapy)

Systemic chemotherapy / immunotherapy may involve administration of multiple drugs / agents during the line of therapy. Rather than reporting each drug separately, standard combination regimens should be reported using the options in question 166 when available. Review the regimen options provided in question 166. If the recipient’s line of therapy includes one of the regimens listed, report **Yes** for question 165 and indicate the regimen that was given in question 166. If the recipient did not receive one of the standard regimens provided in question 166 as part of the line of therapy being reported, indicate **No** for question 165 and go to question 167.

Only one regimen may be reported for question 166. Generally, each regimen should be reported as a separate line of therapy. If the recipient received a regimen specified in question 166 as well as additional systemic therapy drugs as part of the line of therapy being reported, indicate the standard regimen in question 166 and report the additional drugs in 167-169.

#### Questions 167 – 169: Were systemic drugs given?

Questions 167-169 are intended to capture systemic therapy drugs / agents not already reported in questions 165-166. If part or all of the recipient’s regimen can be reported in questions 165-166, report them in those questions and do not report them again in questions 167-169. If all systemic therapy drugs given as part of the line of therapy being reported were included in the regimen indicated in question 166, report **No** for question 167 and go to question 170.

If the recipient received systemic chemotherapy drugs not already reported in questions 165-166 as part of the line of therapy being reported, report **Yes** for question 167 and specify the chemotherapy drug(s) in questions 168-169. Otherwise, report **No** for question 167 and go to question 170.

If the center needs to report a systemic chemotherapy drug (or drugs) in question 168, but it is not listed as an option, report **Other systemic therapy** and use question 169 to specify any drugs not already reported. Only report systemic chemotherapy drugs in questions 167-169.

#### Question 170: Was this line of therapy given for stem cell mobilization (priming)?

Indicate **Yes** if this line of therapy was given for stem cell priming. For example, high dose cyclophosphamide (Cytoxan) may be used in a myeloma patient to collect their peripheral blood stem cells (PBSCs) as they recover their white blood count. Report **No** if this line of therapy was not given for stem cell priming.

#### Question 171: Did the recipient receive any amyloid fibril-directed therapies?

Amyloid fibrils are protein (or peptide) aggregates that develop under certain conditions within the body. Some therapies directly target these aggregates to offset their clinical affects. Indicate **Yes** or **No** if the recipient received amyloid fibril-directed therapy. Answer **No** if the recipient did not receive amyloid fibril-directed therapy and continue with question 174.

#### Questions 172 – 173: Specify amyloid fibril-directed therapies (check all that apply)

Indicate which amyloid fibril-directed therapies the recipient received. If the therapy administered is not listed in this section, report **Other** and specify the agent given for amyloid fibril-directed therapy in question 173.

#### Question 174: Radiation therapy

Radiation therapy uses high-energy radiation to kill cancer cells. For multiple myeloma, external beam radiation is the type of radiation used most frequently. In this method, a beam of radiation is delivered to a specific part of the body, such as a lytic lesion or plasmacytoma. Indicate **Yes** or **No** if the recipient received radiation therapy between the time of diagnosis and the start of the preparative regimen. If **No**, continue with question 181.

#### Questions 175 – 176: Date radiation therapy started

Indicate if the start date for radiation therapy is **Known** or **Unknown**. If **Known**, enter the date the line of radiation therapy began. If **Unknown**, continue with question 177.

#### Questions 177 – 178: Date radiation therapy stopped

Indicate if the stop date for radiation therapy is **Known** or **Unknown**. If **Known**, enter the date the line of radiation therapy ended. If **Unknown**, continue with question 179. If the recipient is still receiving radiation therapy at the time of their transplant, report **Not applicable (still receiving therapy)** and go to question 181.

#### Questions 179 – 180: Dose of radiation therapy

Enter the total dose of radiation given. If radiation was given as a single dose, the amount of radiation delivered in the single dose constitutes the total dose. If the radiation was given in fractionated doses, multiply the total number of fractions by the dose per fraction to determine the total dose. Enter the total dose of radiation in either grays (Gy) or centigrays (cGy).

**Example:**

Radiation order: TBI, 200 cGy/day for three days (3 doses)

Total dose: 200 cGy x 3 doses = 600 cGy

Report “Dose of radiation therapy” as 600 cGy

#### Question 181: Cellular therapy (e.g., CAR-T cells)

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR-T cells).

Report **Yes * if the recipient received cellular therapy as part of the line of therapy being reported. For subsequent infusions, this includes any previous cell therapy infusions to treat disease already reported to the CIBMTR. If not, report *No**.

#### Question 182: Best hematologic response to line of therapy

If the recipient’s primary disease is monoclonal gammopathy of renal significance (MGRS), go to question 188.

Indicate the best response to the line of therapy. See the [Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria) section for multiple myeloma and solitary plasmacytoma disease status definitions. See [Plasma Cell Leukemia Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/pcl-response-criteria) for plasma cell leukemia disease status definitions. For more information on determining what baseline values to use to establish best response, see [Appendix G](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-g).

If, at any response level, some but not all criteria are met, the best response should be downgraded to next lower level of response. The percentage of plasma cells in the bone marrow aspirate and/or biopsy may also be identified on a flow cytometry report. If high sensitivity or next generation flow cytometry was utilized, those results can be used to confirm CR (e.g., <5% plasma cells in the bone marrow.

If the disease response to this line of therapy is unknown, select **Unknown** and continue with question 184.

#### Question 183: Date assessed

Enter the date the best response was assessed. Report the date of the first assessment, not the date of the second confirmatory assessment. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathologic examination.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 184: Best hematologic response to line of therapy (for Amyloid patients only)

Indicate the best response to the line of therapy. See the [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) section for amyloidosis disease status definitions.

#### Question 185: Date assessed

Enter the date the best response was assessed. Report the date of the first assessment, not the date of the second confirmatory assessment. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathologic examination.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 186: Did disease relapse/progress during or following this line of therapy?

Indicate **Yes** if a relapse or progression occurred during or following the line of therapy being reported. Indicate **No** if the recipient did not relapse or progress following this line of therapy and continue with question 188.

See [Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria) and [Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria) for progressive disease and Relapse from CR disease status definitions.

#### Question 187: Date of relapse / progression

Enter the date the relapse or progression was established during or following the line of therapy. Report the date the blood/urine was collected for the laboratory evaluations (e.g., SPEP/UPEP, serum/urine immunofixation) or report the date the bone marrow was collected for pathological evaluation.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q181 | 6/28/2023 | Add | The Reporting Prior Cellular Therapy as a Line of Therapy blue information box added: As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form |
Due to change in FormsNet3 validation |
| Q181 | 10/17/2022 | Add | Q181 updated for clarification: Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR-T cells). Report Yes if the recipient received cellular therapy as part of the line of therapy being reported. For subsequent infusions, this includes any previous cell therapy infusions to treat disease already reported to the CIBMTR. If not, report No. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)