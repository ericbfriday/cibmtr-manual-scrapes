The blood is composed of platelets, red blood cells, and several kinds of white blood cells. One kind of white blood cells, the plasma cells (also called plasma B cells, plasmocytes, or effector B cells) produce proteins called antibodies or immunoglobulins (Igs) that are part of our defense system against foreign substances (called antigens). Antibodies are produced in response to such things as viruses, bacteria, and other infectious agents.


Multiple myeloma is a cancer that leads to the proliferation of malignant plasma cells (myeloma cells). Myeloma cells usually proliferate in the bone marrow. When myeloma cells grow into isolated masses in other sites, these masses are called plasmacytomas. Health problems caused by multiple myeloma can affect the bones, immune system, kidneys, and red blood cell count.

The immunoglobulins (antibodies) produced by healthy plasma cells are composed of pairs of heavy chains and light chains (see Graphic 1 below). Healthy plasma cells create many different kinds of immunoglobulins that are classified by their heavy chain type into five categories (IgG, IgA, IgM, IgD, or IgE). The light chain types are designated kappa (κ) or lambda (λ). The whole Ig molecule is then labeled IgG kappa, IgG lambda, IgA kappa, IgA lambda, etc. These protein levels can be measured in blood serum and/or urine.

#### Graphic 1: Structure of an Immunoglobulin (Antibody)

*Secretory Multiple Myeloma:*

Healthy plasma cells make immunoglobulins (antibodies) of all types. With the proliferation of malignant plasma cells, the level of one immunoglobulin type increases in the blood and/or urine. This abnormal immunoglobulin type is called the monoclonal immunoglobulin, monoclonal protein (M-protein/M-spike/M-component), or paraprotein. In most cases, the normal immunoglobulins are reciprocally depressed. Patients with this condition are said to have *secretory myeloma*.

Some myeloma patients make only an excess of the light chain portion of the immunoglobulin molecule (i.e., only monoclonal kappa or lambda light chains). The light chain is also called Bence Jones protein. In most patients whose myeloma cells only make light chains, this paraprotein may not be detectable in the blood, but only in the urine. These patients are said to have *light chain only* disease. Ninety-seven percent of patients diagnosed with multiple myeloma have a detectable paraprotein in the blood serum and/or urine.

#### Table 1. Distribution of Monoclonal Proteins in Secretory Multiple Myeloma[1](#fn7803696268596b687f208-1)[2](#fn7803696268596b687f208-2)

[1](#fn7803696268596b687f208-1)

[2](#fn7803696268596b687f208-2)

| Monoclonal Proteins at Diagnosis | Percent |
|---|---|
Source of monoclonal proteins |
|
| Serum monoclonal proteins | 80% |
| Urine monoclonal proteins | 75% |
Type of monoclonal proteins |
|
| IgG | 50-54% |
| IgA | 20% |
| Monoclonal light chain (light-chain-only disease) | 20% |
| IgD | 2% |

1 Kyle RA, et al. Review of 1027 patients with newly diagnosed multiple myeloma. *Mayo Clin Proc.* 2003;78(1):21-33.

2 International Myeloma Working Group. Criteria for the classification of monoclonal gammopathies, multiple myeloma and related disorders: a report of the International Myeloma Working Group. *Br J Haem.* 2003;121(5):749-757.

*Nonsecretory Multiple Myeloma:*

In some myeloma patients, the malignant plasma cells do not produce an excess of the heavy chain or light chain portion of the immunoglobulin molecule; therefore, a paraprotein is not detectable in the serum or urine. These patients are said to have *nonsecretory myeloma* (i.e., the absence of a paraprotein on immunofixation). Immunofixation detects the specific immunoglobulins after separating the proteins into bands on an electrophoresis gel. Nonsecretory myeloma accounts for 3% of myeloma cases.

#### Table 2. Epidemiology of Multiple Myeloma in the United States[1](#fn7803696268596b687f208-1)

[1](#fn7803696268596b687f208-1)

| Cases diagnosed per year | ~21,700 |
| US Prevalence (2009) | ~71,213 |
| Median Age at Diagnosis | 69 yrs |
| Sex | Higher incidence in men |
| Race | Higher incidence in African Americans |
| 5-year survival rate | 40% |

1 National Cancer Institute. Surveillance Epidemiology and End Results (SEER) Stat Fact Sheets: Myeloma. Acessed at: [http://seer.cancer.gov/statfacts/html/mulmy.html](http://seer.cancer.gov/statfacts/html/mulmy.html). Accessibility verified on August 8, 2013.

**Amyloidosis:**

Amyloidosis is a disease in which abnormally folded proteins build up in different tissues of the body. In the most common amyloidosis, AL amyloidosis, the abnormally folded protein is the light chain component of an immunoglobulin. These light chains may build up in a variety of tissues, but the most common sites of build-up are the heart, kidneys, liver, and nerves. According to the Amyloidosis Foundation, AL Amyloidosis is a relatively rare disorder, with 1200-3200 new cases reported each year in the United States. The disease mostly impacts men over 40.[1](#fn7803696268596b687f208-1)

1 Amyloidosis Foundation. Amyloidosis – Primary AL. Accessed at: [http://www.amyloidosis.org/TreatmentInformation/primaryAL.html](http://www.amyloidosis.org/TreatmentInformation/primaryAL.html).

Accessibility verified on August 8, 2013.

[Multiple Myeloma Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/multiple-myeloma-response-criteria)

[Amyloidosis Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/amyloidosis-response-criteria)

[2016: PCD Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2016-pcd-pre-hct)

[2116: PCD Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2116-pcd-post-hct)

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/23/2020 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)