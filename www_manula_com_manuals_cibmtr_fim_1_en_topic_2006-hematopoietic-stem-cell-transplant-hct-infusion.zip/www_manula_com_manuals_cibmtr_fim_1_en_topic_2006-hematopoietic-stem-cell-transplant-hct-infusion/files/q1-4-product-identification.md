#### Question 1: In what setting is this cell therapy product infusion being planned?

Indicate if this cell therapy product infusion will be administered as an **Inpatient** or **Outpatient** procedure.

#### Question 2: Is a subsequent HCT part of the overall treatment protocol?

This question intends to capture instances where the cellular therapy is administered in association with an HCT, either planned or dependent upon the response to the cellular therapy. It is not intended to capture an HCT given prior to this cellular therapy infusion. If, at the time of the current infusion, a subsequent HCT is planned according to the protocol, check **Yes** even if the recipient does not receive the planned subsequent HCT. The word “planned” should not be interpreted as: if the recipient relapses, then the “plan” is to perform a subsequent HCT. If a subsequent HCT is not planned as part of the overall treatment protocol, select **No**.

#### Question 3: Specify the HCT type:

Specify the type of the subsequent HCT that is planned as part of the overall treatment protocol.

**Autologous** product has cells collected from the recipient for his / her own use.

**Allogeneic** product is from a donor who is not the recipient, either related or unrelated to the recipient.

#### Question 4: Specify the circumstances which the subsequent HCT will be performed:

Specify the reason for which the subsequent HCT will be performed as **Regardless of response to cellular therapy**, **Only if the patient responds to cellular therapy**, or **Only if the patient fails to respond or has an incomplete response**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)