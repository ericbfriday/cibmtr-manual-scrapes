#### Question 147: Was the HCT impacted for a reason related to the COVID-19 (SARS-CoV-2) pandemic? (Examples of applicable impacts include changes to the original HCT date, donor, product type, preparative regimen, and GVHD prophylaxis) (Does not apply if infected by COVID-19 (SARS-CoV-2))

Indicate if the HCT was impacted for any reason related to the COVD-19 pandemic. Examples include changes to the original HCT date, donor, product type, preparative regimen, and / or GVHD prophylaxis.

For example, the initial plan was to use myeloablative conditioning but changed to reduced intensity to minimize transfusion needs or the preferred stem cell source was marrow but changed to peripheral blood for more rapid count recovery.

**Do not include** here if the HCT was impacted due to the recipient being infected by COVID-19 (i.e., the HCT was delayed due to the recipient having COVID-19 or there was a change in the original planned preparative regimen due to the recipient having a history of COVID-19). Information about COVID-19 infection of the recipient is captured above in the Comorbid Conditions section.

If the HCT was not impacted for a reason related to COVID-19, report **No** and submit the form.

#### Questions 148 – 149: Is the HCT date different than the originally intended HCT date?

Indicate if the current HCT date is different than the originally planned HCT date. If **Yes**, report the original HCT date (YYYY-MM-DD). If the exact date is unknown, use the guidelines for reporting estimated dates and check the **Date estimated** box.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 150 – 151: Is the donor different than the originally intended donor?

Indicate if the current donor for HCT is different than the originally intended donor. If Yes, specify the originally intended donor.

**Unrelated donor**: A donor who shares no known ancestry with the recipients. Include adoptive parents / children or stepparents / children.**Syngeneic**: Monozygotic (identical) twins. Does not include other types of twins or HLA-identical siblings (see below).**HLA-identical sibling**: Non-monozygotic (dizygotic, fraternal, non-identical) twins. Does not include half-siblings (report as HLA-matched other relatives if their HLA typing is a match, or HLA-mismatched relative if it does not match).**HLA-matched other relative**: All blood-related relatives, other than siblings, who are HLA matched (e.g., parents, aunts, uncles, children, cousins, half-siblings). Does not include adoptive parents / children or stepparents / children who are HLA matched.**HLA-mismatched relative**: Siblings who are not HLA-identical and all other blood-related relatives who have at least one HLA mismatch (mismatch can be at the antigen or allele level) (e.g., parents, aunts, uncles, children, cousins, half-siblings). Does not include adoptive parents / children or stepparents / children.

#### Questions 152 – 154: Is the product type (bone marrow, PBSC, cord blood unit) different than the originally intended product type?

Indicate if the current product type of HCT is different than the originally intended product type. If **Yes**, specify the originally intended product type. If **Other product** is selected, specify the product.

#### Question 155: Was the current product thawed from a cryopreserved state prior to infusion?

Indicate if the current product for HCT was thawed from a cryopreserved state prior to infusion.

#### Question 156: Did the preparative regimen change from the original plan?

Indicate if the current preparative regimen changed from the original plan. This includes changes in the preparative regimen drugs.

#### Question 157: Did the GVHD prophylaxis change from the original plan?

Indicate if the current GVHD prophylaxis changed from the original plan.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q147 | 3/13/2024 | Modify | The red warning box above Q147 updated to clarify this section is now disabled and will be updated with the next revision of the Pre-TED (2400) form. | Due to change in FormsNet3SM validation |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)