#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the disease. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

#### Questions 180 – 181: Specify acute leukemias of ambiguous lineage and other myeloid neoplasm classification

CIBMTR captures the classification of ambiguous lineage and other myeloid neoplasms based on the World Health Organization (WHO) 2022. Indicate the other acute leukemia disease classification at diagnosis. If the subtype is not listed, report as **Other acute leukemia of ambiguous lineage or myeloid neoplasm** and specify the reported disease.


**Acute undifferentiated leukemia**is a type of AML characterized by immature predominating cells that cannot be classified.- Biphenotypic, bilineage, or hybrid leukemias have characteristics representative of both myeloid and lymphoid lineages.

#### Question 182: What was the disease status (based on hematological test results)?

Indicate the disease status of acute leukemia at the last evaluation prior to the start of the preparative regimen.

### Table 7. Disease Status of Acute Leukemia

Disease Status |
Definition |
Primary Induction Failure (PIF) |
The patient received treatment for acute leukemia but never achieved complete remission at any time. PIF is not limited by the number of unsuccessful treatments; this disease status only applies to recipients who have never been in complete remission. |
Complete Remission (CR) |
Hematologic complete remission is defined as meeting all of the following response criteria for at least four weeks.
|
Relapse (REL) |
Relapse is defined as the recurrence of disease after CR, meeting the following criteria:
|
No Treatment |
The recipient was diagnosed with acute leukemia and never received therapeutic agents; include patients who have received only supportive therapy, including growth factors and/or blood transfusions. |

#### Question 183: Date assessed

Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q180 | 1/24/2025 | Remove | CIBMTR captures the classification of ambiguous lineage and other myeloid neoplasms based on the World Health Organization (WHO) 2022. Indicate the other acute leukemia disease classification at diagnosis. If the subtype is not listed, report as Other acute leukemia of ambiguous lineage or myeloid neoplasm and specify the reported disease.
|
Removed for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)