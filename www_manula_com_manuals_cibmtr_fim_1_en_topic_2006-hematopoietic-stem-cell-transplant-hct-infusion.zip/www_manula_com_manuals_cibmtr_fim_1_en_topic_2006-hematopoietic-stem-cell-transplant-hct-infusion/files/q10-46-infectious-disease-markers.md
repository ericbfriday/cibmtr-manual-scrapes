Report the final test results. Final test results could refer to either the initial screening test or the confirmatory test. If a screening test is negative, a confirmatory test might not be done. In this case, use the screening test as the final test result. However, if a screening test is positive, a confirmatory test may be done. In this case, use the confirmatory test as the final test result. If testing is only performed on the harvested product and not on the peripheral blood sample, report those samples accordingly.

## Hepatitis B Virus (HBV)

Hepatitis B infection is caused by the hepatitis B virus (HBV). Hepatitis B is spread through infected blood and other body fluids. Signs and symptoms of infection generally occur 60-150 days after exposure and include fever, fatigue, nausea, vomiting, and jaundice (secondary to liver inflammation). Patients with an acute hepatitis B infection generally do not require treatment; approximately 95% of adults who get acute hepatitis B will recover without developing chronic hepatitis B infection. Chronic hepatitis B infection is generally monitored for progression or evidence of liver damage, at which point patients may be treated with antiviral drugs. Chronic hepatitis B infection can lead to liver scarring (cirrhosis) and liver cancer (hepatocellular carcinoma). In the United States, the hepatitis B vaccine is now part of the routine childhood vaccination schedule.

#### Question 2: HBsAg (hepatitis B surface antigen)

The hepatitis B surface antigen is a protein expressed on the surface of the hepatitis B virus. Its presence in the blood serum indicates acute or active chronic infection. In acutely infected patients, blood will test HBsAg positive within one to nine weeks of exposure to the virus. Patients who do not go on to develop chronic infection will be surface antigen negative by 15 weeks after the onset of symptoms. Chemiluminescent immunoassay (CIA), electrochemiluminescent immunoassay (ECLIA), or enzyme-linked immunosorbent assay (ELISA) are used to test for the presence of hepatitis B surface antigens; research indicates CIA and ECLIA may be more sensitive for detecting low levels of HBsAg1. Positive HBsAg results require confirmation with specific antigen neutralization.

Report the laboratory result as **Reactive** (positive) or **Non-reactive** (negative). If HBsAg testing was not performed, report **Not done**.

1 Fei CR, Ye AQ, Zhang J. (2011). Evaluation of different methods in determination of low level HBsAg. Zhejiang Da Xue Xue Bao Yi Xue Ban, 40(4):436-439.

#### Question 3: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

#### Question 4: Anti HBc (hepatitis B core antibody)

The total hepatitis B core antibody refers to both IgG and IgM antibodies produced by the body in response to the presentation of the core antigen by liver cells. Since core antigen is present only in infected liver cells and cannot be detected in the blood of an infected individual, only core antibody is tested, since it circulates in the peripheral blood. After infection, total core antibodies will persist for life. Presence of core antibodies can indicate active and/or prior infection, but hepatitis core antibodies will not be present in individuals with no history of natural infection with HBV. This means that vaccinated individuals will not be anti-HBc positive because vaccination results in the body developing antibodies to the hepatitis B surface antigen. Chemiluminescent immunoassay (CIA), enzyme-linked immunosorbent assay (ELISA), or Elecsys anti-HBc is used to test for the presence of hepatitis B core antibodies. Currently, there is no licensed confirmatory test for anti-HBc in the United States; confirmation of antibody presence is done by performing a second anti-HBc test using a different manufacturer’s test kit.2

Report the laboratory result as **Reactive** (positive) or **Non-reactive** (negative). If anti-HBc testing was not performed, report **Not done**.

2 Centers for Disease Control & Prevention. (2012). CDC Hepatitis B Information for Health Professionals. Retrieved from http://www.cdc.gov/hepatitis/HBV/HBVfaq.htm

#### Question 5: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

#### Question 6: FDA licensed NAAT testing for HBV

Nucleic acid amplification testing (NAAT) is a combination PCR test that detects the presence of viral genes rather than antigens or antibodies. This test allows earlier detection and provides more sensitivity than previously used tests.

Report the laboratory result as **Positive** or **Negative**. If HBV NAAT testing was not performed, report **Not done**.

If HBV NAAT testing was performed but results are not being reported to the CIBMTR (e.g., donor declines to release results), report **Not done**.

Non-U.S. centers should answer this question, regardless of FDA licensure.

If a non-FDA licensed NAAT test was used, report these results under *Other Infectious Disease Marker*.

#### Question 7: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Hepatitis C Virus (HCV)

Hepatitis C infection is caused by the hepatitis C virus (HCV). Hepatitis C is generally spread through infected blood. Newly infected individuals are generally asymptomatic, though signs and symptoms of infection, similar to those seen in other viral hepatitis infections, can develop. Since acute hepatitis C infection is generally asymptomatic, it is rarely identified or treated during the acute infection stage. Approximately 15-25% of infected individuals will clear the virus without treatment, and will not develop chronic hepatitis C infection. Chronic hepatitis C infection can lead to chronic liver disease and/or scarring of the liver (cirrhosis); chronic HCV is the leading indication for liver transplant in the United States. Currently no approved vaccination for hepatitis C exists.

#### Question 8: Anti-HCV (hepatitis C antibody)

The total hepatitis C antibody refers to both IgG and IgM antibodies produced by the body in response to the presentation of antigens by the hepatitis C virus. Antibodies can generally be detected as soon as four weeks after exposure and will persist for life. Enzyme-linked immunosorbent assay (ELISA) or chemiluminescent immunoassay (CIA) is used to screen for hepatitis C antibodies; confirmatory testing is done by recombinant immunoblot assay (RIBA). A positive ELISA or CIA result without confirmation by RIBA is considered an indeterminate result, unless HCV RNA is detected in the blood by PCR.

Report the laboratory result as **Reactive** (positive) or **Non-reactive** (negative). If anti-HCV testing was not performed, report **Not done**.

#### Question 9: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

#### Question 10: FDA licensed NAAT testing for HCV

Nucleic acid amplification testing (NAAT) is a combination PCR test that detects the presence of viral genes rather than antigens or antibodies. This test allows earlier detection and provides more sensitivity than previously used tests.

Report the laboratory result as **Positive** or **Negative**. If HCV NAAT testing was not performed, report **Not done**.

If HCV NAAT testing was performed but results are not being reported to CIBMTR (e.g., donor declines to release results), report **Not done**.

Non-U.S. centers should answer this question, regardless of FDA licensure.

If a non-FDA licensed NAAT test was used, report these results under *Other Infectious Disease Marker*.

#### Question 11: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Human Immunodeficiency Virus (HIV)

HIV infection is caused by exposure to one of two viruses, either HIV-1 or HIV-2. HIV-2 is less virulent and has a longer incubation period than HIV-1. Both types of HIV progressively destroy CD4+ cells, which include T-helper cells, monocytes, and their derivatives (macrophages and dendritic cells), and are an important part of the body’s immune defense. HIV can lead to acquired immunodeficiency syndrome (AIDS), a condition in which the immune system begins to fail, leading to life-threatening opportunistic infections. Mechanism of HIV transmission is through exposure to blood or other body fluids, or through vertical transmission (maternal-fetal transmission).

#### Question 12: HIV-1 p24 antigen

The HIV p24 antigen is a viral core protein that is detectable in the blood during acute infection; it is detectable earlier than HIV antibody. The p24 antigen appears approximately two weeks after exposure and will be present in the blood for three to five months. Once antibodies to HIV are detectable in the blood, p24 antigen is usually no longer detectable by immunoassay due to antigen-antibody binding. Enzyme-linked immunosorbent assay (ELISA) is used to test for the presence of p24 antigen; it may be done in conjunction with antibody testing in order to detect the virus in all stages of infection. Positive p24 antigen results require confirmation with specific antigen neutralization.3

Report the laboratory result as **Reactive** (positive) or **Non-reactive** (negative). If HIV-1 p24 antigen testing was not performed, report **Not done**.

If HIV-1 p24 testing was performed but results are not being reported to CIBMTR (e.g., donor declines to release results), select **Not reported**.

3 University of California, San Francisco. (n.d.) HIV InSite Knowledge Base. Retrieved January 15, 2013, from http://hivinsite.ucsf.edu/InSite?page=KB

#### Question 13: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

#### Question 14: FDA licensed NAAT testing for HIV-1

Nucleic acid amplification testing (NAAT) is a combination PCR test that detects the presence of viral genes rather than antigens or antibodies. This test allows earlier detection and provides more sensitivity than previously used tests.

Report the laboratory result as **Positive** or **Negative**. If HIV-1 NAAT testing was not performed, report **Not done**.

If HIV-1 NAAT testing was performed but results are not being reported to CIBMTR (e.g., donor declines to release results), report **Not done**.

Non-U.S. centers should answer this question, regardless of FDA licensure.

If a non-FDA licensed NAAT test was used, report these results under *Other Infectious Disease Marker*.

#### Question 15: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

#### Question 16: Anti-HIV 1 and anti-HIV 2 (antibodies to Human Immunodeficiency Viruses)

The HIV-1 and HIV-2 antibodies are produced by the body in response to the antigens presented by the HIV-1 and HIV-2 viruses, such as p24 (HIV-1) core antigen and p26 (HIV-2) core antigen. Antibodies are not detectable as early during the course of infection as the viral antigens, but will persist for the patient’s lifetime once developed. Enzyme-linked immunosorbent assay (ELISA) is used to test for the presence of HIV-1 and HIV-2 antibodies. Most laboratories will utilize a combined assay that detects both viral antibodies, but in some cases they will be done as separate tests. Positive HIV-1 antibody results require confirmation by western blot, which uses gel electrophoresis to detect specific proteins. Currently, there is no licensed confirmatory test for anti HIV-2 in the United States; confirmation of antibody presence is done by performing a second anti HIV-2 test using a different manufacturer’s test kit.

Report the laboratory result as **Reactive** (positive) or **Non-reactive** (negative) only if the patient was evaluated for antibodies to both HIV-1 and HIV-2.

If the patient was only assessed for antibodies to one virus, report **Not done**.

If anti-HIV-1 and / or anti-HIV-2 testing was not performed, report **Not done**.

If anti-HIV-1 and anti-HIV-2 testing was performed but results are not being reported to CIBMTR (e.g., donor declines to release results), report **Not reported**.

#### Question 17: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Chagas (T. cruzi)

Chagas disease is caused by the parasitic protozoan *Trypanosoma cruzi* (T. cruzi), which is endemic in South America, Central America, and the Caribbean. Chagas is spread through exposure to infected blood, most commonly through an insect vector such as triatomine bugs. It can also be spread through transmission from mother to fetus (also known as “vertical transmission”), blood transfusions, organ transplant, or needlesticks. In acute infection, there are rarely severe symptoms; most cases are asymptomatic or will exhibit generalized, non-specific symptoms. Treatment with anti-parasitic drugs during the acute phase is often curative. Of the individuals who are untreated and enter the chronic phase of infection, only 20-40% will ever have signs and symptoms related to Chagas disease. Symptomatic Chagas disease can affect the nervous, digestive, and cardiac systems and can be very severe, even resulting in death.

#### Question 18: Chagas testing

Testing for antibodies to T. cruzi is generally done by enzyme-linked immunosorbent assay (ELISA) or chemiluminescent immunoassay (CIA). If active infection is suspected, another evaluation, such as PCR, may be done to confirm and identify the strain of infection. In 2011, the FDA approved a more specific immunoassay that evaluates the donor for antibodies to specific excreted-secreted antigens presented by the T. cruzi pathogen. This assessment is intended to be a supplemental test for individuals who have been repeatedly reactive to the previously approved immunoassays.

Report the laboratory result as **Positive** or **Negative**. If Chagas testing was not performed, report **Not done**.

#### Question 19: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Herpes Simplex Virus (HSV)

Herpes Simplex Virus includes two viruses, HSV-1 and HSV-2, which are two of the human herpes viruses (Herpesviridae family). Other human herpes viruses include cytomegalovirus (CMV), Epstein-Barr virus (EBV), and varicella zoster virus (VZV). HSV-1 is typically manifested as skin lesions or lesions of the oral mucous membranes; it may also infect the genitalia, but this is less common. HSV-2 is typically manifested as lesions of the external genitalia. Both HSV-1 and HSV-2 are spread through contact with lesions during active infection; HSV-1 can be spread through saliva. After initial infection, the virus will lay dormant in the body and can reoccur. Stress, fatigue, and infection can all cause the virus to be reactivated. According to data from 1999-2004, the seroprevalence of HSV-1 in individuals in the United States between ages 14-49 is estimated at 57.7%, while the seroprevalence of HSV-2 for the same population is estimated at 17.2%.5

5 Xu F, Sternberg MR, Kottiri BJ, et al. (2006). Trends in Herpes Simplex Virus Type 1 and 2 Seroprevalence in the United States. J Am Med Assoc, 296(8).

#### Question 20: Anti-HSV (Herpes simplex virus antibody)

Testing for antibodies to HSV is typically done by enzyme-linked immunosorbent assay (ELISA), glycoprotein G-specific immunoblot assay, or Western Blot. These immunoassays detect antibodies to both HSV-1 and HSV-2, though the results will specify whether detected antibodies are specific to HSV-1 or HSV-2 (or both). Results may be expressed as quantified antibody titer; in this case, the laboratory or test kit manufacturer will provide reference ranges to determine if the result is considered positive, indeterminate, or negative.

Report the laboratory result as **Positive** or **Negative**. If *either* HSV-1 or HSV-2 antibodies are detected, report **Positive**. If anti-HSV testing was not performed, report **Not done**.

#### Question 21: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Epstein-Barr Virus (EBV)

Epstein-Barr Virus (EBV) is part of the human herpes viruses family *Herpesviridae*. EBV infection may cause infectious mononucleosis, particularly in young adults. Infectious mononucleosis symptoms include fever, sore throat, lymphadenopathy, and fatigue. After initial infection, the virus will lay dormant in the body and can reoccur; recurrence of EBV is often subclinical. Late events associated with prior EBV infection include Burkitt’s lymphoma, post-transplant lymphoproliferative disorder (PTLD), and nasopharyngeal carcinoma.

#### Question 22: Anti-EBV (Epstein-Barr virus antibody)

Testing for antibodies to EBV is typically done by enzyme-linked immunosorbent assay (ELISA). This immunoassay can be used to detect IgM and/or IgG antibodies to EBV. The presence of IgM antibodies indicates a recent or current infection, usually within the past four to six months. Presence of IgG antibodies indicates a previous infection and confers long-term immune response to the virus. Results may be expressed as quantified antibody titer; in this case, the laboratory or test kit manufacturer will provide reference ranges to determine if the result is considered positive, indeterminate, or negative.

Report the laboratory result as **Positive**, **Negative**, or Inconclusive. A positive IgM or IgG assay is considered a **Positive** (reactive) result. If anti-EBV testing was not performed, report **Not done**.

#### Question 23: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Varicella Zoster Virus (VZV)

Varicella zoster virus (VZV) is one of the human herpes viruses Herpesviridae family). VZV, known as chickenpox with its initial presentation, manifests as pruritic skin blisters and typically first presents in childhood. After the initial infection, the virus will lay dormant in the body and can reoccur. Recurrence results in herpes zoster, more commonly known as shingles, which manifests as a painful, blistering skin rash.

#### Question 24: Anti-VZV (Varicella zoster virus antibody)

Testing for antibodies to VZV is generally done by fluorescent-antibody-to-membrane-antigen (FAMA), enzyme-linked immunosorbent assay (ELISA) or chemiluminescent immunoassay (CIA). These immunoassays can be used to detect IgM and/or IgG antibodies to VZV. Presence of IgM antibodies indicates a recent or current infection, usually within the past four to six months. Presence of IgG antibodies indicates a previous infection and confers a long-term immune response to the virus. Results may be expressed as quantified antibody titer; in this case, the laboratory or test kit manufacturer will provide reference ranges to determine if the result is considered positive, indeterminate, or negative.

Report the laboratory result as **Positive** or **Negative**. A positive IgM or IgG assay is considered a **Positive** (reactive) result.

If anti-VZV testing was not performed, report **Not done**.

#### Question 25: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

## Other Infectious Disease Marker

Testing may be done for antibodies to pathogens other than those already listed on this form. If the donor was tested for any other infectious disease markers, report below. The *Other infection disease marker* questions can be duplicated to report multiple additional IDM results. Note, results of CMV testing do **not** need to be reported on this form.

Examples of other testing that may be reported as an “other infectious disease marker” include:


- Anti-HBs
- Anti-HBe
- WNV by ELISA
- Lyme disease

#### Question 26: Other infectious disease marker, specify

Indicate if the donor was tested for an IDM other than those already listed on this form; do not report PCR results. If the donor was tested for other IDMs, report **Yes**. If the donor was not tested for any other IDMs, report **No** and continue with the signature section.

#### Question 27: Date sample collected

Indicate the date the sample was collected for infectious disease marker testing.

#### Question 28: Specify test and method

Specify the pathogen(s) evaluated, the immunoassay or other test used, and the immunoglobulins measured.

#### Question 29: Specify test results

Report the qualitative laboratory results of the IDM (ex: reactive/non-reactive); do not report quantified titer levels.

**Signature**

The FormsNet3SM application will automatically populate the signature data fields, including name and email address of person completing the form, and date upon submission of the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)