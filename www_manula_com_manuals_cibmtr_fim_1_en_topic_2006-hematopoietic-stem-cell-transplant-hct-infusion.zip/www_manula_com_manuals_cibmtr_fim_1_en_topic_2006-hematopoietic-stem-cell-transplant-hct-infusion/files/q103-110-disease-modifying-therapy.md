#### Question 114: Were disease modifying therapies given? (excludes blood transfusions)

Indicate if the recipient received disease modifying therapies (see question 104 for a list of common disease modifying therapies) during the current reporting period, excluding blood transfusion(s).

If the recipient did not receive disease modifying therapies or if no information is available to determine if the recipient received disease modifying therapies, select **No** or **Unknown**, respectively and submit the form.

#### Questions 115 – 116: Specify the disease modifying therapy (check all that apply)

Select the disease modifying therapy administered as part of the line of therapy being reported.

**Hydroxyurea:**A type of chemotherapy. Common brand names include Droxia and Hydrea.**Luspatercept:**Treatment for anemia with recipient’s beta thalassemia. Also known as Reblozyl.

If the recipient received a therapy which is not listed, select **Other** and specify the treatment. Report the generic name of the agent, not the brand name.

#### Question 117: Was the date therapy started previously reported?

Specify if the therapy start date was previously reported. If the therapy was started in a prior reporting period and continued into the current reporting period, select **Yes**, and continue with *Date therapy stopped*.

The **Yes** option is not applicable for the Day 100 reporting period.

#### Questions 118 – 119: Date therapy started

Indicate if the therapy start date is known. If Known, report the first date (YYYY-MM-DD) the recipient began this line of therapy.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Questions 120 – 121: Date therapy stopped

Indicate if the stop date is known. If the therapy stop date is Known, report the date (YYYY-MM-DD) when the therapy end. If the therapy is being given in cycles, report the end date as the date when the recipient started the last cycle for this line of therapy. Otherwise, report the final administration date for the therapy being reported.

If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

Report **Not applicable** if the recipient is still receiving therapy on the contact date.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)