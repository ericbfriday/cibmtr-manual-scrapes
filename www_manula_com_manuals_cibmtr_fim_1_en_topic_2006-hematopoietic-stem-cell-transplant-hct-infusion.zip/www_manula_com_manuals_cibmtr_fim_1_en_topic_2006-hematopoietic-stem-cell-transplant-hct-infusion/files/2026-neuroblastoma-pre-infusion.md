The Neuroblastoma Pre-HCT Data Form (Form 2026) is one of the Comprehensive Report Forms. This form captures neuroblastoma specific pre-HCT data such as: the recipient’s clinical and laboratory findings at the time of diagnosis and prior to the start of the preparative regimen, pre-HCT treatments administered, and disease manifestations prior to the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as Neuroblastoma under “Solid tumors.”

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype, and this baseline disease insert has not been completed for the previous transplant (e.g., patient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), begin at question 1. If this is a report of a second or subsequent transplant for a different disease (e.g., patient was previously transplanted for a disease other than neuroblastoma), begin at question 1.

If this is a report of a second or subsequent transplant for the same disease and this baseline disease insert has previously been completed, check the indicator box and continue with question 218.

Links to Sections of Form

[Q1 – 61: Clinical and Laboratory Characteristics at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-61-clinical-and-laboratory-characteristics-at-diagnosis)

[Q62 – 232: Laboratory Values at Diagnosis of Neuroblastoma](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q233-271-disease-status-immediately-prior-to-preparative-regimen)

[Q233 – 271: Disease Status Immediately Prior to Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q62-232-laboratory-values-at-diagnosis-of-neuroblastoma)

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/21/2023 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)