# Q290-295: POEMS Syndrome Assessment at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion

#### Questions 290 – 292: Vascular endothelial growth factor (VEGF) serum value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the serum-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen. If **Known**, report the value (in pg/mL) and specify the upper limit of normal. If **Unknown**, continue with question 293.

#### Questions 293 – 295: Vascular endothelial growth factor (VEGF) plasma value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the plasma-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen. If **Known**, report the value (in pg/mL) and specify the upper limit of normal. If **Unknown**, continue with First Name.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)