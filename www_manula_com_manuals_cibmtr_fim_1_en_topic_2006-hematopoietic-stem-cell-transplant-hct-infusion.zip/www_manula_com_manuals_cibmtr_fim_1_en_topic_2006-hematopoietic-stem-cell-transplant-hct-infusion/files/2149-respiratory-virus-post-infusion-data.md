In an effort to collect data on the impact of the COVID-19 (SARS-CoV-2) pandemic on our transplant and cellular therapy recipients, CIBMTR released the Respiratory Virus Post-Infusion Data (2149) Form. This form captures information regarding the diagnosis, treatment, and response to treatment of COVID-19 (SARS-CoV-2) diagnosed after a transplant or cellular therapy infusion.

The Respiratory Virus Post-Infusion Data (2149) Form will no longer have the option to be created on-demand (on-demand is when a form can be generated at any time).

This form will be completed at two timepoints, “Initial” and “Follow-up”:


- Initial Form Submission: reported data should be between 7 days prior to and up to 14 days after the date of diagnosis.
- Follow-Up Form Submission: reported data should be between the date of evaluation (from the initial form submission) to the date of the infection resolution (or day of death).

Links to Form Sections:

[Q1-10: Infection Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-9-infection-diagnosis)

[Q11-24: Hematologic Findings at Diagnosis of Infection](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q10-23-hematologic-findings-at-diagnosis-of-infection)

[Q25-40: Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q25-40-therapy)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 8/25/2023 |
|

[2149: Respiratory Virus Post-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2149-respiratory-virus-post-infusion-data)**Nasal swab / wash:**a sample is collected from the nose using a swab or a small amount of saline solution. The sample is tested via polymerase chain reaction techniques that quantify the amount of viral RNA present or using novel CRISPR testing from respiratory swab RNA extracts. If the amount of viral RNA is above the upper limit of normal (found on the laboratory report), the result will be considered positive for the virus being tested. If the testing report does not clearly indicate whether the result was positive, negative, or equivocal, contact your center’s lab for clarification.[2149: Respiratory Virus Post-Infusion Data](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2149-respiratory-virus-post-infusion-data)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)