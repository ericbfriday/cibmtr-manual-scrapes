#### Question 1: Is this a second or subsequent transplant or cellular therapy for the same disease?

Report **No** and go to *What is the recipient’s beta-globin genotype* in any of the following scenarios:

• This is the first infusion reported to the CIBMTR; or

• This is a second or subsequent infusion for a different disease (i.e., the patient was previously transplanted for a disease other than a leukodystrophy); or

• This is a second or subsequent infusion for the same disease subtype and this baseline disease insert was not completed for the previous transplant (i.e., the recipient was on the TED track for the prior infusion, prior infusion was autologous with no consent, etc.).

Report **Yes** and go to What is the donor’s beta-globin genotype if this is a subsequent infusion for the same disease *and* the Pre-Infusion Thalassemia (2058) Form was completed previously.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)