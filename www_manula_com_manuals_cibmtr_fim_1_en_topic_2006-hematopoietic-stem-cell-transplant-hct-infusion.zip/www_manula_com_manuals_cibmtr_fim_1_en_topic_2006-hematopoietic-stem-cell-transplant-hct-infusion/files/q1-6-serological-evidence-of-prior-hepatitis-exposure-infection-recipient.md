#### Question 1: Specify and/or confirm previous Hepatitis B surface antigen (HBsAg) testing performed and reported on the Form 2000 – Recipient Baseline Data

The hepatitis B surface antigen is a protein expressed on the surface of the hepatitis B virus. Its presence in the blood serum indicates acute or active chronic infection. In acutely infected patients, blood will test HBsAg positive within one to nine weeks of exposure to the virus. Patients who do not go on to develop chronic infection will be surface antigen negative by 15 weeks after the onset of symptoms. Chemiluminescent immunoassay (CIA), electrochemiluminescent immunoassay (ECLIA), or enzyme-linked immunosorbent assay (ELISA) are used to test for the presence of hepatitis B surface antigens; research indicates CIA and ECLIA may be more sensitive for detecting low levels of HBsAg. 1 Positive HBsAg results require confirmation with a neutralization procedure using human Anti-HBs (HBsAg Confirmation Assay). If the sample is neutralizable in the confirmatory test, the specimen is considered positive for HBsAg.

Report the laboratory result as “positive” (reactive), “negative” (non-reactive), or “inconclusive” (indeterminate) for recipient HBsAg testing. If HBsAg testing was not done, indicate “not tested.” Continue with question 2.

1 Fei CR, Ye AQ, Zhang J. (2011). Evaluation of different methods in determination of low level HBsAg. Zhejiang Da Xue Xue Bao Yi Xue Ban, 40(4):436-439.

**Hepatitis B viral load testing**

Hepatitis B viral load testing is used to quantify hepatitis B viral DNA in the blood. The diagnosis of hepatitis B infection, either acute or chronic, is generally made by serologic testing, though DNA testing may be useful in the diagnosis of early acute HBV. Additionally, DNA testing is useful to determine whether the infection is active and to monitor response to anti-HBV therapies. Hepatitis B viral load testing is performed by PCR amplification of HBV DNA in the patient’s serum.

Report all instances of Hepatitis B viral load testing performed within three months prior to the start of the preparative regimen; create an instance for each test result. If no testing was performed within three months prior to the start of the preparative regimen, report the testing performed prior to this period; report only the latest instance.

#### Question 2: Pre-HCT Hepatitis B viral load – date

Specify the date recipient Hepatitis B viral load testing was performed and continue with question 3.

#### Question 3: Hepatitis B viral load level

Report the result for recipient viral load testing as indicated on the laboratory report. If necessary, convert values so they can be reported in the unit of measurement options available on the form.

**Hepatitis C viral load testing**

Hepatitis C viral load testing is primarily used to monitor response to anti-viral therapy and confirm activity of infection; additionally, it may be used to diagnosis early acute HCV infection and to detect active chronic infection. Hepatitis C viral load testing is performed by RT-PCR amplification of HCV RNA in the patient’s serum.

Report all instances of Hepatitis C viral load testing performed within three months prior to the start of the preparative regimen; create an instance for each test result. If no testing was performed within three months prior to the start of the preparative regimen, report the testing performed prior to this period; report only the latest instance.

#### Question 4: Pre-HCT Hepatitis C viral load – date

Specify the date recipient Hepatitis C viral load testing was performed and continue with question 5.

#### Question 5: Hepatitis C viral load level

Report the result for recipient viral load testing as indicated on the laboratory report. If necessary, convert values so they can be reported in the unit of measurement options available on the form.

#### Question 6: Were any liver biopsies performed for cytology and/or pathology prior to HCT?

Indicate if the recipient had a liver biopsy performed, either for cytologic or histopathologic evaluation, prior to the start of the preparative regimen. If “yes,” submit a copy of the biopsy report using a Log of Appended Documents, Form 2800. Proceed with question 7.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)