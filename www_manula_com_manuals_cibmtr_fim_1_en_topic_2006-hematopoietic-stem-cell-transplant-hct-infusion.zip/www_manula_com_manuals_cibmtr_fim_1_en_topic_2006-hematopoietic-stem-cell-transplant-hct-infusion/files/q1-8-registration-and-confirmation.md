#### Question 1: The recipient should be enrolled on the following study:

Select the study the recipient should be enrolled to.

- CMS Sickle Cell Disease (SCD) Cell and Gene Therapy (CGT) Access Model

- Multiple myeloma (17-CMS-MM)
- Myelofibrosis (16-CMS-MF)
- Sickle cell disease (17-CMS-SCD)

For more information on the Medicare studies, click here [https://cibmtr.org/CIBMTR/Studies/Research-Programs/Clinical-Trials-Support/Medicare-Clinical-Trials](https://cibmtr.org/CIBMTR/Studies/Research-Programs/Clinical-Trials-Support/Medicare-Clinical-Trials)

#### Question 2: Has the recipient signed an IRB / Ethics Committee-approved consent form for participation in the study?

Indicate if the recipient signed an IRB-approved consent form to participate in one of the CMS-approved clinical studies. If **Yes ( recipient consented)**, continue with

*Date form signed*. If

**No (**, continue with

*recipient declined*)*Does the recipient have Medicare coverage*.

#### Question 3: Date form was signed:

Report the date the consent form was signed by the recipient. Do not report the date that the witness or health care professional signed the consent form.

#### Question 4: Does the recipient have Medicare coverage?

Indicate if the recipient has Medicare coverage.

#### Question 5: Does the recipient have Medicaid coverage?

Indicate if the recipient has Medicaid coverage.

#### Question 6: Medicaid issuing state/territory:

Indicate the state that issued the Medicaid. This can be found in the Insurance Face Sheet in Epic. If the state is unknown, leave the question blank.

#### Question 7: State Medicaid Beneficiary ID:

Medicaid beneficiary ID can be found in the Insurance Face Sheet in Epic. The ID may be listed as “subscriber number”. If the beneficiary ID is unknown, leave the question blank.

#### Question 8: Medicaid ID date issued:

Report the date the Medicate ID was issued. This can be found in the Insurance Face Sheet in Epic. If the date issued is unknown, leave the question blank.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)