The Veno-occlusive Disease (VOD) / Sinusoidal Obstruction Syndrome (SOS) Form, Form 2553, must be completed when VOD / SOS has been reported to have developed on the 100 Day Post-HCT Data Form (F2100) or the 100 Day Post-TED Form (Form 2450). Additionally, a Six Month VOD/SOS Form will come due if the center has reported VOD/SOS did not resolve during the 100 day reporting period (question 124). This form captures laboratory and pathologic studies at the time of diagnosis, treatment administered during the reporting period, and the maximum severity of VOD / SOS during the reporting period.

[Q1-28: Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-28-diagnosis)

[Q29-42: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q29-42-laboratory-studies-at-diagnosis)

[Q43-98: Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q43-98-therapy)

[Q99-112: Maximum Severity](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q99-112-maximum-severity)

[Q113-145: VOD / SOS Status](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q113-123-current-status)

[Q146-153: Management of Late Sequelae](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q146-153-management-of-late-sequelae)

[Q154-163: Hospital Stay](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q154-163-hospital-stay)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/7/2020 | 2553: VOD/SOS | Add | Added reporting guidance for scenario when drugs given for liver prophylaxis (red information box). |
| 5/7/2018 | 2553: VOD/SOS | Add | Added an example on how to report the planned total daily dose for Defibrotide |
| 5/24/17 | 2553: VOD/SOS | Add | Updated the description of the VOD / SOS Form on the title page by adding the text in red below:The Veno-occlusive Disease (VOD) / Sinusoidal Obstruction Syndrome (SOS) Form, Form 2553, must be completed when VOD / SOS has been reported to have developed on the 100 Day Post-HCT Data Form (F2100) or the 100 Day Post-TED Form (Form 2450). Additionally, a Six Month VOD/SOS Form will come due if the center has reported VOD/SOS did not resolve during the 100 day reporting period (question 124). This form captures laboratory and pathologic studies at the time of diagnosis, treatment administered during the reporting period, and the maximum severity of VOD / SOS during the reporting period. |
| 7/26/16 | 2553: VOD/SOS | Add | Version 1 Released |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)