#### Question 255: Did the recipient have evidence of pulmonary hypertension at HCT?

Pulmonary hypertension (PH) refers to elevated pulmonary arterial pressure. PH can be due to a primary elevation of pressure in the pulmonary arterial system alone (pulmonary arterial hypertension), or secondary to elevations of pressure in the pulmonary venous and pulmonary capillary systems (pulmonary venous hypertension; post-capillary PH).

Indicate “yes” if the recipient has evidence of PH at the time of HCT or “no” if they did not. If documentation is not clear or is not available to determine if PH was present, select “unknown.”

#### Question 256: Did the recipient have evidence of portal hypertension at HCT?

Portal hypertension is high blood pressure in the hepatic portal system, which includes the portal vein and its branches. The hepatic portal system drains most of the intestines to the liver.

Indicate “yes” if the recipient has evidence of portal hypertension at the time of HCT or “no” if they did not. If documentation is not clear or is not available to determine if portal hypertension was present, select “unknown.”

#### Question 257: Iron overload

Indicate “yes” if the recipient has documented iron overload at the last evaluation and continue with question 258. Indicate “no” if the recipient doesn’t have documented iron overload and submit the form.

#### Question 258-259: Indicate how the iron overload diagnosis was made (check all that apply):

Iron overload can be detected by several methods such as: Serum ferritin level or liver MRI. Indicate the method(s) the iron overload diagnosis was made. If the iron overload diagnosis was made by a method which is not listed, select “Other method” and specify the method of diagnosis in question 259.

**Serum ferritin**: Ferritin is a blood protein that contains iron. A ferritin level indicates how much iron a person’s body is storing. If the ferritin level is lower than normal, it indicates the body’s iron stores are low (iron deficiency). If the ferritin level is higher than normal it could indicate hemochromatosis, a condition that causes the body to store too much iron. Other causes of an elevated ferritin level include liver disease, acute and chronic inflammatory conditions, malignancy to name a few.

**Liver MRI**: Iron overload can be detected in a liver MRI by presence of an abnormal accumulation of iron in hepatocytes, Kupffer cells, or both.

**T2*MRI**: Iron overload can be detected by T2 imaging by presence of reduced signal intensity (compared to the non iron-overloaded case) in the liver.

**SQUID MRI**: A SQUID MRI is a magnetic detector in which can measure the magnetic properties of liver can quantify liver iron.

**Liver biopsy**: Detection and quantification of liver iron can be assessed by a liver biopsy. A sample is sent and tested for the presence of iron.

**FerriScan**: A FerriScan provides measurements of liver iron concentration (LIC) through a non-invasive, MRI-based technology.

**Other method**: Indicate if another method was used to make the diagnosis of iron overload and indicate the method in question 259.

#### Question 260: Iron chelation therapy

Iron chelation therapy is the removal of excess iron from the body using drugs such as deferoxamine.

Indicate “yes” if iron chelation therapy was given for iron overload or “no” if it was not.

#### Question 261: Phlebotomy

Phlebotomy is procedure in which removes the blood from the body with the goal of reducing iron overload.

Indicate “yes” if phlebotomy was given for iron overload or “no” if it was not.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)