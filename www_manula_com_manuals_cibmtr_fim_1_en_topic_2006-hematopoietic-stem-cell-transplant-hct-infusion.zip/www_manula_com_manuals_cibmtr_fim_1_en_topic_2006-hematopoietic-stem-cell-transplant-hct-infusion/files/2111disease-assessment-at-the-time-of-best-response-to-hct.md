#### Question 1: What was the best response to HCT or cellular therapy since the date of the last report? (Include response to any therapy given for post-HCT / post-infusion maintenance or consolidation, but exclude any therapy given for relapsed, persistent or progressive disease.)

The intent of this question is to determine the best overall response to HCT or cellular therapy. This is assessed in each reporting period. For any recipients in complete remission (CR) or complete remission with incomplete hematologic recovery (CRi) at the time of infusion, report “Continued Complete Remission” for question 1 and go to question 35.

When evaluating the best response, determine the disease status within the reporting period using the international working group criteria provided in the in [ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria) section of the Forms Instructions Manual. Compare this response to all previous post-infusion reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status. See question 2 to indicate that this disease status was previously reported.

Include response to any post-infusion treatment planned as of Day 0. If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR or as preemptive therapy for recipients with minimal residual disease, consider this “planned therapy,” even if this was not documented prior to the transplant. *Do not include response any treatment for relapse, progression, or persistent disease*. If a recipient started treatment for relapse, progression, or persistent disease, report the best response prior to the initiation of treatment (even if this was confirmed in a prior reporting period).

For scenarios where this form is completed for both the cellular therapy track and the HCT track:

**Do not report a best response to the HCT on a disease form for the cellular therapy.** If recipient has received a cellular therapy then an HCT, and this form is being completed for the first cellular therapy infusion, then the best response achieved will be prior to the start of preparative regimen for the subsequent HCT (or prior to the HCT if no preparative regimen is given).

**Do not report a best response to the cellular therapy on a disease form for the HCT.** If recipient has received an HCT then a cellular therapy, and this form is being completed for the first HCT infusion, then the best response achieved will be prior to the start of systemic therapy for the subsequent cell therapy (or prior to the CT if no systemic therapy is given).

**Best Response to HCT Reporting Scenarios:**

**A.** A recipient in complete remission at the time of infusion has a disease relapse detected on their first bone marrow biopsy post-HCT. They do not achieve a sustained recovery of their absolute neutrophil count by day 100.

*100 Day Follow-Up Form:*

**Question 1:** Report “Continued complete remission.” This option should be used for all recipients in CR at the time of infusion regardless of post-infusion disease assessments.

**B.** A recipient in primary induction failure at the time of infusion achieves a CRi on 6/1/2016. Their platelets are persistently low through their day 100 contact date (6/15/2016); however, they do rise / remain above 100 × 109/L beginning 6/30/2016 at which time the recipient’s disease status was CR.

*100 Day Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “No.” The date of best response has not been previously reported. Never report “Yes” for question 2 on the day 100 follow-up form.

**Question 3:** Report 6/1/2016 as indicated in the report scenario.

*Six Month Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “Yes.” The date of best response was previously reported on the 100 day follow-up form.

**Question 3:** Leave blank. This question will not be answered when question 2 has been answered “Yes.”

**C.** A recipient in primary induction failure at the time of infusion achieves a CR during the 100 day reporting period on 5/1/2014. The recipient has a disease relapse during the 6 month reporting period and their disease status remains “Relapse” on the 6 month date of contact despite multiple treatments.

*100 Day Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “No.” The date of best response has not been previously reported. Never report “Yes” for question 2 on the day 100 follow-up form.

**Question 3:** Report 5/1/2014 as indicated in the report scenario.

*Six Month Follow-Up Form:*

**Question 1:** Report “Complete Remission.” Use this option to indicate CR or CRi was achieved post-infusion for recipients not in CR / CRi at the time of infusion.

**Question 2:** Report “Yes.” The date of best response was previously reported on the 100 day follow-up form.

**Question 3:** Leave blank. This question will not be answered when question 2 has been answered “Yes.”

*Note, once a CR / CRi is achieved post-infusion, the best response will always be reported as CR for question 1. Changes to disease status after CR / CRi is achieved are not reported in question 1.*

*For scenarios where this form is completed for both the cellular therapy track and the HCT track*:


**Do not report a best response to the HCT on a disease form for the cellular therapy.**If recipient has received a cellular therapy then an HCT, and this form is being completed for the first cellular therapy infusion, then the best response achieved will be prior to the start of preparative regimen for the subsequent HCT (or prior to the HCT if no preparative regimen is given).**Do not report a best response to the cellular therapy on a disease form for the HCT.**If recipient has received an HCT then a cellular therapy, and this form is being completed for the first HCT infusion, then the best response achieved will be prior to the start of systemic therapy for the subsequent cell therapy (or prior to the CT if no systemic therapy is given).

#### Question 2: Was the date of best response previously reported?

If the best response to HCT / cellular therapy was first documented during the current reporting period, report “no” and go to question 3. If the best response was achieved during a previous reporting period (and therefore reported on a previous ALL Post-Infusion Data Form), report “Yes” and go to question 35.

Do not report “Yes” if completing this form for the 100 day reporting period.

#### Question 3: Date assessed

Report the date the best response to HCT / cellular therapy was established. This should be the earliest date when all international working group criteria for the response reported in question 1 were met. Report the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear). If no pathologic, radiographic, or laboratory assessments were performed to establish the best response, report the office visit in which the physician clinically evaluated the response.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms.](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms)

## Disease Assessments at Time of Best Response

For reporting purposes, the definition of “at the time of best response” depends on the reporting period. See Disease Assessment Time Windows below. Only consider assessments with samples collected within the time window which corresponds to the follow-up form being completed. If assessments were performed during the reporting period, but the samples were not collected within the indicated time window, consider them “Not done” when completing questions 4-34.

#### Table 1. Disease Assessment Time Windows

| Follow-Up Form | Approximate Time Window |
|---|---|
| 100 Day | + / – 15 days of date of best response (Question 3) |
| 6 Month | + / – 15 days of date of best response (Question 3) |
| Annual | + / – 30 days of date of best response (Question 3) |

#### Question 4: Were tests for molecular markers performed (e.g. PCR, NGS)?

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If testing for molecular markers was performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)), report “Yes” and go to question 5.

If molecular marker testing was not performed at the time of best response or it is unknown if testing was done, report “No” or “Unknown” respectively and go to question 9.

#### Question 5-8: Specify results

For each molecular marker in questions 5-8, report whether testing was “Positive,” “Negative,” or “Not done.” If tests identified a molecular marker other than those listed in questions 5-6, report the result in question 7 and specify the marker in question 8.

If multiple “Other molecular marker[s]” were tested at the time of best response, report one instance (i.e., copy) of question 7-8 for each “Other molecular marker” tested. If greater than 3 “Other molecular marker[s]” were tested, do the following:


- report one instance of question 7-8; and
- report “Positive” if any of the “Other molecular marker[s]” were positive, otherwise, report “Negative;” and
- report “see attachment” in question 8; and
- attach any / all reports documenting the results of testing for “Other molecular marker[s].”

#### Question 9: Was the disease status assessed via flow cytometry?

Flow cytometry (immunophenotyping) is a technique that can be performed on blood, bone marrow, or tissue preparations where cell surface markers can be detected on cellular material. Only testing performed on the blood or bone marrow may be reported in questions 10-17.

If flow cytometry was performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)), report “Yes” and go to question 10.

If flow cytometry was not performed at the time of best response, report “no” and go to question 18.

#### Question 10-13: Flow cytometry testing on blood

Indicate whether flow cytometry was performed on peripheral blood at the time of best response (refer to [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)). If “Yes,” report the date the sample was collected and whether disease was detected in questions 11 and 12 respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 13. Otherwise, go to question 14.

If flow cytometry was not performed on the blood at the time of best response, report “No” for question 10 and go to question 14.

#### Question 14-17: Flow cytometry testing on bone marrow

Indicate whether flow cytometry was performed on bone marrow at the time of best response. If “Yes,” report the date the sample was collected and whether disease was detected in questions 15 and 16 respectively. If disease was detected, report the percent disease detected (i.e., percent leukemic blasts) in question 17. Otherwise, go to question 18.

If flow cytometry was not performed on the bone marrow at the time of best response, report “No” for question 14 and go to question 18.

#### Question 18: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of a known chromosomal abnormality which reflects the recipient’s disease. Testing methods you may see include conventional chromosome analysis (karyotyping) or fluorescence *in situ* hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism. Additionally, the FISH probe panel should reflect the patient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

If cytogenetic (karyotyping or FISH) studies were obtained at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)), report “Yes” and go to question 19.

If cytogenetic studies were attempted at the time of best response, but there were not adequate cells (metaphases), report “No,” and go to question 30.

If no cytogenetic studies were obtained at the time of best response, indicate “No” and go to question 30.

If it is not known whether any cytogenetic studies were obtained at the time of best response, indicate “Unknown” and go to question 30.

#### Question 19-20: Were cytogenetics tested via FISH?

If FISH studies were performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)), report “Yes” for question 19 and indicate whether clonal abnormalities were detected in question 20. If FISH studies were not performed, report “No” for question 19 and go to question 24. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Question 21-23: Specify cytogenetic abnormalities (FISH)

Report the number of abnormalities detected by FISH at the time of best response in question 21. After indicating the number of abnormalities in question 21, select all abnormalities detected in questions 22-23.

If a clonal abnormality is detected, but not listed as an option in question 22, select “Other abnormality” and specify the abnormality in question 23. If multiple “Other abnormalities” were detected, report “see attachment” in question 23 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 24-25: Were cytogenetics tested via karyotyping?

If karyotyping was performed at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)), report “Yes” for question 24 and indicate whether clonal abnormalities were detected in question 32. If karyotyping was not performed, indicate “No” and go to question 29. Examples of this include: karyotyping was not performed or karyotyping sample was inadequate.

#### Question 26-28: Specify cytogenetic abnormalities (karyotyping)

Report the number of abnormalities detected by karyotyping at the time of best response in question. After indicating the number of abnormalities in question 26, select all abnormalities detected in questions 27-28.

If a clonal abnormality is detected, but not listed as an option in question 27, select “Other abnormality” and specify the abnormality in question 28. If multiple “Other abnormalities” were detected, report “see attachment” in question 28 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 29: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported in questions 18-28. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 30-34: Was the disease status assessed by other assessment?

Indicate whether ALL was assessed by any method other than those included in questions 4-29 at the time of best response (see [Table 1](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#table)). If “Yes,” report the date assessed and specify the type of assessment in questions 31 and 32 respectively. Also indicate whether the reported assessment detected disease (question 33) and, if so, whether this was considered a disease relapse (question 34). If the exact date of assessment is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If ALL was not assessed by any methods other than those included in questions 4-29, report “No” for question 30 and go to question 35.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)