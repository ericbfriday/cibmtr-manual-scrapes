The FormsNet3SM application allows questions 33-68 to be reported multiple times. Complete these questions for each line of therapy administered on or after the date of diagnosis of AML and prior to the start of the preparative regimen (or prior to infusion if no preparative regimen was given). When submitting the paper version of the form for more than one line of therapy, copy the “Pre-HCT or Pre-Infusion Therapy” section and complete a copy of the section for each line of therapy administered.

A single line of therapy refers to any agents administered during the same time period with the same intent (induction, consolidation, etc.). If a recipient’s disease status changes resulting in a change to treatment, a new line of therapy should be reported. Additionally, if therapy is changed because a favorable disease response was not achieved, a new line of therapy should be reported.

#### Question 32: Was therapy given?

Indicate if the recipient received treatment for their primary disease between diagnosis and the start of the preparative regimen. This includes systemic chemotherapy, intrathecal therapy, radiation therapy, and cellular therapies. Do not report a prior HCT or any surgery in questions 32-68. If therapy was given to treat AML during the time frame indicated above, report “Yes” and go to question 33. If reporting “No” or “Unknown,” go to question 69.

#### Question 33: Purpose of therapy

The purpose of each line of therapy depends on the disease status at the time of administration. See below for general definitions of each option choice. Indicate the purpose of the line of therapy being reported and go to question 34.

**Induction:** The first line(s) of therapy given following diagnosis to achieve a complete remission (CR). If the first line of therapy (induction) fails to produce a CR, the recipient may undergo another cycle or a different line of therapy (re-induction) in order to achieve their first CR. Report “Induction” as the purpose for all lines of therapy given to achieve the first CR.

**Consolidation:** Once a recipient has achieved a hematologic CR (1st, 2nd, 3rd or greater), they may receive several additional lines of therapy as part of a protocol or to eliminate known minimal residual disease. In either case, report “Consolidation” as the purpose for these lines of therapy.

**Maintenance:** Following induction and consolidation, a recipient may receive low dose chemotherapy over an extended period of time to maintain a CR. Maintenance therapy is usually given as a single drug taken in the outpatient setting when the recipient has no known evidence of disease. Report “Maintenance” as the purpose for these lines of therapy.

**Treatment for disease relapse:** Once the recipient has achieved their first CR, their disease may relapse and require further treatment to produce another CR (2nd or greater). The intent is the same as induction, but setting is different as the recipient has already achieved at least one prior CR. Report “Treatment for disease relapse” as the purpose for all lines of therapy given to induce a CR following relapse.

#### Question 34: Intrathecal Therapy

Intrathecal therapy refers to chemotherapy administered via lumbar puncture to treat or prevent leukemic blasts in the central nervous system. Report “Yes” if intrathecal therapy was given as part of the line of therapy being reported. Report “No” if intrathecal therapy was not given as part of the line of therapy being reported.

#### Question 35: Systemic therapy

Systemic therapy is delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein / central line or given orally. Do not report intrathecal therapy as systemic therapy. If systemic therapy was administered as part of the line of therapy being reported, report “Yes” and continue with question 36. If not, report “No” and go to question 47.

#### Question 36-37: Date therapy started

Indicate whether the therapy start date is “Known” or “Unknown.” If the therapy start date is known, report the date the recipient began this line of therapy in question 37. If the start date is partially known (e.g., the recipient started in mid-July 2010), use the process for reporting partial or unknown dates as described in the General Instructions, Guidelines for Completing Forms.

If the date therapy started is “Unknown,” go to question 38.

#### Question 38-39: Date therapy stopped

Indicate if therapy stop date is “Known” or “Unknown.” If the therapy is being given in cycles, report the date the recipient started the last cycle for this line of therapy in question 39. Otherwise, report the final administration date for the therapy being reported. If the stop date is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, Guidelines for Completing Forms.

If the date therapy stopped is “Unknown,” go to question 40.

#### Question 40-41: Number of cycles

Systemic therapy is usually administered in cycles with rest periods in-between. This enables cancer cells to be attacked at vulnerable times and provides healthy cells adequate time to recover from the damage sustained during therapy. A cycle can last one or more days and can repeat weekly, bi-weekly, or monthly. A single systemic therapy course may consist of multiple cycles.

Indicate whether the number of cycles is “Known” or “Unknown.” If “Known,” enter the number of cycles the recipient received in question 41. If “Unknown,” go to question 42.

If therapy is not being administered in cycles (e.g., daily chemotherapy), report “Not Applicable” for question 40 and go to question 42.

#### Question 42: Specify therapy given

Treatments vary based on protocol. A treatment may consist of a single drug or a combination of drugs. Additionally, the drugs may be administered on one day, over consecutive days, or continuously. Select all chemotherapy drugs administered as part of the line of therapy being reported. If the recipient received a systemic therapy which is not listed, select “Other systemic therapy” and specify the treatment in question 46. Report the generic name of the agent, not the name brand.

#### Question 43-45: Specify months of therapy

Azacytidine, decitabine, and sorafenib may be given daily rather than in cycles. In order to capture the duration for which these medications are given, centers are asked to report the number of months these drugs were given whenever they have been reported in question 42. If therapy is given greater than a whole month, use the general rules of rounding. (i.e., A recipient receives sorafenib twice a day for 13 weeks – specify the months of therapy as “3.”)

Question 43 will only be answered if azacytadine has been reported. Question 44 will only be answered if decitabine has been reported. Question 45 will only be answered if sorafenib has been reported. If more than one of these drugs was reported as part of a single line of therapy, ensure questions 43-45 are completed for the correct drug.

#### Question 46: Specify other systemic therapy

If “Other systemic therapy” has been selected in question 42, question 46 must be answered. Complete question 46 by reporting any / all chemotherapy drugs which were given as part of the line of therapy being reported and have not been selected in question 42.

#### Question 47: Radiation therapy

Radiation therapy utilizes high-energy x-rays, gamma rays, electron beams, or proton beams to kill cancer cells. Radiation therapy may be used to kill cells that have invaded other tissues and lymph nodes. Radiation therapy may be given in conjunction with systemic chemotherapy or as a separate line of therapy.

If radiation therapy was given during or adjacent to administration of systemic therapy, report them together as single line of therapy on the form (i.e., one copy of questions 33-68). Otherwise, capture the radiation treatment as a separate line of therapy.

If the recipient received radiation therapy as part of the line of therapy being reported, report “Yes” and go to question 48. If not, report “No” and go to question 55.

#### Question 48-49: Date therapy started

Indicate whether the start date for radiation therapy is “Known” or “Unknown.” If “Known,” enter the date radiation therapy began in question 49. If the start date is partially known (e.g., the recipient started in mid-July 2010), use the process for reporting partial or unknown dates as described in the General Instructions, Guidelines for Completing Forms.

#### Question 50-51: Date therapy stopped

Indicate if the stop date for radiation therapy is “Known” or “Unknown.” If “Known,” enter the final date radiation was administered in question 50. If the stop date is partially known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms.

#### Question 52-54: Specify site(s) of radiation therapy

Report all sites of radiation therapy administered between the start and stop dates reported in questions 48-51. If “Yes” is reported for “Other site,” specify all other sites in question 54.

#### Question 55: Cellular Therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells).

Report “Yes” if the recipient received cellular therapy as part of the line of therapy being reported. If not, report “No.”

#### Question 56: Best response to line of therapy

Indicate the best response to the line of therapy using the international working group criteria provided in AML Response Criteria section of the Forms Instructions Manual. The best response is determined by a disease assessment, such as hematologic testing, pathology study, and / or physician assessment.

#### Question 57: Date assessed

Report the date the best response to the line of therapy was established. This should be the earliest date all international working group criteria were met for the response reported in question 56. Enter the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear). If no pathologic, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically evaluated the recipient’s response.

If the best response was achieved prior to starting the line of therapy being reported, indicate the date of the first assessment which was performed after initiating the current line of therapy and confirms the sustained response.

If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms.

#### Question 58: Was the recipient MRD negative following this line of therapy?

Minimal residual disease (MRD) can be assessed by different methods including, but not limited to, the following:


- Next generation sequencing
- Sanger sequencing
- Polymerase chain reaction (PCR) testing
- Chromosomal / genomic microarray analysis
- Fluorescence in situ hybridization (FISH)
- Karyotyping
- Flow cytometry

If any MRD testing was performed following the line of therapy being reported, answer question 58 based on the results of the testing performed within 30 days after the date therapy was stopped and prior to any new therapy being initiated. If any MRD testing during this timeframe was positive for markers of AML, report “No” for question 58. If all MRD testing during this time frame was negative for markers of AML, report “Yes” for question 58. If the recipient was MRD negative prior to therapy completion and not retested after therapy ended, report “Yes” for question 58.

If no MRD testing was performed during this timeframe, leave question 58 blank and override the error in FormsNetSM using the code “Unknown.”

#### Question 59: Did the recipient relapse following this line of therapy?

Refer to the international working group criteria provided in AML Response Criteria section of the Forms Instructions Manual for more information on how to determine recurrence of disease. Report “Yes” if the recipient met the criteria for relapse after starting this line of therapy and prior to starting a subsequent line of therapy. If “Yes” is reported, also completed questions 60-68.

Report “No” if the recipient never relapsed following this line of therapy. Also, report “No” if the recipient relapsed after beginning a subsequent line of therapy. This episode of relapse will be captured in the instance (i.e., copy) of questions 33-68 completed for the subsequent line of therapy. If “No” is reported, go to question 69.

If this is the last line of therapy administered prior to infusion, only report “Yes” if relapse occurred prior to infusion. Relapse occurring after the infusion date will be reported on the AML Post-Infusion Data Form (Form 2110).

#### Question 60: Date of relapse

Enter the assessment date relapse was established following initiation of this line of therapy. Report the date of the pathologic evaluation (e.g., bone marrow) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathologic and laboratory evaluations. If extranodal disease is detected upon radiographic examination (e.g., X-rays, CT scans, MRI scans, PET scans), enter the date the imaging took place. If the physician determines evidence of relapse following a clinical assessment during an office visit, report the date of assessment.

If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms.

#### Question 61-68: Sites of Relapse

Report all known sites of active disease at the time of relapse in questions 61-68. This includes any sites identified between the date of relapse reported in question 60 and the time treatment for relapse is initiated. If “Yes” has been reported for “Other site” in question 67, use question 68 to specify all sites of active disease not already reported in questions 61-66. If relapse was detected in the bone marrow and / or peripheral blood, report “Yes” for question 67 and specify these sites in question 68.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q55 | 6/28/2023 | Add | The Reporting Prior Cellular Therapy as a Line of Therapy blue information box added: As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form |
Due to change in FormsNet3 validation |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)