Aplastic Anemia is a disease in which the bone marrow does not produce enough red blood cells, white blood cells, or platelets for the body. The disease can be idiopathic, or can be caused by environmental exposure, pharmaceutical or drug exposure, or exposure to viral hepatitis. Symptoms of aplastic anemia include, but are not limited to pallor, weakness, frequent infection, and/or easy bruising.

[2028: Aplastic Anemia Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2028-aplastic-anemia-pre-hct)

[2128: Aplastic Anemia Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2128-aplastiv-anemia-post-hct)

Last modified:
Mar 02, 2015

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)