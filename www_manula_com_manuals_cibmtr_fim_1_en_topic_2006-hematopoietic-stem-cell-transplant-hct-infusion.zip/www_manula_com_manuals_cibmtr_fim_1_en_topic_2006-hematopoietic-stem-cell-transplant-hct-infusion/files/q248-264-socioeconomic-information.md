#### Question 104: Is the recipient an adult (18 years of age of older) or emancipated minor?

Indicate if the recipient is 18 years of age or older, or if under 18, has been declared an emancipated minor by law. An emancipated minor is a child who has been granted the status of adulthood by a court order or other formal arrangement.

If “yes,” continue with question 105. If “no,” continue with question 106.

#### Question 105: Specify the recipient’s marital status:

Report the recipient’s marital status as of the date of HCT. If the recipient is in a same-sex partnership, but they are not legally married in their state, report “married or living with a partner.”

#### Questions 106-107: Specify the category which best describes the recipient’s current occupation: (if the recipient is not currently employed, check the box which best describes his/her last job.)

Report the recipient’s occupation category prior to illness.

If the recipient is unemployed, select the option that best describes his/her most recent job.

If the recipient is “under school age,” select this option, and continue with question 109.

The “other” category should only be used if the recipient’s occupation does not fit into one of the broad occupation categories listed. Please review the text associated with each answer to ensure that the occupation is being reported within the correct category. One common oversight is the reporting of “other” when the recipient’s occupation actually fits best in the “Professional, technical, or related occupation” category.

#### Question 108: What is the recipient’s most recent work status? (Within the last year)

Report the recipient’s most recent work status within the last year. This refers to the employment status at the time in which they were no longer able to work due to the illness or due to preparation for their transplant. If the recipient is on medical leave other than medical disability (such as short-term or long-term medical leave), report their employment status prior to the start of their leave. If they are on medical disability, select “medical disability.”

**Example 1:** Patient was diagnosed with AML and had been working a full-time job. The patient was on a medical leave as the AML treatment prevented them from returning to work prior to the HCT. The correct option to choose would be “Full time.”

**Example 2:** Patient was diagnosed with Multiple Myeloma and had been working a full-time job. Due to treatment related side effects, the patient had to reduce their hours and only work part-time. The correct option to choose would be “Part time, due to illness” & not “Full time”. Full time would not be chosen because the most recent status of their employment was part time. Full time would have been chosen had the recipient stopped working and was on a medical leave from their employer due to their illness.

**Example 3:** Patient was diagnosed with Non-Hodgkin’s Lymphoma and worked part time during her treatment. Following initial therapy, the recipient began working full time. After the recipient’s retirement, her annual scan showed relapse, treatment began again and the recipient proceeded to transplant. “Retired” would be reported on the form.

If the recipient’s occupation was reported as “student” in question 106, specify “full time,” “part time,” or “unknown” in question 108.

#### Question 109: What is the highest educational grade the recipient completed?

Report the recipient’s highest completed educational level as of the date of HCT. If the recipient is a student who is currently in the middle of a school year, indicate the previous education level completed.

#### Question 110: Is the recipient currently in school, or was enrolled prior to illness?

Indicate if the recipient is a current student, or was a student prior to illness.

#### Question 111: Is the recipient covered by health insurance?

Indicate if the recipient has health insurance.

If “yes,” continue with question 112. If “no,” continue with question 115.

#### Questions 112-114: Specify type of health insurance (check all that apply)

Report the recipient’s source of health insurance as of the date of HCT. If the recipient carries more than one source, check for all that apply. If the recipient has a government health insurance that is not listed, select “Other government program” and specify the government health insurance program in question 113. If the recipient has a health insurance that is not listed, select “Other health insurance coverage” and specify the health insurance in question 114.

#### Question 115: Specify the recipient’s combined household gross annual income: (include earnings by all family members living in the household, before taxes.) (For U.S. residents only)

Indicate the sum of the before-tax annual incomes for all family members living in the recipient’s household. If the recipient decides not to provide this information, select “recipient declines to provide this information.” If annual income is only known for some of the income earners in the house or if it is not known what the household’s gross annual income is, select “unknown.”

#### Question 116: Number of people living in the household

Specify the total number of people who are living in the recipient’s household. Include those who are both older and younger than the age of 18.

#### Question 117: Number of people living in the household under the age of 18

Specify the number of people who are under the age of 18 living in the recipient’s household.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q115 | 7/28/2023 | Add | Red warning box added above Q115 to clarify question is now disabled: Specify the recipient’s combined household gross annual income is disabled. This question will be updated with the next revision of the Recipient Baseline (2000) Form. |
Due to Summer 2023 Quarterly Release |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)