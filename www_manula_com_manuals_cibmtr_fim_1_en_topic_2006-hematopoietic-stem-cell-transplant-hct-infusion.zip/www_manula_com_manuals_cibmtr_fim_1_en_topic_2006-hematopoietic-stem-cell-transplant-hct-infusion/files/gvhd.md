This section is intended to provide general information about reporting GVHD.

[General Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-information)[Acute GVHD](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/acute-gvhd)[Chronic GVHD](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/chronic-gvhd)- GVHD Reporting Examples and Scenarios
- GVHD Treatment

Manual Updates

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspxwebpage).

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 7/26/2024 |
|

Last modified:
Jul 29, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)