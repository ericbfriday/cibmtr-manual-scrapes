#### Karnofsky/Lansky Performance Status

The CIBMTR uses Karnofsky / Lansky performance status to determine the functional status of a recipient. Recipient performance status is a critical data field that has been determined to be essential for all outcome-based analyses. The Karnofsky Scale is designed for recipients aged 16 years and older, and the Lansky Scale is designed for recipients one year old to less than 16 years old. Use this scale (see table 1) to determine the score (10 – 100) that best represents the recipient’s activity status at the requested time point.

If a Karnofsky / Lansky score is not documented in the source documentation (e.g., inpatient progress note, physician’s clinic notes), data management professionals should not assign a performance score based on analysis of available documents. Rather, a physician or mid-level health care provider (NPs and PAs) should provide documentation of the performance score. Documentation from an RN who has been trained and authorized to determine performance scores may also be used.

**Table 1. Karnofsky/Lansky Scale**

| Karnofsky Scale (recipient age ≥ 16 years) | Lansky Scale (recipient age ≥ 1 year and <16 years) |
|---|---|
Able to carry on normal activity; no special care is needed |
Able to carry on normal activity; no special care is needed |
100 Normal, no complaints, no evidence of disease |
100 Fully active |
90 Able to carry on normal activity |
90 Minor restriction in physically strenuous play |
80 Normal activity with effort |
80 Restricted in strenuous play, tires more easily, otherwise active |
Unable to work, able to live at home, cares for most personal needs, a varying amount of assistance is needed |
Mild to moderate restriction |
70 Cares for self, unable to carry on normal activity or to do active work |
70 Both greater restrictions of, and less time spent in active play |
60 Requires occasional assistance but is able to care for most needs |
60 Ambulatory up to 50% of time, limited active play with assistance/supervision |
50 Requires considerable assistance and frequent medical care |
50 Considerable assistance required for any active play, fully able to engage in quiet play |
Unable to care for self, requires equivalent of institutional or hospital care, disease may be progressing rapidly |
Moderate to severe restriction |
40 Disabled, requires special care and assistance |
40 Able to initiate quite activities |
30 Severely disabled, hospitalization indicated, although death not imminent |
30 Needs considerable assistance for quiet activity |
20 Very sick, hospitalization necessary |
20 Limited to very passive activity initiated by others (e.g., TV) |
10 Moribund, fatal process progressing rapidly |
10 Completely disabled, not even passive play |

#### Karnofsky/Lansky Performance Score vs. ECOG performance score

The CIBMTR recognizes some centers prefer to collect and use the ECOG performance as opposed to the Karnofsky / Lansky score. Although the ECOG and Karnofsky / Lansky performance score systems are based on similar principles, the scales are not the same. For example, the Karnofsky / Lansky scale is described in 11 categories, whereas the ECOG performance status is reported in six categories. Due to the overlap between the two systems, an ECOG score of “one” can represent either “80” or “90” on the Karnofsky / Lansky scale.

For centers that collect only the ECOG performance score, CIBMTR will make the following accommodations when auditing the source data:


- Centers collecting ECOG scores should do so using standard practices to ensure accuracy.
- For the purposes of CIBMTR reporting, the conversion of ECOG to Karnofsky / Lansky should follow standard and consistent practice. This practice should be clear and reproducible.

To convert the ECOG to Karnofsky / Lansky and for more information regarding the conversion, see the memorandum and worksheet example found in [Appendix L](https://cibmtr.org/Files/Data-Operations/Retired-Forms-Manuals/Appendices/appendix-l.pdf) of the ‘Appendices’ section of the Retired Forms Manuals webpage.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

To reference the historical Manual Change History for this form, review the table below or reference the retired manual section on the [Retired Forms Manuals](https://cibmtr.org/CIBMTR/Data-Operations/Manuals-Guides/Retired-Forms-Manuals) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)