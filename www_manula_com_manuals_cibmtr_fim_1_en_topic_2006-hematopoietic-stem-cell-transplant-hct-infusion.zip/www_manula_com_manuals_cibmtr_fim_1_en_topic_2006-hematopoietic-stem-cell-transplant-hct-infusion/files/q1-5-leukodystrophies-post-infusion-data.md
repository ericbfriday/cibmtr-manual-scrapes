#### Question 1: For which type of leukodystrophy was the infusion performed

Indicate the recipient’s disease subtype:

**Krabbe Disease (globoid cell leukodystrophy)**: A rare lysosomal storage disorder affecting the nervous system, most typically occurring in infants.**Metachromatic leukodystrophy (MLD)**: A rare genetic disorder in which there is an accumulation of sulfatides, causing damage to the myelin sheath within the nervous system. The three types of MLD are based on age symptoms occur: late-infantile MLD, juvenile MLD, and adult MLD.**Adrenoleukodystrophy (ALD)**: A rare genetic disorder causing buildup of very long-chain fatty acids (VLCFAs) and in response, damages myelin sheath within the nervous system. The most common form of ALD is X-linked ALD, more commonly affecting males.**Hereditary diffuse leukoencephalopathy with spheroids (HDLS)**: A rare hereditary disorder affecting adults. The disease is associated with leukoencephalopathy and spheroids in the axons of the brain.

**Enzyme activity / enzyme substrate – recipient**

#### Questions 2 – 3: Was enzyme activity and/or enzyme substrate tested

Indicate if the recipient’s enzyme activity and / or enzyme substrate was tested during the current reporting period. The type of testing performed is specific to leukodystrophy subtype. Types of testing can include enzyme assays, urine testing, etc. An example of enzyme activity testing is the quantitative measurement of arylsulfatase A enzyme.

If enzyme activity / enzyme substrate was tested on the recipient select **Yes** and report the date (YYYY-MM-DD) of testing. If testing is performed multiple times in the reporting period, report the most recent date and results.

If the exact date is not known, use the process described in General Instructions, [Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

If enzyme activity / enzyme substrate was not tested for the recipient within the reporting period or it is unknown, select **No** or **Unknown**, respectively and continue with *Was the total neurologic function scale (NFS) score obtained*.

#### Questions 4 – 5: Recipient result

Indicate whether the results of the recipient’s enzyme activity and / or enzyme substrate testing were **Normal** or **Abnormal**. Additionally, specify if documentation was submitted to CIBMTR (CIBMTR recommends attaching the enzyme / storage activity testing).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/ManualsGuides/Pages/default.aspx).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)