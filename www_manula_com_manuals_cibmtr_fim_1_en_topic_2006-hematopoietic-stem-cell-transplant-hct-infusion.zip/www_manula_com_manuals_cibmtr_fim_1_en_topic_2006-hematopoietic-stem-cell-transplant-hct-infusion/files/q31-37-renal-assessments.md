#### Questions 59 – 60: Urine albumin

Indicate whether urine albumin was measured in the current reporting period. If measured, select **Known** and report the laboratory value and unit of measure documented on the laboratory report. If urine albumin was assessed multiple times within the reporting period, report the most recent results. If urine albumin was not measured or if no information is available to determine if urine albumin was measured in the current reporting period, select **Unknown**.

If the urine albumin is < 30 mg / g, report the urine albumin value as “29 mg / g” (29,000 mg / kg).

#### Question 61: Serum creatinine *(if multiple, report the most recent tested)*

Report the laboratory value and unit of measurement as documented on the laboratory report in the current reporting period. If serum creatinine was measured multiple times in the reporting period, report the most recent results.

If serum creatinine was not measured in the current reporting period, leave the data field blank and override the FormsNet3SM error,

#### Questions 62 – 63: Glomerular filtration rate (GFR)

The glomerular filtration rate (GFR) estimates how much blood passes through the glomeruli each minute and is used to check how well the kidneys are working.

Indicate whether the GFR was measured in the current reporting period reporting period. If measured, select **Known** and report the laboratory value and unit of measure documented on the laboratory report. If the GFR was measured multiple times in the reporting period, report the most recent results. If the GFR was not measured or if no information is available to determine if the GFR was assessed in the current reporting period, select **Unknown**.

GFR may be reported to the CIBMTR as “actual” or “calculated.” If your center’s laboratory does not calculate the actual GFR value, the following equations may be used to determine the calculated value.

**Cockcroft-Gault Equation**

GFR = [(140 – age) x Wt] / (72 x Cr)

- GFR_cg = Glomerular Filtration Rate (Cockcroft) (mL / min)
- Age = Patient Age (years)
- Sex = Gender (Male)
- If female, multiply result by 0.85

- Wt = Body Weight (kg)
- Cr = Creatinine (S, mg / dL)

An online calculator for this equation can be found here: [https://www.kidney.org/professionals/kdoqi/gfr_calculatorCoc](https://www.kidney.org/professionals/kdoqi/gfr_calculatorCoc)

**Bedside Schwartz Equation**

eGFR = K x H / Cr

- H = Height (cm)
- Cr = Creatinine (S, mg / dL)
- K =
- 0.33 for preemies
- 0.45 for infants to 1 year
- 0.55 for 1 year to 18 years for females
- 0.55 for 1 year to 13 years for males
- 0.70 for adolescent to 18 years for males


An online calculator for this equation can be found here: [https://www.kidney.org/professionals/KDOQI/gfr_calculatorPed](https://www.kidney.org/professionals/KDOQI/gfr_calculatorPed)

If the laboratory report indicates the GFR as a range, report the average. Example, the laboratory report indicates GFR is 80 – 120, report “100.”

If the GFR value is expressed as “> X,” report the value as “X+1.” Example, the laboratory report indicates the GFR is > 120, report “121.”

If the GFR value is reported as “< X”, report “X-1.” Example, the laboratory report indicates the GFR is < 80, report “79.”

#### Question 64 – 65: Cystatin-C

Cystatin-C is a protein in the blood that can be used to evaluate kidney function. If measured, select **Known** and report the laboratory value . If testing was performed multiple times, report the most recent laboratory value obtained. If the cystatin-C was not measured or if no information is available to determine if the cystatin-C was assessed, report **Unknown**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)