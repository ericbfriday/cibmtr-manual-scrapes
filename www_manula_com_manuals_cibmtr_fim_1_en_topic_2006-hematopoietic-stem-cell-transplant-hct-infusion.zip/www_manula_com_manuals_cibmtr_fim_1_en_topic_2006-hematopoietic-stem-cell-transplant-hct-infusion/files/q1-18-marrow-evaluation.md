#### Question 1: Date of marrow aspirate and / or biopsy

Report the date of collection for the bone marrow aspirate and/or biopsy.

If the exact date is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 2: Were cytogenetics tested?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing, including karyotyping and FISH, and cytogenetic terminology, see [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

**Pre-infusion:**Indicate if cytogenetic testing was performed on the bone marrow evaluation date and same sample reported above (i.e., performed on the bone marrow biopsy / aspirated completed at the last evaluation prior to the start of the preparative regimen / infusion).**Post-infusion:**Indicate if cytogenetic testing was performed on the bone marrow evaluation date reported above (i.e., performed on the bone marrow biopsy / aspirate completed in the current reporting period)

#### Question 3: Were cytogenetics tested via FISH?

Indicate if FISH studies were performed at the applicable timepoint. If FISH was not performed, unknown if performed, or if FISH was performed but ‘failed’ or the sample was inadequate, report **No**.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c) for an overview of FISH assessments.

#### Question 4: Sample source

Specify if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used to test FISH at diagnosis, the preferred sample source is the bone marrow.

#### Questions 5 – 10: Results of tests

Specify if FISH testing performed identified any abnormalities. If **Abnormalities identified**, report the International System for Human Cytogenetic Nomenclatures (ISCN) compatible string, if applicable, or specify all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality(ies) *or* report ‘see attached report’ and attach the report(s). For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Question 11: Were cytogenetics tested via karyotyping?

Indicate if karyotyping was performed at the applicable timepoint. If karyotyping was not performed or unknown if performed, report **No**.

Refer to Appendix C: Cytogenetic Assessments for an overview of karyotyping assessments.

#### Question 12: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used for karyotyping assessments, the preferred sample source is the bone marrow.

#### Questions 13 – 18: Specify cytogenetic abnormalities (karyotyping)

Specify if karyotyping testing performed identified any abnormalities. If karyotyping was performed but ‘failed’ or the sample was inadequate, select **No evaluable metaphases**.

If **Abnormalities identified**, report the International System for Human Cytogenetic Nomenclatures (ISCN) compatible string, if applicable, or specify all abnormalities detected.

Additionally, if abnormalities were identified, specify the number of cytogenetic abnormalities.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality(ies) *or* report ‘see attached report’ and attach the report(s). For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)