Drugs may be given during the peri-transplant (before and after infusion) period to prevent transplant-related complications, such as liver injuries or to facilitate engraftment.

#### Questions 135 – 139: Drugs

For each agent listed, indicate whether the drug was administered during the peri-transplant period to prevent transplant-related complications or facilitate engraftment, and any additional question(s) for each drug administered.

**ALG (Anti-Lymphocyte Globulin), ALS (Anti-Lymphocyte Serum), ATG (Anti-Thymocyte Globulin, ATS (Anti-Thymocyte Serum)**: Serum or gamma globulin preparations containing polyclonal immunoglobulins directed against lymphocytes. These drugs are usually prepared from animals immunized against human lymphocytes. Report the total dose*prescribed*pre- and post-infusion and the animal source. If**Other**is selected, specify the source.**Alemtuzumab (Campath)**: Antibody preparations that are infused in the recipient. Report the total dose*prescribed*pre- and post-infusion to the nearest tenth and specify the units of measurement.**Defibrotide**: Antithrombotic agent used to prevent veno-occlusive disease.**KGF (keratinocyte growth factor)**: Alternate names: palifermin, Kepivance. KGF acts to stimulate the growth of cells that line the surface of the mouth and intestinal tract. KGF may also be given to treat oral mucositis or as GVHD prophylaxis.**Ursodiol**: A naturally occurring bile acid used to dissolve small gall stones and to increase bile flow in patients with primary biliary cirrhosis.

If the recipient did not receive any of the drugs listed above, leave these questions blank and override the error as ‘verified correct.’

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q135 – 139 | 10/18/2022 | Add | Clarification added on how to answer these questions when peri-transplant drugs were not given: If the recipient did not receive any of the drugs listed above, leave these questions blank and override the error as ‘verified correct.’ |
Added for clarification |
| Q135 – 139 | 5/1/2023 | Add | Peri-transplant time frame defined: Drugs may be given during the peri-transplant (before and after infusion). period to prevent transplant-related complications, such as liver injuries or to facilitate engraftment. For each agent listed, indicate whether the drug was administered during the peri-transplant period to prevent transplant-related complications or facilitate engraftment, and any additional question(s) for each drug administered.
|
Added for clarification |

Last modified:
May 01, 2023

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)