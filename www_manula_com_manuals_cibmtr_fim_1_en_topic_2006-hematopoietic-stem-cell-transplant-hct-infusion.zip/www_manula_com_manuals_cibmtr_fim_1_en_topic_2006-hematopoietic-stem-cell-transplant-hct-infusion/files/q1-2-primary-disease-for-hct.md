*****Disease Classification Questions**

The newest versions of the TED Forms use the World Health Organization (WHO) disease classifications. The Disease Classification questions contain all of the established WHO disease types and subtypes. The **Other disease** category should be used only if the recipient’s disease is not one of the listed options. For more information regarding disease classification, consult a transplant physician, contact the CIBMTR Customer Service Center, or visit the WHO website at: [http://www.who.int/classifications/icd/en/.](http://www.who.int/classifications/icd/en/)

Several of the Disease Classification questions ask for *“Status at Transplantation.”* Although there are many interpretations of disease response criteria, **when reporting data to the CIBMTR, use the guidelines in this manual to determine disease status**. A majority of the disease response criteria are established by an international working group. Citations of resources used to define disease responses are included where applicable.

If the recipient’s status is unclear, consult with the transplant physician for further information or contact the CIBMTR Customer Service Center.

*!***Subsequent HCT / Cellular Therapy**

For many diseases, the CIBMTR data collection forms capture disease assessments at multiple time points pre- and post-infusion. If the recipient is receiving a subsequent infusion for the same disease and they have had a previous infusion that was reported to the CIBMTR, only disease assessments performed after the previous infusion until the current infusion are required to be reported. If relapse / progression occurred following the previous infusion but prior to the Last Evaluation timepoint for the current infusion, report the relapse / progression assessments at the In Between timepoint. Some pre-infusion forms on the Case Report Form (CRF) track have different reporting rules, depending on if a pre-infusion CRF had been previously complete for the recipient. Carefully review the Disease-Specific CRF manuals for additional information.

*****Malignant vs. Non-Malignant**

Malignant diseases involve cells dividing without control that can spread to other parts of the body through blood and lymph systems. These diseases are usually characterized by unlimited, aggressive growth, invasion of surrounding tissues, and metastasis.

Non-malignant diseases involve cell overgrowth, but lack the malignant properties of cancer.

The CIBMTR database disease codes are represented in parentheses after the disease subtype on the Disease Classification questions and can be helpful in mapping diagnosis [e.g., Myeloid Sarcoma (295)], and determining if the disease is malignant or non-malignant. Disease codes (10-299) indicate a malignant disease, with the exception of Paroxysmal Nocturnal Hemoglobinuria (PNH) (56). A disease code of (300) or above indicates a non-malignant disease.

If the indication for infusion is due to a combination of diseases or a transformation of one disease to another, it may be necessary to report multiple disease classifications. The tables below list how common examples of disease combinations and transformations should be reported using the Disease Classification questions.

**Common Disease Combinations**

| Disease Combinations |
Report Primary Disease as: |
Report disease diagnosis date of: |
Complete multiple disease sections of the Disease Classification Form? |
| FAN or SAA and AML |
AML |
AML |
No |
| FAN or SAA and MDS |
MDS |
MDS |
No |
| MYE and AMY |
MYE |
MYE |
No |

**Common Disease Transformations**

| Disease Transformation |
Report primary disease as: |
Report disease diagnosis date of: |
Complete multiple disease sections of the Disease Classification Form? |
| MDS or MPN to AML |
AML |
AML |
Yes – AML and MDS or MPN |
| JMML to AML |
AML |
AML |
Yes – AML and MDS (select questions only) |
| NHL to another NHL |
Second NHL diagnosis |
Second NHL diagnosis |
No |
| HL to NHL* |
NHL |
NHL |
No |
| CLL to NHL (i.e., Richter’s Syndrome) |
NHL |
NHL |
No |

AML=Acute Myelogenous Leukemia; AMY=Amyloidosis; CLL=Chronic Lymphocytic Leukemia; FAN=Fanconi Anemia; MDS=Myelodysplastic Syndrome; MPS=Myeloproliferative Disease; MYE=Multiple Myeloma; NHL=Non-Hodgkin Lymphoma; SAA=Severe Aplastic Anemia.

*Ensure that the disease process is a transformation from Hodgkin lymphoma to Non-Hodgkin lymphoma (typically diffuse large B-cell lymphoma), rather than the distinct entity “B-cell lymphoma, unclassifiable, with features indeterminate between DLBCL and classical Hodgkin Lymphoma.”

#### Question 1: Date of diagnosis for primary disease for HCT / cellular therapy

The date of diagnosis is important because the interval between diagnosis and HCT is often a significant indicator for the recipient’s prognosis post-HCT. Refer to the disease-specific section of the Disease Classification (2402) manual for guidelines when reporting the diagnosis date for each disease.

If the recipient was diagnosed prenatally (*in utero*) or was diagnosed with a **congenital** immunodeficiency, report the date of birth as the date of diagnosis.

If this is a subsequent infusion for the same disease, report the date of diagnosis as the first date when the primary disease for infusion was diagnosed.

If this is a subsequent infusion for a new malignancy (or other new indication), report the date of diagnosis of the new malignancy.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

*!***Erythropoietic protoporphyria (EPP)**

Historically, if the primary disease for transplant was erythropoietic protoporphyria, the primary disease for transplant was reported as “Other Disease.” However, the primary disease for infusion should be reported as **Hemoglobinopathies** and specify the classification as **Other hemoglobinopathy**.

#### Question 2: What was the primary disease for which the HCT / cellular therapy was performed?

Select the primary disease for which the recipient is receiving the infusion and continue with the appropriate disease classification questions.

**Section Updates:**

| Question Number |
Date of Change |
Add/Remove/Modify |
Description |
Reasoning (If applicable) |
| . |
. |
. |
. |
. |

Last modified:
Oct 27, 2024