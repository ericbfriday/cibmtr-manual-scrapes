PCD pre-infusion lines of therapy data fields capture information about systemic therapy administered and why it stopped, if a standard drug regimen or specific drug was given, radiation treatment, and the best response to the line of therapy along if a clinical / hematologic relapse or progression occurred.

This section provides multiple myeloma specific reporting instructions used when completing the pre-infusion lines of therapy on the PCD Pre-Infusion (2016) Form.

### Reporting Lines of Therapy

For PCD line of therapy reporting, it is important to know if therapy changed due to the disease status; however, it is not necessary to consider if therapy changed for other reasons (i.e., toxicity, insurance coverage, drug shortage, etc.).

If a regimen is discontinued for any reason and a different regimen is started, these are counted as separate lines of therapy. A regimen is considered ‘discontinued’ when all drugs in the regimen stopped. A regimen is not considered as ‘discontinued’ if some of the drugs in the regimen, but not all, have been stopped. Additionally, dose modifications of the same regimen, regardless of the reason, are not considered as a new line of therapy.

From a PCD perspective, it is imperative to know if the recipient was exposed to specific drugs. Use the following guidelines when determining if separate lines of therapy should be reported for PCD:

**Report a new line of therapy in the following scenarios**:

- If the recipient’s disease status changes (favorable or unfavorable), resulting in a change of treatment.
- Example 1: Lenalidomide, bortezomib, and dexamethasone are given, but disease progression occurs, resulting in a change of therapy to bortezomib, cyclophosphamide, and dexamethasone. Following this, lenalidomide, bortezomib, and dexamethasone is used again as salvage. Three separate lines should be reported.

- When there is a change in regimen, regardless of the reason why the regimen changed.
- Example 2: Lenalidomide and dexamethasone are given as induction but due to a toxicity, the regimen switched to bortezomib, cyclophosphamide, and dexamethasone. This is considered two separate lines of therapy.

- If a specific drug, either a standalone drug or as part of a specific regimen, was swapped, regardless of the reason.
- Example 3: Pomalidomide, bortezomib, and dexamethasone was started but due to insurance coverage for bortezomib, this was swapped for carfilzomib and the recipient began pomalidomide, carfilzomib, and dexamethasone. This is counted as two lines of therapy.

- When a drug is added to the current regimen.
- Example 4: Lenalidomide and dexamethasone are given as induction but due to an inadequate response, bortezomib is added. This is counted as two separate lines of therapy.

- When a drug is added after restarting a previous regimen.
- Example 5: Lenalidomide maintenance is stopped and restarted. After restarting lenalidomide, bortezomib is added. This is two separate lines of therapy.


**Report a single line of therapy in the following scenarios**:

- When there is a dose change to a specific drug(s), regardless of the reason why.
- Example 6: Carfilzomib, lenalidomide, and dexamethasone are given but due to a rash from lenalidomide, the dose is decreased. This is considered one line of therapy.

- When a regimen is stopped and restarted, regardless of the reason why.
- Example 7: Lenalidomide and dexamethasone given for two years and then was discontinued due to plateau (or any other reason) and then restarted six months later due to disease progression. This is counted as a single line of therapy.

- If a specific drug(s) as part of a regimen stopped, regardless of the reason why.
- Example 8: Daratumumab, bortezomib, and dexamethasone are given but due to insurance coverage, daratumumab is stopped and the remaining drugs continue. This is considered one line of therapy.

- If the dose of a specific drug(s) as part of a regimen was changed and then eventually stopped.
- Example 9: Carfilzomib, lenalidomide, and dexamethasone are given but due to a rash from lenalidomide, the dose is decreased. The rash persists even with the dose decrease so lenalidomide is discontinued. This is considered one line of therapy.


**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)