#### Question 95: Does the current disease status reflect the disease detected in this reporting period section (as captured in questions 48-80), without subsequent therapy?

This section of the form is intended to capture the most recent disease assessment. The most recent disease assessments may have already been reported in the Disease Detection Since the Date of Last Report (questions 48-80) and, if that is the case, it is not necessary to report those same disease assessments in the Disease Status at the Time of Evaluation for this Reporting Period (questions 95-128). Refer to the instructions below to determine how to complete this section of the form. Reporting scenarios have also been provided below.

Report “Yes” for question 95 and go to question 129 in *any* of the following scenarios:


- Disease was detected by any method in the reporting period (reported in the Disease Detection Since the Date of Last Report, questions 48-80) and no therapy was given to treat diseases between the date(s) of the assessments reported in the Disease Detection Since the Date of Last Report (questions 48-80) for the form and the date of contact for this reporting period
- Disease was detected by any method in the reporting period (reported in the Disease Detection Since the Date of Last Report, questions 48-80), therapy was administered, but no assessments were performed after the initiation of therapy

Report “No” for question 95 and report the most recent disease assessments in the reporting period in questions 96 – 128 in *any* of the following scenarios:


- Disease was not detected by any method of assessment during the reporting period
- Disease was detected in the reporting period (reported in the Disease Detected Since the Date of Last Report, questions 48 – 80), therapy was administered, and additional assessment(s) were performed after therapy


Report “Not applicable” for question 95 and submit the form if no disease assessments were performed during the current reporting period. Only report this option if the recipient did not have any disease assesssments, including a physical exam by their primary care provider, performed during the reporting period. Contact the CIBMTR Customer Service Center if there are questions regarding whether a visit or test should be reported as a disease assessment.

**Disease Status Evaluation Reporting Scenarios:**

**A.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD (FLT3-ITD was detected at diagnosis). Disease was not detected by any of these three assessments. Subsequently, on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are negative. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 48-80:** No assessments will be reported here since the recipient’s disease did not relapse, did not persist or have evidence of minimal residual disease. In this scenario, questions 51, 63, 70, 80, and 87 must be answered “No”.

**Question 95:** Report “No” for question 95. Disease was not detected by any method of assessment during the reporting period.

**Questions 96-128:** Report the results of the most recent assessment by each method including:


- PCR testing for FLT3-ITD performed on 1/15/2016.
- Flow cytometry testing performed on the bone marrow on 3/20/2016.
- Morphology review performed on the bone marrow on 3/20/2016.

**B.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD (FLT3-ITD was detected at diagnosis). Disease was not detected by any of these three assessments. Subsequently, on D+95 (3/20/2016), all three tests are repeated and are positive indicating disease relapse. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 48-80:** All three disease assessments performed on 3/20/2016 (PCR test for FLT3-ITD as well as morphology and flow cytometry on the bone marrow) will be reported because they were the earliest positive assessments of disease during the reporting period.

**Question 95:** Report “Yes” for question 95. The most recent assessments have already been reported in questions 48-80.

**Questions 96-128:** These questions will be left blank (i.e., not enabled)

**C.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD (FLT3-ITD was detected at diagnosis). Disease was not detected by any of these three assessments. Subsequently, on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are positive indicating disease relapse. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 48-80:** Morphology and flow cytometry assessments of the bone marrow on 3/20/2016 will be reported because they were the earliest positive assessments of disease during the reporting period. Testing for molecular markers was not done at the time of relapse and should not be reported here.

**Question 95:** Report “Yes” for question 95 since the most recent test results were reported in Q48-80.

**Questions 96-128:** These questions will be left blank (i.e., not enabled)

**D.** A recipient has a bone marrow assessment on D+30 (1/15/2016) including morphology review, flow cytometry, and PCR testing for FLT3-ITD. All three assessments detect disease. Subsequently, on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are again positive for disease. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 48-80:** All three disease assessments performed on 1/15/2016 (PCR test for FLT3-ITD as well as morphology and flow cytometry on the bone marrow) will be reported because they were the earliest positive assessments of disease during the reporting period.

**Question 95-128:** Report “Yes” for question 95 if no therapy was given to treat the disease between 1/15/2016 and 3/20/2016. If therapy was used to treat the disease during this time frame, indicate “No” and report the most recent test results in questions 96-128.

**E.** A recipient has a bone marrow assessment on D+30 (1/15/2016), including morphology review, flow cytometry, and PCR testing for FLT3-ITD. All three assessments detect disease. Therapy was started and assessments were performed again on D+95 (3/20/2016), a repeat bone marrow assessment is performed including morphology and flow cytometry. Testing for molecular markers is not done. Both assessments (morphology and flow) are again positive for disease. The date of contact for the 100 Day Follow-Up Form is 3/20/2016.

*100 Day Follow-Up Form:*

**Questions 48-80:** All three disease assessments performed on 1/15/2016 (PCR test for FLT3-ITD as well as morphology and flow cytometry on the bone marrow) will be reported because they were the earliest positive assessments of disease during the reporting period.

**Question 95-128:** Report “No” for question 95 and report the testing performed after treatment (bone marrow and flow on the bone marrow done on D+95).

#### Question 96: Were tests for molecular markers performed (e.g. PCR, NGS)?

Refer to [question 4](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#mol) for a description of testing for molecular markers. If molecular testing was performed during the reporting period, report “Yes” and go to question 97. If testing was not performed during the reporting period or it is not known whether testing was performed, report “No” or “Unknown” respectively and go to question 101.

#### Question 97-100: Specify results

For each molecular marker in questions 97-98, report whether testing was “Positive,” “Negative,” or “Not done” at the time of the most recent assessment during the reporting period. If the most recent testing performed during the reporting period identified a molecular marker other than those listed in questions 97-98, report the result in question 99 and specify the marker in question 100.

If multiple “Other molecular marker[s]” were tested at the time of best response, report one instance (i.e., copy) of question 99-100 for each “Other molecular marker” tested. If greater than 3 “Other molecular marker[s]” were tested, do the following:


- report one instance of question 99-100; and
- report “Positive” if any of the “Other molecular marker[s]” were positive, otherwise, report “Negative;” and
- report “see attachment” in question 100; and
- attach any / all reports documenting the results of testing for “Other molecular marker[s].”

#### Question 101: Was the disease status assessed via flow cytometry?

Refer to [question 9](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#flow) for a description of flow cytometry. Only testing performed on the blood or bone marrow may be reported in questions 101-109. If flow cytometry was performed on the blood and / or bone marrow during the reporting period, report “Yes” and go to question 101. If testing was not performed during the reporting period, report “No” and go to question 106.

#### Question 102-105: Flow cytometry testing on blood

If flow cytometry was performed on the blood during the reporting period, report “Yes” for question 102 and go to question 103. If testing was not performed during the reporting period, report “No” and go to question 106.

If “Yes” has been reported for question 102, report the date of collection and results for the most recent assessment performed during reporting period in questions 103 and 104 respectively. If disease was detected by the most recent assessment, report the percent disease detected (i.e., percent leukemic blasts) in question 105. Otherwise, go to question 106.

#### Question 106-109: Flow cytometry testing on bone marrow

If flow cytometry was performed on the bone marrow during the reporting period, report “Yes” for question 106 and go to question 107. If testing was not performed during the reporting period, report “No” and go to question 110.

If “Yes” has been reported for question 106, report the date of collection and results for the most recent assessment performed during reporting period in questions 107 and 108 respectively. If disease was detected by the most recent assessment, report the percent disease detected (i.e., percent leukemic blasts) in question 109. Otherwise, go to question 110.

#### Question 110: Were cytogenetics tested (karyotyping or FISH)?

Refer to [question 18](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111disease-assessment-at-the-time-of-best-response-to-hct#cyto) for a description of cytogenetic testing. If cytogenetic testing was performed during the reporting period, report “Yes” and go to question 111. If testing was not performed during the reporting period or it is not known whether testing was performed, report “No” or “Unknown” respectively and go to question 122.

If cytogenetic studies were attempted during the reporting period, but there were not adequate cells (metaphases) for any cytogenetic assessments, report “No,” and go to question 122.

#### Question 111-112: Were cytogenetics tested via FISH?

If FISH studies were performed during the reporting period, report “Yes” and indicate whether clonal abnormalities were detected on the most recent assessment in the reporting period in question 112. If FISH studies were not performed, report “No” for question 111 and go to question 116. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Question 113-115: Specify cytogenetic abnormalities (FISH)

Report the number of clonal abnormalities detected by the most recent FISH assessment in the reporting period in question 113. After indicating the number of abnormalities in question 113, select all clonal abnormalities detected in questions 114-115.

If a clonal abnormality is detected on the most recent FISH assessment in the reporting period, but not listed as an option in question 114, select “Other abnormality” and specify the abnormality in question 115. If multiple “Other abnormalities” were detected, report “see attachment” in question 115 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 116-117: Were cytogenetics tested via karyotyping?

If karyotyping was performed during the reporting period, report “Yes” for question 116 and indicate whether clonal abnormalities were detected in question 117. If karyotyping was not performed, indicate “No” for question 116 and go to question 121. Examples of this include: karyotyping was not performed or karyotyping sample was inadequate.

#### Question 118-120: Specify cytogenetic abnormalities (karyotyping)

Report the number of clonal abnormalities detected by the most recent karyotype in the reporting period in question 118. After indicating the number of clonal abnormalities in question 118, select all abnormalities detected in questions 119-120.

If a clonal abnormality is detected on the most recent karyotype during the reporting period, but not listed as an option in question 119, select “Other abnormality” and specify the abnormality in question 120. If multiple “Other abnormalities” were detected, report “see attachment” in question 120 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 121: Was documentation submitted to the CIBMTR?

Indicate if a karyotyping or FISH testing report is attached to support the cytogenetic findings reported in questions 110-120. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 122-124: Was disease status assessed by clinical / hematologic assessment?

Clinical / hematologic assessments include, but are not limited to, biopsies, imaging assessments, complete blood counts, radiographic studies and physical exams. If clinical / hematologic testing was performed during the reporting period, report “Yes” for question 122 and report the date and result in questions 123 and 124 respectively. The date and results reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). Indicate the date the sample was collected for examination for pathological and laboratory evaluations; enter the date of physical examination. If no disease assessments were performed within approximately 30 days prior to the date of contact, report the results and date of the most recent assessment performed during the reporting period. If the exact date is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If no clinical / hematologic assessments (including a physical exam by the recipient’s primary care provider) were performed during the reporting period, report “No” for question 122 and go to question 125.

#### Question 125-128: Was the disease status assessed by other assessment?

Indicate in question 125 whether ALL was assessed by any method other than those included in questions 96-124 during the reporting period. If “Yes,” report the date of assessment and specify the type of assessment in questions 126 and 127 respectively. Also report the results of the assessment in question 128. If the exact date of assessment is not known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms). If ALL was not assessed by any methods other than those included in questions 96-124, report “No” for question 125 and go to question 129.

#### Question 129: What is the current disease status?

Indicate the hematologic disease status of ALL as of the last evaluation during the reporting period. Determine the current disease status using the international working group criteria provided in the in [ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria) of the Forms Instructions Manual. Report “Complete Remission” for recipients who meet the criteria for complete remission (CR). Do not consider testing for molecular markers, testing for cytogenetic abnormalities, or testing by flow cytometry when reporting the hematologic disease status in question 129.

Some clinical judgment is required for evaluating whether a recipient meets the CR criteria, specifically neutrophil, platelet, and transfusion parameters. If a recipient does not meet these specifications, the underlying cause should be assessed; if the cause for not meeting one of these parameters is felt to be due to a reason other than underlying leukemia, such as renal insufficiency, hemolysis, or drug-related causes, the disease status may be reported as “complete remission.” If the cause for not meeting the parameters is judged to be leukemia-related, the disease status should be reported as “not in complete remission.”

If the recipient did not meet the criteria for CR report “Not in complete remission.”

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 130: Date assessed

Enter the date of the most recent assessment establishing disease status within the reporting period. The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). In addition to clinician evaluation and physical examination, clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory analysis (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluation; the date the imaging took place for radiographic assessments, or the date of physical examination.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)