#### Question 146: Specify if the recipient received any of the following (at any time prior to HCT / infusion) (check all that apply)

Indicate if any of the following agents were administered to the patient prior to HCT / infusion:

: A monoclonal antibody used to treat B-cell acute lymphoblastic leukemia (ALL)[Blinatumomab](http://www.cancer.gov/publications/dictionaries/cancer-terms/def/blincyto): An antibody-drug conjugate used to treat CD33 positive acute myeloid leukemia (AML)[Gemtuzumab ozogamicin](http://www.cancer.gov/publications/dictionaries/cancer-terms/def/gemtuzumab-ozogamicin): An antibody-drug conjugate used to treat B-cell acute lymphoblastic leukemia (ALL)[Inotuzumab ozogamicin](http://www.cancer.gov/publications/dictionaries/cancer-terms/def/inotuzumab-ozogamicin): A specific brand of thiotepa, an alkylating agent used in the conditioning regimen to treat myeloma, lymphomas, acute leukemia and other malignant and non-malignant[Adienne Tepadina®](http://www.adienne.com/?page_id=1248).: A monoclonal antibody used to treat mycosis fungoides or Sezary syndrome (types of cutaneous T-cell lymphoma). It is also being studied in the treatment of other types of cancer[Mogamulizumab](http://www.cancer.gov/publications/dictionaries/cancer-terms/def/794274)

If the recipient did not receive any of the agents listed above select **None of the above**.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Sep 23, 2022

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)