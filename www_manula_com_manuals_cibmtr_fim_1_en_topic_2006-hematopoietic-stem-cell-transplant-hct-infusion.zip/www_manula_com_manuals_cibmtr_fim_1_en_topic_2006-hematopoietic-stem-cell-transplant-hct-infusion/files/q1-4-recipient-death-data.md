#### Question 1: Date of Death

Report the date the recipient died. Confirm that the date matches the last date of actual contact reported on the Post-TED (2450), Post-Infusion Follow-Up (2100) form or Cellular Therapy Essential Data Follow-Up (4100) form.

If the death occurred at an outside location and records of death are not available, the dictated date of death within a physician note may be reported. If the progress notes detailing the circumstances of death are available, request these records. These records are useful for completing required follow-up data fields on the Form 2100 or Form 4100 and the cause of death data fields on this form.

If the exact date of death is not known, use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms)

#### Question 2: Was cause of death confirmed by autopsy?

Indicate if the cause of death was confirmed by autopsy.

If **Autopsy pending**, the form will not go to complete (CMP) status until the autopsy results are reported. The form may be submitted with question 2 as **Autopsy pending**, but the form will remain in saved (SVD) status until it is updated with the results. Once the autopsy results are known, update question 2 and the **Primary cause of death**, if applicable, to ensure all pertinent causes of death are reported, then resubmit in order to complete the form.

#### Question 3: Was documentation submitted to the CIBMTR? (autopsy report)

Indicate if a documentation (i.e., copy of the autopsy report) was submitted to the CIBMTR.

For further instructions on how to attach documents in FormsNet3SM, refer to the [training guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/getting-started).

#### Questions 4-5: Primary cause of death

Report the underlying cause of death. According to the Centers for Disease Control and Prevention, National Center for Health Statistics, the underlying cause of death is “the disease or injury that initiated the chain of events that led directly or inevitably to death.”

Report only one primary cause of death. Options which require additional specification include **Other infection**, **Other pulmonary syndrome**, **Multiple organ failure**, **Other organ failure**, **Other hemorrhage**, **Other vascular**, and **Other cause**. Information reported in the specify field must pertain to the option selected (e.g., an infectious cause of death should be specified for **Other infection**).

If the recipient has recurrent / persistent / progressive disease at the time of death, consider if the disease was the primary cause of death or a contributing cause of death. It should not be assumed that the presence of disease indicates that the disease was the primary cause of death.

If a cause of death has related questions on the comprehensive report form, report the appropriate data in both locations. For example, if a primary cause of death was infection, complete the infection data fields on the comprehensive report form.

If the primary cause of death is unclear, consult with a physician for their best medical opinion.

#### Questions 6-7: Contributing cause of death

Report any additional causes of death. All contributing causes of death are important for analysis of transplant outcomes.

Options which require additional specification include **Other infection**, **Other pulmonary syndrome**, **Multiple organ failure**, **Other organ failure**, **Other hemorrhage**, **Other vascular**, and **Other cause**. Information reported in the specify field (question 7) must pertain to the option selected (e.g., an infectious cause of death should be specified for **Other infection**).

If a cause of death has related questions on the comprehensive report form, report the appropriate data in both locations. For example, if a contributing cause of death was acute graft-versus-host disease (GVHD), complete the acute GVHD data fields on the comprehensive report form.

If there were multiple contributing causes of death, enable an additional instance to report additional causes.

Review the examples below on how to report primary and contributing cause of death:

**Example 1**: In the 1-year reporting period, a recipient transplanted for AML has relapsed disease that leads to multiple organ failure. In this scenario, the primary cause of death should be captured as relapsed disease and the contributing cause of death should be reported as multiple organ failure.

**Example 2**: A recipient with acute GVHD on immunosuppression develops a fungal infection and then dies. In this scenario, the primary cause of death should be reported as acute GVHD and the contributing cause of death would be captured as a fungal infection.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q1 | 2/15/2023 | Add | The ‘No Documentation of Contact Date’ red warning box added: No Documentation of Contact Date The contact date data field cannot be left blank and is required to be reported. In cases where the recipient passed away and there is no documentation to report the date of death, the guidelines for reporting estimated dates must be used. |
Added for clarification |
| Q1 | 7/22/2022 | Modify | Instructions for Q1 updated: _Report the date the recipient died. Confirm that the date matches the last date of actual contact reported on the Post-TED (2450), Post-Infusion Follow-Up (2100) form or Cellular Therapy Essential Data Follow-Up (4100) form. If the death occurred at an outside location and records of death are not available, the dictated date of death within a physician note may be reported. If the progress notes detailing the circumstances of death are available, request these records. These records are useful for completing required follow-up data fields on the |
Due to changes made during the Summer 2022 release – the 2900 is now completed for TED, CRF, and CT track. |
| Q2 | 2/12/2024 | Modify | Instructions for when ‘autopsy pending’ is reported were updated: If Autopsy pending, the form will not go to complete (CMP) status until the autopsy results are reported. The form may be submitted with question 2 as Autopsy pending, but the form will remain in saved (SVD) status until it is updated with the results. Once the autopsy results are known, update question 2, and the Primary cause of death, if applicable, to ensure all pertinent causes of death are reported, then resubmit in order to complete the form. All pertinent causes of death should be reported on the second Recipient Death Data (2900) form. |
Added for clarification |
| Q2 | 2/28/2022 | Modify | Instructions for when ‘autopsy pending’ is reported were updated: If Autopsy pending, Autopsy pending, but the form will remain in saved (SVD) status until it is updated with the results. Once the autopsy results are known, update question 2 and resubmit in order to complete the form. All pertinent causes of death should be reported on the second Recipient Death Data (2900) form. |
Due to changes made during the Spring 2021 release – a second 2900 is no longer required when an autopsy is pending. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)