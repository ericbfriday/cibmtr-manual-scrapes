This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “disorders of the immune system” and question 628 as X-Linked Lymphoproliferative Syndrome. The X-Linked Lymphoproliferative Syndrome Post-HCT Data Form (Form 2134) must be completed in conjunction with each Post-HCT follow-up form (Forms 2100, 2200, 2300) completed. The form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100 for Form 2100, between day 100 and the six-month date of contact for Form 2200, between the date of contact for the six-month follow up and the date of contact for the one-year follow up for Form 2200, etc.).

[Q1-19: Disease Assessment Since the Date of Last Report](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-19-disease-assessment-since-the-date-of-last-report)

[Q20-30: Current Assessment of Immunologic Fuction Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q20-30-current-assessment-of-immunologic-fuction-post-hct)

[Q31-41: Laboratory Studies at the Time of Evaluation for This Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q31-41-laboratory-studies-at-the-time-of-evaluation-for-this-reporting-period)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/24/17 | Comprehensive Disease-Specific Manuals | Modify | Updated explanations of triggers for disease inserts to refer to the primary disease reported on the Pre-TED Disease Classification Form (Form 2402) instead of the Pre-TED Form (Form 2400) |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)