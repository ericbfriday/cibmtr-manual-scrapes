#### Question 1: Is the recipient participating in a clinical trial?

Indicate **Yes**, **No**, or **Unknown** if the recipient has consented to any new clinical trial in this reporting period.

Submit a ticket through [CIBMTR Center Support](https://nmdp.service-now.com/csm) when there are questions on reporting clinical trials.

#### Question 2: Specify the Clinicaltrials.gov identification number

Clinical trials are required to be registered on the clinicaltrials.gov website and will have an associated identification number.

Report the identification number – do not include the letters “NCT,” preceding the digits.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Sep 30, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)