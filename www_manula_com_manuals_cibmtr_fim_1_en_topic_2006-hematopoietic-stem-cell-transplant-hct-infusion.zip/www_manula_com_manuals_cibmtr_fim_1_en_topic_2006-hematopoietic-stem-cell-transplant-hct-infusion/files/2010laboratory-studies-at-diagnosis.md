All values reported in questions 14-31 must reflect testing performed prior to any treatment of AML. If testing was not performed near the time of diagnosis (within approximately 30 days) and prior to the initiation of treatment, the center should report “Unknown” for that value.

#### Question 14-16: WBC

Indicate whether the white blood count (WBC) in the peripheral blood is “Known” or “Unknown” at the time of diagnosis. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms. If the WBC at diagnosis is not known, report “Unknown” and go to question 17.

#### Question 17-19: Blasts in blood

Indicate whether the percent blasts in the peripheral blood is “Known” or “Unknown” at the time of diagnosis. This may be determined by an automated differential, a manual count, or flow cytometry. Testing by any of these methods may be reported in questions 17-19. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms. If the percent blasts in blood at diagnosis is not known, report “Unknown” and go to question 20.

If a differential was performed and there were no blasts present in the peripheral blood, the lab report may not display a column for blasts. In this case, it can be assumed no blasts are present and ‘0’ should be reported.

#### Question 20-22: Blasts in bone marrow

Indicate whether the percent blasts in the bone marrow is “Known” or “Unknown” at the time of diagnosis. The percent blasts may be assessed by manual differential or flow cytometry. If available, report the manual differential performed on the bone marrow aspirate sample. If a manual differential was not performed on an aspirate sample, other methods / sample types may be reported (such as flow cytometry on an aspirate sample, or testing on a core biopsy) may be reported.

If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms. If the percent blasts in bone marrow at diagnosis is not known, report “Unknown” and go to question 23.

#### Question 23-31: Extramedullary disease

Extramedullary disease refers to any confirmed site of AML other than the peripheral blood and bone marrow. Examples include detection of leukemic blasts in the cerebrospinal fluid and skin (leukemia cutis) as well as detection of soft tissue masses (myeloid sarcoma). If the recipient had extramedullary disease at the time of diagnosis, report “Yes” for question 23 and report all extramedullary sites of involvement in questions 24-31. If the recipient did not have any extramedullary disease at diagnosis, report “No” for question 23 and go to question 32. If extramedullary disease at diagnosis is not known, report “Unknown” and go to question 32.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q17 – 19 | 8/12/2022 | Add | Indicate whether the percent blasts in the peripheral blood is “Known” or “Unknown” at the time of diagnosis. This may be determined by an automated differential, a manual count, or flow cytometry. Testing by any of these methods may be reported in questions 17-19. If “Known,” report the laboratory value, unit of measure, and date sample collected. If the exact date is not known, use the process described for reporting partial or unknown dates in General Instructions, Guidelines for Completing Forms. If the percent blasts in blood at diagnosis is not known, report “Unknown” and go to question 20. If a differential was performed and there were no blasts present in the peripheral blood, the lab report may not display a column for blasts. In this case, it can be assumed no blasts are present and ‘0’ should be reported. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)