#### Question 1: Estimated delivery date

Report the estimated delivery date, as documented within the medical record. If the date is not documented, seek physician clarification.

#### Question 2: Was the recipient pregnant at the time of this report? (Female only)

Indicate if the recipient (female only) was pregnant at the time of completing this form.

If this form was created using the on-demand function, indicate if the recipient is pregnant at the time of submitting this form.

If this form was generated as a result of reporting on the Cellular Therapy Essential Data Follow-Up (4100) Form or Post-Infusion Follow-Up (2100) Form, indicate if the recipient is pregnant on the contact date for the corresponding reporting period in which the pregnancy was first reported.

If the recipient is pregnant at the time of completing this form (on-demand) or pregnant on the reported contact date for the current reporting period, select **Yes** and submit the form.

#### Question 3: Was the recipient’s female partner pregnant at the time of this report (Male only)

Indicate if the male recipient’s female partner was pregnant at the time of this report.

If this form was created using the on-demand function, indicate if the male recipient’s female partner is pregnant at the time of submitting this form.

If this form was generated as a result of reporting on the Cellular Therapy Essential Data Follow-Up (4100) Form or Post-Infusion Follow-Up (2100) Form, indicate if the male recipient’s female partner is pregnant on the contact date for the corresponding reporting period in which the pregnancy was first reported.

If the male recipient’s female partner is pregnant at the time of completing this form (on-demand) or pregnant on the reported contact date for the current reporting period, select **Yes** and submit the form.

#### Question 4: Specify the outcome of the pregnancy

Indicate the outcome of the pregnancy. The **Unknown** option should be used sparingly and only when no information can be obtained regarding the outcome.

#### Question 5: Were there congenital abnormalities? (Live birth)

Congenital abnormalities are defined as structural or functional abnormalities that occur during intrauterine life.

Examples of structural abnormalities include cleft palate, club foot, missing or abnormal limbs, etc.

Examples of functional abnormalities include mental retardation, Down syndrome, etc.

Indicate if the baby was diagnosed with a structural or functional congenital abnormality(ies).

#### Questions 6: Was the baby diagnosed with intrauterine growth restriction (IUGR)? (Live birth)

Intrauterine growth restriction (IUGR) is a condition where a fetus does not grow as expected during pregnancy. IUGR is a concern for gene therapy recipients because it is unknown if the genetically modified cells can pass to the fetus.

Specify if the baby was diagnosed with intrauterine growth restriction. IUGR documentation can be found in a pre-natal note from the obstetrician.

#### Questions 7: Was the baby small for gestational age (SGA)? (Live birth)

Small for gestational age refers to a baby who is smaller is size than is considered normal for the number of weeks of pregnancy. SGA is a concern for gene therapy recipients because it is unknown if the genetically modified cells can pass to the fetus.

Specify if the baby was small for gestational age. SGA documentation can be found in a newborn nursery admin note listed under the baby’s medical record, or in a post-delivery note from the obstetrician.

#### Questions 8: Delivery date

Specify the date of delivery. If the exact delivery date is not known but the month and year is known, use the process described for reporting partial or unknown dates in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) and select the Date estimated box.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)