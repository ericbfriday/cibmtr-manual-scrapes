#### Question 194: Specify transfusion dependence at last evaluation prior to the start of the preparative regimen / infusion:

Indicate the transfusion dependence for the recipient at the time last evaluation prior to the start of the preparative regimen / infusion and continue with question 195.

Select “Non-transfused (NTD)” if the recipient has not received any RBC transfusions within a period of 16 weeks prior to the start of the preparative regimen.

Select “Low-transfusion burden (LTB)” if the recipient had 3-7 RBC transfusions within a period of 16 weeks or at least 2 transfusion episodes with a maximum of 3 RBC transfusions in 8 weeks prior to the start of the preparative regimen.

Select “High-transfusion burden (HTB)”- if the recipient had ≥8 RBCs transfusions within a period of 16 weeks or ≥4 within 8 weeks prior to the start of the preparative regimen.

#### Questions 195: Did the recipient have constitutional symptoms in six months before last evaluation prior to the start of the preparative regimen / infusion)? (symptoms are >10% weight loss in 6 months, night sweats, unexplained fever higher than 37.5 °C)

Indicate if constitutional symptoms were present at the last evaluation prior to the preparative regimen. Constitutional symptoms are often called “B” symptoms and include unexplained fever greater than 38°C (100.4°F), night sweats, or unexplained weight loss in the six months prior to diagnosis. Indicate “yes” if any constitutional symptoms were present at the last evaluation before the preparative regimen. Indicate “no” if constitutional symptoms were not present at the last evaluation prior to the preparative regimen. Indicate “unknown” if it is not possible to determine the presence or absence of constitutional symptoms at the last evaluation prior to the start of the preparative regimen.

#### Question 196: Did the recipient have splenomegaly at the last evaluation prior to the start of the preparative regimen / infusion?

Indicate if the recipient had splenomegaly at the last evaluation prior to the start of the preparative regimen/infusion. Splenomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate “yes” if splenomegaly was present at the time of the last evaluation prior to the start of the preparative regimen / infusion and continue with question 197.

Indicate “no” if splenomegaly was not present at the last evaluation prior to the start of the preparative regimen / infusion and continue with question 200.

Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at the last evaluation prior to the start of the preparative regimen / infusion and continue with question 200.

Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy or congenital asplenia) and continue with question 200.

#### Question 197: Specify the method used to measure spleen size

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 198. If the method selected is “ultrasound” or “CT / MRI” continue with question 199. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 198: Specify the spleen size in centimeters below the left coastal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 200.

#### Question 199: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 200.

#### Question 200: Did the recipient have hepatomegaly at last evaluation prior to the start of the preparative regimen / infusion?

Indicate if the recipient had hepatomegaly at the last evaluation prior to the start of the preparative regimen / infusion. Hepatomegaly is often documented during the physician’s physical assessment of the patient and represents an abnormal finding.

Indicate “yes” if hepatomegaly was present at the last evaluation prior to the start of the preparative regimen / infusion and continue with question 201.

Indicate “no” if hepatomegaly was not present at the last evaluation prior to the start of the preparative regimen / infusion and continue with question 204.

Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at the last evaluation prior to the start of the preparative regimen / infusion and continue with question 204.

#### Question 201: Specify the method used to measure liver size

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 202. If the method selected is “ultrasound” or “CT / MRI” continue with question 203. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 202: Specify the liver size in centimeters below the right coastal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 204.

#### Question 203: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 204.

#### Question 204: Iron overload

Indicate “yes” if the patient has documented iron overload at the last evaluation prior to the start of the preparative regimen and continue with question 205. Indicate “no” if the patient doesn’t have documented iron overload and submit the form.

#### Question 205-206: Indicate how the iron overload diagnosis was made:

Iron overload can be detected by several methods such as: Serum ferritin level or liver MRI. Indicate the method the iron overload diagnosis was made. If the iron overload diagnosis was made by a method which is not listed, select “Other method” and specify the method of diagnosis in question 206.

**Serum ferritin**: Ferritin is a blood cell protein that contains iron. A ferritin level indicates how much iron a person’s body is storing. If the ferritin level is lower than normal, it indicates the body’s iron stores are low (iron deficiency). If the ferritin level is higher than normal it could indicate hemochromatosis, a condition that causes the body to store too much iron. Other causes of an elevated ferritin level include transfusion dependence, liver disease, acute and chronic inflammatory conditions, malignancy to name a few.

**Liver MRI**: Iron overload can be detected in a liver MRI by presence of an abnormal accumulation of iron in hepatocytes, Kupffer cells, or both.

**T2*MRI**: Iron overload can be detected by T2 imaging by presence of reduced signal intensity (compared to the non iron-overloaded case) in the liver.

**SQUID MRI**: A SQUID MRI is a magnetic detector in which can measure the magnetic properties of liver can quantify liver iron.

**Liver biopsy**: Detection and quantification of liver iron can be assessed by a liver biopsy. A sample is sent and tested for the presence of iron.

**FerriScan**: A FerriScan provides measurements of liver iron concentration (LIC) through a non-invasive, MRI-based technology.

**Other method**: Indicate if another method was used to make the diagnosis of iron overload and indicate the method in question 206.

#### Question 207: Iron chelation therapy

Iron chelation therapy is the removal of excess iron from the body using drugs such as deferoxamine.

Indicate “yes” if iron chelation therapy was given for iron overload or “no” if it was not.

#### Question 208: Phlebotomy

Indicate “yes” if phlebotomy was utilized for iron overload or “no” if it was not.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)