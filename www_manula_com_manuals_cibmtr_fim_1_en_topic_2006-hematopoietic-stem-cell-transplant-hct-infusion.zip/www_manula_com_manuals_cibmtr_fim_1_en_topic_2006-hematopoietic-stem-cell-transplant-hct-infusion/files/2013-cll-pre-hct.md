The CLL Pre-Infusion (2013) Form is a Comprehensive Report Forms. This form captures CLL-specific pre-infusion data such as disease assessments and laboratory studies at diagnosis, pre-infusion treatment for CLL, and most recent disease assessments prior to the start of the preparative regimen / infusion.

This form must be completed for all recipients assigned to the CRF track whose disease, reported on Disease Classification (2402) Form, is chronic lymphocytic leukemia (CLL), B-cell/small lymphocytic leukemia (SLL), or prolymphocytic leukemia (PLL). Both the CLL Pre-Infusion (2013) and Lymphoma Pre-Infusion (2018) Forms must be completed if the recipient had Richter’s transformation from CLL to diffuse large B-cell lymphoma prior to transplant or cellular therapy.

**Links to Sections of Form**

[Q1: Subsequent Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-subsequent-infusion)

[Q2 – 8: Disease Assessments at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-q1-21)

[Q9 – 47: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-q22-73)

[Q48 – 104: Pre-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-q74-148)

[Q105 – 154: Disease Assessment at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-q149-191)

**Manual Updates**

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

To reference the historical Manual Change History for this form, please see the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/2025 |
|

**Disease Assessments at the Last Evaluation and CLL to NHL Transformations**: When CLL has transformed to NHL, the disease assessment at the last evaluation section will be disabled.[2013: CLL Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2013-cll-pre-hct)*Systemic symptoms or B symptoms (also known as constitutional symptoms) include unexplained fever > 38˚ C (100.4˚ F), night sweats, and / or unexplained weight loss of >10% of body weight in six months before*~~treatment~~ diagnosis. Specify if the recipient had B symptoms within six months prior to the diagnosis. If it is unclear if symptoms were present within six months prior to the diagnosis, seek physician clarification.[2013: CLL Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2013-cll-pre-hct)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)