#### Question 28: Was therapy given for reasons other than relapse or progressive disease? (include any maintenance and consolidation therapy)

Indicate if the recipient received treatment post-infusion for reasons other than treatment for measurable residual disease (MRD), relapse, progressive, or persistent disease during the current reporting period. Recipients generally receive a HCT / cellular therapy under a specific protocol which defines radiation and / or systemic therapy to be given post-infusion, along with prophylactic medication as well as any systemic therapy, radiation, and / or other treatments to be administered post-infusion as planned (or maintenance) therapy. Planned (maintenance or consolidation) therapy is given to assist in prolonging remission. Planned therapy may be described in a research protocol or standard of care protocol and these should be referred to when completing this section.

If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR consider this ‘planned therapy,’ even if this was not documented prior to infusion. *Do not include any treatment administered as a result of relapse, progression, or persistent disease.*

Indicate if therapy was given for reasons other than measurable residual disease (MRD), relapse, progressive, or persistent disease in the current reporting period.

#### Questions 29 – 30: Specify therapy given (check all that apply)

Specify the therapy given for reasons other than relapse, progressive, or persistent disease in the current reporting period in the current reporting period. Select all that apply.

**Systemic therapy**: Systemic therapy includes chemotherapy, immunotherapy, or targeted therapies delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein or given orally. Common systemic therapies for CLL include chemotherapy and monoclonal antibodies. If**Systemic therapy**was given in the current reporting period, specify the type of systemic therapy (i.e., ‘chemotherapy’)*and*the generic drug name (i.e., ibrutinib).- Examples of systemic therapy include, but not limited to, chemotherapy, immune therapy / monoclonal antibody, immunomodulatory agents, and targeted therapies.

**Radiation**: Radiation therapy utilizes high-energy x-rays, gamma rays, electron beams, or proton beams to kill cancer cells. For CLL, radiation therapy may be used to kill cells which have invaded other tissues and lymph nodes. Radiation therapy may be given in conjunction with systemic chemotherapy or as a separate line of therapy.

#### Questions 31 – 32: Was therapy given as part of clinical trial?

Indicate whether the treatment was administered as part of a clinical trial. Consult the physician overseeing treatment if it is not clear if the therapy is being given as part of a clinical trial.

If **Yes**, specify the clinical trial number (NCT number). The clinical trial number can be looked up using the ‘Find a Study’ feature on www.clinicaltrials.gov.

If the treatment was given as part of a clinical trial that is not registered with clinicaltrials.gov but is registered elsewhere, leave the *Specify the ClinicalTrials.gov identification number* data field blank and override the FormsNet3SM error as ‘unable to answer.’ Additionally, attach documentation which displays the clinical trial number and corresponding registry in FormsNet3SM. For further instructions on how to attach documents in the FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q28 | 1/24/2025 | Modify | Blue note box updated:Measurable Residual Disease Treatment If treatment for measurable residual disease was given in this reporting period, report YesNo for Was therapy given for reasons other than relapse or progressive disease? (include any maintenance and consolidation therapy). |
Additional instructions determined after form / manual release |
| Q28 | 1/24/2025 | Add | Instructions clarified to report not report MRD treatment with maintenance / consolidation: Indicate if the recipient received treatment post-infusion for reasons other than treatment for measurable residual disease (MRD), relapse, progressive, or persistent disease during the current reporting period. Recipients generally receive a HCT / cellular therapy under a specific protocol which defines radiation and / or systemic therapy to be given post-infusion, along with prophylactic medication as well as any systemic therapy, radiation, and / or other treatments to be administered post-infusion as planned (or maintenance) therapy. Planned (maintenance or consolidation) therapy is given to assist in prolonging remission. Planned therapy may be described in a research protocol or standard of care protocol and these should be referred to when completing this section. If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR consider this ‘planned therapy,’ even if this was not documented prior to infusion. Do not include any treatment administered as a result of relapse, progression, or persistent disease. Indicate if therapy was given for reasons other than measurable residual disease (MRD), relapse, progressive, or persistent disease in the current reporting period. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)