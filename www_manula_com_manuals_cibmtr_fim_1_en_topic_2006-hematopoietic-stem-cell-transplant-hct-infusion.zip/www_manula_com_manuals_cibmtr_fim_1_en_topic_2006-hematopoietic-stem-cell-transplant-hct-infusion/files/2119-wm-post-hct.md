This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as Non-Hodgkin lymphoma and the subtype is reported as Waldenström’s Macroglobulinemia/Lymphoplasmacytic Lymphoma. The Waldenström’s Macroglobulinemia/Lymphoplasmacytic Lymphoma Post-HCT Data (Form 2119) must be completed in conjunction with each Post-HCT follow-up form (Forms 2100, 2200, 2300) completed. The form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100 for Form 2100, between day 100 and the six-month date of contact for Form 2200, between the date of contact for the six-month follow-up and the date of contact for the one-year follow-up for Form 2200, etc.).

[Q1-17: Disease Assessment at the Time of Best Response to HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-17-disease-assessment-at-the-time-of-best-response-to-hct)

[Q18-58: Post-HCT Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q18-58-post-hct-therapy)

[Q59-77: Laboratory Studies at the Time of Evaluation for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q59-77-laboratory-studies-at-the-time-of-evaluation-for-this-reporting-period)

[Q78-79: Disease Status at the Time of Evaluation for this Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q78-79-disease-status-at-the-time-of-evaluation-for-this-reporting-period)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 3/19/18 | Comprehensive Disease Specific Manuals | Add | Added the following instruction for applicable post-infusion disease-specific forms where current disease status is asked (2110, 2111, 2112, 2113, 2114, 2115, 2116, 2118, 2119). The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression. |
| 2/24/17 | Comprehensive Disease-Specific Manuals | Modify | Updated explanations of triggers for disease inserts to refer to the primary disease reported on the Pre-TED Disease Classification Form (Form 2402) instead of the Pre-TED Form (Form 2400) |
| 5/29/15 |
|

[22-23](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q18-58-post-hct-therapy#22):**Indicate if the number of cycles is “known” or “unknown.” If known, report the number of cycles the recipient received during the reporting period for the line of therapy reported in question 23. If the therapy is not given in cycles or the number of cycles is not known, select “unknown” and continue with question 24.**
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)