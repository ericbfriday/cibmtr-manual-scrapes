Acute Lymphoblastic Leukemia (ALL) is a cancer of the white blood cells. It is characterized by the rapid proliferation of abnormal, immature lymphocytes, or lymphoblasts, in the bone marrow. This accumulation of blasts in the marrow prevents the formation of healthy red blood cells, white blood cells, and/or platelets. Normal lymphoblasts develop into B and T lymphocytes that fight infection. In ALL, the leukemic lymphoblasts do not fully develop and therefore cannot fight infection. The symptoms of ALL are caused by the replacement of normal bone marrow with lymphoblasts, resulting in lower numbers of red blood cells, platelets, and normal white blood cells. It is estimated that 80-85% of ALL cases occur in children, with peak incidence of pediatric ALL at age 5. Biologically, adult and pediatric ALL are very different. Pediatric cases are more often characterized by favorable prognostic indicators including a precursor B-cell population, TEL/AML1 fusion gene, and/or hyperdiploidy; adult cases are more often characterized by poor prognostic indicators including a precursor T-cell population and/or BCR/ABL fusion gene.[1](#fn8570026968596b5186453-1)

1 Sallan S. (2006). Myths and Lessons from the Adult/Pediatric Interface in Acute Lymphoblastic Leukemia. *ASH Education Book*, 1st edition, 128-132.

[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)

[2011: ALL Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2011)

[2111: ALL Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2111)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)