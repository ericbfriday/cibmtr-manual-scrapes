#### Question 20: Did the recipient receive supplemental intravenous immunoglobulins (IVIG)?

IVIG is a product made from pooled human plasma that primarily contains IgG. It is used to provide immune-deficient recipients with antibody function to prevent infection.

Indicate whether the recipient received IVIG during the reporting period. If “yes,” continue with question 21. If “no,” continue with question 22.

#### Question 21: Was therapy ongoing within three months of immunoglobulin testing?

Indicate whether the recipient received IVIG within three months prior to the immunoglobulin testing done during the reporting period. If IVIG was given within three months of the immunoglobulin testing, the IgG level would not represent the recipient’s native IgG. If “yes,” continue with question 24. If “no,” continue with question 22.

#### Questions 22-23: IgG

Indicate whether IgG level was “known” or “unknown” during the reporting period. If “known,” report the laboratory value and unit of measure in question 23; if multiple tests were done, report the latest. If “unknown,” continue with question 24.

#### Questions 24-25: IgM

Indicate whether IgM level was “known” or “unknown” during the reporting period. If “known,” report the laboratory value and unit of measure in question 25; if multiple tests were done, report the latest. If “unknown,” continue with question 26.

#### Questions 26-27: IgA

Indicate whether IgA level was “known” or “unknown” during the reporting period. If “known,” report the laboratory value and unit of measure in question 27; if multiple tests were done, report the latest. If “unknown,” continue with question 28.

#### Questions 28-29: IgE

Indicate whether IgE level was “known” or “unknown” during the reporting period. If “known,” report the laboratory value in question 29; if multiple tests were done, report the latest. If “unknown,” continue with question 30.

#### Question 30: NK cell function

Natural killer (NK) cells are cytotoxic lymphocytes implicated in viral response and tumor immunosurveillance. Patients with XLP often have normal numbers of NK cells, but the cells have functional defects. Indicate if the patient’s immune studies revealed absent (≤ 10% lower limit of normal), decreased (11-50% lower limit of normal), or normal quantity of NK cells (> 50% lower limit of normal); if multiple NK studies were performed during the reporting period, report the latest results. If NK cell function was not assessed during the reporting period, indicate “unknown.”

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)