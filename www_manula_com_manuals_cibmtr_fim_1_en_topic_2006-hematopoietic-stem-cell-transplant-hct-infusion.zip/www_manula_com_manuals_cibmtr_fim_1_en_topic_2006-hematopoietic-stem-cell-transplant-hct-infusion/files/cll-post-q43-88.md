#### Questions 65 – 66: Were tests for molecular markers performed (e.g., PCR)?

Indicate if testing for molecular markers was performed at the last evaluation. If **Yes**, report the sample collection date. If multiple tests were performed, report the most recent assessment in the current reporting period.

If molecular marker testing was not performed or it is unknown if performed, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 67 – 70: Specify positive mutation(s) (check all that apply)

Specify the molecular markers identified at the time of the molecular assessment date reported above.

If **BTK** was detected, specify the BTK mutation(s) identified. If **Other** is selected, specify the other BTK detected.

If an **Other molecular** marker was detected, specify the marker identified.

If molecular markers were not identified, select **None**.

#### Question 71: P53 / TP53

Specify if the P53 / TP53 mutation was detected by molecular testing (i.e., PCR, NGS) at the last evaluation. If molecular testing for the P53 / TP53 mutation was not completed or unknown if completed at this time point, select **Not done**.

#### Questions 72 – 73: Was the disease status assessed via clonoSEQ?

Indicate if clonoSEQ was performed at the last evaluation. If **Yes**, report the sample collection date. If multiple tests were performed, report the most recent assessment in the current reporting period.

If clonoSEQ was not performed or it is unknown if performed, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 74: Sample source

Specify the same source for the date of the clonoSEQ assessment reported above.

#### Question 75: Was disease or measurable residual disease detected?

Indicate if the clonoSEQ reported above detected disease or measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Questions 76 – 77: Was the disease status assessed via flow cytometry? *(minimum 4-color flow) (immunophenotyping)*

Indicate if flow cytometry was performed at the last evaluation. If **Yes**, report the sample collection date. If multiple tests were performed, report the most recent assessment in the current reporting period.

If flow cytometry was not performed or it is unknown if performed, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 78: Sample source

Specify the same source for the date of the flow cytometry assessment reported above.

#### Question 79: Was disease or measurable residual disease detected?

Indicate if the flow cytometry reported above detected disease or measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Question 80: Specify the sensitivity of test for MRD *(i.e., level of detection)*

Specify the level of the flow cytometry sensitivity (i.e., level of detection) as listed on the flow cytometry report. If the level of sensitivity is unclear, seek clinician clarification.

#### Question 81: Was the disease status assessed by cytogenetic testing? *(FISH or karyotyping)*

Indicate if cytogenetics (FISH or karyotyping) was performed at the last evaluation. If cytogenetics (FISH or karyotyping) was not performed or it is unknown if performed, select **No**.

#### Questions 82 – 83: Was the disease status assessed via FISH?

Indicate if FISH was performed at the last evaluation. If **Yes**, report the sample collection date. If multiple tests were performed, report the most recent assessment in the current reporting period.

If FISH was not performed, ‘failed,’ or it is unknown if performed, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 84: Was disease or measurable disease detected?

Indicate if the FISH assessment reported above detected disease or measurable residual disease. If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Questions 85 – 86: Was the disease status assessed via karyotyping?

Indicate if karyotyping was performed at the last evaluation. If **Yes**, report the sample collection date. If multiple tests were performed, report the most recent assessment in the current reporting period.

If karyotyping was not performed, or it is unknown if performed, select **No**.

If the date is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, General Guidelines for Completing Forms.

#### Question 87: Was disease or measurable residual disease detected?

Indicate if the karyotype assessment reported above detected disease or measurable residual disease. If karyotype was completed but ‘failed,’ select **No evaluable metaphases**.

If it is unclear if this assessment identified disease or measurable residual disease, seek clinician clarification.

#### Question 88: What is the current disease status

Indicate the clinical / hematologic disease status at the last evaluation in the current reporting period. Determine the current disease status using the CLL international working group criteria provided in the in [CLL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cll-response-criteria) section of the Forms Instructions Manual. Do not consider testing for molecular markers, testing for cytogenetics abnormalities, or testing by flow cytometry when reporting the current disease status.

Some clinical judgment is required for evaluating whether a recipient meets the CR criteria, specifically the blood cell count parameters. If a recipient does not meet these specifications, the underlying cause should be assessed; if the cause for not meeting one of these parameters is felt to be due to a reason other than underlying leukemia, such as renal insufficiency, hemolysis, or drug-related causes, the disease status may be reported as **Complete remission**. If the cause for not meeting the parameters is judged to be leukemia-related, the disease status cannot be reported as complete remission.

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 89: Date assessed

Enter the date of the most recent clinical / hematologic assessment establishing disease status within the reporting period. The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). In addition to clinician evaluation and physical examination, clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (i.e., X-ray, CT scan, MRI scan, PET scan), and laboratory analysis (i.e., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluation; the date the imaging took place for radiographic assessments, or the date of physical examination.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)