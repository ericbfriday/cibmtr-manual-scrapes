This section refers to quantitative analysis utilizing discriminating DNA markers. Peripheral blood cells must undergo separation or sorting into T, B, or lymphoid vs. myeloid populations to perform this determination. If RFLP analysis indicate only donor type hematopoiesis, mark T-cell, B-cell, and myeloid as “predominantly or completely donor.”

Also, report chimerism in the Form 2100 – 100 days Post-HCT Data or Form 2200 – Six Months to Two Years Post-HCT Data.

#### Questions 167-168: What is the current status of T-cell engraftment?

Reporting the T-cell engraftment requires that the sample is separated into sub-sets for chimerism analysis. T-cell subsets may be reported as CD3+ or CD4+ cells on the laboratory report.

If a T-cell chimerism was performed during the reporting period, indicate if the results showed:


- Predominantly or completely donor (≥80% donor chimerism)
- Mixed chimerism (5-79% donor)
- Only host cells detected (<5% donor)

Report the date of sample collection for the most recent T-cell chimerism in question 168.

If a T-cell chimerism was not performed during the reporting period, report “unknown” and continue with question 169.

#### Questions 169-170: What is the current status of B-cell engraftment?

Reporting the B-cell engraftment requires that the sample is separated into sub-sets for chimerism analysis. B-cell subsets may be reported as CD19+ or CD20+ cells on the laboratory report.

If a B-cell chimerism was performed during the reporting period, indicate if the results showed:


- Predominantly or completely donor (≥80% donor chimerism)
- Mixed chimerism (5-79% donor)
- Only host cells detected (<5% donor)

Report the date of sample collection for the most recent B-cell chimerism in question 170.

If a B-cell chimerism was not performed during the reporting period, report “unknown” and continue with question 171.

#### Questions 171-172: What is the current status of myeloid engraftment?

Reporting myeloid engraftment requires that the sample is separated into sub-sets for chimerism analysis. Myeloid subsets may be reported as CD15+ or CD33+ on the laboratory report.

If a myeloid chimerism was performed during the reporting period, indicate if the results showed:


- Predominantly or completely donor (≥80% donor chimerism)
- Mixed chimerism (5-79% donor)
- Only host cells detected (<5% donor)

Report the date of sample collection for the most recent myeloid chimerism in question 172.

If a myeloid chimerism was not performed during the reporting period, report “unknown” and continue with the signature lines.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)