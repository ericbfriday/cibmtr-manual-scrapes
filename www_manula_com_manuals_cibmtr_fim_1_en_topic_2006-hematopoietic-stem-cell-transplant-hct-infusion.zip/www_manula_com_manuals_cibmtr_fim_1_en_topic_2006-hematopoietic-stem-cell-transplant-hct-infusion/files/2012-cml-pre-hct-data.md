Chronic myelogenous leukemia (CML) is a slow-progressing cancer of the myeloid white blood cells. It is characterized by the increased proliferation of immature white blood cells (granulocytes) with damaged DNA, or blasts, which accumulate in the blood and bone marrow. Normal blasts develop into white blood cells which function to fight infection. The symptoms of CML are caused by the replacement of normal bone marrow with leukemic cells, resulting in a drop in red blood cells, platelets, and normal white blood cells.

The Chronic Myelogenous Leukemia Pre-infusion Data Form is one of the Comprehensive Report Forms. This form captures CML-specific pre-infusion data such as: the recipient’s hematologic and cytogenetic findings at the time of diagnosis and prior to the start of the preparative regimen, pre-infusion treatments administered, and disease status prior to the preparative regimen.

This form must be completed for all recipients whose primary disease, reported on Pre-TED Disease Classification Form (Form 2402), is CML. This includes CML with the following chromosomal abnormalities: Philadelphia chromosome, complex variation and/or variant form, or *BCRABL* gene rearrangement.

This form must be completed for all recipients whose primary disease, reported on Pre-TED Disease Classification Form (Form 2402), is CML. This includes CML with the following chromosomal abnormalities: Philadelphia chromosome, complex variation and/or variant form, or BCR/ABL gene rearrangement. The CML Post-Infusion Data Form must be completed in conjunction with each Post-Infusion Data Form (Form 2100) completed. The post-infusion forms are designed to capture specific data occurring within the timeframe of each reporting period (i.e. between day 0 and day 100 date of contact for the 100 day follow-up, between day 100 date of contact and the six-month date of contact for the six-month follow-up, etc.).

#### Is this the report of a second or subsequent transplant or cellular therapy for the same disease?

Report “no” and go to question 1 in any of the following cases:

- This is the first infusion reported to the CIBMTR;
- This is a second or subsequent transplant for a different disease (e.g., patient was previously transplanted for a disease other than Chronic Myelogenous Leukemia);
- This is a second or subsequent infusion for the same disease subtype and if this baseline disease insert was not completed for the previous transplant (e.g., patient was on TED track for the prior infusion, prior infusion was autologous with no consent, etc.).

If this is a report of a second or subsequent infusion for the same disease and this baseline CML disease insert was completed previously, report “yes” and go to question 186.

Links to Sections of Form:

[Q1-17: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-q1-17)

[Q18-83: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-q18-83)

[Q84-185: Pre-HCT or Pre-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-q84-185)

[Q186-191: Disease Assessment at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-q186-191)

[Q192-252: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-q192-252)

[Q253-256: Disease Status at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-q253-256)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please click [here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/7/2020 | 2012: CML Pre-Infusion Data Form | Add | Clarification added to question to 84 to explain how to report lines of therapy for subsequent infusions: Lines of Therapy and Subsequent InfusionsIf this is a subsequent infusion and a 2012 was completed for the previous infusion, lines of therapy do not need to be reported in duplication on the subsequent 2012. Please report from post previous infusion to time of preparative regimen / infusion for the current infusion. If a 2012 was not previously completed, all lines of therapy from diagnosis to the current preparative regimen / infusion must be completed. |
| 5/24/17 | 2012: CML Pre-Infusion Data Form | Modify | Corrected an error in Table 3 by adding the text in red below to the definition of complex variation. Translocation of three or more chromosomes, one of which must be chromosome 22 [e.g., t( 3; 9; 22)] |
| 1/31/17 | 2012: CML Pre-Infusion Data Form | Add | Version 1 of the 2012: CML Pre-Infusion Data Form section of the Forms Instructions Manual released. Version 1 corresponds to revision 2 of the Form 2012. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)