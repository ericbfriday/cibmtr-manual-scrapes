Tandem Transplants: For recipients receiving a tandem transplant, the current disease status prior to HCT #2 of the tandem depends on the pre-transplant disease status and the best response to the prior transplant (i.e., HCT #1 of the tandem).


- If the recipient was in complete remission at the time of HCT #1 or achieved complete remission prior to HCT #2 of their tandem transplant, the current disease status should be reported as “Complete remission (CR)” (given there is no evidence of relapse / progression disease based on labs / clinical assessments between the tandem HCTs).
- If the recipient was not in complete remission or did not achieve complete remission in response to HCT #1 prior to HCT #2 of their tandem transplant, either “Not in complete remission (NCR)” or “Not evaluated” would be appropriate options; however, ensure the best response to transplant and the current diseases status are answered consistently

#### Question 109: What is the current disease status?

Indicate the disease status of the primary transplant disease as of the last evaluation in the reporting period. Complete remission (CR) criteria vary by disease and are outlined in the CIBMTR Forms Instructions Manual. If the recipient achieves CR or continues in CR at the time of last evaluation in the reporting period, indicate **Complete remission (CR)**. If the recipient is not in CR due to presence of disease on last evaluation in the reporting period or an incomplete evaluation that does not allow for reporting CR, indicate **Not in complete remission**. If the recipient’s disease status was not evaluated post-HCT, check **Not evaluated** and submit the form. This option is **not** commonly used, as this would indicate that **no tests** (radiological, laboratory, or a clinical assessment) were performed to assess the CR status at **any time** during the reporting period.

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

**Example 1:** A recipient with neuroblastoma is not in complete remission prior to transplant, in the 100-day reporting period the recipient receives a tandem transplant. Between HCT 1 and HCT 2 the only disease assessment performed was a clinical evaluation. In this case either option would be appropriate to answer for the current disease status: “Not evaluated” or “Not in complete remission (NCR)” and “no disease detected but incomplete evaluation to establish CR.”. However, we want to ensure the best response and the current disease status are consistent.

**Example 2:** A recipient with neuroblastoma is in complete remission prior to transplant, in the 100-day reporting period the recipient receives a tandem transplant. Between HCT 1 and HCT 2 the only disease assessment performed was a clinical evaluation in which the clinician did not mention progressive or relapsed disease. In this case “Complete remission (CR)” should be reported for the current disease status.

#### Question 110: Specify disease status if not in complete remission

Disease status criteria are generally based upon clinical assessment confirming ongoing presence or absence of disease. However, there are also situations in which an evaluation may have been performed but be incomplete and not have all testing required in order to meet the criteria for reporting complete remission (CR).

For recipients **Not in complete remission**, indicate whether clinical evidence of disease persisted on disease-specific assessments within the reporting period. If all assessments have shown resolution of disease, but not all assessments required to report complete remission have been completed, indicate **No disease detected but incomplete evaluation to establish CR**. This option is also appropriate for scenarios in which the recipient has not previously achieved a post-HCT CR but does not have any disease assessments performed within the reporting period. Indicate **Disease detected** if disease persists by any method of radiological or clinical assessment; persistence of abnormalities by molecular, cytogenetic, or flow cytometry assessments does not constitute “disease detected.”

**Example 1:** A recipient with multiple myeloma goes to transplant in VGPR, without a bone marrow showing < 5% blasts completed prior to transplant. Post-transplant serum and urine electrophoreses and immunofixations are negative. However, no bone marrow biopsy is performed within the 100-day reporting period. In this case, “not in complete remission” should be selected for question the current disease status, and “no disease detected by incomplete evaluation to establish CR” for the specify disease status if not in complete remission question.

**Example 2:** A recipient with AML goes to transplant in primary induction failure. Post-transplant, they recover their counts, but had circulating blasts noted on differential. They expire due to persistent disease with their last CBC performed on their date of death showing circulating blasts. In this case, “not in complete remission” should be selected for the current disease status, and “disease detected” for the specify disease status if not in complete remission question.

**Example 3:** Similar to example 2, a recipient with AML goes to transplant in primary induction failure. They expire on D+11 due to infection and had not engrafted as of that date. Their last CBC showed a WBC of 0.5 × 109/L with no blasts detected on their differential. A bone marrow biopsy was not performed between transplant and the date of death. In this case, “not in complete remission” should be selected for the current disease status, and “no disease detected by incomplete evaluation to establish CR” for the specify disease status if not in complete remission question.

#### Question 111 Date of assessment of current disease status

Report the date of latest clinical / hematologic assessment for the current disease status using the guidelines below:

Report the date of the clinical / hematologic assessment using the guidelines below:


- If the current disease status is
**Complete remission**, report the date of the most disease specific clinical / hematologic or radiologic assessment performed within approximately 30 days of the contact date. - If the current disease status is
**Not in complete remission – disease detected**, report the most recent clinical / hematologic or radiologic assessment performed in the reporting period that detects disease. - If the current disease status is
**Not in complete remission – no disease detected but incomplete evaluation to establish CR**, report the last clinical / hematologic or radiologic assessment performed in the reporting period. - If there are no disease-specific assessments within the reporting period, report the latest assessment in which the recipient was clinically assessed by a physician or midlevel clinician. In this scenario, this date does not need to be consistent with the disease status reported current disease status.

Refer to [General Instructions, General Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates.

**Example 1:** The current disease status for a recipient with non-Hodgkin’s lymphoma is “complete remission.” A PET scan was performed 3 months prior to the contact date showing no evidence of disease and a physician’s exam was performed on the contact date. In this case, the physician’s exam performed on the contact date should be reported as the current disease assessment date since this is the most disease specific clinical / hematologic assessment performed within 30 days of the contact date.

**Example 2:** For a recipient with neuroblastoma, the current disease status is “not in complete remission – disease detected” since disease was still present on the last PET scan. The PET scan was performed 7 months prior to the contact date and a physician’s exam was performed on the contact date – disease cannot be detected by the physician’s exam. The date of the PET scan should be reported as the current disease assessment date since this is the most disease specific clinical / hematologic assessment showing evidence of disease.

**Example 3:** The bone marrow biopsy performed for a recipient with AML still showed > 5% blasts in the bone marrow and therefore, the current disease status is reported as “not in complete remission – disease detected.” The bone marrow biopsy was performed 6 months prior to the contact date and a CBC was performed 2 weeks prior to the contact date – the CBC showed > 5% blasts in the blood. In this scenario, the current disease assessment date should be reported as the date of the CBC as this is the most recent disease specific clinical / hematologic assessment showing evidence of disease.

**Example 4:** A recipient with multiple myeloma had a bone marrow biopsy performed 2 weeks prior to the contact date which showed < 5% plasma cells; however, the last set of myeloma labs performed in the prior reporting period still showed evidence of disease; these labs were not repeated in the current reporting period. On the contact date, a physician’s exam was performed. The current disease status is “not in CR – no disease detected but incomplete evaluation to establish CR” and the current disease assessment date should be reported as the date of the physician’s exam as this is the last clinical / hematologic assessment performed in the reporting period.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)