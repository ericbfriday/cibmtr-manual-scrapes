This section provides an overview of reporting acute GVHD data on the Post-TED (2450) and Post-Infusion Follow-Up (2100) Forms.

### Development vs Persistence of Acute GVHD

This section is intended to provide guidance on when to report **Yes** or **No** for questions asking if acute GVHD developed or persisted.

*Did acute GVHD develop since the date of last report* should be answered as **Yes** in the following scenarios:

- Acute GVHD was diagnosed for the first time during the reporting period.
- An acute GVHD flare was diagnosed during the current reporting period and all the following conditions are met:
- The prior acute GVHD symptoms did not persist from the prior reporting period into the beginning of the current reporting period.
- The flare was diagnosed after at least 30 days without any active acute GVHD symptoms.
- The recipient was not diagnosed with chronic GVHD on or before the date of the flare (review the Diagnosis of Both Acute and Chronic GVHD note box above).


If there is active acute GVHD during the reporting period, but does not match either of the scenarios above, this question will most likely be reported as **No** and acute GVHD will be reported as ‘persistent.’

*Did acute GVHD develop since the date of last report* should be answered as **No** in the following scenarios:

- There were no active acute GVHD symptoms during the current reporting period.
- Acute GVHD symptoms were present in the reporting period, but they continued from the previous reporting period into the current reporting period.
- All acute GVHD symptoms during the current reporting period occurred after the diagnosis of chronic GVHD (review the Diagnosis of Both Acute and Chronic GVHD note box above).

The **Unknown** option should only be used when there is no information about the recipient’s GVHD status for the *entire* reporting period. This option should be used sparingly and only when no judgement can be made about the presence or absence of GVHD in the reporting period.

*Did acute GVHD persist since the date of last report* should be answered as **Yes** in the following scenarios:

- Acute GVHD was diagnosed in a previous reporting period and the acute GVHD symptoms have been active since diagnosis and continue to be active in the current reporting period (i.e., there is no period of symptom resolution or quiescence since diagnosis).
- Acute GVHD symptoms resolved before the first day of the current reporting period, but a flare occurred within 30 days of symptom resolution / quiescence.
- The recipient was not diagnosed with chronic GVHD on or before the date of the flare (review the
[GVHD: General Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-information)for guidance on how to GVHD when acute and chronic GVHD is present).

- The recipient was not diagnosed with chronic GVHD on or before the date of the flare (review the

*Did acute GVHD persist since the date of last report* should be answered as **No** in the following scenarios:

- There were no active acute GVHD symptoms during the current reporting period.
- All acute GVHD symptoms during the current reporting period occurred after the diagnosis of chronic GVHD (review the
[GVHD: General Information](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-information)for guidance on how to GVHD when acute and chronic GVHD is present).

The **Unknown** option should only be used when there is no information about the recipient’s GVHD status for the *entire* reporting period. This option should be used sparingly and only when no judgement can be made about the presence or absence of GVHD in the reporting period.

### Acute GVHD Grading and Staging Criteria

1 Harris AC, Young R, Devine S, et al. International, Multicenter Standardization of Acute Graft-versus-Host Disease Clinical Data Collection: A Report from the Mount Sinai Acute GVHD International Consortium. Biol Blood Marrow Transplant. 2015;22(1):4–10. doi:10.1016/j.bbmt.2015.09.001

When acute GVHD is reported, the organ staging and overall grade, based on the criteria published by Przepiorka et al., *Bone Marrow Transplant* 1995; 15(6):825-8 is reported at two different time points:

- At diagnosis
- The period between onset of signs / symptoms and the start of GVHD treatment (topical or systemic). If acute GVHD is reported as ‘persisted,’ the organ staging and grading at diagnosis data fields are disabled.

- Maximum overall stage and grade
- Intended to capture the maximum organ staging and grading in the current reporting period. The maximum staging does not need to be at the time when the maximum overall grade occurred. Additionally, the maximum organ staging and grading may differ from the stage / grade at diagnosis or may be the same.
- When reporting the maximum grade, the date of the maximum grade is also reported.
- Report the first date when the maximum grade occurred.
- When there are multiple instances when the same maximum grade occurred, report the earliest date.



The ‘maximum overall stage and grade’ is intended to capture the maximum organ staging and grading in the current reporting period. The maximum staging does not need to be at the time when the maximum overall grade occurred. Additionally, the maximum organ staging and grading may differ from the stage / grade at diagnosis or may be the same. These data fields will be answered for every reporting period when acute GVHD is reported.

Acute GVHD Overall Grade

When acute GVHD is reported, either a new development or persistence of GVHD, the overall grade of acute GVHD will be captured. The acute GVHD grading scale is based on *clinical evidence* (clinician observation), not histology. Pathology reports sometimes list a histologic grade of GVHD. Do not report the histologic grade. GVHD scoring and grading is based on clinical severity, not histologic severity. Biopsy of affected organs allows for more precise diagnosis as to the presence or absence of GVHD. However, *overall grading remains clinical* and is based on the criteria published by Przepiorka et al., *Bone Marrow Transplant* 1995; 15(6):825-8 (refer to the Acute GVHD Grading and Staging table below).

If acute GVHD was present, but the grade was not documented and cannot be determined from the grading and staging table, report the overall grade as **Not applicable**. Examples may include:

- Any other organ involvement without skin, liver, or gut symptoms attributable to GVHD.
- Lower GI involvement where the stage cannot be determined in select scenarios. Review the lower GI involvement description below.

**Acute GVHD Grading and Staging Table**


| Stage | Skin | Liver | Gut | |
|---|---|---|---|---|
| 1 | Rash on <25% of skin
|
Bilirubin 2-3 mg/dl
|
Diarrhea > 500 ml/day or persistent nausea
Pediatric: 280-555 ml/m2/day or 10-19.9 mL/kg/day |
|
| 2 | Rash on 25-50% of skin | Bilirubin 3-6 mg/dl | Diarrhea >1000 ml/dayPediatric: 556-833 ml/m2/day or 20-30 mL/kg/day |
|
| 3 | Rash on >50% of skin | Bilirubin 6-15 mg/dl | Diarrhea >1500 ml/dayPediatric: >833 ml/m2/day or > 30 mL/kg/day |
|
| 4 | Generalized erythroderma with bullous formation | Bilirubin >15 mg/dl | Severe abdominal pain, with or without ileus, and / or grossly bloody stool | |
Grade
|
||||
| I | Stage 1-2 | None | None | |
| II | Stage 3 | Stage 1 | Stage 1 | |
| III | — | Stage 2-3 | Stages 2-4 | |
| IV
|
Stage 4 | Stage 4 | — |

1 Use “Rule of Nines” Percent Body Surfaces table below or burn chart to determine extent of rash.

2 Range given as total bilirubin. Downgrade one stage if an additional cause of elevated bilirubin has been documented.

3 Volume of diarrhea applies to adults. For pediatric patients, the volume of diarrhea should be based on body surface area. Downgrade one stage if an additional cause of diarrhea has been documented.

4 Persistent nausea with or without histologic evidence of GVHD in the stomach or duodenum.

5 Criteria for grading given as minimum degree of organ involvement required to confer that grade.

6 Grade IV may also include lesser organ involvement with an extreme decrease in performance status

Acute GVHD Organ Staging

In addition to capturing the overall grade, the staging of each organ involved with acute GVHD is also collected.

**Skin**

The skin stage is based on the percentage of body surface area (BSA) involved with a maculopapular rash, due to acute GVHD. If the skin stage or BSA percentage is not documented within the medical records, the Percent Body Surfaces table (provided below) should be used to determine the BSA percentage involved with the rash. When determining the rash, do not include BSA affected by a rash not related to acute GVHD.

**Percent Body Surfaces Table**


| Body Area | Percent | Total Percentage |
|---|---|---|
| Each Arm | 9% | 18% |
| Each Leg | 18% | 36% |
| Chest & Abdomen | 18% | 18% |
| Back | 18% | 18% |
| Head | 9% | 9% |
| Pubis | 1% | 1% |

**Lower intestinal tract**

The lower GI stage is based on the volume of diarrhea attributed to acute GVHD. For adults, mL / day should be used and for pediatrics, use mL / m2 / day. In addition to reviewing the progress note, the input and output records may be used when determining the volume of diarrhea. Do not include diarrhea not related to acute GVHD.

**Upper intestinal tract**

The stage of upper intestinal tract is based on the presence of persistent nausea or vomiting, related to acute GVHD. When reporting the stage of upper GI involvement, do not include nausea or vomiting not attributed to acute GVHD.

**Liver**

The liver staging is based on elevated bilirubin levels, due to acute GVHD. Transaminitis related to GVHD is not included when determining the liver stage. If there is only isolated transaminitis, do not report acute GVHD occurred. If there is transaminitis and other organs involved (i.e., skin rash), report acute GVHD occurred but do not report there was liver involvement. Additionally, do not include elevated bilirubin not due to acute GVHD.

**Other sites**

If an organ other than skin, upper GI, lower GI, or liver was affected by acute GVHD, the organ will be specified in the ‘other site’ data field. Do not report liver if there was isolated transaminitis. In addition, do not report symptoms ongoing but not attributed to acute GVHD.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)