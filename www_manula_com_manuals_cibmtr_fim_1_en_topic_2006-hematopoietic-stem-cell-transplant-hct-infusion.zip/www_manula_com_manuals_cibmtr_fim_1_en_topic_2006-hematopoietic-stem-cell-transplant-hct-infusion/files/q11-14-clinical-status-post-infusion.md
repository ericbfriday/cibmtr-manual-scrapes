#### Questions 11-12: Specify therapy given for the prevention or treatment of seizures (check all that apply)

Indicate if any of the therapies were given for the prevention or treatment of seizures in the current reporting period. If prevention and / or treatment was given but is not listed in the options provided, select **Other therapy** and specify.

If no therapy was given for the prevention or treatment of seizures during the current reporting period, select **None**.

#### Question 13-14: Were RBC alloantibodies present?

The presence of RBC alloantibodies may cause serologic incompatibility and make the selection of RBC units for future transfusions difficult. RBC alloantibodies are typically present once alloimmunization has occurred.

If RBC alloantibodies are present at any time in the current reporting period, report **Yes** and specify the number of alloantibodies identified. If testing for RBC alloantibodies were performed multiple times in the reporting period, report the most recent assessment.

If RBC alloantibodies were not present at any time in the current reporting period, report

**No**.

Report **Unknown** if testing was not performed, or it is not known if alloantibodies were present in the current reporting period.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)