The Myeloproliferative Neoplasms Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures MPN-specific pre-HCT data such as: disease assessment at diagnosis, laboratory studies at diagnosis, pre-HCT therapy, disease transformation, most recent disease assessments, laboratory studies, and disease status prior to the preparative regimen.

This form must be completed for all recipients who are randomized to the Comprehensive Report Form (CRF) track and whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “Myeloproliferative (MPN) diseases (50) and recipients with AML whose disease progressed from MPN.

Links to Sections of Form:

[Q1: Subsequent Transplant](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-subsequent-transplant)

[Q2-10: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q2-10-disease-assessment-at-diagnosis)

[Q11-40: Diagnostic Studies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q11-40-diagnostic-studies-measured-prior-to-first-disease-treatment)

[Q41-54: DIPSS Prognosis Score](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q41-54-dipss-prognosis-score)

[Q55-212: Pre-HCT / Pre-Infusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q55-212-pre-hct-pre-infusion-therapy)

[Q213-254: Laboratory Studies at Last Evaluation Prior to the Start of the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q213-254-laboratory-studies-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen-infusion)

[Q255-261: Disease Assessment at the Last Evaluation Prior to the Preparative Regimen / Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q255-261-disease-assessment-at-the-last-evaluation-prior-to-the-preparative-regimen-infusion)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text. If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](https://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/28/2023 |
|

*As of June 28, 2023, the ‘cellular therapy’ option within the Pre-Infusion Lines of Therapy section is no longer enabled. Recipients who received a cellular therapy prior to the current infusion is no longer required to be reported as a line of therapy on the pre-infusion disease specific form*[2057: Myeloproliferative Neoplasm (MPN) Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2057-myeloproliferative-neoplasm-mpn-pre-infusion)[2057: Myeloproliferative Neoplasm (MPN) Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2057-myeloproliferative-neoplasm-mpn-pre-infusion)*Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.*

*Enter the date the best response to the line of therapy was established. Report the date of the pathological evaluation (e.g., bone marrow biopsy), or the date of blood/serum assessment (e.g., CBC, peripheral blood smear) used to establish the best response to the line of therapy. Enter the date the sample was collected for pathological and/or laboratory evaluations. If the recipient was treated for extramedullary disease and a radiological assessment (e.g., X-ray, CT scan, MRI scan, PET scan) was performed to assess disease response, enter the date the imaging took place for radiologic assessments. If no pathological, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically assessed the recipient’s response)*[2057: Myeloproliferative Neoplasm (MPN) Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2057-myeloproliferative-neoplasm-mpn-pre-infusion)**Lines of Therapy and Subsequent Infusions***If this is a subsequent infusion and a 2057 was completed for the previous infusion, lines of therapy do not need to be reported in duplication on the subsequent 2057. Please report from post previous infusion to time of preparative regimen / infusion for the current infusion. If a 2057 was not previously completed, all lines of therapy from diagnosis to the current preparative regimen / infusion must be completed.*[2057: MPN Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2057-myeloproliferative-neoplasm-mpn-pre-infusion)**Total Serum Ferritin**Questions 250-252 are disabled and cannot be answered at this time. The total serum ferritin is already captured in the “Comorbid Conditions” section of the Pre-TED (2400) Form (questions 103-106).

[2057: Myeloproliferative Neoplasm (MPN) Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2057-myeloproliferative-neoplasm-mpn-pre-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)