#### Question 143: Is additional post-HCT therapy planned?

If additional post-HCT therapy is planned according to the protocol or standard of care, check **Yes** even if the recipient does not receive the planned therapy. The word “planned” should not be interpreted as: *if the recipient relapses, then the “plan” is to treat with additional therapy*. If additional post-HCT therapy is not planned per protocol, check **No** and submit the form.

#### Questions 144 – 145: Specify post-HCT therapy planned (check all that apply)

Indicate if the options listed on the form are intended to be part of the post-HCT planned therapy according to the protocol or standard of care. Select **Other therapy** for other planned therapies and specify the other therapy.

Examples of when the **Unknown** option would be used include inclusion in a treatment protocol where a trial drug is used and randomized, or if post-HCT therapy is planned, but the specific therapy intended for use is not known pre-HCT.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)