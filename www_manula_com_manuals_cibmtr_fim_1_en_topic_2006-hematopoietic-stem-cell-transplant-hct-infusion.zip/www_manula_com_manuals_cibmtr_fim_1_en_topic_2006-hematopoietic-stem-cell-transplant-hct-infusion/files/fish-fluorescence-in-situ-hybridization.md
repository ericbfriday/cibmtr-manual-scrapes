FlSH is a molecular cytogenetic technique using fluorescent probes that bind to a specific part of a chromosome (i.e., the probes recognize and bind to fragments of DNA). It is a sensitive technique that can assess hundreds of cells per test. The probes are mixed with cells from the tissue sample. A fluorescent “tag” is then used to visualize the binding of the probe to the cells. Probes can identify the number of chromosomes or gene copies within a cell as well as the relative locations of specific genes or chromosome regions. Unlike karyotype assessments, FISH can be done on non-dividing, or interphase, cells. A FISH assessment typically examines between 200 and 500 cells.

Each probe has a specific target or set of targets and is therefore only capable of detecting abnormalities associated with that area. Additionally, the type of probe used affects the interpretation of the results. See Table 1 for descriptions of common categories of FISH probes.

Table 1. FISH Probes


It is important to know what a FISH assessment is testing for before trying to interpret the results. For instance, a probe specific to the p arm of chromosome 9 would not be capable of detecting a deletion anywhere on chromosome 4. In Figure 1 below, two cells were exposed to centromere enumeration probes (CEP) specific to chromosomes 6 and 8 in order to determine the number of each chromosome present. Both cells have two copies of chromosome 6 (green probes) and three copies of chromosome 8 (red probes). This FISH result indicates the presence of a trisomy of chromosome 8.

Figure 1. FISH


Image source: Weisdorf, Daniel J., MD. “Cytogenetics.” 2017 Clinical Research Professionals / Data Management Conference. Orlando. 21 Feb. 2017. Cibmtr.org. Web. 6 Dec. 2017.

### FISH Results

FISH Results

FISH results are usually provided as a percentage or ratio of cells, for which, an abnormality was detected. The result may also be accompanied by a normal range to define when the test is considered positive for the abnormality being assessed. Additionally, the FISH ISCN nomenclature along with the interpretation / impression of the results is also commonly included. When reporting FISH results, review the interpretation / impression section of the report to determine which abnormalities are detected.

Figure 2 is an example FISH report. It includes the identity of each probe, the number of abnormal cells, the normal range, a result for each probe, the ISCN nomenclature, and a final interpretation. The report confirms the TP53 and CEP12 probes detected abnormalities; however, the TP53 probe did not detect an abnormality at a rate above the normal cut off value (7%). The final interpretation indicates these findings represent a gain of chromosome 12 (trisomy).

Figure 2. FISH Results


Image source: Cancer Genetics, INC. “CGI Sample Reports.” Issuu. N.p., 16 Nov. 2013. Web. 11 Dec. 2017. https://issuu.com/cgi201/docs/cgi_sample_reports_booklet/37>.

FISH reports may only refer to a probe by a gene name without indicating the chromosome number / region. For example, the report in Figure 2 could have only specified an ATM probe was used without also indicating the gene location was 11q22.3. It may be necessary, depending on the CIBMTR form, to know the gene location to accurately report the test results. The laboratory performing the study is the best resource for more information about the test that was done. A probe search can also be done using the HUGO Gene Nomenclature Committee’s website genenames.org. This website provides gene symbols, approved names, associated names, and chromosomal locations for many of the probes in current use.

Table 2. Common Genes with Corresponding Chromosome

### Reporting Other FISH Results

The ‘other’ FISH data field is used to report abnormalities detected, but not listed as an option on the form. Abnormalities that should be reported in the ‘other’ specify data field, include, but are not limited to the following:


- Abnormality detected but not listed as a specific option on the form
- Tetrasomies: Four copies of a specific chromosome
- Example: FISH results detect ‘tetrasomy of 9, 11, and 15’
- This abnormality indicates there are four copies of chromosome 9, 11, and 15, which is not the same as +9, +11, or +15, indicating there are three copies of chromosome 9, 11, and 15


- Example: FISH results detect ‘tetrasomy of 9, 11, and 15’
- ‘Monosomy or deletion’ of a specific chromosome: The entire chromosome or part of the chromosome is missing but the exact abnormality is unknown.
- Example: ‘Monosomy 7 or deletion 7’ is detected
- Report this abnormality under ‘other’ and specify ‘Monosomy 7 or deletion 7’


- Example: ‘Monosomy 7 or deletion 7’ is detected
- ‘Trisomy or add’: An extra entire chromosome or part of the chromosome but the exact abnormality is unknown.
- Example: ‘Trisomy 3 or addition 3’ is detected
- Report this abnormality under ‘other’ and specify ‘Trisomy 3 or addition 3’


- Example: ‘Trisomy 3 or addition 3’ is detected

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Reporting Other FISH Results | 4/4/2024 | Add | The Reporting Other FISH Results section added | Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)