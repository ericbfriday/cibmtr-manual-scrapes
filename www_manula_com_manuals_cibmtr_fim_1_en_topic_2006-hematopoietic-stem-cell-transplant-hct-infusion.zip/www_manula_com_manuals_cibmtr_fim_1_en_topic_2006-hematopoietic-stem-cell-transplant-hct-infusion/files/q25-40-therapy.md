#### Question 25 : Did the recipient receive any therapy?

For the initial form, report “Yes” if the recipient received therapy to treat the respiratory virus infection from 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report “Yes” if the recipient received therapy to treat the respiratory virus infection between the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death).

#### Question 26: Antiviral drugs

For the initial form, report “Yes” if the recipient received antiviral drugs for the respiratory virus infection from 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report “Yes” if the recipient received antiviral drugs for the respiratory virus infection between the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death).

If the recipient did not receive antiviral therapy during the specified time window for the form being completed, report “No” and go to question 40.

#### Questions 27-31: Specify antiviral drugs

One instance of questions 27-31 must be completed for each drug administered during the time window indicated in the instructions for question 26.

For each drug given, indicate the specific drug in questions 27-28 and specify the start date in question 29. If the exact start date is not known, but the month and year the drug was started is known, refer to the refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates. If an estimated date is reported, check the “Date Estimated” box next to question 29.

If the antiviral drug specified in questions 27-28 was stopped before the date of evaluation reported on the form (question 41), indicate the date stopped in question 31. If the exact start date is not known, but the month and year the drug was stopped is known, refer to the refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates. If an estimated date is reported, check the “Date Estimated” box next to question 31.

Antiviral Drug Reporting Scenarios:

**A**. The recipient was diagnosed with COVID-19 (SARS-CoV-2) on 3/15/2020, medications given between 3/8/2020 to 3/29/2020 should be reported. If the start date of the drug is prior to 3/8/2020, the start date should be reported as 3/8/2020 as this is within the appropriate time window. Additionally, the check box for “Date Estimated” should be selected, indicating that the true start date was prior to the date reported.

**B**. The recipient was diagnosed with COVID-19 (SARS-CoV-2) on 3/15/2020. It is noted in a clinic progress note dated 3/19/2020 that the recipient was started on Valacyclovir, “a few days ago,” record the start date of the Valacyclovir as 3/19/2020 and select the check box for “Date Estimated.”

#### Question 32-34: IVIG

For the initial form, report “Yes” if the recipient received IVIG therapy for the respiratory virus infection from 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report “Yes” if the recipient received IVIG therapy for the respiratory virus infection between the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death).

Additionally, report “yes” to question 33 if IVIG therapy was started more than 7 days prior to the date of diagnosis in question 1 and then go to question 35. If therapy was not started greater than 7 days prior to the diagnosis date, report “No” and continue with question 34. If the exact date is not known, but the month and year IVIG was started is known, refer to the refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates. If an estimated date is reported, check the “Date Estimated” box next to question 34.

If the recipient did not receive IVIG therapy during the specified time window, report “No” for question 32 and go to question 35.

#### Question 35: Other therapy

For the initial form, report “Yes” if the recipient received any other therapy for the respiratory virus infection from 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report “Yes” if the recipient received any other therapy for the respiratory virus infection between the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death).

If the recipient did not receive any other therapy during the specified time window, report “No” and go to question 40.

#### Questions 36-39: Specify other therapy

One instance of questions 36-39 must be completed for each other therapy administered during the time window indicated in the instructions for question 35.

For each other therapy given, specify the other therapy in question 36 and specify the start date in question 37. If the exact start date is not known, but the month and year the drug was started is known, refer to the refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates. If an estimated date is reported, check the “Date Estimated” box next to question 37.

If the other therapy specified in question 36 was stopped before the date of evaluation reported on the form (question 41), indicate the date stopped in question 39. If the exact start date is not known, but the month and year the drug was stopped is known, refer to the refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates. If an estimated date is reported, check the “Date Estimated” box next to question 39.

#### Question 40: What was the status of the infection?

Report the status of the respiratory viral infection on the date of evaluation for the initial form. If the status of the infection is not documented in the primary care provider’s note summarizing their last evaluation performed, obtain documentation from the provider indicating which option to report. For reporting purposes, the definitions of infection status are:

**Death**: The recipient died prior to the resolution of the infection

**Ongoing**: The infection continues without any signs of significant improvement at present

**Improved**: The recipient remains on treatment to complete a course of therapy, but the signs and symptoms of infection are resolved

**Resolved**: All signs and symptoms are resolved, and the recipient has completed the planned course of treatment for the infection

**Unknown**: The status of the recipient’s infection is unknown

If the infection status is reported as “Ongoing” or “Improved”, complete a follow-up form at the time of infection resolution or death.

#### Question 41: Date of Evaluation

Report the date of evaluation for the status of the infection reported in question 40. The date reported depends on the status of the infection reported in question 40. See Table 1 below for more information:

**Table 1**. Dates of Evaluation to report based on the status of the infection


| Status of Infection (reported in question 40) |
Date of Evaluation to Report |
|---|---|
| Death | Date of death |
| Ongoing | Date of evaluation 14 days after diagnosis |
| Improved | Date of evaluation 14 days after diagnosis |
| Resolved | Date of infection resolution |
| Unknown | N/A (question 41 will not be completed) |

If the exact date of evaluation is not known, but the month and year are known, refer to the refer to General Instructions, General Guidelines for Completing Forms, for information about reporting partial or unknown dates. If an estimated date is reported, check the “Date Estimated” box next to question 41.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)