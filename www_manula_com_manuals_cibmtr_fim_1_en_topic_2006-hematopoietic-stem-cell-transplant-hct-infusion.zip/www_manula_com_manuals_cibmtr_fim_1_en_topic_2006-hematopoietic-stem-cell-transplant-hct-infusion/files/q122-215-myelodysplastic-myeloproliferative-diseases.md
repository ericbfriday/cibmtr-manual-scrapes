The **myelodysplastic syndromes** (**MDS**) are a group of clonal hematopoietic stem cell diseases characterized by cytopenia(s), dysplasia (abnormal growth or development leading to an alteration in size, shape, and organization of the cell) in one or more of the major myeloid cell lines (WBC, RBC, and/or platelets), ineffective hematopoiesis, and an increased risk of developing acute myelogenous leukemia (AML). MDS occurs primarily in older adults, with a median age of 70 years. The majority of recipients present with symptoms related to cytopenias. Most recipients present with anemia requiring RBC transfusions.

Primary or *de novo* MDS occurs without a known history of chemotherapy or radiation exposure. Some inherited hematologic disorders, such as Fanconi anemia, dyskeratosis congenita, Shwachman-Diamond syndrome, and Diamond-Blackfan syndrome are associated with an increased risk of MDS.

#### Question 1: Date of diagnosis of primary disease for HCT / cellular therapy

Report the date of the first pathological diagnosis (e.g., bone marrow or tissue biopsy) of the disease. Enter the date the sample was collected for examination. If the diagnosis was determined at an outside center, and no documentation of a pathological or laboratory assessment is available, the dictated date of diagnosis within a physician note may be reported. Do not report the date symptoms first appeared.

If the recipient’s MDS progressed to from a lower grade MDS to a higher grade MDS, report the diagnosis date of the original MDS diagnosis (i.e., the lower MDS grade). The transformation date (i.e., diagnosis of the higher grade) is captured below.

If the recipient’s MDS transformed to AML prior to HCT, report the diagnosis date of AML and ensure the primary disease for infusion is reported as **AML**. Ensure AML section of the Disease Classification Form is completed appropriately. The MDS diagnosis date is captured below.

If the exact diagnosis date is not known, use the process described in [General Instructions, Guidelines for Completing Forms](%7BTOPIC-LINK+general-guidelines-for-completing-forms)

#### Question 195: What was the MDS subtype at diagnosis?

CIBMTR captures the MDS classification based on the World Health Organization (2022) WHO classification. Indicate the MDS subtype at diagnosis.

Report the most specific entity that applies to the recipient. For example, if the recipient was classified using both defining genetic abnormalities and differentiation, the defining genetic abnormality classification should be reported for classification purposes. Additionally, if the recipient meets the criteria for MDS-5q, MDS-SF3B1, and MDS-biTP53 report the disease subtype as **MDS-biTP53**.

In some cases, disease specific cytogenetic and / or molecular abnormalities are not identified at the initial diagnosis but identified at some point prior to the infusion, report the most disease specific entity. Review the example below for further clarification:


- Example 1: A recipient diagnosed with MDS had only a bone marrow biopsy and karyotyping performed at diagnosis. The bone marrow identified MDS with low blasts and karyotyping was normal. Induction began and additional FISH testing for deletion 5q was completed after starting treatment which identified deletion 5q. The disease classification should be reported as
**Myelodysplastic syndrome with low blasts and isolated 5q deletion**.

#### Question 196: Was documentation submitted to the CIBMTR? *(e.g. pathology report used for diagnosis)*

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 197: Was the disease (MDS) therapy-related?

Agents such as radiation or systemic therapy used to treat other diseases (e.g., Hodgkin lymphoma, non-Hodgkin lymphoma, or breast cancer) can damage the marrow and lead to a secondary malignancy, such as MDS.

If the diagnosis of MDS is therapy-related, select **Yes**. If the diagnosis of MDS is not therapy-related, select **No**. If it is unknown if the MDS is therapy-related, select **Unknown**.

Do not report **Yes** if the recipient developed MDS after an environmental exposure (e.g., exposure to benzene).

#### Question 198: Did the recipient have a predisposing condition?

A predisposing condition contributes to the susceptibility of developing MDS. Therefore, diagnosis of the condition increases the likelihood that the recipient will develop MDS. If the recipient has a documented history of a predisposing condition, select **Yes**. If there is no history of a predisposing condition or if predisposition is unknown, indicate **No** or **Unknown**.

#### Questions 199 – 200: Specify condition

Specify the recipient’s predisposing condition.

**Aplastic anemia**may progress to MDS and/or AML. Aplastic anemia is a broad classification referring to bone marrow failure characterized by pancytopenia and marrow hypoplasia. If aplastic anemia is selected and the recipient is on the CRF track, the Aplastic Anemia Pre-HCT (2028) Form will come due.**Germline CEPBA variant (CEBPA-associated familial AML)**is the presence of a heterozygous germline CEBPA pathogenic variation in an AML patient and/or a family with multiple AML cases.**DDX41-associated familial MDS**is a rare germline heterozygous mutation. DDX41 represents a class of tumor suppressor genes in myeloid neoplasms.**Germline ANKRD26 variant (Thrombocytopenia 2)**is an inherited disorder that causes a mild to moderate decrease in the number of normal platelets leading to uncontrolled bleeding.**Germline ETV6 variant (Thrombocytopenia 5)**is a mutation in hematological precursor cells that lead to leukemia and thrombocytopenia.**Diamond-Blackfan anemia**is a rare genetic disorder that affects the ability of the marrow from producing red blood cells. These recipients may present with anemia, recipients may also exhibit physical abnormalities such as: small head size, cleft lip, webbed neck, defects of the hands and a short stature. Fanconi anemia is a rare genetic blood disorder that prevents the body from producing a sufficient number of new blood cells to function properly. Abnormal blood cells may also be produced. These recipients are short in stature, exhibit skeletal abnormalities, and have an increased risk of developing solid tumors, MDS, and leukemias. If Fanconi anemia is selected and the recipient is on the CRF track, the Fanconi Anemia Pre-HCT (2029) Form will come due.**Fanconi anemia**is a rare genetic blood disorder that prevents the body from producing a sufficient number of new blood cells to function properly. Abnormal blood cells may also be produced. These patients are short in stature, exhibit skeletal anomalies, and have an increased risk of developing solid tumors and leukemias.**Germline GATA2 deficiency**is a rare genetic disorder which can cause a variety of issues including viral and bacterial infections, cytopenias, myelodysplasia, myeloid leukemias, pulmonary alveolar proteinosis and lymphedema.**Germline TP53 variant (Li-Fraumeni syndrome)**is a rare genetic disorder which increases the risk of developing several types of cancers, notably: breast cancer, osteosarcoma, sarcoma, brain tumors and leukemias. Li-Fraumeni syndromes are associated with mutations in the TP53 gene.**Paroxysmal nocturnal hemoglobinuria (PNH)**is a rare genetic disorder of the blood cells. The disease is characterized by destruction of red blood cells. blood clots and impaired bone marrow function. PNH is very closely related and often derives from aplastic anemia. If PNH is selected and the recipient is on the CRF track, the Aplastic Anemia Pre-HCT (2028) Form will come due.**Germline RUNX1 variant**was previously known as “familial platelet disorder with propensity to myeloid malignancies”. Recipients with RUNX1 deficiencies typically present with mild to moderate thrombocytopenia with normal-sized platelets, functional platelets defects leading to prolonged bleeding and an increased risk to develop myelodysplastic syndromes (MDS), acute myeloid leukemia (AML), or T-cell acute lymphoblastic leukemia (T-ALL).*(familial platelet disorder with associated myeloid malignancy, FFD-MM)***SAMD9 variant (MIRAGE Syndrome)**is a rare disorder that results in myelodysplasia, infection, restriction of growth, adrenal hypoplasia, genital phenotypes, and enteropathy.**SAMD9L variant (SAMD9L-related Ataxia Pancytopenia Syndrome)**is a disorder that results in symptoms such as cerebellar ataxia, myelodysplasia, and myeloid leukemia.**Severe congenital neutropenia (SCN)**are germline mutations which can result in a spectrum of multisystem disorders that carry a markedly increased risk of developing myeloid malignancies.**Shwachman-Diamond syndrome (SDS)**is a rare autosomal recessive disorder in which is characterized by exocrine pancreatic insufficiency, bone marrow dysfunction, and skeletal abnormalities.**Telomere biology disorder (including dyskeratosis congenita)**are a complex set of inherited conditions defined by the presence of very short telomeres. Telomere biology disorder can be characterized by bone marrow failure and lung disease.

If the recipient had a predisposing condition not listed above, select **Other condition** and specify the condition.

A list of entities that would fall into the **Other condition** category include: ETV6-related familial thrombocytopenia, ANKRD26-related familial thrombocytopenia, SRP72-related familial aplastic anemia / MDS, MBD4-related familial leukemia, Bloom Syndrome, Noonan Syndrome, Neurofibromatosis, Downs Syndrome, ATG2B/GSKIP duplication (chromosome 14q32.2), MECOM-associated syndrome, Essential thrombocytopenia (ET), and Polycythemia vera (PCV).

#### Question 201: Date CBC drawn

These questions are intended to capture the laboratory studies performed at the diagnosis of MDS. All values reported must reflect testing performed prior to the start of first treatment of the primary disease for HCT. If the recipient’s MDS transformed, report the studies from the original diagnosis.

Report the date the sample was drawn

#### Questions 202 – 203: WBC

Indicate whether the white blood cell (WBC) count was **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Questions 204 – 205: Neutrophils

Indicate whether the neutrophil percentage in the blood was **Known** or **Unknown** at diagnosis. If **Known**, report the neutrophil percentage documented on the laboratory report.

#### Questions 206 – 207: Blasts in the blood

Indicate whether the percent blasts in the peripheral blood is **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory value. If the percent blasts in blood at diagnosis is not known, report **Unknown**. Note, blasts are not typically seen in the peripheral blood. If blasts are NOT reported on the differential, Known and “0%” can still be reported.

#### Questions 208 – 209: Hemoglobin

Indicate whether the hemoglobin was **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Question 210: Were RBCs transfused ≤ 30 days before the date the CBC was drawn?

Transfusions temporarily increase the red blood cell count. It is important to distinguish between a recipient whose body is creating these cells and a recipient who requires transfusions to support the counts.

Indicate if red blood cells were transfused less than or equal to 30 days prior to the date the CBC was drawn as reported above.

#### Questions 211 – 212: Platelets

Indicate whether the platelet count was **Known** or **Unknown** at diagnosis. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Question 213: Were platelets transfused ≤ 7 days before date the CBC was drawn?

Transfusions temporarily increase the platelet count. It is important to distinguish between a recipient whose body is creating the platelets and a recipient who requires transfusions to support the counts.

Indicate if platelets were transfused less than or equal to 7 days prior to the date the CBC was drawn as reported above.

#### Questions 214 – 215: Blasts in bone marrow

Indicate whether the percentage of blasts in the bone marrow was **Known** or **Unknown** at diagnosis. If **Known**, report the percentage documented on the laboratory report.

If multiple methods were used to detect the percentage of blasts in the bone marrow, the aspirate differential is the preferred method; followed by flow cytometry and IHC (immunohistochemical staining).

#### Question 216: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

If no Indicate if cytogenetic studies were obtained at diagnosis. If cytogenetic studies were obtained, select **Yes**.

If cytogenetic studies were not obtained, or it is unknown if chromosome studies were performed, select **No** or **Unknown**, respectively.

#### Question 217: Were cytogenetics tested via FISH?

If FISH studies were performed at diagnosis, report **Yes**.

If FISH studies were not performed at diagnosis, FISH samples were inadequate, or it is unknown if performed, report **No**. See [Appendix C, Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c), for assistance interpreting FISH results.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Question 218: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used to test FISH at diagnosis, the preferred sample source is the bone marrow.

#### Question 219: Results of tests

Specify if FISH abnormalities were detected at diagnosis.

#### Questions 220 – 223: Specify cytogenetic abnormalities (FISH) at diagnosis

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string.

Report the number of abnormalities detected by FISH at diagnosis. After indicating the number of abnormalities, select all abnormalities detected. If a clonal abnormality is detected, but not listed as an option, select **Other abnormality**, and specify the abnormality.

If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 224: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 225: Were cytogenetics tested via karyotyping?

If karyotyping was performed at diagnosis, report **Yes**. Report Yes even if there were no evaluable metaphase cells (these results will be specified below).

If karyotyping was not performed at diagnosis or it is unknown if performed, indicate **No** and continue.

#### Question 226: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If multiple sources were used for karyotyping assessments at diagnosis, the preferred sample source is the bone marrow.

#### Question 227: Results of test

If karyotyping assessments identified abnormalities, indicate **Abnormalities identified**.

If karyotyping assessments yielded **No evaluable metaphases** or there were **No abnormalities identified**, indicate as such.

#### Question 228 – 231: Specify cytogenetic abnormalities (karyotyping) identified at diagnosis

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping at diagnosis. After indicating the number of abnormalities, select all abnormalities detected. If a clonal abnormality is detected, but not listed as an option, select **Other abnormality**, and specify the abnormality.

If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 232: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., FISH report, karyotype report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 233: Did the recipient progress or transform to a different MDS subtype or AML between diagnosis and the start of the preparative regimen / infusion?

Indicate if the recipient’s disease progressed to AML or transformed into a different MDS subtype between initial diagnosis and the start of the preparative regimen / infusion. Approximately one third of MDS cases transform into AML, signifying a poorer prognosis. Progression to AML is defined by an increase in blood or bone marrow blasts equal to or greater than 20%.

MDS subtypes may also transform / progress from one into another. A progression from one subtype of MDS to another indicates that the number of cytopenias, number of blasts, and/or morphology of marrow sufficiently qualified them for a higher grade (i.e., more severe) MDS. For example, an MDS classified as MDS-SLD at diagnosis whose blast count rises to 8% as documented on bone marrow aspirate would have progressed to MDS-EB-1.

Conversely, do not report a progression / transformation if the recipient’s assessments after diagnosis show that they qualify for a lower grade (i.e., less severe MDS). For example, a recipient who is diagnosed with MDS-EB-2, but whose assessments show that they meet the criteria for MDS-EB-1 as a response to treatment, would not qualify as a progression or transformation. In this example, the disease is lower grade (i.e., less severe), rather than a higher grade (i.e., more severe) so it should not be reported as a progression/transformation. See the table below for guidance in determining the severity of MDS progressions and transformations.

**Grade of MDS Progression/Transformations**


Lower Grade |
>>>>>> | >>>>>> | >>>>>> | Higher Grade |
|---|---|---|---|---|
| MDS-SLD / MDS-RS-SLD / MDS-RS-MLD / Childhood MDS | MDS-MLD | MDS-EB-1 | MDS-EB-2 | AML |
| JMML/CMML | — | — | — | AML |

Indicate if the recipient’s disease progressed to AML or transformed from one MDS subtype to another. If the recipient’s disease transformed or progressed, select **Yes**. If there was no documented transformation or progression, select **No**.

#### Question 234: Specify the MDS subtype after transformation

Indicate the recipient’s current MDS subtype after transformation. If the recipient experienced more than one transformation after diagnosis, report the most recent subtype. For a list of MDS subtypes and their diagnostic criteria, see Appendix H.

If the recipient progressed or transformed to **MDS unclassifiable**, specify the MDS-U subtype. If the disease progressed to **AML**, continue with to report the date of MDS diagnosis. If MDS progresses to AML and the recipient is on the CRF track, the Acute Myelogenous Leukemia (AML) Pre-HCT (2010) Form will also come due.

For all other progressions or transformations, continue with to specify the date of the most recent transformation.

#### Question 235: Specify the date of the most recent transformation

Report the date of assessment that determined the most recent disease transformation (i.e., if there were multiple transformations, report the most recent). Report the date of the pathological evaluation (e.g., bone marrow) or blood/serum assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological and laboratory evaluations.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 236: Date of MDS Diagnosis

**If the recipient’s MDS transformed to AML prior to HCT, report the date of diagnosis of MDS.** If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, Guidelines for Completing Forms.

Ensure the date of diagnosis for AML has been reported as the diagnosis date, AML is reported as the primary disease for HCT, and the AML section of the Disease Classification Form has been complete appropriately. Go to the signature line.

#### Question 237: Date CBC drawn

Report the date the CBC was drawn at the last evaluation prior to the start of the preparative regimen / infusion. If multiple assessments were performed, report the most recent assessment prior to the start of the preparative regimen / infusion.

#### Questions 238 – 239: WBC

Indicate whether the white blood cell (WBC) count was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Questions 240 – 241: Neutrophils

Indicate whether the neutrophil percentage in the blood was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the neutrophil percentage documented on the laboratory report.

#### Questions 242 – 243: Blasts in the blood

Indicate whether the percent blasts in the peripheral blood is **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the laboratory value documented on the laboratory report. If the percent blasts in blood at last evaluation is not known, report **Unknown**. Note, blasts are not typically seen in the peripheral blood. If blasts are NOT reported on the differential, **Known** and “0%” can still be reported.

#### Questions 244 – 245: Hemoglobin

Indicate whether the hemoglobin was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Question 246: Were RBCs transfused ≤ 30 days before the date the CBC was drawn?

Transfusions temporarily increase the red blood cell count. It is important to distinguish between a recipient whose body is creating these cells and a recipient who requires transfusions to support the counts.

Indicate if red blood cells were transfused less than or equal to 30 days prior to the date the CBC was drawn as reported above.

#### Questions 247 – 248: Platelets

Indicate whether the platelet count was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the laboratory count and unit of measure documented on the laboratory report.

#### Question 249: Were platelets transfused ≤ 7 days before the date the CBC was drawn?

Transfusions temporarily increase the platelet count. It is important to distinguish between a recipient whose body is creating the platelets and a recipient who requires transfusions to support the counts.

Indicate if platelets were transfused less than or equal to 7 days prior to the date the CBC was drawn as reported above.

#### Questions 250 – 251: Blasts in bone marrow

Indicate whether the percentage of blasts in the bone marrow was **Known** or **Unknown** at the last evaluation prior to the start of the preparative regimen / infusion. If **Known**, report the percentage documented on the pathology report.

If multiple assessments were performed at the last evaluation, report the most recent assessment prior to the start of the preparative regimen / infusion.

#### Question 252: Were cytogenetics tested (karyotyping or FISH)?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Indicate if cytogenetic studies were obtained at the last evaluation prior to the preparative regimen / infusion. If cytogenetic studies were obtained, select **Yes**.

If no cytogenetic studies were obtained, or it is unknown if chromosome studies were performed, select **No** or **Unknown**, respectively.

#### Question 253: Were cytogenetics tested via FISH?

Indicate if FISH studies were performed at the last evaluation prior to the start of the preparative regimen / infusion.

If FISH studies were not performed at the last evaluation prior to the start of the preparative regimen / infusion, FISH samples were inadequate, or it is unknown if performed, report **No**. See [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c), for assistance interpreting FISH results.

Report chromosomal microarrays / chromosomal genomic arrays as FISH assessments.

#### Question 254: Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If FISH studies were performed on multiple samples at the last evaluation prior to the start of the preparative regimen / infusion, the bone marrow results are the preferred sample source to report.

#### Question 255: Results of tests

Specify if FISH abnormalities were detected at the last evaluation.

#### Questions 256 – 259: Specify cytogenetic abnormalities (FISH) at last evaluation prior to the start of the preparative regimen / infusion

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable.

Report the number of abnormalities detected by FISH at the last evaluation prior to the preparative regimen / infusion. After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality. If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 260: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 261: Were cytogenetics tested via karyotyping?

If karyotyping was performed at the last evaluation prior to the preparative regimen / infusion, report **Yes**. Report **Yes** even if there were no evaluable metaphase cells (these results will be specified below).

If karyotyping was not performed at the last evaluation prior to the start of the preparative regimen / infusion or it is unknown, indicate **No**.

#### Question 262 Sample source

Indicate if the sample was from **Bone marrow** or from **Blood**. If karyotyping studies were performed on multiple samples at the last evaluation prior to the start of the preparative regimen / infusion, the bone marrow results are the preferred sample source to report

Question 263: Results of tests

If karyotyping assessments identified abnormalities, indicate **Abnormalities identified**.

If karyotyping assessments yielded **No evaluable metaphases** or there were* No abnormalities identified*, indicate as such.

#### Questions 264 – 267: Specify cytogenetic abnormalities (karyotyping) at last evaluation prior to the stat of the preparative regimen / infusion

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable. Refer to [Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/iscn-functionality) for more information on how to report using the ISCN functionality.

Report the number of abnormalities detected by karyotyping prior to the start of the preparative regimen / infusion. After indicating the number of abnormalities, select all abnormalities detected.

If a clonal abnormality is detected, but not listed as an option, select **Other abnormality** and specify the abnormality. If multiple other abnormalities were detected, report “see attachment” and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 268: Was documentation submitted to the CIBMTR?

Indicate whether documentation was submitted to the CIBMTR (e.g., karyotype report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Question 269: What was the disease status?

Indicate the disease status of MDS at the last evaluation prior to the start of the preparative regimen / infusion.

**Refer to the MDS Response Criteria section of the Forms Instructions Manual for definitions of each disease response.**

#### Question 270: Specify the cell line examined to determine HI status

Indicate the cell line examined to determine hematologic improvement. To determine the cell line, review the Hematologic Improvement criteria listed in the MDS Response Criteria section of the Forms Instructions Manual.

If the cell lines examined to determine hematologic improvement included **Hematologic Improvement – Erythroid (HI-E)**, continue with *Specify transfusion dependence.*

If the cell lines examined to determine hematologic improvement only included **Hematologic Improvement – Platelets (HI-P)** and/or **Hematologic Improvement – Neutrophils (HI-N)**.

#### Question 271: Specify transfusion dependence

If the recipient’s pre-transplant disease status included **Hematologic improvement – Erythroid (HI-E)**, indicate the transfusion dependence at the time of determining disease status at last evaluation prior to start of the preparative regimen / infusion.

Select **Non-transfused (NTD)** if the recipient was without RBC transfusions as supportive care for the disease within a period of 16 weeks prior to the start of the preparative regimen / infusion.

Select **Low-transfusion burden (LTB)** if the recipient had 3-7 RBC transfusions within a period of 16 weeks in at least 2 transfusion episodes with a maximum of 3 RBC transfusions in 8 weeks prior to the start of the preparative regimen / infusion.

#### Question 272: Date assessed

Enter the date of the most recent assessment of disease status prior to the start of the preparative regimen / infusion. The date reported should be that of the most disease-specific assessment within the pre-transplant work-up period (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), and laboratory assessment (e.g., CBC, peripheral blood smear), in addition to clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations; enter the date the imaging took place for radiographic assessments.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q195 | 1/24/2025 | Add | Myelodysplastic/myeloproliferative neoplasm with neutrophilia and Disease Status added: Myelodysplastic/myeloproliferative neoplasm with neutrophilia and Disease Status: As of October 2024, atypical CML is captured as an MDS and the disease classification is reported as Myelodysplastic/myeloproliferative neoplasm with neutrophilia. The disease status for Myelodysplastic/myeloproliferative neoplasm with neutrophilia will be reported in the Other Leukemia section of the form. |
Added for clarification |
| Q198 | 1/24/2025 | Add | ET or PCV to MDS Transformation blue box added above Q198: ET or PCV to MDS Transformation: In the rare event MDS transformed from ET or PCV, report Yes there was a predisposing condition, the condition as Other condition and specify as ET or PCV. Do not report there was a disease transformation below. |
New instructions |
| Q199 | 1/24/2025 | Add | ET and PCV added as possible other predisposing conditions to report: A list of entities that would fall into the Other condition category include: ETV6-related familial thrombocytopenia, ANKRD26-related familial thrombocytopenia, SRP72-related familial aplastic anemia / MDS, MBD4-related familial leukemia, Bloom Syndrome, Noonan Syndrome, Neurofibromatosis, Downs Syndrome, ATG2B/GSKIP duplication (chromosome 14q32.2), MECOM-associated syndrome , Essential thrombocythemia (ET), Polycythemia vera (PCV). |
New instructions |
| Q201 | 4/19/2025 | Add | ET or PCV to MDS Transformation and Disease Assessments at Diagnosis blue note box added: ET or PCV to MDS Transformation and Disease Assessments at Diagnosis: If MDS transformed from ET or PCV, report assessments from the time of the MDS transformation. Do not report assessments from the time of ET or PCV diagnosis. |
Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)