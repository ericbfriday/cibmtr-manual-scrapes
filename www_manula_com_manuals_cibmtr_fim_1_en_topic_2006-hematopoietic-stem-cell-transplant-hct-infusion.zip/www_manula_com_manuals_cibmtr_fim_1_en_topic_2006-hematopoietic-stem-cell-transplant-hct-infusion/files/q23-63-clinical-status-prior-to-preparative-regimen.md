#### Questions 30 – 31: Was enzyme activity and/or enzyme substrate tested?

Indicate if the recipient was tested for enzyme activity and / or enzyme substrate prior to the start of the preparative regimen / infusion. The type of testing performed is specific to leukodystrophy subtype. Types of testing can include enzyme assays, urine testing, etc.

If the recipient’s enzyme activity and / or enzyme substrate was tested, select **Yes** and report the date (YYYY-MM-DD) of testing. If testing is performed multiple times, report the most recent date and results prior to the start of the preparative regimen / infusion.

If the exact date is not known, use the process described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the enzyme activity and / or enzyme substrate was not tested prior to the start of the preparative regimen / infusion or it is unknown if testing occurred, select **No** or **Unknown**, respectively and continue with *Was the total neurologic function scale (NFS) score obtained*.

#### Questions 32 – 33: Recipient result

Indicate whether the results of the recipient’s enzyme activity and / or enzyme substrate testing were **Normal** or **Abnormal** and if documentation was submitted to CIBMTR (CIBMTR recommends attaching the enzyme / storage activity testing).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 34 – 35: Was the total neurologic function scale (NFS) score obtained? (ALD recipients only)

The total neurologic function scale (NFS) is a 25-point scale used to assess severity of neurological dysfunction and is done by scoring 15 disabilities.

Indicate **Yes** or **No** if a NFS score was obtained prior to the preparative regimen / infusion. This information will be documented within a physician’s note.

If a total NFS score was obtained, select **Yes**, and report the date (YYYY-MM-DD) of assessment. If the total NFS was obtained multiple times prior to the preparative regimen / infusion, report the date and results of the most recent assessment.

If the exact date is not known, use the process described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the total NFS score was not obtained prior to the preparative regimen / infusion or it is not known if a score was obtained, select **No**, and continue with *Is there a history of seizures attributed to the underlying disease at any time prior to the preparative regimen*.

#### Question 36: Specify total neurologic function scale score

Report the total neurologic function scale (NFS) score as documented by the physician. The total NFS score will be a value between 1-25.

If the NFS score is not known and only the domain clinical scores are documented, leave this data field blank.

#### Questions 37 – 52: Select known domain clinical score(s) (check all that apply)

Select the known domain clinical score(s) and report the score(s) as documented by the physician.

**Hearing / auditory processing problems:**Trouble with hearing.**Aphasia / apraxia:**Speech disorder / impairment.**Loss of communication:**Loss of the ability to communicate.**Vision impairment / fields cut:**Reduced field of vision.**Cortical blindness:**Total or partial loss of vision due to damage to the occipital cortex.**Swallowing difficulty or other central nervous system dysfunction:**Dysphagia due to damage of the nervous system.**Tube feeding:**Percutaneous endoscopic gastrostomy (PEG), esophagogastroduodenoscopy (EGD), or G-tube insertion.**Running difficulties / hyperreflexia:**Muscles are less responsive to stimuli. Causing trouble holding, running, driving etc.**Walking difficulties / spasticity / spastic gait (no assistance):**Trouble walking, and / or abnormal muscle tightness due to prolonged muscle contractions.**Spastic gait (needs assistance) wheelchair required:**Stiff, often foot dragging walk, due to prolonged muscle contractions on one side. Assistance with wheelchair required.**No voluntary movement:**Absence of voluntary movements such as moving fingers, toes, sitting upright, etc.**Episodes or urinary or fecal incontinency:**Loss of bladder and / or bowel control with episodes of any urinary or bowel incontinence.**Total urinary or fecal incontinency:**Total loss of bladder and / or bowel control. This will require continuous use of a catheter.**Nonfebrile seizures:**A single, uncontrolled electrical activity in the brain, which may produce a physical convulsion, minor physical signs, thought disturbances or a combination of symptoms. Nonfebrile seizures are characterized as spontaneous recurrent seizures unrelated to fever.

If only the total NFS score is known and not the domain clinical scores, leave these questions blank.

#### Question 53: Is there a history of seizures attributed to the underlying disease at any time prior to the preparative regimen?

Indicate **Yes** if there was a history of seizures attributed to the underlying disease at any time prior to the preparative regimen / infusion. If there was no history of seizures attributed to the underlying disease or it is not known, indicate **No**, and continue with *Was cerebrospinal fluid (CSF) testing done prior to the preparative regimen*.

#### Question 54: Were any of the seizures considered nonfebrile?

Report **Yes** if any of the seizures prior to the preparative regimen / infusion were considered nonfebrile (spontaneous recurrent seizures unrelated to fever). If all seizures prior to the start of the preparative regimen / infusion were febrile, select **No**.

#### Questions 55 – 56: Was cerebrospinal fluid (CSF) testing done prior to the preparative regimen?

Indicate if cerebrospinal fluid (CSF) testing was completed prior to the preparative regimen / infusion. CSF is collected via lumbar puncture or spinal tab.

If testing was performed, select **Yes** and report the date (YYYY-MM-DD) of the most recent CSF testing.

If the exact date is not known, use the process described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If CSF testing was not performed prior to the preparative regimen / infusion or it is not known, select **No** or **Unknown**, respectively and continue with *Date of most recent magnetic resonance imaging (MRI) prior to the preparative regimen*.

#### Questions 57 – 59: Specify known CSF result(s) (check all that apply)

Report the known CSF results.

**Opening Pressure:**Opening pressure is measured during the lumbar puncture; this is a measurement of intracranial pressure. If the opening pressure is known, select this option and report the opening pressure value.

**Total Protein:**Total protein is a measurement used to determine the levels of protein in cerebrospinal fluid. If the total protein is known, select this option and report the CSF total protein value.

In the rare case where neither the opening pressure or the total protein was known, leave Specify known CSF result(s) blank, override the validation error using the code “unknown,” and continue with Date of most recent magnetic resonance imaging (MRI) prior to the preparative regimen.

#### Question 60: Date of most recent MRI prior to the preparative regimen

Magnetic resonance imaging (MRI) is an imaging technique used to form pictures of the anatomy and the physiological processes of the body. MRIs are used to assess recipient’s with leukodystrophy.

Report the date (YYYY-MM-DD) of the most recent MRI performed prior to the preparative regimen / infusion.

If the exact date is not known, use the process described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 61: Specify MRI results

Specify the results of the most recent MRI performed prior to the start of the preparative regimen / infusion. Indicate if the results were **Normal** or **Abnormal** as determined by the radiologist or physician.

#### Questions 62 – 64: Was gadolinium contrast used for this assessment?

Gadolinium contrast is often used in MRI assessments to enhance imagining, improving the visibility of inflammation, blood vessels and blood supply.

If gadolinium contrast was used, select **Yes** and indicate if gadolinium enhancement was reported. If gadolinium contrast was used, gadolinium enhancement will be noted in the MRI report and can be suggestive of abnormalities. Additionally, specify if a copy of the MRI report is attached in FormsNet3SM (CIBMTR recommends attaching the MRI report).

If gadolinium contrast was not used in the MRI assessment, select **No** and continue with *Was documentation submitted to the CIBMTR*.

For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 65-66: Were nerve conduction velocities tested at any time prior to the preparative regimen?

Nerve conduction velocity (NCV) testing measures how quickly an electrical impulse moves through the nerve and can identify nerve damage. This procedure is typically performed by a neurologist.

Indicate if NCV testing was performed at any time prior to the preparative regimen / infusion. If **Yes**, report the date (YYYY-MM-DD) of the most recent testing. If NCV testing was not done or it is unknown, report **No** or **Unknown**, respectively and continue with Was a neurocognitive test administered at any time prior to the preparative regimen.

#### Questions 67-68: Specify Results

Report whether the results of the recipient’s NCV testing were **Normal** or **Abnormal**. Additionally, indicate if documentation was submitted to CIBMTR (CIBMTR recommends attaching the nerve conduction velocities tests).

The results of the NCV test may be found in the procedure / results report or in the neurologist’s note. For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 69-71: Was a neurocognitive test administered at any time prior to the preparative regimen?

A neurocognitive test is an assessment completed by a neuropsychologist, used to assess the cognitive function of a recipient. Indicate if a neurocognitive test was administered at any time prior to the preparative regimen / infusion. This information will be found within a progress note by the neuropsychologist.

If neurocognitive testing was performed, indicate **Yes**, and report the date (YYYY-MM-DD) of the most recent assessment. Specify if documentation of mental development neurocognitive testing was submitted to the CIBMTR. It is highly encouraged to attach this assessment / documentation. Additionally, complete the Neurocognitive Assessment (3503) Form.

If testing was not done or it is unknown, indicate **No** or **Unknown**, respectively and continue to the signature line.

For instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 69 | 3/6/2025 | Add | New blue note box above question 69: Neurocognitive Assessment (3503) Form: The Neurocognitive Assessment Form will only come due for recipients enrolled in CIBMTR study CS20-51 when a neurocognitive test was administered. | Clarifying the Neurocognitive Assessment (3503) Form is currently only for CIBMTR study CS20-51 |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)