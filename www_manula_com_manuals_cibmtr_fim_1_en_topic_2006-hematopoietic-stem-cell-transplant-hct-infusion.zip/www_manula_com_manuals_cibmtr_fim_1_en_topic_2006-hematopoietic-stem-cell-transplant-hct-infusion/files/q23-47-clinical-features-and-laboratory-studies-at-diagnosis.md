#### Question 23: Anemia (Hgb < 9 g/dL):

Indicate if the recipient had anemia at diagnosis or prior to the start of treatment for HLH. Anemia is defined as hemoglobin less than 9 g/dL. Select “yes,” “no,” or “unknown.”

#### Question 24: Degranulation assay of NK cells (as defined by local laboratory):

Degranulation in natural killer (NK) cells is the process by which NK cells release granules containing chemicals (perforin and granzymes) that are used to destroy targeted cells. In some subtypes of FHL (FHL3, 4, and 5), degranulation of NK cells is absent or abnormally low. A granule release assay (GRA) can be used to assess the degranulation indirectly by measuring the expression of CD107a on the cell surface following stimulation. 1 This expression is only detectable when the granules fuse with the cell membrane, thus the absence of CD107a by GRA would indicate a defect in some part of NK degranulation. Indicate if the results of the degranulation assay of NK cells were “normal,” “abnormal,” or “unknown” at diagnosis.

1 Gholam C, Grigoriadou S, Gilmour KC, Gaspar HB. Familial haemophagocytic lymphohistiocytosis: advances in the genetic basis, diagnosis and management. *Clin Exp Immunol*. 2011;163(3):271-83.

**Question 25: Fever (> 38.5° C or > 101.3° F for > 7 days within 1 week of diagnosis):**

Indicate if the recipient had fever at diagnosis for HLH. The fever should last more than 7 days and be within 1 week of diagnosis. Fever is defined as a temperature above 38.5° C (101.3° F) for more than 7 days within 1 week of diagnosis. Select “yes,” “no,” or “unknown.”

#### Question 26: Hepatomegaly (liver edge palpable > 3 cm below right costal margin):

Indicate if the recipient had hepatomegaly (enlargement of the liver) at diagnosis or prior to the start of treatment for HLH. Hepatomegaly is defined by the palpability of the liver edge 3 cm or more below the right costal margin. Indicate “yes,” “no,” or “unknown.”

#### Questions 27-28: Serum ferritin:

Indicate if the serum ferritin level was known at diagnosis or prior to the start of treatment for HLH. If “known,” indicate the value in question 28. If “unknown,” continue with question 29.

#### Questions 29-30: Triglycerides:

Indicate if the triglyceride level was known at diagnosis or prior to the start of treatment for HLH. If “known,” indicate the value in question 30. If “unknown,” continue with question 31.

#### Questions 31-32: Fibrinogen antigen assay (factor I; fibrinogen activity; functional fibrinogen; fibrinogen antigen):

Fibrinogen levels may be low in patients with HLH. Indicate if a fibrinogen antigen assay (factor 1; fibrinogen activity; functional fibrinogen; fibrinogen antigen) level was known at diagnosis or prior to the start of treatment for HLH. If “known,” indicate the value (and corresponding unit) in question 32. If “unknown,” continue with question 33.

#### Question 33: NK cell function:

NK cell function is measured by a cytotoxicity assay. NK cell function (cytotoxicity) may be absent or reduced in those with HLH. Indicate the NK cell function at diagnosis or prior to the start of treatment for HLH; select “absent (≤ 10% lower limit of normal),” “decreased (11-50% lower limit of normal),” “normal,” or “unknown.”

#### Question 34: Neutropenia (ANC < 1.0 × 109/L):

Indicate if the recipient was neutropenic at diagnosis or prior to the start of therapy for HLH. Neutropenia is defined as an absolute neutrophil count (ANC) less than 1.0 × 109/L. Indicate “yes,” “no,” or “unknown.”

#### Question 35: Soluble interleukin-2 receptor alpha chain (sCD25): (As defined by local laboratory)

The presence of soluble interleukin-2 receptors (soluble IL-2R, sCD25) in the plasma indicates the activation of T cells. Elevated soluble IL-2R is indicative of prolonged T-cell activation, indicating a protracted immune response. Levels of soluble IL-2R differ based on age, so using age-based reference ranges is helpful to identify abnormal results 2 Indicate the soluble IL-2R alpha chain level at diagnosis or prior to the start of therapy for HLH. The results of the test should be reported as defined by the local laboratory. Indicate if the soluble IL-2R alpha chain level was “normal,” “elevated,” or “unknown.”

2 Zhang K, Filipovich AH, Johnson J, et al. Hemophagocytic Lymphohistiocytosis, Familial. 2006 Mar 22 [Updated 2013 Jan 17]. In: Pagon RA, Adam MP, Bird TD, et al., editors. GeneReviews™ [Internet]. Seattle (WA): University of Washington, Seattle; 1993-2013.Accessed at: [http://www.ncbi.nlm.nih.gov/books/NBK1444/](http://www.ncbi.nlm.nih.gov/books/NBK1444/) on October 3, 2013.

#### Question 36: Splenomegaly (spleen palpable > 3 cm below left costal margin):

Indicate if the recipient had splenomegaly (enlargement of the spleen) at diagnosis or prior to the start of treatment for HLH. Splenomegaly is defined by the palpability of the spleen edge 3 cm or more below the left costal margin. Indicate “yes,” “no,” or “unknown.”

#### Question 37: Thrombocytopenia (platelets < 100 × 109/L):

Indicate if the recipient was thrombocytopenic at diagnosis or prior to the start of therapy for HLH. Thrombocytopenia is defined as a platelet count less than 100 × 109//L. Indicate “yes,” “no,” or “unknown.”

#### Question 38: Neopterin level:

The measurement of neopterin in the cerebrospinal fluid (CSF) is useful to determine immune system activity. Indicate the neopterin level in the CSF at diagnosis or prior to the start of therapy for HLH. Indicate “normal” or “elevated.” “Elevated” indicates levels above the upper limit of normal for the laboratory processing the specimen. If an assessment of neopterin levels in the CSF was not done at diagnosis or prior to the start of therapy for HLH, select “not done.”

#### Question 39: Protein:

Indicate the protein level in the cerebrospinal fluid (CSF) at diagnosis or prior to the start of therapy for HLH. Indicate “normal” or “elevated.” “Elevated” indicates levels above the upper limit of normal for the laboratory processing the specimen. If an assessment of protein levels in the CSF was not done at diagnosis or prior to the start of therapy for HLH, select “not done.”

#### Question 40: WBC count:

Indicate the WBC count in the cerebrospinal fluid (CSF) at diagnosis or prior to the start of therapy for HLH. Indicate “normal” if there were less than or equal to 5 cells/μL in the CSF. Indicate “elevated” if there were greater than 5 cells/μL in the CSF. If an assessment of WBC count in the CSF was not done at diagnosis or prior to the start of therapy for HLH, select “not done.”

#### Questions 41-47: Specify the site(s) where hemophagocytosis was documented at diagnosis:

Indicate the site(s) where hemophagocytosis was present at diagnosis or prior to the start of any therapy for HLH. Hemophagocytosis is the process in which a phagocyte engulfs red blood cells, white blood cells, or platelets. Hemophagocytosis is a characteristic of HLH, but does not need to be present for diagnosis; it is one of eight criteria of which five must be met. Select “yes” or “no” for each question, ensure that no question is left blank. If a site is not listed but hemophagocytosis was present, select “yes” for question 46 (“other site”) and specify the site using question 47.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)