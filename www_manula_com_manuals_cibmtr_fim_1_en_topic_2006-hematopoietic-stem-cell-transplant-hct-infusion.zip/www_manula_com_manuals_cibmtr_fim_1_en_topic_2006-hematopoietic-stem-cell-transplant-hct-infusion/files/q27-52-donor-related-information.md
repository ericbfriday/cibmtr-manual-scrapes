#### Questions 27 – 29: What is the donor’s beta-globin disease genotype?

Specify the donor’s beta-globin genotype. If the donor has a normal genotype (i.e., the beta mutation is not detected), select **B / B**.

If the donor’s beta-globin genotype is not listed, select **Other genotype** and specify the other beta-globin genotype.

If the donor’s Beta thalassemia disease genotype is not known, select **Unknown**.

Additionally, indicate whether documentation of the donor’s beta-globin genotype was submitted to CIBMTR (e.g., pathology report, laboratory report).

For further instructions on how to attach documents in FormsNet3SM, refer to the T[raining Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 30 – 32: What is the donor’s alpha-globin genotype?

Specify the donor’s alpha-globin genotype. The ‘ – ‘ represents the number of genes deleted (i.e., ‘ – – / aa‘ signifies two gene deletions, ‘- – / a-‘ signifies three gene deletions).

If the donor has a normal alpha-globin genotype (i.e., the alpha-globin mutation is not detected), select **aa / aa**.

If the donor’s alpha-globin genotype is not listed, select **Other genotype** and specify the other alpha-globin genotype.

If the donor’s alpha-globin genotype is not known, select **Unknown**.

Additionally, indicate whether documentation of the donor’s alpha-globin genotype was submitted to CIBMTR (e.g., pathology report, laboratory report).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 33 – 35: Hemoglobin (for donor)

Hemoglobin is a molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level.

Specify if the donor’s hemoglobin is known prior to harvesting of stem cells for infusion. If the donor’s hemoglobin is **Known**, report the most recent value and units of measurement prior to collection of stem cells. In addition, indicate if the donor received red blood cell transfusion(s) within 30 days prior to testing.

#### Questions 36 – 37: Mean corpuscular volume (MCV) (for donor)

Mean corpuscular volume (MCV) measures the average size of red blood cells.

Specify if the donor’s MCV is known prior to harvesting of stem cells for infusion. If **Known**, report the most recent value and units of measurement prior to collection of stem cells.

#### Questions 38 – 39: Was hemoglobin electrophoresis performed for the donor? (do not include results if an RBC transfusion occurred within 4 weeks of the electrophoresis study)

Specify if hemoglobin electrophoresis was performed for the donor at any time prior to the start of the preparative regimen / infusion. If a hemoglobin electrophoresis assessment was not performed or it is not known if performed, select **No** or **Unknown**, respectively and continue with Were any red blood cell (RBC) transfusion administered?

If hemoglobin electrophoresis was performed but the donor received RBC transfusions within four weeks of the electrophoresis study, select **Not applicable** and continue with Were any red blood cell (RBC) transfusion administered?

If **Yes**, report the date (YYYY-MM-DD) of the hemoglobin electrophoresis test. If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

If multiple hemoglobin electrophoresis assessments were performed prior to the start of the preparative regimen / infusion, report the date of the most recent assessment.

#### Questions 40 – 52: Specify the hemoglobin allele types based on the sample tested in question 39

For each hemoglobin type listed, indicate if the specific hemoglobin was assessed on the sample date reported above. If **Yes**, report the hemoglobin percentage. If a hemoglobin type was assessed but is not listed, select **Yes** for *Other thalassemia related hemoglobin allele type*, specify the type and the hemoglobin percentage.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)