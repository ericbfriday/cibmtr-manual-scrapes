#### Question 2: Best response for target lesion

The intent of this question is to determine the best overall response to infusion for the **target** lesion.

When evaluating the best response, determine the disease status within the reporting period using the [RECIST criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/recist-criteria) for target lesions. Compare this response to all previous post-infusion reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period.

Select **Previously reported** when the best response to infusion was established in a previous reporting period.

Select **Not evaluable** when no imaging / measurement is done at all at a particular timepoint, or a subset of lesion measurements are made at an assessment.

#### Question 3: Date of best response for target lesion

Report the first date when the best response for the **target** lesion occurred. This date should be the earliest date when all RECIST criteria for the response reported above were met. Report the date of imaging (e.g. x-ray, CT, MRI).

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 4: Best response for non-target lesion(s)

The intent of this question is to determine the best overall response to infusion for the **non-target** lesion(s).

When evaluating the best response, determine the disease status within the reporting period using the [RECIST criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/recist-criteria) for non-target lesions. Compare this response to all previous post-infusion reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period.

Select **Previously reported** when the best response to infusion was established in a previous reporting period.

Select **Not evaluable** when no imaging / measurement is done at all at a particular timepoint, or a subset of lesion measurements are made at an assessment.

Select **Not applicable** if there are no non-target lesions.

#### Question 5: Date of best response for non-target lesion(s):

Report the first date when the best response for the **non-target** lesion(s) occurred. This date should be the earliest date when all RECIST criteria for the response reported above were met. Report the date imaging (e.g. x-ray, CT, MRI).

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)