#### Questions 62 – 69 Provide laboratory studies at diagnosis

For each value below, indicate if the result was **Known** or **Not known** at diagnosis. If the value is **Known**, specify the value and the units of measurement, taking care to convert them to a unit available on the form, if necessary.


- WBC: The white blood cell count is a value that represents all of the white blood cells in the blood. If the count is too high or too low, the ability to fight infection may be impaired.
- Hemoglobin (untransfused): Hemoglobin is a molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level. Report a hemoglobin value from diagnosis without supported blood transfusions. If there is no hemoglobin value available without transfusions report
**Not known**. - Platelets (untransfused) : Platelets are formed elements within the blood that help with coagulation. A low platelet count, called thrombocytopenia, may lead to easy bleeding or bruising. Thrombocytopenia may require platelet transfusions. Report a platelet count from diagnosis without supported transfusions. If there is no platelet count available without transfusions report
**Not known**. - Hematocrit: The hematocrit is the percentage (sometimes displayed as a proportion) of red blood cells relative to the total blood volume. A low hematocrit may require red blood cell transfusions or growth factors.

#### Questions 70 – 83: Specify the following tumor marker analyses performed at diagnosis

Tumor markers, also known as biomarkers, are substances produced by cancer tissue or by the body in response to cancer at higher than normal levels. In certain situations, these substances can be used to detect and monitor disease due to their elevated presence in blood, urine, and/or tissue. The substances listed below have been identified as potential tumor markers for neuroblastoma.

For each substance, indicate if tumor marker analyses were performed at diagnosis. If the analysis was performed, select **Known**, specify the value. If the analysis was performed and the value not known or it is unknown if performed, select **Not known**.


- Homovanillic acid (HVA): Catecholamines (e.g. epinephrine/adrenaline) are secreted as hormones from the adrenal medulla. Neuroblastomas typically produce excessive levels of these catecholamines. After catecholamines are secreted they are broken down into metabolites including Homovanillic acid (HVA) and Vanillylmandelic acid (VMA). Both HVA and VMA are excreted in the urine. As a result, elevated levels of HVA and VMA detected by urinary analysis can be indicative of neuroblastoma.
- Neuron specific enolase (NSE): A glycolytic enzyme (enolase) specific to neuronal-type tissues. NSE may be excessively expressed by neuroblastomas and indicative of disease.
- Serum ferritin: Ferritin is a blood protein that contains iron. A ferritin level indicates how much iron a person’s body is storing. If the ferritin level is lower than normal, it indicates the body’s iron stores are low (iron deficiency). If the ferritin level is higher than normal it could indicate hemochromatosis, a condition that causes the body to store too much iron. Other causes of an elevated ferritin level include liver disease, acute and chronic inflammatory conditions, malignancy (neuroblastoma) to name a few.
- Vanillylmandelic acid (VMA): Both HVA and VMA are excreted in the urine. As a result, elevated levels of HVA and VMA detected by urinary analysis can be indicative of neuroblastoma.
- LDH: Lactate dehydrogenase is an enzyme found in the cytoplasm of almost all tissues, which converts L-lactate into pyruvate, or pyruvate into L-lactate depending on the oxygen level. For some diseases, high levels indicate active disease (e.g., lymphoma, multiple myeloma and neuroblastoma).
- Other tumor marker analysis: If testing for a tumor marker was performed at diagnosis and is not listed above, select
**Known**, and specify the other tumor marker, value and units of measurements in questions 82 – 83. Examples of other testing can include Chromogranin A (CgA) or Neuropeptide Y (NpY

#### Question 84: Was a DNA analysis performed at diagnosis?

DNA analysis is useful in further characterizing neuroblastoma and can provide prognostic and therapeutic value. Types of DNA analysis include ploidy testing to measure total cell DNA, detecting the presence of proto-oncogenes, and quantifying amplification.

Indicate if DNA analysis was performed at diagnosis (at the time the diagnosis of neuroblastoma was established). If **Yes**, continue with question 85. If **No** or **Unknown**, continue to question 101.

#### Questions 85 – 88: Specify the tissue(s) analyzed

Indicate **Yes** or **No** if DNA analysis was performed on the bone marrow or the first-degree tumor (primary tumor) at diagnosis. If DNA analysis was performed at diagnosis on a tissue type other than bone marrow or first-degree tumor, select **Yes** for “other tissue” in question 87 and specify tissue in question 88.

#### Questions 89 – 92: Specify ploidy

Ploidy refers to the number of chromosome sets in a cell. Examples of ploidy includes the modal number and the DNA index. Karyotyping is a technique often used to determine a cell’s ploidy and proliferative activity while flow cytometry may measure the DNA index.

The modal number is the number of chromosomes present. A normal diploid cell has two sets of chromosomes or 46 total chromosomes. The “46” is the modal number.

The DNA index is a ratio between the DNA content of a normal cell (1) and a tumor cell (occasionally differing from 1) dictated via flow cytometry. See Figure 1 below for an example of a DNA index within a flow cytometry report.

Figure 1. DNA index in a flow cytometry report.


For questions 89 – 92, indicate if the modal number and the DNA index is **Known** or **Not known** at diagnosis. If **Known**, specify the value.

#### Questions 93 – 99: Specify any methods used to determine the presence of proto-oncogenes

Proto-oncogenes are normal genes that typically encode proteins with regulatory roles in cell growth and cell death. When proto-oncogenes are altered, they can contribute to cancer. N-myc and trk A are proto-oncogenes associated with neuroblastoma. This is often assessed by Fluorescence in situ hybridization (FISH) analysis.

N-myc amplification: N-myc is an oncogene that encodes for the n-myc protein. This proto-oncogene amplification is often associated with poor prognosis / outcomes for neuroblastoma. Indicate whether N-myc amplification was **Known** or **Not known** at the time of diagnosis. If **Known**, indicate **Yes** or **No** if proto-oncogenes were detected in question 94 and specify the copy number.

If N-myc amplification was not assessed or it is unknown if assessed, report **Not known** continue with question 96.

Trk A expression: Trk A is a protein that is encoded is encoded by the NTRK1 gene. Expression of this protein in tumors is often associated with a favorable prognosis / outcome. Indicate whether trk A expression was **Known** or **Not known** at the time of diagnosis. If **Known**, specify the expression of proto-oncogenes as either **High** (expression detected in high levels), **Low** (expression detected in low levels), or **Absent** (expression absent) in question 97. The report will indicate the expression (high, low or absent).

If Trk A expression was not assessed or it is unknown if assessed, report **Not known** and continue with question 98.

Other molecular abnormalities present: Indicate **Yes** or **No** if other molecular abnormalities were present at diagnosis. If other molecular abnormalities were identified, specify the molecular abnormality in question 99.

If other molecular markers were not identified at diagnosis, report **No**. If it is not known if testing for other molecular markers were performed at diagnosis or if testing was performed but the results are not known, select **Unknown** and continue with question 101.

#### Question 100: Is a copy of the DNA report attached?

Indicate whether a copy of the DNA analysis report (reported in questions 84 – 99) was submitted to the CIBMTR. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Question 101: Was a cytogenetic analysis performed at diagnosis?

Cytogenetics is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods you may see include conventional chromosome analysis (karyotyping). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.cibmtr.org/manuals/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach the dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrate evidence of disease.

Indicate whether a cytogenetic analysis was obtained at diagnosis. Do not report any testing performed after the treatment for neuroblastoma has started. If a cytogenetic analysis was obtained at diagnosis and metaphases were evaluable, select Yes and continue with question 102. If a cytogenetic analysis was performed at diagnosis but metaphases were not evaluable, select **Yes, but no evaluable metaphases** and continue with question 116. If a cytogenetic analysis was not performed or it is unknown, indicate **No** or **Unknown**, respectively and continue to question 116.

#### Questions 102 – 105: Specify the tissue(s) analyzed

Indicate **Yes** or **No** if the tissue types listed in questions 102-103 were analyzed by cytogenetic methods at the time of diagnosis.

If a tissue type was analyzed and not listed as an option, select **Yes** for “other tissue” (question 104) and specify the tissue in question 105.

If it is not known if the cytogenetics were performed on the tissue, select **No**.

#### Questions 106 – 107: Number of metaphases

Metaphase is a cell life cycle stage indicative of mitotic activity (cell division). A normal metaphase includes 46 chromosomes (46, XX or 46, XY). Indicate if the number of metaphases was known at the time of diagnosis. If **Known**, report the number of metaphases. If the number of metaphases is unknown, select **Not known**, and continue with question 108.

#### Question 108: Was the karyotype abnormal?

Indicate if the karyotype was abnormal at diagnosis. If abnormalities were identified at diagnosis, select **Yes** and continue with question 109. If abnormalities were not identified or it is unknown if abnormalities were present at diagnosis, report **No** or **Unknown**, respectively, and continue with question 115.

#### Questions 109 – 114: Specify the karyotype abnormalities

For each of the karyotype abnormalities listed in questions 109-113, indicate **Yes** or **No** if the abnormality was identified at diagnosis. If an abnormality was identified but is not listed, report Yes for “other abnormality” (question 113) and specify the abnormality in question 114.

If it is not known if the abnormality was identified at diagnosis, report **Unknown**. This option should be used sparingly and only when there is no information available about the results of the cytogenetics performed at diagnosis.

#### Question 115: Is a copy of the cytogenetic report attached?

Indicate if the diagnostic karyotype report was submitted to the CIBMTR. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/formsnet).

#### Question 116: Specify the International Neuroblastoma Staging System (INSS) disease stage at diagnosis

The INSS is a standardized way to classify the extent of the cancer and considers surgical excision of the tumor. Specify the recipient’s stage at diagnosis and continue with question 119. The stage may be documented in progress notes or the can be confirmed with a clinician using Table 1 below.

If the INSS stage at diagnosis was not known or if only the Pediatric Oncology Group (POG) stage or the Evans Group stage is known, select **Unknown** and continue with question 117.

Table 1.


| Stage | Definition |
|---|---|
| Stage 1 | Localized tumor with complete gross excision, with or without microscopic residual disease; representative ipsilateral lymph nodes negative for tumor microscopically (nodes attached to and removed with the primary tumor may be positive) |
| Stage 2A | Localized tumor with incomplete gross excision; representative ipsilateral nonadherent lymph nodes negative for tumor microscopically. |
| Stage 2B | Localized tumor with or without complete gross excision, with ipsilateral nonadherent lymph nodes positive for tumor; enlarged contralateral lymph nodes must be negative microscopically. |
| Stage 3 | Unresectable unilateral tumor infiltrating across the midline (defined as the vertebral column; tumors originating on one side and crossing the midline must infiltrate to or beyond the opposite side of the vertebral column), with or without regional lymph node involvement; or localized unilateral tumor with contralateral regional lymph node involvement; or midline tumor with bilateral extension by infiltration (unresectable) or by lymph node involvement. |
| Stage 4 | Any primary tumor with dissemination to distant lymph nodes, bone, bone marrow, liver, skin and/or other organs (except as defined for stage 4S). |
| Stage 4S | Localized primary tumor (as defined for Stages 1, 2A, or 2B), with dissemination limited to skin, liver, and/or bone marrow (marrow involvement in Stage 4S should be minimal i.e., <10% of total nucleated cells identified as malignant on bone marrow biopsy or on marrow aspirate; more extensive marrow involvement would be considered to be Stage 4; the MIBG scan (if performed) should be negative in the marrow). Stage 4S is limited to infants < 1 year of age. |

#### Question 117: Specify the POG Stage

Using Table 2 below, specify the recipient’s POG Stage at diagnosis. If the POG stage at diagnosis was not known, select **Unknown** and continue with question 118.

Table 2.


| Stage | Definition |
|---|---|
| A | Complete gross excision of primary tumor, margins histologically negative or positive. Intracavitary lymph nodes not intimately adhered to and removed with resected tumor must be histologically free of tumor. If primary is in abdomen or pelvis, liver must be histologically free of tumor. |
| B | Incomplete gross resection of primary. Lymph nodes and liver must be histologically free of tumor. |
| C | Complete or incomplete gross resection of primary. Intracavitary nodes (cavity of primary) histologically positive for tumor. Liver histologically free of tumor. |
| D | Disseminated disease beyond intracavitary nodes in bone marrow, bone, liver, skin, or lymph nodes beyond cavity containing primary tumor. |

#### Question 118: Specify the Evans Stage

Using Table 3 below, specify the recipient’s Evans Stage at diagnosis. If the Evans Stage at diagnosis was not known, select **Unknown** and continue with question 119.

Table 3.


| Stage | Definition |
|---|---|
| I | Tumor confined to the organ structure of origin |
| II | Tumors extending in continuity beyond the organ or structure of origin but not crossing the midline. Regional lymph nodes on the ipsilateral side may be involved |
| III | Tumors extending in continuity beyond the organ or structure or origin but not crossing the midline. Regional lymph nodes on the homolateral side may be involved |
| IV | Remote disease involving skeleton, soft tissues, distant lymph node groups, etc. |
| IV-S | Patients with local stage I or II disease but who have remote disease confined to one or more the following: liver, skin, bone marrow, (with no evidence of bone metastases on complete skeletal survey). |

#### Question 119: Are other family members known to have neuroblastoma or ganglioneuroma?

Gene mutations that increase the risk of developing neuroblastoma can be inherited. Indicate whether immediate family members or other relatives are known to have neuroblastoma or ganglioneuroma.

If immediate family members or other relatives are known to neuroblastoma or ganglioneuroma, select **Yes**. If immediate family members or other family members were not diagnosed with neuroblastoma or ganglioneuroma or it not known if other family members were diagnosed, report **No** or **Unknown**, respectively, and continue to question 128.

#### Questions 120 – 127: Specify the family member(s) diagnosed with neuroblastoma or ganglioneuroma

For family members listed in questions 120-127, indicate **Yes** or **No** if the family member was diagnosed with neuroblastoma or ganglioneuroma.

If a sibling is diagnosed with a neuroblastoma or ganglioneuroma, specify the number of sisters and / or brothers affected. If the number of siblings affected is not known, select **Number of affected sisters / brothers unknown**.

If a relative not listed was diagnosed with a neuroblastoma or ganglioneuroma, indicate **Yes** for question 126 and specify the relationship.

If it is not known if a family member is diagnosed with a neuroblastoma or ganglioneuroma, select **Unknown**. This option should be used sparingly and only when the health history is not known for the family member.

#### Question 128: Does the recipient have a family history of other genetic diseases in first-degree blood relatives?

Indicate if the recipient has a family history of other genetic diseases in first-degree blood relatives. First degree relatives include parents, siblings & offspring. If **Yes**, continue with question 129. If there is not a family history of other genetic disease or it is not known, select **No** or **Unknown**, and continue to question 135.

#### Questions 129 – 134: Specify the diagnoses present in the immediate family

Indicate **Yes** or **No** if the listed genetic diseases (see below) were / are present in the immediate family. If it is not known if the genetic disease was / is present, select **Unknown**.


- Beckwith-Wiedemann (EMG) syndrome: A common overgrowth / cancer predisposing disorder caused by changes on chromosome 11. EMG syndrome is characterized by a wide arrange of physical symptoms including; increased growth and birth weight, enlargement of internal organs and abdominal wall defects.
- Nesidioblastosis: A rare disorder of the beta cells of the pancreas, causing persistent hyperinsulinemic hypoglycemia.
- Neurofibromatosis: A genetic disorder in which causes tumors to form within the nervous system (brain, spinal cord, nerves, etc.)
- Trisomy 18: A chromosomal disorder associated with physical abnormalities such as decreased growth and birth weight, heart defect and abnormally shaped head and small facial features.
- Other disease: If an immediate family member was diagnosed with a genetic disease not listed above, select
**Yes**and specify the disease. Examples of other genetic diseases include PHOX2B mutation, neurocristopathy, and ALK germline mutation.

#### Question 135: Did spontaneous regression of the recipient’s tumor occur?

In certain cases of neuroblastoma, generally those with early disease onset (<1 year of age), spontaneous regression of the disease is possible. Indicate whether spontaneous regression of the recipient’s tumor occurred.

#### Question 136: Did the recipient undergo surgery as part of the initial disease treatment plan?

Treatment for neuroblastoma is determined based on the patient’s risk group:


- Low-risk neuroblastoma is typically treated with surgery, chemotherapy, or a combination of the two. In certain instances, observation may be the course of action.
- Intermediate-risk neuroblastoma is typically treated with surgery, chemotherapy, a combination of surgery and chemotherapy, or less commonly, radiotherapy.
- High-risk neuroblastoma therapy can include a regimen of surgery, chemotherapy, radiotherapy, hematopoietic cell transplant, cis-retinoic acid and immunotherapy.

Indicate if surgery was performed as part of initial treatment (either at diagnosis or after induction therapy). If surgery was performed, indicate **Yes** and continue with question 137. If surgery was not performed, indicate **No** and continue with question 155.

#### Question 137: Specify surgery timepoint

Indicate the timepoint in when the surgery was performed. If **After induction chemotherapy** is selected as the surgery timepoint, continue with question 138.

#### Question 138: Specify the histological diagnosis of resected tissue

Neuroblastic tumors can be classified as ganglioneuroblastomas, ganglioneuromas, or neuroblastomas. These neuroblastic tumors differ histologically in degree of cellular and extracellular maturation. Ganglioneuroblastomas consist of mature gangliocytes and immature neuroblasts resulting in intermediate aggressive behavior. Ganglioneuroma is the most benign tumor of the three and exhibits greater degrees of maturation. Neuroblastoma is the most malignant and immature of the three tumors.3

Indicate if the resected tissue has the histological diagnosis of **Ganglioneuroblastoma**, **Ganglioneuroma**, or **Neuroblastoma**.

#### Questions 139 – 154: Specify the site(s) of surgery

Indicate **Yes** or **No** whether each of the anatomical locations listed in questions 139-154 was a site of surgery for disease. If surgery was performed at a site listed, indicate **Yes** and specify the extent (using Table 4 below) and date of surgery. If surgery was performed at a site not listed, select **Yes** for “other site” (question 151), specify the extent and date of surgery, and surgery site.

Table 4.


Gross |
≥95% resection, no radiographic residual tumor |
|---|---|
Near |
90-95% resection, minimal radiographic residual tumor |
Subtotal |
51-89% resection, moderate radiographic residual tumor |
Partial |
10-50% resection, significant radiographic residual tumor |
Biopsy |
<10 % resection, no radiographic change from pre-op |

#### Question 155: Did the recipient undergo radiotherapy as part of the initial disease treatment plan?

Radiation therapy utilizes high-energy radiation to kill cancer cells. Indicate whether radiotherapy was used as part of the initial disease treatment plan. If radiotherapy was used, indicate **Yes**, and continue with question 156. If radiotherapy was not used or if no information is available to determine if radiotherapy was given as part of the initial disease treatment plan, report **No** or **Unknown**, respectively and continue with question 163.

#### Questions 156 – 158: Primary tumor bed after resection

Indicate **Yes** or **No** if radiation therapy was given to the primary tumor site. If therapy as given to the primary tumor bed, report **Yes** and specify the number of fractions given to this site and the dose per fraction in centigrays (cGy / rads).

#### Questions 159 – 161: Other site

If radiation therapy was given to a site other than the primary tumor location, indicate **Yes** for question 159. Specify the other site, the number of actual fractions (treatments) given to this site, and the actual dose per fraction in centigrays (cGy / rads) in questions 160-162.

#### Question 163: Did the recipient undergo chemotherapy as part of the initial disease treatment plan?

Indicate **Yes** or **No** if the recipient received chemotherapy as part of the initial disease treatment plan. If the recipient received chemotherapy, indicate **Yes**. If chemotherapy was not given or if no information is available to determine if chemotherapy was administered as part of the initial disease treatment plan, report **No** or **Unknown**, respectively and continue with question 184.

#### Question 164: Specify the date the first chemotherapy cycle began

Chemotherapy is usually administered in cycles with rest periods between the cycles. This enables cancer cells to be attacked at vulnerable times and provides healthy cells adequate time to recover from the damage. A cycle can last one or more days and may repeat weekly, bi-weekly, monthly, etc. A chemotherapy course may consist of multiple cycles.

Enter the date the first chemotherapy cycle began. If the start date is partially known (i.e., the recipient started treatment in mid – July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

If the therapy start date is not known, select the **Date the first chemotherapy cycle began unknown** option.

#### Question 165:Specify the date the last chemotherapy cycle began

Report the chemotherapy end date. If the therapy is being given in cycles, report the date the recipient started the last cycle of chemotherapy. If the start date of the last cycle is partially known (i.e., the recipient started treatment in mid – July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 166: Specify the total number of chemotherapy cycles given

A chemotherapy course may consist of multiple cycles. Enter the number of cycles the recipient received. If the therapy is not given in cycles or the number of cycles is not known, check the **Number of chemotherapy cycles given unknown** option.

#### Questions 167 – 178: Specify the treatment(s) given

Treatments vary based on protocol. A treatment may consist of a single drug or a combination of drugs. Additionally, the drugs may be administered on one day, over consecutive days, or continuously.

For each drug listed, indicate **Yes** or **No** if the recipient received the therapy. If the recipient received an agent that is not listed, select Yes for “other treatment” (question 177) and specify the treatment. Report the generic name and not the brand name.

#### Question 179: Specify the best response to chemotherapy

Based on the International Neuroblastoma Response Criteria, indicate the best response to chemotherapy. Refer to the Neuroblastoma Response Criteria section of the Forms Instructions Manual for definitions of each response. The best response is determined by a disease assessment, such as radiology or pathology.

If the recipient was not evaluated at this time or the best response is unknown, report **Not evaluable** or **Not tested / unknown** respectively.

#### Questions 180 – 181: Did neuroblastoma recur?

Indicate **Yes** if neuroblastoma recurred (after achieving a CR) after the initial disease treatment plan and prior to starting any subsequent therapy. If disease recurred, specify the date of recurrence.

#### Question 182: Specify reason

If the best response to chemotherapy was **Not evaluable**, specify the reason why the best response to the chemotherapy was not evaluated.

#### Question 183: Specify the date of the best response to chemotherapy was determined

Enter the date the best response to chemotherapy was established. Report the date of the pathological evaluation or radiographic assessment (e.g., bone marrow biopsy, CT scan, etc.). If no pathologic/radiographic evaluation was reported, report the date of blood/serum/urine assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological, radiographic and/or laboratory evaluations. If the recipient was treated for extramedullary disease and a radiological assessment (e.g., X-ray, CT scan, MRI scan, PET scan) was performed to assess disease response, enter the date the imaging took place for radiologic assessments. If no pathological, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically assessed the recipient’s response.

If the date of best response was not known, then leave the date field blank and select the corresponding unknown option. If the exact date is not known but can be estimated, then use the process for reporting estimated dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 184: Did the recipient undergo surgery, chemotherapy or other cytotoxic treatment for persistent or recurrent disease after the initial treatment but prior to the preparative regimen?

Indicate whether the recipient underwent surgery, chemotherapy or other cytotoxic treatment after the initial disease treatment but before the start of the preparative regimen / infusion. If the recipient received treatment, select **Yes** and continue with question 185. If the recipient did not receive additional therapy after the initial treatment (and prior to the start of the preparative regimen / infusion), report **No** and continue with question 218. Refer to the Neuroblastoma Response Criteria section of the Forms Instructions Manual for definitions of persistent and progressive disease.

A single line of therapy refers to any agents administered during the same time period with the same intent (induction, consolidation, etc.). If a recipient’s disease status changes resulting in a change to treatment, a new line of therapy should be reported. Additionally, if therapy is changed because a favorable disease response was not achieved, a new line of therapy should be reported.

#### Question 185: Date therapy started

Enter the date the recipient first began this line of therapy. If the start date is partially known (e.g. the recipient started in mid – July 2010), use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 186: Date therapy stopped

Enter the date the recipient started the last cycle for this line of therapy. If the stop date is partially known (e.g. the recipient started in mid-July 2010), use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 187: Systemic therapy

Systemic therapy refers to a delivery mechanism where a therapeutic agent is delivered orally or intravenously to the whole body. These drugs enter the bloodstream and are distributed throughout the body.

Indicate **Yes** if the patient received systemic therapy as part of the reported line of therapy. If the patient did not receive systemic therapy, indicate **No** and continue with question 201.

#### Question 188: Number of cycles

Chemotherapy is usually administered in cycles with rest periods between the cycles. This enables cancer cells to be attacked at vulnerable times and provides healthy cells adequate time to recover from the damage. A cycle can last one or more days and may repeat weekly, bi-weekly, monthly, etc. A chemotherapy course may consist of multiple cycles.

Enter the number cycles the recipient received during this line of therapy being reported. If the therapy is not given in cycles or the number of cycles is not known, then check the **Number of cycles unknown / not applicable** option.

#### Questions 189 – 200: Treatment

Indicate **Yes** or **No** for each chemotherapeutic agent listed. Do not leave any response blank. If the recipient received an agent that is not listed, check Yes for the “other therapy” (question 199) and specify the treatment. Report the generic name and not the brand name.

#### Question 201: Radiation therapy

Radiation therapy uses high-energy, ionizing radiation to kill malignant cells. Much like non-targeted systemic therapy, radiation therapy does not specifically target malignant cells and does have significant side effects. For that reason, high-dose radiation often targets a limited field.

Indicate if the recipient received radiation therapy for persistent, progressive, or recurrent disease after the initial treatment of disease but prior to the start of the preparative regimen / infusion. If **Yes**, continue with question 110. If **No**, continue with question 117.

#### Questions 202 – 204: Primary tumor bed

Indicate **Yes** or **No** if radiation therapy was given to the primary tumor site. If therapy as given to the primary tumor bed, report **Yes** and specify the number of fractions given to this site and the dose per fraction in centigrays (cGy / rads).

#### Questions 205 – 208: Other site

If radiation therapy was given to a site other than the primary tumor location, indicate **Yes** for question 205. Specify the other site, the number of actual fractions (treatments) given to this site, and the actual dose per fraction in centigrays (cGy / rads) in questions 206 – 208.

#### Questions 209 – 210: Surgical biopsy / resection

Indicate if surgery was used to biopsy or resect all or a portion of the tumor tissue as part of the reported line of therapy. If **Yes**, specify the anatomical location of the surgical biopsy or section.

If surgery or a resection was not performed as part of the reported line therapy, report **No** and continue to question 213.

#### Question 211: Type of surgery

Specify the type of surgery performed (biopsy, partial, gross total, etc.).


**Gross total**: ≥ 95% resection, no radiographic residual tumor**Near total**: 90-95% resection, minimal radiographic residual tumor.- Subtotal*: 51-89% resection, moderate radiographic residual tumor.
**Partial**: 10-50% resection, significant radiographic residual tumor. This method of approach is often used when there is a risk of neurological damage ***Biopsy**: < 10 % resection, no radiographic change from pre-op. Usually preformed to be examined and confirm diagnosis.

#### Question 212: Histologic diagnosis

Neuroblastic tumors can be classified as ganglioneuroblastomas, ganglioneuromas, or neuroblastomas. These neuroblastic tumors differ histologically in degree of cellular and extracellular maturation. Ganglioneuroblastomas consist of mature gangliocytes and immature neuroblasts resulting in intermediate aggressive behavior. Ganglioneuroma is the most benign tumor of the three and exhibits greater degrees of maturation. Neuroblastoma is the most malignant and immature of the three tumors.

Indicate if the biopsied / resected tissue has the histological diagnosis of **Ganglioneuroblastoma**, **Ganglioneuroma**, or **Neuroblastoma**.

#### Question 213: Best response to line of therapy

Based on the International Neuroblastoma Response Criteria, indicate the best response to the line of therapy. Refer to the Neuroblastoma Response Criteria section of the Forms Instructions Manual for definitions of each response. The best response is determined by a disease assessment, such as radiology or pathology

If the best response was **Not evaluable**, continue with question 214 to specify the reason. This option should be used sparingly, as this would suggest that disease was not assessed by any method. For all other best response options continue with question 215.

#### Question 215: Date response evaluated

Enter the date the best response to chemotherapy was established. Report the date of the pathological evaluation or radiographic assessment (e.g., bone marrow biopsy, CT scan, etc.). If no pathologic/radiographic evaluation was reported, report the date of blood/serum/urine assessment (e.g., CBC, peripheral blood smear). Enter the date the sample was collected for pathological, radiographic and/or laboratory evaluations. If the recipient was treated for extramedullary disease and a radiological assessment (e.g., X-ray, CT scan, MRI scan, PET scan) was performed to assess disease response, enter the date the imaging took place for radiologic assessments. If no pathological, radiographic, or laboratory assessment was performed to establish the best response to the line of therapy, report the office visit in which the physician clinically assessed the recipient’s response.

If the date of best response was not known, then leave the date field blank and select the corresponding unknown option. If the exact date is not known but can be estimated, then use the process for reporting estimated dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 216: Did the patient relapse / progress following this line of therapy?

Indicate **Yes** or **No** if relapse / progression occurred following the reported line of therapy but prior to starting a new line of therapy. Refer to the Neuroblastoma Response Criteria section of the Forms Instructions Manual for definitions of relapsed and progressive disease.

#### Question 217: Date of relapse / progression

Enter the date of the assessment that identified relapse or progression following the line of therapy. Enter the date the sample was collected for pathological and laboratory evaluation or enter the date the imaging took place. If the physician determined evidence of relapse in a clinical assessment during an office visit, report the date of assessment.

If the exact date is not known but can be estimated, then use the process for reporting estimated dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.cibmtr.org/manuals/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 218 – 232: Specify any sites of tumor involvement at any time after diagnosis but prior to the preparative regimen

For each listed anatomical location, indicate **Yes** or **No** if there was tumor involvement at any time after diagnosis but prior to the start of the preparative regimen / infusion. Do not leave any response blank. If there was tumor involvement at a site not listed, indicate **Yes**, for “other site” (question 231) and specify the other site.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| 62 | 4/21/2023 | Modify | Clarified the instructions for the labs at diagnosis should reflect the labs closest to the date of diagnosis. | To ensure more consistent reporting, all labs for the “at diagnosis” timepoint were clarified to reflect the values obtained closest to the date of diagnosis, prior to the start of any therapy. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)