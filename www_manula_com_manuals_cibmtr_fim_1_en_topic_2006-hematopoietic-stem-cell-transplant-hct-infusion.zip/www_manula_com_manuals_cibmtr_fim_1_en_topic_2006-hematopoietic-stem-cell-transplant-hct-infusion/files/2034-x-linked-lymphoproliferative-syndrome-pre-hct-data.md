The X-Linked Lymphoproliferative Syndrome Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures XLP-specific pre-HCT data such as: the recipient’s clinical and genetic findings at the time of diagnosis and prior to the start of the preparative regimen, pre-HCT treatments administered, and disease manifestations prior to the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classification Form (Form 2402) as “disorders of the immune system” and question 628 as X-Linked Lymphoproliferative Syndrome. Additional disease insert forms will be required if the recipient had lymphoma at the time of their XLP diagnosis or prior to the start of the preparative regimen.

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype and **this baseline disease insert was not completed for the previous transplant** (e.g., patient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), begin at question 1.

If this is a report of a second or subsequent transplant for a **different disease** (e.g., patient was previously transplanted for a disease other than X-Linked Lymphoproliferative Syndrome), begin at question 1.

If this is a report of a second or subsequent transplant for the **same disease and this baseline disease insert has previously been completed,** check the indicator box and continue with question 52.

[Q1-23: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-23-disease-assessment-at-diagnosis)

[Q24-32: History of Epstein Barr Virus (EBV) Infection](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q24-32-history-of-epstein-barr-virus-ebv-infection)

[Q33-51: Assessment of Immunologic Function at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q33-51-assessment-of-immunologic-function-at-diagnosis)

[Q52-104: Disease Assessment between Diagnosis and the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q52-104-disease-assessment-between-diagnosis-and-the-start-of-the-preparative-regimen)

[Q105-130: Disease Status at Last Evaluation Prior to the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q105-130-disease-status-at-last-evaluation-prior-to-the-start-of-the-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 2/24/17 | Comprehensive Disease-Specific Manuals | Modify | Updated explanations of triggers for disease inserts to refer to the primary disease reported on the Pre-TED Disease Classification Form (Form 2402) instead of the Pre-TED Form (Form 2400) |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)