These sections include additional information referenced in other manuals.

[Appendix A: Abbreviations and Definitions](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-a-abbreviations-and-definitions)

[Appendix B: Glossary of Terms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-b-glossary-of-terms)

[Appendix C: Cytogenetics](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c)

[Appendix D: How to Distinguish Infusion Types](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d)

[Appendix E: Definition of a Product](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-e)

[Appendix F: Response Evaluation Criteria in Solid Tumors](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-f)

[Appendix G: Tracking Disease Status for Multiple Myeloma](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-g)

[Appendix I: Ethnicity and Race](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-i-ethnicity-and-race)

[Appendix J: Reporting Comorbidities](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-j)

[Appendix L: Karnofsky / Lansky Performance Status](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-l-karnofsky-lansky-performance-status)

[Appendix N: Drug Classification](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-n-drug-classification)

Last modified:
May 02, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)