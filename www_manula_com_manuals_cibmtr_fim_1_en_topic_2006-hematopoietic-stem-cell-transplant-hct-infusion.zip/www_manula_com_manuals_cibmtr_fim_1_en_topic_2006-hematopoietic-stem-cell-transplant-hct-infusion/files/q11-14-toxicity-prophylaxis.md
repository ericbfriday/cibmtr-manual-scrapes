#### Question 11-12: Therapy given for the prevention of CRS: (prophylactic therapy)

Presently, CRS prophylaxis is not routinely performed. However, practices related to CRS are evolving rapidly and some programs have considered using drugs like tocilizumab preemptively in patients with high risk to develop serious CRS. If therapy was given for the prevention of CRS check all that apply from the list of the drugs given. If **Other therapy** is selected, specify the therapy.

If more than one **Other** drug is prescribed, report each **Other** drug in the specify field. List the generic name of the drug in the space provided and attach a copy of the source document using the attachment feature in FormsNet3SM.

#### Question 13-14: Therapy given for the prevention of neurotoxicity (ICANS: (prophylactic therapy))

For neurotoxicity, anti-epileptic drugs are often prescribed to prevent seizures. The intent of this question to separate the use of these drugs from prevention to treatment of seizure, which is captured in F4100. Additionally and similar to CRS, practices are evolving rapidly, and other drugs might be used to prevent neurotoxicity among patients with high risk for serious manifestations of this complication. If therapy was given for the prevention of neurotoxicity, check all that apply from the list of the drugs given. If **Other therapy** is selected, specify the therapy.

If more than one **Other** drug is prescribed, report each **Other** drug in the specify field. List the generic name of the drug in the space provided and attach a copy of the source document using the attachment feature in FormsNet3SM.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 11-14 | 11/6/2023 | Add | Add blue box at top of section: If drugs given for toxicity prophylaxis were started at the time of cell therapy infusion, including after day zero, they should be reported in this section. | Added for clarification |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)