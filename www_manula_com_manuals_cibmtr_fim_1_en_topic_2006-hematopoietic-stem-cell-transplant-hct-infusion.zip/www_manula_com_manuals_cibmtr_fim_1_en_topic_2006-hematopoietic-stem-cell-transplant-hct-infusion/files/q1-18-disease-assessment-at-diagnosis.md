#### Question 1: Is this the report of a second or subsequent transplant or cellular therapy for the same disease?

Report **No** and go to question 2 in any of the following scenarios:


- This is the first infusion reported to the CIBMTR; or
- This is a second or subsequent infusion for a different disease (i.e., the patient was previously transplanted for a disease other than Aplastic Anemia); or
- This is a second or subsequent infusion for the same disease subtype and this baseline disease insert was not completed for the previous transplant (i.e., the patient was on the TED track for the prior infusion, prior infusion was autologous with no consent, etc.).

Report **Yes** and go to question 59 if this is a subsequent infusion for the same disease and the baseline Aplastic Anemia disease insert was completed previously.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Dec 22, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)