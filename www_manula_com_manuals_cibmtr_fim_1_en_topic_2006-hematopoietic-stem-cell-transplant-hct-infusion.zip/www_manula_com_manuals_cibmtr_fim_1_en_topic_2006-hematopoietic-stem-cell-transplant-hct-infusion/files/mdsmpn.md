The **myelodysplastic syndromes** (MDS) are a diverse group of clonal hematopoietic stem cell diseases characterized by cytopenia(s), dysplasia (abnormal growth or development leading to an alteration in size, shape, and organization of the cell) in one or more of the major cell lines (WBC, RBC, and/or platelets), ineffective hematopoiesis, and an increased risk of development of Acute Myelogenous Leukemia (AML). MDS occurs primarily in older adults with a median age of 70 years. The majority of patients present with symptoms related to cytopenias; most patients present with anemia requiring RBC transfusions.

Primary or *de novo* MDS occurs without a known history of chemotherapy or radiation exposure. Some inherited hematologic disorders, such as Fanconi anemia, dyskeratosis congenita, Shwachmann-Diamond syndrome, and Diamond-Blackfan syndrome are associated with an increased risk of MDS.

[MDS Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mds-mpn-response-criteria)

[2014: MDS Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2014-mds-mpn-pre-hct)

[2114: MDS Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2114-mds-mpn-post-hct)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)