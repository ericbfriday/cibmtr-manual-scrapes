#### Questions 2 – 4: What is the recipient’s beta-globin genotype?

Beta thalassemia occurs when there are mutations in the beta-globin gene leading to impaired production of the beta globin chains. This leads to an excess of alpha or alpha-type chains. Everyone has two beta globin genes (one from each parent). There are different types of beta thalassemia gene variants:

- Beta
0: No beta-globin is produced (B0) - Beta
+: A reduced amount of beta-globin is produced (B+) - Beta
E(hemoglobin E): A reduced amount of beta-globin is produced (BE)

A lack of the beta-globin protein causes a reduced amount of functional red blood cells and hemoglobin resulting in anemia.

Specify the recipient’s beta-globin genotype. If the recipient has a normal genotype (i.e., the beta mutation is not detected), select **B / B**.

If the recipient’s beta-globin genotype is not listed, select **Other genotype** and specify the other beta-globin genotype.

If the recipient’s beta-globin genotype is not known, select **Unknown**.

Additionally, indicate whether documentation of the recipient’s beta-globin disease genotype was submitted to CIBMTR (e.g., pathology report, laboratory report).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Questions 5 – 7: What is the recipient’s alpha-globin genotype?

A healthy individual has four genes to produce the alpha-globin protein. Alpha thalassemia occurs when one or more of the four genes for alpha-globin are defective or absent. Suppressed alpha-globin protein causes reduced amounts of healthy red blood cells and hemoglobin.

Specify the recipient’s alpha-globin genotype. The ‘ – ‘ represents the number of genes deleted (i.e., ‘ – – / aa‘ signifies two gene deletions, ‘ – – / a-‘ signifies three gene deletions). Hemoglobin Constant Spring (Hb CS) is a non-deletional α-thalassemia (aCS).

If the recipient has a normal genotype (i.e., the alpha-globin mutation is not detected), select **aa / aa**.

If the recipient’s alpha-globin genotype is not listed, select **Other genotype** and specify the other alpha- globin genotype.

If the recipient’s alpha-globin genotype is not known, select **Unknown**.

Additionally, indicate whether documentation of the recipient’s alpha-globin genotype was submitted to CIBMTR (e.g., pathology report, laboratory report).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

#### Question 8: Is alpha-gene triplication present?

The alpha gene provides instructions for producing the alpha-globin protein. Alpha-gene triplication is referred to as the presence of more than four alpha genes.

Indicate if the alpha-gene triplication is present is at diagnosis. If alpha-gene triplication testing was not assessed or it is not known if it was assessed / present, select **Unknown**.

#### Questions 9 – 10: Was hemoglobin electrophoresis performed at diagnosis? (do not include results if an RBC transfusion occurred within 4 weeks of the electrophoresis study)

Indicate if hemoglobin electrophoresis studies were performed at diagnosis (prior to the initiation of RBC transfusions). If hemoglobin electrophoresis studies were not performed or it is not known if assessments were performed, select **No** or **Unknown**, respectively, and continue with *Were genetic mutations identified at diagnosis*.

If RBC transfusion(s) were given within four weeks prior of the hemoglobin electrophoresis study, select **Not applicable** and continue with *Were genetic mutations identified at diagnosis*.

If **Yes**, report the date (YYYY-MM-DD) of the most recent hemoglobin electrophoresis study prior to the administration of RBC transfusion(s). If the exact date is not known report an estimated date and check the **Date estimated** box. Refer to General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms) for information about reporting estimated dates.

#### Questions 11 – 23: Specify the hemoglobin allele types based on the sample tested in question 9

Specify the hemoglobin allele types identified in the hemoglobin study reported above. If the hemoglobin allele type was assessed, report **Yes** and specify the percentage.

If additional thalassemia related hemoglobin types are identified but not listed as options on the form, select **Yes** for *Other thalassemia related hemoglobin type*, specify the type and the report the hemoglobin percentage.

#### Questions 24 – 26: Which genetic mutations were identified at diagnosis? (check all that apply)

Indicate if any of the listed genetic mutations were identified at diagnosis. Check all that apply. If a genetic mutation was detected at diagnosis but not listed, select **Other** and specify the mutation.

If testing for genetic mutations were not performed at diagnosis or it is not known, select **Not done** or **Unknown**, respectively and continue with *What is the donor’s beta-globin genotype*.

Specify if documentation of the genetic mutations identified at diagnosis was submitted to CIBMTR (e.g., laboratory report).

For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/attachments).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)