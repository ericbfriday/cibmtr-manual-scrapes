#### Questions 1-10: Specify hematologic, lymphoid growth factor or cytokine received

A growth factor is a substance that stimulates cell growth, differentiation, and proliferation. Cytokines can act as growth factors or have an inhibitory effect on cell growth.

Select all agents given during the reporting period. For each agent administered during the reporting period, report the start date, the reason it was given, and if the agent was still being administered on the contact date.

**G-CSF (granulocyte-colony stimulating factor):**Alternate names: filgrastim, pegfilgrastim, Neupogen, Neulasta, Lenograstim. If G-CSF was given, specify the drug.**GM-CSF (granulocyte / macrophage-colony stimulating factor):**Alternate names: sargramostim, Leukine.**Erythropoietin (EPO):**Alternate names: Epogen, Procrit, darbepoietin alfa (Aranesp). EPO stimulates red blood cell production.**Thrombopoietin:**Alternate names: megakaryocyte growth and development factor. A glycoprotein hormone which regulates the production of hormones.**KGF (keratinocyte growth factor):**Alternate names: palifermin, Kepivance. KGF acts to stimulate the growth of cells that line the surface of the mouth and intestinal tract. KGF may also be given to treat oral mucositis or as GVHD prophylaxis. Report if administered to stimulate cell growth or to treat oral mucositis. Do not report KGF if it is administered as GVHD prophylaxis.**Blinded growth factor or cytokine trial:**If the recipient is on a blinded randomized trial, specify the trial agent administered. Additionally, update the Post-Infusion Follow-Up (2100) Form once the trial is over to specify whether the recipient received the trial drug or placebo.**Other agent:**Specify any other hematopoietic growth factor, lymphoid growth factor, or cytokine administered.

If hematopoietic, lymphoid growth factor or cytokine agents were not given in the current reporting period, select **None received**.

If the exact dates are not known, use the process for reporting estimated dates, as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)