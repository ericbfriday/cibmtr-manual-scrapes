#### Question 88: Were disease modifying therapies given? (*excludes blood transfusions*)

Indicate if the recipient received disease modifying therapies (see the question below for a list of common disease modifying therapies) at any time between diagnosis and the start of the preparative regimen / infusion; excluding blood transfusion(s). If the recipient received disease modifying therapies, report **Yes**. If the recipient did not receive disease modifying therapies or if no information is available to determine if the recipient received disease modifying therapies, select **No** or **Unknown**, respectively.

#### Questions 89 – 90: Specify the disease modifying therapy

Select the disease modifying therapy administered as part of the line of therapy being reported. If the recipient received a therapy which is not listed, select “**Other**” and specify the treatment. Report the generic name of the agent, not the brand name.

**Crizanlizumab (Adakveo)**: A monoclonal antibody given to reduce the frequency of vaso-occlusive crises.**Hydroxyurea**: A type of chemotherapy. Common brand names include Droxia and Hydrea.**L-Glutamine (Endari)**: An amino acid in the form of an oral powder given to reduce the complications of sickle cell disease.**Voxelotor (Oxbryta)**: An oral medication given to inhibit sickle hemoglobin polymerization.

#### Questions 91 – 92: Date therapy started

Indicate whether the therapy start date is **Known** or **Unknown**. If the therapy start date is **Known**, report the date the recipient began this line of therapy. If the start date is partially known (i.e., the recipient started treatment in mid- July 2010), use the process described for reporting partial or unknown dates in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the therapy start date is not known, report **Unknown**.

#### Questions 93 – 94: Date therapy stopped

Indicate if the stop date is **Known** or **Unknown**. If the therapy is being given in cycles (i.e., Crizanlizumab), report the date the recipient started the last cycle for this line of therapy. Otherwise, report the final administration date for the therapy being reported. If the stop date is partially known, use the process for reporting partial or unknown dates as described in the [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the disease modifying therapy stop date is not known, select **Unknown**.

Report **Not applicable** if the recipient is still receiving therapy at the start of the preparative regimen / infusion.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)