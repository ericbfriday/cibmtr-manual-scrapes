#### Complete Remission (CR)

Hematologic complete remission is defined as meeting **all** of the following response criteria for at least four weeks.


- < 5% blasts in the bone marrow
- Normal maturation of all cellular components in the bone marrow
- No extramedullary disease (e.g., CNS, soft tissue disease)
- ANC (absolute neutrophil count) ≥ 1,000/µL
- Platelets ≥ 100,000/µL
- Transfusion independent

Alternative post-transplant CR criteria are accepted in the setting of pediatric ALL when the center does not routinely perform bone marrow biopsies post-transplant and the patient was in CR pre-transplant. These criteria are not used for pre-transplant ALL disease status. The criteria are as follows:


- Complete donor chimerism (≥ 95% donor chimerism without recipient cells detected)
- No extramedullary disease (e.g., CNS, soft tissue disease)
- Neutrophils ≥ 1,000/µL
- Platelets ≥ 100,000/µL
- Transfusion independent (a minimum of four weeks without platelet or red blood cell transfusion)

In some cases, there may not be a four-week interval between completion of therapy and the pre-transplant disease assessment; in this case, CR should still be reported as the status at transplant, since it represents the “best assessment” prior to HCT. This is an exception to the criteria that CR be durable beyond four weeks. The pre-transplant disease status should not be changed based on early relapse or disease assessment post-transplant.

Include recipients who are MRD positive or where the MRD status is unknown. MRD assessments include cytogenetic, flow cytometry, and molecular methods.

Include recipients meeting the above CR criteria regardless of how many courses of therapy were required to achieve CR.

The number of this complete remission can be determined by using the following guidelines:


- 1st CR: no prior relapse
- 2nd CR: one prior relapse
- 3rd or higher: two or more prior relapses

#### Complete Remission with Incomplete Hematologic Recovery (CRi)

Hematologic complete remission with incomplete hematologic recovery is defined as meeting all of the following response criteria for at least four weeks:


- < 5% blasts in the bone marrow
- Normal maturation of all cellular components in the bone marrow
- No extramedullary disease (e.g., CNS, soft tissue disease)
- Transfusion independent (a minimum of four weeks without platelet or red blood cell transfusion) (Please note, if the physician documents transfusion dependence related to treatment and not the patient’s underlying ALL, CR should be reported)

#### Primary Induction Failure (PIF)

The patient received treatment for ALL but **never achieved CR or CRi at anytime**. PIF is not limited by the number of unsuccessful treatments; this disease status only applies to recipients who have never been in CR or CRi.

#### Relapse (REL)

Relapse is defined as the recurrence of disease after CR, meeting at least one of the following criteria:


- ≥ 5% blasts in the marrow or peripheral blood
- Extramedullary disease
- Disease presence determined by a physician upon clinical assessment

The number of this relapse can be determined by using the following guidelines:


- 1st relapse: one prior CR
- 2nd relapse: two prior CRs
- 3rd or higher: three or more CRs

Do not include a partial response (PR) when determining number of relapse. Recipients who achieve a PR to treatment should be classified as either PIF or relapse; PR in ALL is generally of short duration and is unlikely to predict clinical benefit.

#### No Treatment

The recipient was diagnosed with acute leukemia and never received therapeutic agents. Include patients who have received only supportive therapy, including growth factors and/or blood transfusions.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2011.ALL%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

**Relapse Criteria**: The Disease presence determined by a physician upon clinical assessment criteria is not if there is**only**disease detected by MRD or other methods of assessment (i.e., molecular, cytogenetics, flow cytometry). In order to report relapse, disease must be detected by clinical / hematologic assessments.[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)*Transfusion independent (Please note, if the physician documents transfusion dependence related to treatment and not to the patient’s underlying AML, CR-i- should be reported*[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)*Include recipients who are MRD positive or where the MRD status is unknown. MRD assessments includes*~~with persistent~~ cytogenetic, flow cytometry, and molecular methods.[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)*Transfusion independent (Please note, if the physician documents transfusion dependence related to treatment and not to the patient’s underlying AML, CR-i- should be reported*[ALL Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/all-response-criteria)*Transfusion independent (Please note, if the physician documents transfusion dependence related to treatment and not the patient’s underlying ALL, CRi can be reported)**No blasts with Auer rods*

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)