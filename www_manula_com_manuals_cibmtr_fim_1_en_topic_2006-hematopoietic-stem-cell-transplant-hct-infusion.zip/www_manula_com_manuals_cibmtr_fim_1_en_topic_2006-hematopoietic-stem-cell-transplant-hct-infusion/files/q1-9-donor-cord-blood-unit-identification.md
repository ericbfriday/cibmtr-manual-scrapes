#### Question 1: Who is being tested for IDMs?

Indicate whether the **Donor IDM** (for peripheral blood stem cells and / or bone marrow products), **Maternal IDM** (mother of the cord donor), or **Cord blood unit IDM** itself is being tested. Maternal IDMs and cord blood unit IDMs apply only to cord blood products; if both maternal and cord blood IDMs are available, report the results from cord blood unit testing. Cord blood banks send documentation accompanying the cord that will specify IDM results and the source of the specimen sent for IDM testing; most cord blood banks perform IDM testing on maternal serum due to the limited volume and cell count of cord blood units.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)