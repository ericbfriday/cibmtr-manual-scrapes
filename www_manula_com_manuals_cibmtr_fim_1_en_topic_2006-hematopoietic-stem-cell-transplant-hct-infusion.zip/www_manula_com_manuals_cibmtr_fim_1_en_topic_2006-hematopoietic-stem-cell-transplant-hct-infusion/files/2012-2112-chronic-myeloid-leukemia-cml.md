Chronic myelogenous leukemia (CML) is a slow-progressing cancer of the myeloid white blood cells. It is characterized by the increased proliferation of immature white blood cells (granulocytes) with damaged DNA, or blasts, which accumulate in the blood and bone marrow. Normal blasts develop into white blood cells which function to fight infection. The symptoms of CML are caused by the replacement of normal bone marrow with leukemic cells, resulting in a drop in red blood cells, platelets, and normal white blood cells.

The Chronic Myelogenous Leukemia Pre-infusion Data Form is one of the Comprehensive Report Forms. This form captures CML-specific pre-infusion data such as: the recipient’s hematologic and cytogenetic findings at the time of diagnosis and prior to the start of the preparative regimen, pre-infusion treatments administered, and disease status prior to the preparative regimen.

The Chronic Myelogenous Leukemia Post-Infusion Data Form (Form 2112) is one of the Comprehensive Report Forms. This form captures CML-specific post-infusion data such as: the recipient’s best response to HCT or cellular therapy; planned treatments post-infusion; disease relapse data including treatment administered for relapse or persistent disease; and disease status for the reporting period.

[CML Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/cml-response-criteria)

[2012: CML Pre-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2012-cml-pre-hct-data)

[2112: CML Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2112-cml-post-infusion-data)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)