This form must be completed to determine eligibility for the Prospective Assessment of Allogeneic Hematopoietic Cell Transplantation in Patients with Myelofibrosis (16-CMS-MF) study. Patients with Medicare are eligible for coverage of HCT for myelofibrosis if they participate in a CED clinical trial.

The clinical trial number for this study is NCT02934477 and should be reported on the Pre-TED (2400) form. This study is a sub-study under the CIBMTR Protocol for a Research Database for Hematopoietic Cell Transplantation, Other Cellular Therapies, and Marrow Toxic Injuries NCT01166009.

See the Myelofibrosis Medicare Study page on [cibmtr.org](https://cibmtr.org/CIBMTR/Studies/Research-Programs/Clinical-Trials-Support/Medicare-Clinical-Trials#CMSMF) for patient eligibility.

Participating Transplant Centers are required to:

1. Create a CRID in FormsNet following standard CIBMTR process.

2. Complete Form 2554 (CMS Registration Form, an on-demand form) in FormsNet3.


- Select disease option for myelofibrosis.

3. Complete Form 2555 (CMS – MF Eligibility).

4. Complete Form 2400 (Pre-TED)


- Select CIBMTR CRO Services as the study sponsor, and then select 16-CMS-MF from the list of studies.

5. Complete Form 2402 (Disease Classification) indicating the Primary disease is MPN, Sub-disease is myelofibrosis for transplant.

6. Submit Comprehensive Report Forms for all myelofibrosis recipients regardless of age at transplant.

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/historical-manual-updates) or reference the [Retired Manual Section](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspxRetired) Forms Manuals on the.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/19/2024 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)