#### Question 4: Date of first collection for this mobilization:

Report the date the stem cell collection was performed. If a collection event occurred over multiple days, enter the date the collection started (i.e., Day 1).

**Example 1:** An autologous recipient was mobilized with G-CSF and underwent a two-day PBSC collection. Since the collection and mobilization methods remained the same over the duration of the collection, this collection is considered one product. Report the collection start date as the date of product collection.

**Example 2:** An autologous recipient was mobilized with G-CSF and underwent a two-day PBSC collection. The collected cell counts were poor and no further collections were attempted. One week later the donor was re-mobilized with G-CSF and a second PBSC collection was performed. Due to the recipient having two mobilization events, this is considered two separate products, and two Form 2006s should be submitted. The date of product collection should be the first day of collection of the mobilization event for which the form is being completed.

This question is only enabled for PBSC and bone marrow products from non-NMDP donors.

#### Question 5: Were anticoagulants or other agents added to the product between collection and infusion?

If anticoagulants or other agents were added to the product between collection and infusion, report **Yes**. Anticoagulants are often added to PBSC products and are typically documented on the product bag label.

If anticoagulants or other agents were not added to the product between collection and infusion, report **No**.

This question is only enabled for PBSC and bone marrow products from non-NMDP donors.

#### Questions 6 – 7: Specify anticoagulant(s): (check all that apply)

Report if any of the following anticoagulants were added to the reported product. Check all that apply.

**Acid citrate dextrose**(ACD, ACD-A)**Citrate phosphate dextrose**(CPD, CPD-A)**Ethylenediaminetetraacetic acid**(EDTA)**Heparin**

If an anticoagulant added to the product is not listed on the form, check **Other**, and specify the anticoagulant’s name.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)