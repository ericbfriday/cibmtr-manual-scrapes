#### Question 1: Is this the report of a second or subsequent infusion for the same disease?

Report **No** and go to *Specify the solid tumor sub-disease* in any of the following scenarios:

• This is the first infusion reported to the CIBMTR; or

• This is a second or subsequent infusion for a different disease (i.e., the patient was previously transplanted for a disease other than a leukodystrophy); or

• This is a second or subsequent infusion for the same disease subtype and this baseline disease insert was not completed for the previous transplant (i.e., the patient was on the TED track for the prior infusion, prior infusion was autologous with no consent, etc.).

Report **Yes** and go to the Initial Therapy section if this is a subsequent infusion for the same disease and the baseline Solid tumor pre-infusion form was completed previously.

**Section Updates:**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)