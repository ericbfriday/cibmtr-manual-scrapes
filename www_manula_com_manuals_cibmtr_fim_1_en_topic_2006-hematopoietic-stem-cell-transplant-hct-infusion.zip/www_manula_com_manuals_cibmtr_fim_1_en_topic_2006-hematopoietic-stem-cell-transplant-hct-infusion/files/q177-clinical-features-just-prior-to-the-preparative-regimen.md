#### Question 177: What was the recipient’s disease status immediately prior to the preparative regimen?

The pre-HCT disease status is determined by a disease assessment, such as hematologic testing, pathology study, and / or physician assessment. Indicate the recipient’s disease status immediately prior to the start of the preparative regimen / infusion, using the options as defined below:


**Stable cytopenia, no cytogenetic abnormalities (no MDS)**should be selected if the recipient’s blood counts have remained stable and no cytogenetic abnormalities were noted on karyotyping.**Stable cytopenia with cytogenetic abnormalities (no MDS)**should be selected if the recipient’s blood counts have remained stable; however, cytogenetic abnormalities were noted on karyotyping.**Progressive cytopenia**should be indicated if the recipient’s platelet, red blood cell, or white blood cell count has decreased from the time of diagnosis to prior to the start of the preparative regimen.**Myelodysplasia**should be selected if the recipient’s Fanconi Anemia has progressed to MDS.**Leukemia, untreated**should be selected if the recipient’s Fanconi Anemia has progressed to Leukemia and no chemotherapy was given within six months of the start of the preparative regimen.**Leukemia, treated**should be selected if the recipient’s Fanconi Anemia has progressed to Leukemia and chemotherapy was started within 6 months of the preparative regimen.

**Section Updates**


| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (if applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Feb 01, 2021

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)