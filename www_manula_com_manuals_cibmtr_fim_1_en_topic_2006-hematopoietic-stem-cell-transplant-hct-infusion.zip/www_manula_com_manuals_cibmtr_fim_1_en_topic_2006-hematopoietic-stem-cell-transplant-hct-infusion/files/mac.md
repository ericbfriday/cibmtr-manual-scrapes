Lymphoplasmacytic lymphoma (LPL) and subtype Waldenström’s macroglobulinemia (WM) are specific presentations of Non-Hodgkin lymphoma that are characterized by abnormal cellular populations containing small B-cells, plasma cells, and plasmacytoid lymphocytes. Additional hallmarks of Waldenström’s macroglobulinemia are bone marrow involvement (which may be present in lymphoplasmacytic lymphoma) and IgM paraprotein. Patients typically present with symptoms associated with anemia, such as weakness and fatigue. Workup often reveals normocytic, normochromatic anemia. Additional findings may include IgM paraprotein, clinical hyperviscosity syndrome, and neuropathy. LPL will generally involve the bone marrow and, in some cases, the lymph nodes and other extranodal sites. A significant number of patients with WM will also have organomegaly and adenopathy. Advanced age, decreased performance status, anemia, and elevated ß2 microglobulin have been associated with poorer outcomes, though there is no validated staging system to establish prognosis.[1](#fn199775542768596bb9aafc2-1)

1 World Health Organization. (2008). *WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues* (4th ed.). Lyon, France.

[WM Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/wm-response-criteria)

[2019: WM Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2019-wm-pre-hct)

[2119: WM Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2119-wm-post-hct)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)