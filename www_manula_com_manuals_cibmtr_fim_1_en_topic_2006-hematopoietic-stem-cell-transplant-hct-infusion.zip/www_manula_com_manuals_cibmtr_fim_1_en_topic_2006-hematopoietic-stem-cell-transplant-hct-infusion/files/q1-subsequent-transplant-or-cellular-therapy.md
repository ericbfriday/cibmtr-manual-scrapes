#### Question 1: Is this the report of a second or subsequent infusion?

Report **No** and go to *Was sickle cell disease diagnosed at birth?* in any of the following scenarios:

- This is the first infusion reported to the CIBMTR; or
- This is a second or subsequent infusion for a different disease (i.e., the patient was previously transplanted for a disease other than Sickle Cell Disease); or
- This is a second or subsequent infusion for the same disease subtype and this baseline disease insert was not completed for the previous transplant (i.e., the patient was on the TED track for the prior infusion, prior infusion was autologous with no consent, etc.).

Report **Yes** and go to *Were any red blood cell (RBC) transfusions administered?* if this is a subsequent infusion for the same disease ** and** the baseline SCD disease insert was completed previously.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Oct 27, 2024

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)