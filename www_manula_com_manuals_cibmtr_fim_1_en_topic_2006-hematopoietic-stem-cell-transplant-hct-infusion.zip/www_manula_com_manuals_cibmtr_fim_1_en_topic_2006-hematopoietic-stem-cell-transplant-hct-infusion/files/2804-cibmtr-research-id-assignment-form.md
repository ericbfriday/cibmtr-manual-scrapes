The CIBMTR Research ID (CRID) is a unique identifier assigned when an individual is registered with the CIBMTR as receiving a cellular therapy, including hematopoietic stem cell transplant (HCT), cellular therapy (CT), treatment for marrow toxic injuries, or certain non-cellular therapies. The CRID Assignment (2804) Form collects the information required to create a lifelong identification number specific to an individual, and certain data fields are used to ensure that the same individual does not inadvertently receive multiple CRID assignments.

Instructions for completing the CIBMTR Research ID Assignment (2804) Form are found in the [CIBMTR Data Management Guide](http://www.manula.com/manuals/cibmtr/training-and-reference/1/en/topic/getting-started).

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)