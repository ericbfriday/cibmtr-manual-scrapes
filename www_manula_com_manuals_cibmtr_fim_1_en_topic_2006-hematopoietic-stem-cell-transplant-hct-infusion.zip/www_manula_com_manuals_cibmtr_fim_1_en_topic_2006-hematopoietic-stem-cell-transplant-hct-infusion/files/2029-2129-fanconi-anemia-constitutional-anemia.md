Fanconi anemia is an autosomal recessive genetic disorder associated with genomic instability characterized by developmental defects, short stature, and a high risk of malignancies. Though it is rare, Fanconi Anemia is one of the most common bone marrow failure syndromes that results in a progressive deficiency of all production of red blood cells, white blood cells, and platelets. Signs and symptoms of Fanconi Anemia frequently appear at birth or in children between the ages of 3 and 14 years of age with the median age of diagnosis at 7 years old. Serious complications that can arise in patients with Fanconi Anemia include bone marrow failure, aplastic anemia, or cancers such as acute myeloid leukemia (AML) or myelodysplastic syndromes (MDS). Additionally, affected individuals have an increased risk of developing solid tumor cancers of the head, neck, skin, gastrointestinal, and genital tract.

[2029: Fanconi Anemia / Constitutional Anemia Pre-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2029-fanconi-anemia-constitutional-anemia-pre-infusion)

[2129: Fanconi Anemia / Constitutional Anemia Post-HCT](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2129-fanconi-anemia-constitutional-anemia-post-hct)

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)