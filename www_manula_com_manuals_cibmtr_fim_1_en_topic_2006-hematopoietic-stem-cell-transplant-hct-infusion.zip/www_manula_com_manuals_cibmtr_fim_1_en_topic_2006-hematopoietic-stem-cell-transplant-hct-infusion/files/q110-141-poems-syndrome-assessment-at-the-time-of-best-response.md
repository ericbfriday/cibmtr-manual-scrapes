The response time for POEMS tends to occur well after transplant, so the “best response” to transplant may not occur within the first 100 days. The intent of this question is to determine the best overall response to HCT or cellular therapy, which could include any response to planned therapy post-HCT or post-cellular therapy, or to therapy given for maintenance or prophylaxis. DO NOT include any response to treatment given for relapsed or progressive disease. This is assessed in each reporting period. When evaluating the best response, determine the disease status within the reporting period and compare it to all previous post-HCT or post-cellular therapy reporting periods. If the response in the current reporting period is the best response to date, report the disease status established within this reporting period. If a better response was established in a previous reporting period, report the previously established disease status.

#### Questions 110 – 111: Specify POEMS clinical features at the time of best response (check all that apply)

Indicate which clinical features, specific to POEMS only, are present at the time of best response. Check all that apply. If there are other clinical features not listed in this section, select **Other**, in addition to any available options that apply, and specify the other clinical feature.

#### Questions 112 – 114: Thyroid stimulating hormone (TSH)

Indicate whether the thyroid stimulating hormone (TSH) level was **Known** or **Unknown** at the time of best response. If **Known**, report the value (in mU/L) (mU/L is equivalent to μU/mL) and specify the upper limit of normal. If **Unknown**, continue with question 115.

#### Questions 115 – 117: Testosterone level

Indicate whether the testosterone level was **Known** or **Unknown** at the time of best response. If **Known**, report the value, unit of measure, and upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 118.

#### Questions 118 – 120: Estradiol level

Indicate whether the estradiol level was **Known** or **Unknown** at the time of best response. If **Known**, report the value (in pg/mL) and specify the upper limit of normal. If **Unknown**, continue with question 121.

#### Questions 121 – 123: Prolactin level

Indicate whether the prolactin level was **Known** or **Unknown** at the time of best response. If **Known**, report the value (in ng/mL) and specify the upper limit of normal. If **Unknown**, continue with question 124.

#### Questions 124 – 126: Cortisol level

Indicate whether the cortisol level was **Known** or **Unknown** at the time of best response. If **Known**, report the value, unit of measure to the nearest tenth, and upper limit of normal, as documented on the laboratory report. If **Unknown**, continue with question 127.

#### Questions 127 – 129: Interleukin-6

Indicate whether the interleukin-6 value was **Known** or **Unknown** at the time of best response. If **Known**, report the value (in pg/mL) to the nearest tenth and the upper limit of normal. If **Unknown**, continue with question 130.

#### Questions 130 – 131: Was pulmonary artery hypertension present?

Pulmonary hypertension (PH) refers to elevated pulmonary arterial pressure. PH can be due to primary elevation of pressure in the pulmonary arterial system alone (pulmonary arterial hypertension), or secondary to elevations of pressure in the pulmonary venous and pulmonary capillary systems (pulmonary venous hypertension; post-capillary PH). Indicate whether pulmonary artery hypertension was present at the time of best response. If present, select **Yes** and report the estimated systolic artery pressure documented on the laboratory report. If not present, report **No** and continue with question 132.

#### Questions 132 – 133: Forced vital capacity (FVC)

Forced vital capacity is the total amount of air that can be exhaled during the forced expiratory volume test. FVC is a measurement taken during spirometry studies. Indicate whether the forced vital capacity percentage was **Known** or **Unknown** at the time of best response. If **Known**, report the percentage documented on the pulmonary function test (PFT). If **Unknown**, continue with question 134..

#### Questions 134 – 135: Total lung capacity

Indicate whether the total lung volume was **Known** or **Unknown** at the time of best response. If **Known**, report the value documented on the pulmonary function report If **Unknown**, continue with question 136.

#### Questions 136 – 138: Vascular endothelial growth factor (VEGF) serum value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the serum-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the time of best response. If **Known**, report the value and specify the upper limit of normal as documented on the laboratory report. If **Unknown**, continue with question 139.

#### Questions 139 – 141: Vascular endothelial growth factor (VEGF) plasma value

Vascular endothelial growth factor (VEGF) promotes the growth of new blood vessels and acts as a signaling protein influencing the rate at which this process is performed. Indicate whether the plasma-derived vascular endothelial growth factor (VEGF) value was **Known** or **Unknown** at the time of best response. If **Known**, report the value and specify the upper limit of normal as documented on the laboratory report. If **Unknown**, continue with question 142.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)