#### Question 28: Were lipid profiles assessed?

A lipid profile is a blood test that measures the amount of cholesterol and triglycerides within the blood. Indicate if lipid profiles were assessed since the date of last report. If lipid profiles were assessed in the current reporting period, report **Yes**. If lipid profiles were not assessed or if no information is available to determine if lipid profiles were evaluated during the current reporting period, report **No** or **Unknown**, respectively.

#### Questions 29 – 33: Specify which lipids were assessed (check all that apply)

Indicate which lipids were assessed and report the value in mg / dL. Select all that apply. If multiple lipid profile assessments were performed, report the results of the most recent assessment.

#### Question 34: Was an echocardiogram performed?

Indicate if an echocardiogram was performed since the date of last report. If an echocardiogram was performed during the current reporting period, report **Yes**. If an echocardiogram was not performed or if no information is available to determine if an echocardiogram was performed, select **No** or **Unknown**, respectively.

#### Questions 35 – 36: Was tricuspid regurgitant jet velocity (TRJV) measured?

Tricuspid regurgitant jet velocity (TRJV) measurements are used in determining the pulmonary artery pressure for recipients with sickle cell and other hemolytic disorders. An elevated TRJV is an indication of pulmonary hypertension, a condition common in adults with hemolytic diseases. TRJV is typically documented in the echocardiogram report.

Report **Yes** if TRJV was measured in the current reporting period and provide the TRJV value as documented on the echo report. If the TRJV was measured multiple times in the reporting period, report the most recent value. Report **No** if TRJV was not assessed or is not documented on the echo report.

#### Questions 37 – 39: Was left ventricular ejection fraction (LVEF) or left ventricular shortening fraction reported?

The left ventricular ejection fraction (LVEF) is a percentage that represents the volume of blood pumped from the left ventricle into the aorta (also known as stroke volume) compared to the volume of blood in the ventricle just prior to the heart contraction (also known as end diastolic volume). The left ventricular shortening fraction is the percentage change in cavity dimensions of the left ventricle with systolic contraction.

Report **Yes** if *either* the LVEF or left ventricular shortening fraction were assessed in the current reporting period and provide the percentage(s). If the LVEF or left ventricular shortening fraction were assessed multiple times in the reporting period, report the most recent value(s). Report **No** if the LVEF and left ventricular shortening fraction were not assessed in the current reporting period.

#### Questions 40 – 41: Is there a new onset of pulmonary hypertension?

Pulmonary hypertension (PH) refers to elevated pulmonary arterial pressure and is diagnosed either by an echocardiogram or right heart catherization. PH can be due to a primary elevation of pressure in the pulmonary arterial system alone (pulmonary arterial hypertension) or secondary to elevations of pressure in the pulmonary venous and pulmonary capillary systems (pulmonary venous hypertension; post-capillary PH).

Indicate **Yes** if there was a new onset of pulmonary hypertension (has never been previously diagnosed) since the date of last report and specify if either an echocardiogram or right heart catherization was used to diagnose PH.

Report **No** in in the following scenarios:


- There was not a new onset of PH in the current reporting period.
- PH was diagnosed prior to infusion or in a prior reporting period, resolved, and developed in the current reporting period.
- PH was diagnosed in a prior reporting period and persisted into the current reporting period.

If documentation is not clear or there is not enough information available to determine if PH was present, report **Unknown**.

#### Question 42: Is a copy of the echocardiogram report attached?

Indicate whether an echocardiogram report for either LVEF or pulmonary hypertension is attached to this form. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.manula.com/manuals/cibmtr/formsnet3-training-guide/1/en/topic/welcome).

#### Questions 43 – 44: Was cardiac MRI performed?

Cardiac MRI is a noninvasive test that uses a magnetic field and radiofrequency waves to create detailed pictures of your heart and arteries. Specify if a cardiac MRI was completed in the current reporting period. If **Yes**, indicate if abnormal iron deposition was found based on the MRI of the heart.

#### Questions 45 – 46: Cardiac iron T2 imaging?

Indicate if cardiac iron T2* imaging is known during the current reporting period. If **Known**, specify the value and units of measurement. If the cardiac iron T2* imaging was done multiple times, report the most recent assessment in the reporting period.

#### Questions 47 – 48: Was brain natriuretic peptide (BNP) assessed?

Brain natriuretic peptide (BNP) is a hormone secreted by cardiac ventricle cells in response to increased ventricular blood volume. BNP is typically measured using various immunoassay techniques.

Indicate if the BNP was assessed during the current reporting period. If **Yes**, report the value as documented on the laboratory report (in pg / mL). If BNP was assessed multiple times, report the results of the most recent test. If BNP was not assessed or if no information is available to determine if BNP was tested, report **No** or **Unknown**, respectively.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)