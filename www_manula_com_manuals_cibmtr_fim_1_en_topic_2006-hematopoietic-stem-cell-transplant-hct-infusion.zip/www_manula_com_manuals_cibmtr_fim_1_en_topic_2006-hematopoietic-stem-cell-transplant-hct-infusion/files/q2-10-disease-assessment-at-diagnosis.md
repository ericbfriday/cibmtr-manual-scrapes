**Report findings prior to any first treatment of the primary disease for which the HCT / cellular therapy is being performed.** If multiple studies were performed prior to the start of therapy, report the assessment closest to the diagnosis date of the primary disease for infusion. If the recipient’s MPN transformed, report the studies from the original diagnosis.

#### Question 2: Specify transfusion dependence at the time of diagnosis

“At diagnosis” is defined as from diagnosis until the start of treatment. If there are multiple transfusion dependence statuses, report the closest status to the date of diagnosis as possible.

Indicate the transfusion dependence for the recipient at the time of diagnosis and continue with question 3.

Select “Non-transfused (NTD)” if the recipient has not received any RBC transfusions within a period of 16 weeks prior to the time of diagnosis.

Select “Low-transfusion burden (LTB)” if the recipient 3-7 RBC transfusions within a period of 16 weeks or at least 2 transfusion episodes with a maximum of 3 RBC transfusions in 8 weeks prior to the time of diagnosis.

Select “High-transfusion burden (HTB)” if the recipient had ≥8 RBC transfusions within a period of 16 weeks or ≥4 within 8 weeks prior to the time of diagnosis.

#### Question 3: Did the recipient have splenomegaly at the time of diagnosis?

Indicate if the recipient had splenomegaly (i.e., abnormal enlargement of the spleen) at the time of diagnosis. Splenomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate “yes” if splenomegaly was present at the time of diagnosis and continue with question 4.

Indicate “no” if splenomegaly was not present at diagnosis and continue with question 7.

Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at diagnosis and continue with question 7.

Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy) and continue with question 7.

#### Question 4: Specify the method used to measure spleen size

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 5. If the method selected is “ultrasound” or “CT / MRI” continue with question 6. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 5: Specify the spleen size below the left coastal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 7.

#### Question 6: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 7.

#### Question 7: Did the recipient have hepatomegaly

Indicate if the recipient had hepatomegaly (i.e., abnormal enlargement of the liver) at the time of diagnosis. Hepatomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding.

Indicate “yes” if hepatomegaly was present at the time of diagnosis and continue with question 8.

Indicate “no” if hepatomegaly was not present at diagnosis and continue with question 11.

Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at diagnosis and continue with question 11.

#### Question 8: Specify the method used to measure liver size

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 9. If the method selected is “ultrasound” or “CT / MRI” continue with question 10. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 9: Specify the liver size in centimeters below the right coastal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 11.

#### Question 10: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 11.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)