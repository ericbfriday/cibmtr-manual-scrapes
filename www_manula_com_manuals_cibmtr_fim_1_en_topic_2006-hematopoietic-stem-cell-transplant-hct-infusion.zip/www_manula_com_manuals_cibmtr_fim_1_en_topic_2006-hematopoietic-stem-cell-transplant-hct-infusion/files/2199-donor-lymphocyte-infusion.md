This form is a single abbreviated form with elements of the Pre-CTED Form 4000, Cell Therapy Product Form 4003, Cell Therapy Infusion Form 4006, and Post-CTED Form 4100, which must be completed for all recipients who receive a donor lymphocyte infusion (DLI). DLIs are defined as:


- The infusion must be Post-Allo HCT AND probably from the same donor
+ - Product must be Lymphocytes only
- Product cannot be genetically modified

+This is the most common scenario right now, but in the future, DLI products may be obtained from a different donor

For recipients of any other type of cellular therapy, such as CAR T cells, tumor-infiltrating lymphocytes, cytotoxic T cells, or any cellular therapy product that is genetically modified, complete the Pre-CTED Form 4000.

Multiple donor lymphocyte infusions within the same reporting period require a separate Donor Lymphocyte Infusion (2199) form for each infusion. This form will come due for recipients post-HCT when DLI are reported on the Indication for CIBMTR Data Reporting (2814) after a subsequent infusion is reported on the Post-TED Form 2450, Post-Infusion Follow-Up Form 2100, and Post-CTED Form 4100. At the time of F2814 completion, the total number of DLIs received in that reporting period are reported on the form. That number will make due the same number of F2199s. The F2450/2100/4100 will not be completed early to report DLIs given in the reporting period.

HCT or CT reporting will not be interrupted and combined follow up rules do not apply. There will no longer be any Post-CTED Form 4100s for DLIs.

Links to Sections of Form:

[Q1-34 Donor Lymphocyte Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-34-donor-lymphoctye-infusion-dli)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/25/2024 |
|

When the Post-TED (2450) or Post-Infusion follow up (2100) form is completed at the due date, and no other infusions were given in the reporting period, report the DLI as a subsequent infusion, which will create a new Indication for CIBMTR Data Reporting (2814) Form. Submit a ticket via CIBMTR Center Support to request the form be made NRQ.

[2199: Donor Lymphocyte Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2199-donor-lymphocyte-infusion)*at any time*prior the DLI.[2199: Donor Lymphocyte Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2199-donor-lymphocyte-infusion)[2199: Donor Lymphocyte Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2199-donor-lymphocyte-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)