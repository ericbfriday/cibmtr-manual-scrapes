The Donor Demographic Information section (questions 144-170) is to be completed for all non-NMDP allogeneic donors / CBUs. If the stem cell product was from an NMDP donor or an autologous donor, continue with the signature lines at the end of the form.

#### Question 142: Was the donor ever pregnant?

If the donor has ever been pregnant, select **Yes**. If the donor has never been pregnant, select **No**. If there is no documentation regarding whether or not the donor has ever been pregnant, select **Unknown**.

If the product is a cord blood unit, or was from a male donor, select **Not Applicable (male donor or cord blood unit)**.

#### Questions 143-144: Number of pregnancies

Indicate if the number of pregnancies is **Known** or **Unknown**. If **Known**, specify the total number of pregnancies.

If the total number of pregnancies is not documented or cannot be determined, report *Unknow*n.

#### Question 145: Donor’s ethnicity

Indicate the donor’s ethnicity. For more information regarding ethnicity, see [Appendix I](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-i-ethnicity-and-race).

#### Questions 146-147: Donor’s race and detail: (*Mark the group(s) in which the donor is a member. Check all that apply.*)

Indicate the race of the donor, marking all that apply. For more information regarding race, see [Appendix I](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-i-ethnicity-and-race).

#### Question 148: Was the donor a carrier for potentially transferable genetic diseases?

If the donor was a carrier for a potentially transplantable genetic disease, select **Yes**. If the donor was not tested, or if there is no documentation of genetic testing, select **No**.

#### Questions 149-150: Specify potentially transferable genetic disease

Indicate the potentially transplantable genetic disease for which the donor is a carrier. If the donor was a carrier for a potentially transplantable disease, but the disease was not listed, select **Other disease** and specify. Only genetic diseases that are transferable (from donor to recipient) should be reported. Chagas and WNV (West Nile Virus) should not be reported as a potentially transferable genetic disease as they are examples of infections and not a genetic disease.

Submit a ticket through CIBMTR Center support regarding questions about transferable genetic diseases.

#### Question 151: Was the donor / product tested for other transferable genetic or clonal abnormalities?

If the donor and / or product were tested for other transferable genetic or clonal abnormalities, select **Yes**. If this is a related donor and / or the donor / product were not tested, or if there is no documentation of genetic testing, select **No** or **Unknown**, respectively and continue with the signature lines.

It should be noted for cord blood unit transplants that almost all units are screened, or the infant is screened, for potentially transplantable genetic diseases. This may be documented as a ‘hemoglobin screen,’ which evaluates for sickle cell disease and / or thalassemia, both of which are considered hemoglobinopathies.

#### Questions 152-155: Specify disease(s) tested

For each of the genetic or clonal abnormalities listed, indicate whether the disease testing was done. Indicate **Yes** or **No** and specify the method of testing in the following question. Do not leave any responses blank. If the donor was tested for a potentially transferable genetic or clonal abnormality, but it was not listed, select **Yes** for *Other transferable genetic or clonal abnormality* and specify.

#### Question 157: Did this donor have a central line placed? (non-NMDP PBSC donors only)

This question only applies to non-NMDP PBSC donors. Indicate if the donor had a central line placed during the donation process.

#### Question 158: Was the donor hospitalized (inpatient) during or after the collection?

Indicate if the donor was hospitalized for complications during or after the collection. If the donor was not hospitalized as an inpatient or if the donor was admitted to an observation unit and discharged in less than 24 hours, report **No**.

#### Questions 159 – 160: Did the donor experience any life-threatening complications during or after the collection?

Examples of life-threatening complications include, but are not limited to the following:


- Allergic reaction to filgrastim
- Reaction to anesthesia
- PBSC donors: Low platelet counts (<30,000)
- Marrow donors: Injury to bone, nerve, or muscle during collection

Many of these criteria are outlined by the Common Terminology Criteria for Adverse Events (CTCAE) and would be reported as a Grade 4 or higher adverse event. For more information on CTCAE complications that can be reported, see the published criteria at: [https://ctep.cancer.gov/protocolDevelopment/electronic_applications/ctc.htm](http://ctep.cancer.gov/protocolDevelopment/electronic_applications/ctc.htm).

If the donor experienced life-threatening complications during or after the collection, select **Yes** and specify the complication(s).

If the donor did not experience life-threatening complications during or after the collection, select **No**.

#### Questions 161-163: Did the allogeneic donor give one or more autologous transfusion units?

If the allogeneic donor gave one or more autologous transfusion units, select **Yes**, and specify the date of collection of the first unit and total number of units collected. If the donor did not give autologous blood transfusion units, select **No**.

#### Questions 164-166: Did the donor receive blood transfusions as a result of the collection?

Indicate if the donor received blood transfusions as a result of the collection. If the donor received transfusions of their own blood that had been previously collected and stored, even once, indicate **Autologous transfusions** and specify the number of units received.

If the donor received blood transfusions (excluding autologous blood product), indicate **Allogeneic transfusions** and specify the number of units received.

If the recipient did not receive blood transfusions as a result of the collection, select **No**.

#### Questions 167-168: Did the donor die as a result of the collection?

Indicate if the donor died as a result of the collection. If **Yes**, specify the cause of death. If the donor did not die as a result of the collection, select **No** and continue with the signature lines.

**Signature Lines:**

The FormsNet3SM application will automatically populate the signature data fields, including name and email address of person completing the form and date upon submission of the form.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)