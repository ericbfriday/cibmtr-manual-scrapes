See below for additional information on how to enter data in the ISCN compatible string data field.

- The ISCN compatible string data field has a 1,000 character limit
- Do not report FISH results
- If the results contain ‘nuc ish,’ do not report the results as these are considered FISH results

- The ISCN compatible string data field error cannot be overridden. If an error is fired, it must be addressed and corrected, or the field left blank and the abnormalities selected in the specific abnormalities detected section of the form
- The ISCN compatible string data field cannot be overridden
- A karyotype report alone cannot be attached
- Either the ISCN compatible string data field or the number of abnormalities identified along with the specific abnormalities detected must be completed
- FormsNet3
SMdoes not have the capability to extract the abnormalities from an attached report

- If only a constitutional abnormality is present, report ‘no abnormalities’
- The ISCN compatible string and the number of abnormalities identified along with the specific abnormality data fields will not be answered
- Example:
`47,XX,+21[20]`

is identified at diagnosis- +21 represents Down Syndrome which is a constitutional abnormality and should not be reported.
- In this case, report
**Yes**, karyotype was performed, and**No abnormalities**were detected



If there are questions on how to use the ISCN functionality, submit a ticket through CIBMTR Center Support.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Jul 31, 2023

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)