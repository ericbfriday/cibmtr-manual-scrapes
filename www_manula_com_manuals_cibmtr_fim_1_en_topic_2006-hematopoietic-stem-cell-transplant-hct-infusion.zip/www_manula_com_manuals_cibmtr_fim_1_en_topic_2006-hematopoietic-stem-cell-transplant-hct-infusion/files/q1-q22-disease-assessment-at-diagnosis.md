#### Question 1: Is this recipient a registered participant in the United States Immunodeficiency Network (USIDNET)?

The United Stated Immunodeficiency Network (USIDNET) is a research consortium studying primary immune deficiencies. They maintain a registry of primary immunodeficiency patients and act as a resource for clinical and laboratory research. Indicate if the recipient is a registered participant in the USIDNET. If “yes,” continue with question 2. If “no,” continue with question 3.

#### Question 2: USIDNET ID:

Report the recipient’s USIDNET participant identification number.

#### Question 3: What was the date of diagnosis?

Diagnosis is based on molecular OR diagnostic criteria below:[1](#fn164752720168596aa364f39-1)[2](#fn164752720168596aa364f39-2)

Molecular Diagnosis

A diagnosis consistent with HLH:


*PRF1**UNC13D**STX11**STXBP2**BIRC4**ITK*

**OR**

Diagnostic Criteria

Meets diagnostic criteria for HLH (5 of 8 criteria below):


- Fever
- Splenomegaly
- Cytopenias (affecting ≥ 2 of 3 lineages in the peripheral blood)
- Hemoglobin < 90 g/L (9.0 g/dL) (in infants < 4 weeks: hemoglobin < 100g/L (10.0 g/dl)
- Platelets < 100 × 10
9/L - Absolute neutrophil count < 1.0 × 10
9/L

- Hypertriglyceridemia and/or hypofibrinogenemia:
- Fasting triglycerides ≥ 3.0 mmol/L (265 mg/dL)
- Fibrinogen ≤ 1.5 g/L

- Hemophagocytosis in bone marrow, spleen, or lymph nodes
- Low or absent NK-cell activity (according to local laboratory reference)
- Ferritin ≥ 500 μg/L
- Soluble CD25 (soluble IL-2 receptor) ≥ 2,400 U/mL |

1 Henter JI, Horne A, Aricó M, Egeler RM, Filipovich AH, Imashuku S. Ladisch S, McClain K, Webb D, Winiarski J, Janka G. HLH-2004: Diagnostic and therapeutic guidelines for hemophagocytic lymphohistiocytosis. *Pediatr Blood Cancer*. V 2007:48(2):124-31.

2 Jordan MB, Allen CE, Weitzman S, Filipovich AH, McClain KL. How I treat hemophagocytic lymphohistiocytosis. *Blood*. 2011;118(15):4041-52.

HLH is characterized by multiple clinical, laboratory, and genetic features, rather than distinct pathological characteristics. Examples of testing done to confirm a diagnosis of HLH include molecular analysis to determine defects in *PRF1, UNC13D, STX11, STXBP2,* and *ITK genes*. In situations where molecular testing did not result in diagnosis, the date of diagnosis should be the date the sample was collected for the last assessment used to establish a diagnosis of HLH (i.e., the 5th criteria that establishes 5 of 8 diagnostic criteria are met, in the absence of molecular marker). If there is a strong family history of HLH and no testing was done to confirm the diagnosis, report the recipient’s date of birth as the date of diagnosis.

#### Questions 4-10: Is there a family history of hemophagocytic disorders?

Indicate if there is a family history of hemophagocytic disorders. Family history includes the recipient’s biological aunts, uncles, cousins, and/or siblings. If there is a family history of hemophagocytic disorders, indicate “yes” and continue with questions 5-10. In questions 5-9, indicate the biological family member(s) that were affected by the hemophagocytic disorder. Indicate “yes” or “no” for each member listed, leaving no question blank. If a biological family relationship is not listed, select “other family member” in question 9 and specify the relationship in question 10.

If there is no family history of hemophagocytic disorders, select “no” and continue with question 11. If it is unknown if there is a family history of hemophagocytic disorders, indicate “unknown” and continue with question 11.

#### Question 11: Is there a family history of consanguinity (inter-familial marriage/descent from common ancestors)?

Consanguinity describes a relationship between people who share common ancestors (i.e., are “blood-relatives”). Indicate if the there is a family history of consanguinity in the direct ancestry of the recipient. This includes the recipient’s parents, grandparents, great-grandparents, etc. Indicate “yes” if there is a known history of consanguinity. Indicate “no” if there is no family history of consanguinity. Indicate “unknown” if the family history is not known.

#### Question 12: Was genetic testing used to confirm the diagnosis?

Genetic testing includes molecular methods to detect mutations characteristic of the disease. Genetic mutations for HLH include Perforin deficiency (*PRF1*) MUNC 13-4 (*UNC13D*), Syntaxin 11 (*STX11*), Munc 13-2 (*STXBP2*), and IL-2 inducible T-cell kinase (*ITK*). Indicate if genetic testing was performed to confirm the diagnosis. If “yes,” continue with question 13. If “no,” continue with question 20. If it is unknown if genetic testing was performed to confirm the diagnosis, indicate “unknown” and continue with question 20.

#### Questions 13-19: Specify genetic mutation(s) identified:

For each genetic mutation listed, indicate if the mutation was identified. If the genetic test was performed and the mutation was present, indicate “Yes.” If the genetic analysis was performed, but the mutation was absent, indicate “No.” If it is unknown if the test for the genetic mutation was performed or if the results are unknown, indicate “unknown.” If the test was not done for the genetic mutation, select “not done.” Do not leave any of the questions blank. If a test for a different mutation was performed, indicate the results of the test in question 18 and specify the other mutation in question 19. If no testing was done for mutations other than those already listed, select “not done” for question 18.

#### Question 20: Were central nervous system (CNS) abnormalities found on computed tomography (CT or CAT) or magnetic resonance imaging (MRI) scans?

Indicate if radiology (CT, CAT, and/or MRI) performed on the recipient detected any abnormalities in the central nervous system (brain and spinal cord) at the time of diagnosis. CNS abnormalities may include lesions, leptomeningeal enhancements, or edema.[3](#fn164752720168596aa364f39-3)

If the recipient did have CNS abnormalities found on imaging at diagnosis, select “yes” and continue with question 21. If the recipient did not have CNS abnormalities detected by imaging, select “no” and continue with question 23. If it is unknown if the recipient had imaging done or if the results of imaging studies are not known, select “unknown” and continue with question 23.

3 Jordan MB, Allen CE, Weitzman S, Filipovich AH, McClain KL. How I treat hemophagocytic lymphohistiocytosis. *Blood*. 2011;118(15):4041-52.

#### Question 21: Date scan was performed:

Enter the date the radiological assessment was performed.

If the exact date is not known, use the process for reporting partial or unknown dates as described in [General Instructions, Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 22: Was documentation submitted to the CIBMTR?

Indicate if a copy of the CT, CAT, or MRI scan(s) is attached. Use the Log of Appended Documents (Form 2800) to attach a copy of CT, CAT, or MRI report(s). Attaching a copy of the report may prevent additional queries.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)