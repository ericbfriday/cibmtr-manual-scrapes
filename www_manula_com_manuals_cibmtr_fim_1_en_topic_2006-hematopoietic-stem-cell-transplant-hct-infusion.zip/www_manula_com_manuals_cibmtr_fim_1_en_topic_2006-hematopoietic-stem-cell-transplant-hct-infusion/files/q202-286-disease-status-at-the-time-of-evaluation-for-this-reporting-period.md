#### Question 203: Does the current disease status reflect the disease detected in this reporting period section (as captured in questions 105-202), without subsequent therapy?

This section of the form is intended to capture the most recent disease assessments performed in the reporting period. The most recent disease assessments may have already been reported in questions 105-202 (Disease Detection Since the Date of Last Report). If that is the case and the recipient has not received any therapy, it is not necessary to report those same disease assessments in questions 203-275 (Disease Status at the Time of Evaluation for this Reporting Period). Refer to the instructions below to determine how to complete this section of the form. Reporting scenarios have also been provided below.

Report “Yes” for question 203 and go to question 276 in any of the following scenarios:


- Disease was detected by any method in the reporting period (reported in the Disease Detected Since the Date of Last Report, questions 105-181) and no therapy was given to treat disease between the date(s) of the assessments reported in the Disease Detection Since the Date of Last Report (questions 105-181) for the form and the date of contact for this reporting period
- Disease was detected by any method in the reporting period (reported in the Disease Detection Since the Date of Last Report, questions 105-181), therapy was administered, but no assessments were performed after the initiation of therapy

Report “No” for question 203 and report the most recent disease assessments in the reporting period in questions 204 – 275 in any of the following scenarios:


- Disease was not detected by any method of assessment during the reporting period; or
- Disease was detected in the reporting period (reported in the Disease Detected Since the Date of Last Report, questions 105-181), therapy was administered, and additional assessment(s) were performed after therapy


Report “Not applicable” for question 203 and submit the form if no disease assessments were performed during the current reporting period. This option should not commonly be used as it would indicate that the recipient did not have **any** disease assessments, including a physical exam by their primary care provider, performed during the reporting period.

Contact the CIBMTR Customer Service Center if there are questions regarding whether a visit or test should be reported as a disease assessment.

#### Questions 204-205: Did the recipient have splenomegaly? (at the time of evaluation for this reporting period)

Indicate if the recipient had splenomegaly at the time of evaluation for this reporting period. Splenomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding. Splenomegaly can also be detected by imaging techniques such as ultrasonography, CT or MRI.

Indicate “yes” if splenomegaly was present at the time of evaluation for this reporting period and report the date of assessment in question 205.

Indicate “no” if splenomegaly was not present at the time of evaluation for this reporting period and continue with question 209.

Indicate “unknown” if it is not possible to determine the presence or absence of splenomegaly at the time of evaluation for this reporting period and continue with question 209.

Indicate “not applicable” if the question does not apply to the recipient (e.g. prior Splenectomy) and continue with question 209.

#### Question 206: Specify the method used to measure spleen size:

Indicate the method used to measure the spleen size, if the method selected is “physical assessment” continue with question 207. If the method selected is “ultrasound” or “CT / MRI” continue with question 208. If spleen size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Question 207: Specify the spleen size in centimeters below the left costal margin

Indicate the size of the spleen in centimeters, measured below the left coastal margin as assessed by physical exam then continue with question 209.

#### Question 208: Specify the spleen size in centimeters

Indicate the size of the spleen in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 209.

#### Questions 209-210: Did the recipient have hepatomegaly? (at the time of evaluation for this reporting period)

Indicate if the recipient had hepatomegaly at the time of evaluation for this reporting period. Hepatomegaly is often documented during the physician’s physical assessment of the recipient and represents an abnormal finding.

Indicate “yes” if hepatomegaly was present at the time of evaluation for this reporting period and report the date of assessment in question 210.

Indicate “no” if hepatomegaly was not present at the time of evaluation for this reporting period and continue with question 214.

Indicate “unknown” if it is not possible to determine the presence or absence of hepatomegaly at the time of evaluation for this reporting period and continue with question 214.

#### Question 211: Specify the method used to measure liver size:

Indicate the method used to measure the liver size, if the method selected is “physical assessment” continue with question 212. If the method selected is “ultrasound” or “CT / MRI” continue with question 213. If liver size is measured using multiple methods, report the most accurate assessment. Ultrasound is the most specific and preferred assessment.

#### Questions 212: Specify the liver size in centimeters below the right costal margin

Indicate the size of the liver in centimeters, measured below the right coastal margin as assessed by physical exam then continue with question 214.

#### Question 213: Specify the liver size in centimeters

Indicate the size of the liver in centimeters, as assessed by imaging (ultrasound, CT / MRI) then continue with question 214.

#### Question 214-224: Were tests for driver mutations performed?

Testing for driver mutations may be performed by different methods including next generation sequencing (NGS), polymerase chain reaction (PCR), microarray, and fluorescence in situ hybridization (FISH).

If testing by any / all of these methods was performed at the last evaluation, to assess JAK2, CALR, MPL and CSF3R, report “yes” for question 214 and continue with question 215.

If tests for driver mutations were not performed at the last evaluation, or it is unknown if testing was done, report “no” or “unknown” respectively and go to question 226.

#### Question 225: Was documentation submitted to the CIBMTR (e.g. pathology report, FISH report)?

Indicate whether documentation was submitted to the CIBMTR (e.g., pathology report, FISH report). For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 226: Were molecular tests for molecular markers performed (e.g., PCR)? (please do not include driver mutations JAK2, CALR, MPL, and CSF3R as previously captured above) (at time of evaluation for this reporting period)

Molecular markers for disease refer to specific genetic sequences which are believed to be associated with the recipient’s primary disease. Testing for these sequences is often performed using PCR based methods; however, lower sensitivity testing, including FISH, may also be used to detect molecular markers. **FISH testing for molecular markers should not be reported here**.

Once a marker has been identified, these methods can be repeated to detect minimal residual disease (MRD) in the recipient’s blood, bone marrow, or tissue. Molecular assessments include polymerase chain reaction (PCR) amplification to detect single specific disease markers; however, molecular methods are evolving and now include chromosomal microarray / chromosomal genomic array, Sanger sequencing, and next generation sequencing (e.g., Illumina, Roche 454, Proton / PGM, SOLiD).

If molecular testing for molecular markers was performed at the time of evaluation for this reporting period, report “yes” and go to question 227.

If molecular testing for molecular markers was not performed at the time of evaluation for this reporting period, or it is unknown if testing was done, report “no” or “unknown” respectively and go to question 234.

#### Question 227: Indicate if a positive molecular marker(s) was identified

Indicate if a positive molecular marker was identified at the time of evaluation for this reporting period.

If a positive molecular marker was identified, select “yes” and continue with question 228.

If there were no molecular markers identified, or it is unknown whether molecular markers were identified, select “no” or “unknown” respectively, and continue with question 234.

#### Question 228: Date sample collected

Report the date the sample was collected for molecular testing.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Questions 229-230: Specify the positive molecular marker

Specify the positive molecular marker and continue with question 231. If a positive marker is detected, but not listed as an option, select “other molecular marker” and specify the positive molecular marker in question 230.

#### Questions 231-232: Amino acid change

Amino acid changes can be described using standard mutation nomenclature. For CIBMTR reporting purposes, only amino acid changes based on protein-level sequences, beginning with the prefix “p.,” need to be reported. See Figure 1 below for an example of an amino acid change within a molecular pathology report.

**Figure 1**. Molecular disease assessment with amino acid changes documented (highlighted in yellow).


For more information on nomenclature used for amino acid changes, visit the [Human Genome Variation Society Sequence Variant Nomenclature Protein Recommendations](http://varnomen.hgvs.org/recommendations/protein/).

For question 231, indicate if the amino acid change is “known “or “unknown” for the positive molecular marker reported in questions 229-230. If known, report the amino acid change in question 232. If unknown, continue with question 233.

Copy questions 229-232 to report more than one positive molecular marker.

#### Question 233: Was documentation submitted to the CIBMTR?

Indicate if the pathology report is attached to support the molecular findings reported in questions 229-232. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 234: Was the disease status assessed via flow cytometry? (at the time evaluation for this reporting period)

Flow cytometry assessment is a method of analyzing peripheral blood, bone marrow, or tissue preparations for multiple unique cell characteristics; its primary clinical purpose in the setting of MDS, MPN, and leukemias is to quantify blasts in the peripheral blood or bone marrow, or to identify unique cell populations through immunophenotyping. Flow cytometry assessment may also be referred to as “MRD” or minimal residual disease testing.

Indicate if flow cytometry was performed on peripheral blood and/or bone marrow sample at the time of evaluation for this reporting period.

If flow cytometry was performed, select “yes” and continue with question 235.

If flow cytometry was not performed, flow cytometry sample was inadequate, or it is unknown if flow cytometry was performed, select “no” and continue with question 243.

#### Question 235-236: Blood

Indicate if flow cytometry was performed on the peripheral blood at the time of evaluation for this reporting period. If multiple assessments were performed, report the assessment performed closest to the date of contact.

If flow cytometry was performed on a peripheral blood sample, select “yes” and report the date the sample was collected in question 236. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a peripheral blood sample, select “no” and continue with question 239.

#### Questions 237-238: Was disease detected?

Indicate if evidence of disease was detected in the peripheral blood sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the recipient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 238.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 239.

#### Question 239-240: Bone Marrow

Indicate if flow cytometry was performed on the bone marrow at the time of evaluation for this reporting period. If multiple assessments were performed, report the assessment performed closest to the date of contact.

If flow cytometry was performed on a bone sample, select “yes” and report the date the sample was collected in question 240. If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If flow cytometry was not performed on a bone marrow sample, select “no” and continue with question 243.

#### Questions 241-242: Was disease detected?

Indicate if evidence of disease was detected in the bone marrow sample sent for flow cytometry analysis. Evidence of disease may include the presence of blasts or an immunophenotype known to characterize the recipient’s disease. If flow cytometry results are consistent with evidence of disease, select “yes” and specify the percentage of disease detected (to the nearest thousandth) in the peripheral blood as documented in the flow cytometry report in question 242.

If flow cytometry results were not consistent with evidence of disease, check “no” and continue with question 243.

#### Question 243: Were cytogenetics tested (karyotyping or FISH)? (at time of evaluation for this reporting period)

Cytogenetic analysis is the study of chromosomes. Cytogenetic assessment involves testing blood or bone marrow for the presence of known chromosomal abnormalities that reflect the recipient’s disease. Testing methods include conventional chromosome analysis (karyotyping) or fluorescence in situ hybridization (FISH). For more information about cytogenetic testing and terminology, see [Appendix C, Cytogenetic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-c).

Karyotyping is performed by culturing cells (growing cells under controlled conditions) until they reach their dividing phase. Techniques are then performed to visualize the chromosomes during cell division so that various bands and reconfigurations can be seen. Banding pattern differentiation and chromosomal reconfiguration demonstrated evidence of disease.

FISH is a sensitive technique that assesses a large number of cells. This technique uses special probes that recognize and bind to fragments of DNA. These probes are mixed with cells from the recipient’s blood or bone marrow. A fluorescent “tag” is then used to visualize the binding of the probe to the diseased cells. Additionally, the FISH probe panel should reflect the recipient’s current disease; FISH may be used as surveillance for changes associated with post-therapy malignancy.

FISH testing for sex chromosomes after sex-mismatched allogeneic HCT should not be considered a disease assessment as the purpose is to determine donor chimerism.

If cytogenetic (karyotyping or FISH) studies were obtained at the time of evaluation for this reporting period, report “yes” and continue with question 244.

If cytogenetic studies were attempted at the time of evaluation for this reporting period, but there were not adequate cells (metaphases), report “no” and go to question 262.

If no cytogenetic studies were obtained at the time of evaluation for this reporting period, indicate “no” and continue with question 262.

If it is not known whether any cytogenetic studies were obtained at the time of evaluation for this reporting period, indicate “unknown” and go to question 262.

#### Question 244: Were cytogenetics tested via FISH?

If FISH studies were performed at the time of evaluation for this reporting period, report “yes” for question 244 and go to question 245. If FISH studies were not performed, report “no” for question 244 and go to question 253. Examples of this include: no FISH study performed or FISH sample was inadequate.

#### Question 245-246: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 246. Continue with question 247. If multiple sources were used to test FISH, the preferred sample is the bone marrow

#### Question 247: Results of test

If FISH assessments identified abnormalities, indicate “abnormalities identified” and continue with question 248.

If FISH assessments were unremarkable, indicate “no abnormalities” and continue with question 252.

#### Questions 248-251: Specify cytogenetic abnormalities (FISH)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 248, then continue with question 249.

Report the number of abnormalities detected by FISH at the time of evaluation for this reporting period in question 249. After indicating the number of abnormalities in question 249, select all abnormalities detected in questions 250-251.

If an abnormality is detected, but not listed as an option in question 250, select “other abnormality” and specify the abnormality in question 251. If multiple “other abnormalities” were detected, report “see attachment” in question 251 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 252: Was documentation submitted to the CIBMTR? (e.g. FISH report)

Indicate if the FISH report is attached to support the cytogenetic findings reported in questions 248-251. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 253: Were cytogenetics tested via karyotyping?

If karyotyping studies were performed at the time of evaluation for this reporting period, report “yes” for question 253 and go to question 254. If karyotyping studies were not performed, report “no” for question 253 and go to question 262. Examples of this include: no karyotyping study performed or karyotyping sample was inadequate.

#### Questions 254-255: Sample source

Indicate if the sample was from “bone marrow” or “peripheral blood” and report the date the sample was collected in question 255. Continue with question 256. If multiple sources were used for karyotyping analysis, the preferred sample is the bone marrow

#### Question 256: Results of test

If karyotyping assessments identified abnormalities, indicate “abnormalities identified” and continue with question 257.

If karyotyping assessments were unremarkable, indicate “no abnormalities” and continue with question 261.

If karyotyping assessment yielded an inadequate result, indicate “no evaluable metaphases” and continue with question 261.

#### Questions 257-260: Specify cytogenetic abnormalities (karyotyping)

Report the International System for Human Cytogenetic Nomenclature (ISCN) compatible string, if applicable, in question 257, then continue with question 258.

Report the number of abnormalities detected by karyotyping at the time of evaluation for this reporting period in question 258. After indicating the number of abnormalities in question 258, select all abnormalities detected in questions 259-260.

If an abnormality is detected, but not listed as an option in question 259, select “other abnormality” and specify the abnormality in question 260. If multiple “other abnormalities” were detected, report “see attachment” in question 260 and attach the final report(s) for any other abnormalities detected. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Question 261: Was documentation submitted to the CIBMTR? (e.g. karyotyping report)

Indicate if the karyotyping report is attached to support the cytogenetic findings reported in questions 257-260. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](https://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25).

#### Questions 262-263: Was disease detected via bone marrow examination? (at the time of evaluation for this reporting period)

Indicate if disease was detected at the time of evaluation for this reporting period by a bone marrow examination. If disease was detected, report “yes” for question 262 and report the date of the assessment in question 263. Continue with question 264.

If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If disease was detected by multiple bone marrow biopsies during the reporting period, report the date of the assessment performed closest to the date of contact.

If disease was not detected by a bone marrow examination at any time during the reporting period, or it is unknown if disease was detected, report “no” or “unknown” respectively and go to question 268.

#### Questions 264-265: Blasts in the bone marrow

Indicate wither the percentage of blasts in the bone marrow was “known” or “unknown” at the time of evaluation for this reporting period. If “known” report the percentage documented on the laboratory report in question 265. If “unknown” continue with question 266.

#### Question 266: Myelofibrosis grading by WHO classification

Fibrosis describes the replacement of bone marrow by fibrous (scar) tissue. This is evident in MPN diseases such as chronic idiopathic myelofibrosis. This distinction is made on the pathology report of a bone marrow examination and the myelofibrosis grade may be documented by the pathologist.

Indicate if the myelofibrosis grading is “known” or “unknown.” If the myelofibrosis grade is documented in the pathology report or stated in a physician note, select “known,” continue with question 267.

If the myelofibrosis grade is not documented, select “unknown,” continue with question 268.

#### Question 267: Specify the grade

Specify the Myelofibrosis grading using the WHO classification. The classification and results should be clarified in the pathology report as dictated by the pathologist.

Select “MF-0” if the report documents scattered linear reticulin with no intersection (crossovers) corresponding to normal bone marrow.

Select “MF-1” if the report documents a loose network of reticulin with many intersections, especially in perivascular areas.

Select “MF-2” if the report documents diffuse and dense increase in reticulin with extensive intersections, occasionally with focal bundles of thick fibers mostly consistent with collagen, and/or focal osteosclerosis.

Select “MF-3” if the report documents diffuse and dense increase in reticulin with extensive intersections and coarse bundles of thick fibers consistent with collagen, usually associated with osteosclerosis.

#### Questions 268-269: Was extramedullary disease indicative of AML detected? (e.g. myeloid sarcoma) (at the time of evaluation for this reporting period)

Indicate if the recipient had extramedullary disease indicative of AML at the time of evaluation for this reporting period. An example of extramedullary disease would be a myeloid sarcoma. Indicate “yes” if extramedullary disease indicative of AML was present at the time of evaluation for this reporting period and report the date of assessment in question 269. Indicate “no” if extramedullary disease indicative of AML was not present at the time of evaluation for this reporting period and continue with question 272.

#### Questions 270-271: Specify site(s) of disease (check all that apply)

Select each site where extramedullary disease indicative of AML was detected on the date reported in question 270. If extramedullary disease indicative of AML was detected at a site not specified in question 270, report “other site” and specify all other sites where extramedullary disease indicative of AML in question 271.

#### Questions 272-274: Was disease status assessed by other assessment? (at the time of evaluation for this reporting period)

Indicate if the recipient’s disease status was assessed by any other assessment at the time of evaluation for this reporting period. Indicate “yes” if the disease status was assessed by other assessment at the time of evaluation for this reporting period, report the date of assessment in question 273, and specify the name of the other assessment in question 274. Indicate “no” if the disease status was not assessed by other assessment at the time of evaluation for this reporting period and continue with question 276.

#### Question 275: Was disease detected?

If the other disease assessment indicated the presence of disease, select “yes” and continue with question 276.

If the other disease assessment did not indicate the presence of disease, select “no” and continue with question 276.

#### Question 276: What is the current disease status?

Indicate the disease response of MPN using the definitions found in the text on FormsNet3SM. These definitions are also located in the [MPN Response Criteria](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/mpn-response-criteria).

If the recipient’s disease status was “Complete clinical remission (CR),” “Partial clinical remission (PR),” “Stable disease (SD),” “Progressive disease,” “Relapse,” or “Progression to AML (AML),” continue with question 280.

If the recipient’s disease status was “Clinical improvement (CI),” continue with question 277.

If the disease status was “not assessed,” continue with question 281.

The center does not need to repeat all disease-specific assessments (biopsies, scans, labs) each reporting period in order to complete current disease status data fields. Once a particular disease status is achieved, the center can continue reporting that disease status (based on labs / clinical assessments) until there is evidence of relapse / progression.

#### Question 277: Was an anemia response achieved?

Specify if an anemia response has been achieved at the time of the last evaluation and continue with question 278.

An anemia response is characterized by a ≥20 g/L (or > 2.0 g/dL) increase in hemoglobin level (for transfusion-independent recipients) or by becoming transfusion-independent (transfusion-dependent recipients).

#### Question 278: Was a spleen response achieved?

Specify if a spleen response has been achieved at the time of the last evaluation and continue with question 279.

A spleen response is achieved when a baseline splenomegaly that is palpable at 5-10 cm below the left costal margin (LCM) becomes not palpable or baseline splenomegaly that is palpable at >10 cm below the LCM, decreases by ≥50%.A baseline splenomegaly that is palpable at <5 cm, below the LCM, is not eligible for spleen response.

A spleen response can be documented by a physician or confirmed by MRI / computed tomography showing ≥35% spleen volume reduction.

#### Question 279: Was a symptom response achieved?

Specify if a symptom response has been achieved at the time of the last evaluation and continue with question 280.

A symptom response is achieved when there is a ≥50% reduction in the Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS).

The Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS) is used to evaluate the recipient’s symptom response. The MPN-SAF TSS is used to provide an accurate assessment of MPN symptom burden. The evaluation tool allows recipients with MPN to report their symptom severity at the worst level. They rate their symptom severity on a scale from zero to ten, zero being absent to ten being the worst imaginable. Adding the scores for all symptoms together will result in the recipient’s MPN-SAF TSS. See Table 1 below for an example of this assessment:

**Table 1**. Myeloproliferative Neoplasm Symptom Assessment Form Total Symptom Score (MPN-SAF TSS)


#### Question 280: Date assessed:

Enter the date of the most recent assessment establishing disease status within the reporting period. The date reported should be that of the most disease-specific assessment within a reasonable timeframe of the date of contact (approximately 30 days). Clinical and hematologic assessments include pathological evaluation (e.g., bone marrow biopsy), radiographic examination (e.g., X-ray, CT scan, MRI scan, PET scan), laboratory assessment (e.g., CBC, peripheral blood smear), and clinician evaluation and physical examination. Enter the date the sample was collected for pathological and laboratory evaluations, the date the imaging took place for radiographic assessments, or the date of physical examination.

If the exact date is not known, use the process for reporting partial or unknown dates as described in General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 281: Specify the cytogenetic response:

Specify the recipient’s cytogenetic response at the time of the last evaluation.

If there is eradication of the previous reported abnormality select “Complete response (CR)” and continue with question 282.

If there is a ≥ 50% reduction in abnormal metaphases, select “Partial Remission (PR)” and continue with question 282.

Select “Re-emergence of pre-existing cytogenetic abnormality” if the cytogenetic abnormality was eradicated and reemerged at the time of best response to this line of therapy and continue with question 282.

If cytogenetic response was not tested at the last evaluation, select “Not assessed” and continue with question 283.

Select “not applicable” if cytogenetic abnormalities were never identified and continue with question 283.

If the recipient does not meet the criteria for CR or PR, select “None of the above” and continue with question 282 (e.g. if a new cytogenetic abnormality is identified but there is also eradication of a previous abnormality).

**Example**: A recipient had 10 abnormal metaphases (out of 20) at diagnosis. At the last evaluation, they had 2 abnormal metaphases (out of 20). As this is a ≥50% reduction in abnormal metaphases, “Partial Remission (PR)” should be reported.

#### Question 282: Date assessed:

Report the date the cytogenetic response was established. Enter the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood / serum assessment.

#### Question 283: Specify the molecular response:

Specify the recipient’s molecular response at the time of the last evaluation.

If there is eradication of the previous reported abnormality, **select Complete response (CR)** and continue with question 284.

If there is a 50% decrease in allele burden, select **Partial Remission (PR)** and continue with question 284.

Select **Re-emergence of pre-existing molecular abnormality** if the molecular abnormality was eradicated and reemerged at the time of best response to this line of therapy and continue with question 284.

Select **Not applicable** if molecular abnormalities were never identified and submit the form.

If molecular response was not tested at the last evaluation select **Not assessed** and submit the form.

If the recipient does not meet the criteria for CR, PR, or re-emergence of a pre-existing molecular abnormality, select **None of the above** and go to question 284.

**Example**: A recipient had an allele burden of 50% at diagnosis. At the last evaluation, they had an allele burden of 25%. As this is a ≥50% reduction in the allele burden, **Partial Remission (PR)** should be reported.

#### Question 284: Date assessed:

Report the date the molecular response was established. Enter the date the sample was collected for pathologic evaluation (e.g., bone marrow biopsy) or blood/serum assessment (e.g., CBC, peripheral blood smear).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| Q272 | 4/19/2025 | Modify | Correct typo: Indicate if the recipient’s disease status was assessed by any other assessment at the time of evaluation for this reporting period. Indicate “yes” if the disease status was assessed by other assessment at the time of evaluation for this reporting period, report the date of assessment in question 273, and specify the name of the other assessment in question 274. Indicate “no” if the disease status was not assessed by other assessment at the time of |
Typo |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)