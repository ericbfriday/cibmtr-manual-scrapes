#### Question 1: Were there any Grade ≥ 3 potentially immune-mediated complications of interest?

Indicate whether the recipient experienced a Grade ≥ 3 potentially immune-mediated complication of interest during the timeframe captured by the specific visit ID of form 2542 . Only report the following Grade ≥3 immune-mediated complications of interest:


- Polymyositis
- Autoimmune Thyroiditis
- Autoimmune Hepatitis
- Myositis
- Pneumonitis/Interstitial Lung Disease
- Myocarditis
- Polyneuropathy (Guillain-Barre Syndrome and its variants)
- Dermatitis/rash (not considered GVHD)
- Encephalitis.

If no Grade ≥ 3 potentially immune-mediated complications of interest occurred (timeframe), report **No**. Please use the referenced table [here](https://jitc.biomedcentral.com/articles/10.1186/s40425-017-0300-z) for grading criteria.

Complete questions 2-3 for each specific complication of interest.

#### Questions 2 – 3: Specify Grade ≥ 3 potentially immune- mediated complication of interest.

Specify each Grade ≥3 potentially immune-mediated complications of interest that occurred (in the reporting timeframe) and report the date (YYYY-MM-DD) when the complication initially occurred.

Copy and complete questions 2-3 to report more than one Grade ≥3 potentially immune-mediated complication of interest.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)