Listed in Table 1 are common typographical errors. If a FormsNet3SM error arises after entering the ISCN string, review Table 1 to determine how to correct the error. Seek physician clarification as needed. If unable to correct the error, remove the ISCN string entered in FormsNet3SM and select the applicable abnormalities listed.

Table 1. ISCN Compatible String Errors and Corrections


**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Last modified:
Jul 31, 2023

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)