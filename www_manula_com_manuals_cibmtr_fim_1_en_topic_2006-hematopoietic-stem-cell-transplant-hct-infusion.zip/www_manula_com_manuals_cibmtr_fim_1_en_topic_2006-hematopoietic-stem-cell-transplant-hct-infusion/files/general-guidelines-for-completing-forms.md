#### Fields Requiring a Date

For fields that require a date, if an exact date is not known use the process listed below. This process should be used only if the dates fit within the logical timeframe of the form (i.e. contact date, diagnosis date, relapse date, etc). To assist with the audit process, transplant centers should briefly note their logic in assigning dates that are unknown in the medical record.

Day is Unknown: Report the day of the month as the 15th. If the 15th does not make logical sense in relation to the other date fields reported on the form, then use either the 1st or 30th. Report month and year as documented in the medical record.

**Example 1:** The month and year of diagnosis is May 2006; the first treatment was given on May 17, 2006. The date of diagnosis should be reported as *May 15, 2006*, as this fits logically within the timeframe of the form.

**Example 2.** The month and year of diagnosis is May 2006; the first treatment was given on May 4, 2006. The date of diagnosis should be reported as *May 1, 2006*, since May 15, 2006 is not logical within the timeframe of the form.

Month and Day Are Unknown: Report the month as June and the day as the 15th. If the 15th does not make logical sense in relation to the other date fields reported on the form, then report the day as either the 1st or the 30th. Report the year as documented in the medical record.

**Example 1:** The year of diagnosis is 2006, but an exact diagnosis date is not known; the first treatment was given August 1, 2006. The date of diagnosis should be reported *June 15, 2006*, as this fits logically within the timeframe of the form.

**Example 2:** The year of diagnosis is 2006, but an exact diagnosis date is not known; the first treatment was given on June 14, 2006. The date of diagnosis should be reported as *June 1, 2006*, since June 15, 2006 is not logical within the timeframe of the form.

**Example 3:** The recipient is described as being diagnosed in the winter of 1998 with CLL, however no specific date can be verified. The transplant center may report a date in the middle of the season range, in this case *February 15, 1998*, as the designated date of diagnosis.

Month, day, and year are unknown: In the FormsNet3 application, leave the date field blank and override the error. For paper form submission, draw a single line through the date field, write “unknown” in the margin and date and initial.

#### General Number Reporting Guidelines

**Rounding**: When a value has more decimal places than there is available on the form for reporting, the value should be rounded to the nearest reportable decimal

**Example 1**: A recipient’s weight at the initiation of pre-HCT preparative regimen is documented as 145.36 pounds. The 2400 allows for the reporting of one decimal place for this field. The recipient’s weight should be reported as*145.4 pounds***Example 2**: A recipient was prescribed a total dose of 4.5 mg/kg ATG during the Peri-Transplant Period. The 2400 does not allow for any decimal reporting on this field. The recipient’s total prescribed dose should be reported as*5 mg/kg*

**Values of less than (<) or greater than (>)**: When a value is documented as less than (<) or greater than (>) report in the following manner:


- For < Less Than values: n – 1
- For > Greater Than values: n + 1

**Example 3**: A recipient is documented as having <5% blasts in the bone marrow. The form asks for the total percentage of blasts found in the bone marrow. The recipient’s blast count should be reported as 5 – 1 =*4% blasts***Example 4**: A recipient’s chimerism results indicate >95% donor cells. The form asks for the total percentage of donor cells. The recipient’s donor cell chimerism should be reported as 95 + 1 =*96% donor cells*

**Ranges**: When a value is reported as a range of numbers, report the median value of the range

**Example 5**: A recipient is documented as having 60-70% blasts in the bone marrow. The form asks for the total percentage of blasts found in the bone marrow. The recipient’s blast count should be reported as the median value of*65% blasts***Example 6**: A recipient is documented as having an echocardiogram ejection fraction of 45-50% The form asks for the ejection fraction percentage as a whole number (no decimal places allowed). The median value is 47.5%, however since the form only allows for whole numbers, the rounding rule must also be applied. The recipient’s ejection fraction should be reported as the median value rounded to the nearest whole number of*48%*

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)