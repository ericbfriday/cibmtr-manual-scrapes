#### Question 24: Is there a history of EBV infection?

Epstein-Barr virus (EBV) is one of the human herpes viruses (*Herpesviridae* family). It is the virus that causes infectious mononucleosis, commonly referred to as “mono.” XLP may present as an exaggerated immune response to EBV; up to 90% of XLP patients have previously had an EBV exposure. Indicate if the recipient has a history of EBV infection, as identified by any method of detection. If the patient has not had exposure to EBV or did not have an evaluation of previous exposure, continue with question 33.

#### Questions 25-27: Specify results used for diagnosis of EBV

In situ hybridization refers to the use of a labeled viral probe to detect virus nucleic acids in tissue. Polymerase chain reaction (PCR) amplifies viral DNA to determine if the patient has a current primary infection or reactivation infection. Serologic testing may be used to determine the presence of EBV antigen or antibodies to EBV.

Report the method used to diagnose a current or latent EBV infection. Answer each of the questions 25-27 and do not leave any response blank. If serologic testing was used, continue with question 28. If serologic testing was not performed or was negative, continue with question 32.

#### Questions 28-31: Specify [serologic] results

Antibody titration to four EBV-specific markers can provide distinct information about whether a patient has a current primary or reactivated infection, recent infection, or past infection. Antibodies to EBV nuclear antigen (**EBNA**) are not seen during acute infection, but develop 2-4 months after the first presentation of infection and persist for life. **Early antigen** testing measures IgG antibodies to early antigen; this generally appears at acute onset and is only detectable for 3-6 months. **Viral capsid IgG** measures IgG antibodies to viral capsid antigen that appear 2-4 weeks after presentation and persist for life. **Viral capsid IgM** testing for IgM antibodies to viral capsid antigen indicates current or recent infection, as it is generally only detectable for 4-6 weeks following first presentation.

Specify each EBV serologic antibody test as “positive” or “negative” in questions 28-31. Do not leave any response blank unless testing failed, was inconclusive, or was not performed.

#### Question 32: Was documentation submitted to the CIBMTR?

Indicate if a copy of the EBV infection testing is attached. Use the Log of Appended Documents (Form 2800) to attach a copy of the laboratory report(s). Attaching a copy of the report may prevent additional queries.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)