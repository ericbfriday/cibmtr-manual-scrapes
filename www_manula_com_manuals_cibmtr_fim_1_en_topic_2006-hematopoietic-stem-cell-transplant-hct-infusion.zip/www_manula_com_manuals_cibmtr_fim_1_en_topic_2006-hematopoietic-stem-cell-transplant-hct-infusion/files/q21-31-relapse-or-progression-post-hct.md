#### Question 73: Was therapy given since the date of last report for reasons other than relapse or persistent disease? (include any maintenance therapy)

Indicate if the recipient received treatment post-infusion for reasons other than relapse or persistent disease during the current reporting period. Recipients generally receive a HCT / cellular therapy under a specific protocol which defines radiation and / or systemic therapy to be given prior to infusion; prophylactic medications to be administered pre- and / or post-infusion; as well as any systemic therapy, radiation, and / or other treatments to be administered post-infusion as planned (or maintenance) therapy. Planned (maintenance) therapy is given to assist in prolonging a remission. Planned therapy may be described in a research protocol or standard of care protocol. Refer to these documents (if available) when completing this section. If post-infusion therapy is given as prophylaxis or maintenance for recipients in CR, report the therapy in questions 74-87. *Do not include any treatment administered as a result of relapse or persistent disease (including treatment for minimal residual disease)*.

If therapy was given for reasons other than relapse or persistent disease during the reporting period, report “Yes” and go to question 74. If “No,” go to question 88.

#### Question 74: Systemic therapy

Systemic therapy includes chemotherapy, immunotherapy, or targeted therapies delivered via the blood stream and distributed throughout the body. Therapy may be injected into a vein or given orally. Do not report subsequent HCT / cellular therapies in questions 74-83. If the recipient received systemic therapy during the reporting period for reasons other than relapse or persistent disease, report “Yes” and go to question 75. If not, report “No” and go to question 83.

#### Questions 75-76: Date therapy started

If the recipient started systemic therapy for reasons other than relapse or persistent disease during the reporting period, report “Known” for question 75 and indicate the date started in question 76. If the exact date is not known, use the process for reporting partial or unknown dates as described in the General Instructions, Guidelines for Completing Forms.

If the recipient started therapy for reasons other than relapse or persistent disease in a prior reporting period and continued the therapy into the current reporting period, report “Previously reported” and go to question 77.

For recipients who start and stop therapy multiple times post-infusion, first determine whether the recipient stopped therapy for at least 30 days. If not, consider the therapy continuous. Only report a new therapy start date if all three of the below conditions are met.


- The recipient stopped all therapy given for reasons other than relapse or persistent disease during a prior reporting period; and
- The recipient restarted therapy for reasons other than relapse or persistent disease during the current reporting period; and
- Therapy was restarted at least 30 days after the therapy stop date.

#### Questions 77-78: Date therapy stopped

Indicate if therapy stop date is “Known” or “Unknown.” If the therapy is being given in cycles, report the date the recipient started the last cycle for this line of therapy in question 78. Otherwise, report the final administration date for the therapy being reported.

If the recipient is still receiving this treatment at the end of the reporting period, report “not applicable (still receiving therapy)” and continue with 81.

If the stop date is partially known, use the process for reporting partial or unknown dates as described in the General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

If the date therapy stopped is “Unknown,” go to question 79.

#### Questions 79-80: Reason therapy stopped

If the systemic therapy was stopped during the reporting period, indicate the reason it was stopped using one of the following options in question 79:


- Toxicity (e.g. cytopenia): The recipient developed a toxicity in response to therapy.
- Not tolerable: The therapy was stopped due to intolerability (adverse events)
- Lack of response: The course of treatment stopped due to lack of a complete response.
- Disease progression: The recipient’s disease progressed from HI; Requires at least one of the following in the absence of another explanation (e.g., infection, bleeding, ongoing chemotherapy, etc.):

p((. ≥ 50% reduction from maximum response levels in granulocytes or platelets

p((. Reduction in hemoglobin by ≥ 1.5 g/dL

p((. Transfusion dependence - Response (treatment achieved goal): A favorable disease response was achieved and treatment was no longer required.
- Other: Use this option choice for any reason not included above and specify the reason in question 80.
- Unknown: Use this option when the reason therapy was stopped is unknown.

If the reason therapy stopped isn’t listed in question 79, select “other” and report the other reason therapy stopped in question 80. Continue with question 81.

#### Question 81-82: Specify systemic therapy given for maintenance: (check all that apply)

Report the drug(s) given as part of this line of therapy. If multiple lines of therapy were given during the reporting period, they must be reported separately. If the drug given is not listed as an option for question 81, report “Other systemic therapy” and specify the drug in question 82.

#### Question 83: Cellular Therapy

Cellular therapy treatment strategies include isolation and transfer of specific stem cell populations, administration of effector cells (e.g., cytotoxic T-cells), induction of mature cells to become pluripotent cells, and reprogramming of mature cells (e.g., CAR T-cells).

Report “yes” if the recipient received cellular therapy as part of the line of therapy being reported. If not, report “no.”

#### Question 84-85: Blinded randomized trial

Indicate whether treatment was administered as part of a blinded randomized trial. Consult the physician overseeing treatment if it is not clear whether the therapy is being given as part of a blinded randomized trial. If “yes,” report the clinicaltrials.gov number in question 85. Otherwise, go to question 86.

If the clinical trial number (NCT number) is not clearly documented, it can be looked up using the Find a Study feature on [www.clinicaltrials.gov](http://www.clinicaltrials.gov).

If the recipient is participating in a clinical trial that is not registered with clinicaltrials.gov, but is registered elsewhere, leave question 85 blank and override the validation error using the code “Unable to answer.” Also, attach documentation which displays the clinical trial number and corresponding registry to the form in FormsNet3SM. For further instructions on how to attach documents in FormsNet3SM, refer to the [Training Guide](http://www.cibmtr.org/DataManagement/TrainingReference/FormsNet/Documents/FN3%20Training%20Guide%20AE.pdf#page=25) .

#### Question 86-87: Other therapy

Indicate if the recipient received any other therapy (not already reported in questions 74-85) given for reasons other than relapse or progression as part of this line of therapy. Do not report supportive therapies (e.g., transfusions, growth factors) or a subsequent HCT in questions 86-87. If “yes,” specify all other therapies given in question 87. If “no,” go to question 88.

Copy questions 74-87 to report more than one line of therapy.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)