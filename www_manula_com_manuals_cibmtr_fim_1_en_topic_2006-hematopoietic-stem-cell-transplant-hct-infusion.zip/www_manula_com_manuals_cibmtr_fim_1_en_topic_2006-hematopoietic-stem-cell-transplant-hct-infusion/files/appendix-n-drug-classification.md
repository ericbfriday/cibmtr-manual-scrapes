This appendix includes common drugs administered as part of BMT treatment and therapy. Drug classifications, descriptions, and examples of each drug class are described in Table 1.

| Classification Category | Agent Description | Examples |
|---|---|---|
| BTK inhibitor | Bruton’s tyrosine kinase is a protein involved in B-cell maturation. This protein has been shown to be overactive in certain malignancies such as CLL. Treatments have been developed to target and disrupt BTK function and restore normal cellular processes. Report all BTK inhibitors under this class. | Acalabrutinib, Ibrutinib, Zanubrutinib |
| Chemotherapy | Any systemic cytotoxic agents not already listed under another drug class. Do not report intrathecal therapy under this class. These treatments should be reported under “other therapy” unless otherwise specified or captured on the applicable form. | Cyclophosphamide |
| FLT3 inhibitor | The FLT3 gene produces a specific receptor type tyrosine kinase which acts as a cell surface receptor for cytokines. This protein has been shown to be overactive in certain malignancies such as AML. Treatments have been developed to target and disrupt FLT3 protein function and restore normal cellular processes. Report all FLT3 targeted therapies under this class. | Gilteritinib, Lestaurtinib, Midostaurin, Quizartinib, Sorafenib, Sunitinib |
| Hypomethylating agent | Methylation of specific nucleotides impacts whether specific portions of DNA are available for transcription. Some cancers experience significant cell growth and proliferation due to excessive methylation of DNA which can turn off tumor suppressor genes. Hypomethylating agents counter this process by reducing the amount of DNA methylation and restoring function to tumor suppressor genes. Report all hypomethylating agents under this class. | Azacytidine (Vidaza), Decitabine (Dacogen) |
| Immune-modulating agent | Immune modulating agents have varied targets and mechanisms of action, but are all similarly intended to prompt an anti-tumor response from the recipient’s own immune system | Lenalidomide (Revlimid), Pomalidomide, Thalidomide (Thalomid) |
| Monoclonal antibody (mAb) | Monoclonal antibodies are developed to bind to a specific cell surface marker or protein. These antibodies either prompt the recipient’s immune system to attack the target or they deliver treatments directly to sites of disease (e.g., radio-immunotherapy). | Alemtuzumab, Daratumumab, Gemtuzumab, Rituximab |
| Bispecific monoclonal antibody | Bispecific monoclonal antibodies contain two different antigen-binding sites in one molecule and can simultaneously bind two different types of antigens. | Blinatumomab (Blincyto) |
| Other systemic therapy | Any therapeutic agents that the recipient received that do not fall into any of the drug class options available above (e.g., dexamethasone) should be reported under this class. | Intrathecal agents |
| PD1 inhibitor | PD1 is a cell surface receptor protein present on T-cells. It detects the presence of normal cell surface molecules on healthy cells and prevents T-cells from destroying them. Some cancer cells also produce similar cell surface molecules which prevent T-cells from recognizing and attacking them. PD1 inhibitors block this interaction allowing T-cells to attack cancer cells. Report all PD1 inhibitors under this class. | Nivolumab, Pembrolizumab |
| Proteasome inhibitor | Certain intracellular proteins, such as P53, are necessary for the activation of apoptosis in cancer cells. Proteasomes break down many intracellular proteins including P53. Proteasome inhibitors disrupt the function of proteasomes and are believed to slow or prevent the excessive degradation of the proteins which activate apoptosis. Report all proteasome inhibitors under this class. | Bortezomib (Velcade), Carfilzomib, Ixazomib |
| Tyrosine kinase inhibitors (TKI) | Tyrosine kinases (TKs) are proteins responsible for many cell functions and can be found in the cell membrane, cytoplasm, and nucleus. This large category of proteins is involved in many different cellular processes. Overactive TKs can result in significant disruption of normal cellular processes including uncontrolled growth and proliferation. TKI’s disrupt the function of these overactive proteins allowing other normal cell processes such as adhesion and apoptosis to resume. | Bosutinib, Dasatinib (Sprycel), Imatinib mesylate (Gleevec), Nilotinib (AMN107, Tasigna) |

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 6/11/2020 | Appendix N: Drug Classifications | Add | released Appendix N: Drug Classifications |

Last modified:
Jun 11, 2020

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)