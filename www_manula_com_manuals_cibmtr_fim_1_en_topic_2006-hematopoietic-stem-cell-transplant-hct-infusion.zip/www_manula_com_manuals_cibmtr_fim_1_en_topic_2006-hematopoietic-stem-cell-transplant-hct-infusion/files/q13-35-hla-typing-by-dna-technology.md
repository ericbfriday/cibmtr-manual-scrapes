Complete this section for all typing done by DNA based methods. Examples of HLA typing by DNA technology may include: sequence-specific primer (SSP), sequence-specific oligonucleotide probe (SSOP), and sequence-based typing (SBT).

DNA technology can be used to type for a single allele, combinations of alleles (allele strings), or a “generic” allele designation similar to a serologic typing result. For this reason, the number of digits reported, as well as the number of alleles, will vary.

Laboratories may use “ / ” , “ – ” or a combination of numbers and letters on the typing report as a shorthand notation for the results. Transcribe the information onto the form as directly as possible. The letters, called allele codes, will be 1 or more characters in length and represent a combination of possible alleles at a locus. The same allele combination may be reported several different ways (e.g., DRB1*01:01 or 01:02, DRB1*01:01/01:02, DRB1*01:01/02, or DRB1*01:AB).

There will be two alleles reported for each locus, unless the individual is presumed homozygous (i.e., carries two copies of the same allele) at a locus. Transcribe the first allele designation in the first box, and the second allele designation in the second box. If the person is homozygous, leave the second box blank.

#### Question 2: Was documentation submitted to the CIBMTR (e.g., lab report)?

Indicate if a copy of the HLA typing report is attached. Use the “Add Attachment” feature to attach a copy of the HLA typing report in FormsNet3SM. Attaching a copy of the laboratory report assists in confirming the reporting of HLA typing and reduces the need for later data queries.

## Class I

#### Questions 3-4: Locus A

Indicate whether the allele designations at HLA-A are **Known** or **Unknown**. If **Known**, report the first A* allele and second A* allele designations; report a single allele, a string of alleles, or an allele code.

If **Unknown**, then the *A antigens defined by serologic typing* are required to be answered below.

#### Questions 5-6: Locus B

Indicate whether the allele designations at HLA-B are Known or Unknown. If Known, report the first B* allele and second B* allele designations; report a single allele, a string of alleles, or an allele code.

If **Unknown**, then the *B antigens defined by serologic typing* are required to be answered below.

#### Questions 7-8: Locus C

Indicate whether the allele designations at HLA-C are **Known** or **Unknown**. If **Known**, report the first C* allele and second C* allele designations; report a single allele, a string of alleles, or an allele code.

## Class II

#### Questions 9-10: Locus DRB1

Indicate whether the allele designations at HLA-DRB1 are **Known** or **Unknown**. If **Known**, report the first DRB1* allele and second DRB1* allele designations; report a single allele, a string of alleles, or an allele code.

## Class II (Optional)

#### Questions 11-12: Locus DRB3

Indicate whether the allele designations at HLA-DRB3 are **Known** or **Unknown.** If **Known**, report the first DRB3* allele and second DRB3* allele designations; report a single allele, a string of alleles, or an allele code.

#### Questions 13-14: Locus DRB4

Indicate whether the allele designations at HLA-DRB4 are **Known** or **Unknown**. If **Known**, report the first DRB4* allele and second DRB4* allele designations; report a single allele, a string of alleles, or an allele code.

#### Questions 15-16: Locus DRB5

Indicate whether the allele designations at HLA-DRB5 are **Known** or **Unknown**. If **Known**, report the first DRB5* allele and second DRB5* allele designations; report a single allele, a string of alleles, or an allele code.

#### Questions 17-18: Locus DQB1

Indicate whether the allele designations at HLA-DQB1 are **Known** or **Unknown.** If **Known**, report the first DQB1* allele and second DQB1* allele designations; report a single allele, a string of alleles, or an allele code.

#### Questions 19-20: Locus DPB1

Indicate whether the allele designations at HLA-DPB1 are **Known** or **Unknown**. If **Known**, report the first DPB1* allele and second DPB1* allele designations; report a single allele, a string of alleles, or an allele code.

#### Questions 21-22: Locus DQA1

Indicate whether the allele designations at HLA-DQA1 are **Known** or **Unknown**. If **Known**, report the first DQA1* allele and second DQA1* allele designations; report a single allele, a string of alleles, or an allele code.

#### Questions 23-24: Locus DPA1

Indicate whether the allele designations at HLA-DPA1 are **Known** or **Unknown**. If **Known**, report the first DPA1* allele and second DPA1* allele designations; report a single allele, a string of alleles, or an allele code.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)