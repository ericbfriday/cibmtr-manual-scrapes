#### Question 1: Date of Infection Diagnosis

The reported date of COVID-19 (SARS-CoV-2) diagnosis must match the diagnosis date reported on the corresponding follow-up form. Report the date the sample was collected for the first test which confirmed the diagnosis.

If the exact date of diagnosis is not known, but the month and year are known, refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates.

#### Questions 2-3: Specify positive diagnostic tests used to determine the diagnosis of the respiratory viral infection (check all that apply)

Report all testing which indicated the COVID-19 (SARS-CoV-2) respiratory viral infection was present. See below for definitions of testing methods and specify all positive diagnostic tests performed to determine the diagnosis of the respiratory viral infection. Do not report negative or indeterminate / equivocal testing in this section.

For the initial form, report positive diagnostic tests performed / samples collected within 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report any new positive diagnostic tests performed from the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death).

**Nasal swab / wash**: a sample is collected from the nose using a swab or a small amount of saline solution. The sample is tested via polymerase chain reaction techniques that quantify the amount of viral RNA present or using novel CRISPR testing from respiratory swab RNA extracts. If the amount of viral RNA is above the upper limit of normal (found on the laboratory report), the result will be considered positive for the virus being tested. If the testing report does not clearly indicate whether the result was positive, negative, or equivocal, contact your center’s lab for clarification.

**Lung Fluid from a Bronchoalveolar lavage (BAL)**: a bronchoscope is inserted through the nasal cavity or mouth down into the bronchi. Fluid is released into the alveoli and then suctioned back through the bronchoscope. The fluid is tested via polymerase chain reaction techniques that quantify the amount of viral RNA present. If the amount of viral RNA is above the upper limit of normal, the result will be considered positive for the virus being tested. If the testing report does not clearly indicate whether the result was positive, negative, or equivocal, contact your center’s lab for clarification. This method includes “mini-bronchoalveolar lavage.” Samples collected via BAL may also be sent for culture. Report positive culture results from the BAL under culture.

**Histopathology findings of viral cytogenetic changes (biopsy)**: a tissue sample is taken from the recipient via biopsy or fine needle aspirate and examined via microscopy. The tissue is examined for changes associate with a viral infection. If the report does not clearly indicate whether the result was positive, negative, or equivocal, contact your center’s lab for clarification.

**Culture**: a sample is taken from the recipient and the virus is grown in a supportive medium over several days. For the purposes of this form, any culture result, including a shell vial culture, should be reported if positive. The date of the test is the date the sample was collected, not the date the test was reported.

**Other**: if a positive diagnostic test was performed but not listed as an option in question 2, select “Other” and specify the positive diagnostic test in question 3.

#### Questions 4-6: Were there any positive radiographic findings supporting the infection diagnosis?

Radiographic findings include all imaging assessments. Examples include x-ray, CT scan, PET scan, and MRI. Refer to the clinical interpretation of an imaging assessment to determine whether the test was considered positive for the infection being reported. If the provider’s notes do not specify whether the test was positive, obtain documentation from the primary care provider clarifying how the assessment should be reported.

For the initial form, only report positive radiographic findings supporting the infection diagnosis within 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report any new positive radiographic findings obtained from the date of evaluation (from the initial form submission) until the resolution of the infection (or day prior to death).

Report all sites where the imaging assessments detected the viral infection in questions 5-6. See site definitions below. Only report sites which are part of the respiratory tract.

**Chest**: lungs, pleura, pleural space, bronchioles, bronchi, trachea

**Sinus**: paranasal sinuses and surrounding tissues

**Other**: examples include tonsils. It is unclear that COVID-19 has imaging findings in other sites

If radiographic testing was not performed within the time window specified above or not considered positive for the infection being reported, report “No” for question 4 and go to question 7.

If it is not known whether radiographic testing was performed within the time window specified above, report “Unknown” for question 4 and continue with question 7.

#### Question 7: Did the recipient required supplemental oxygen? (nasal cannula, face mask, ventilator, etc.)

For the initial form, report “Yes” for question 7 if the recipient received any form of supplemental oxygen from 7 days prior to and up to 14 days after the diagnosis date reported in question 1 and continue with question 8.

For the follow-up form, report “Yes” for question 7 if the recipient received any form of supplemental oxygen from the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death) and continue with question 8.

Otherwise, report “No” for question 7 and go to question 10.

#### Questions 8-9: Did the recipient receive endotracheal intubation or mechanical ventilation?

Mechanical ventilation can occur as both an endotracheal tube and ventilator, or as a BIPAP machine with a tight fitting mask in continuous use. The one exception to BIPAP is CPAP used for sleep apnea, which generally involves overnight use only for patients with documented sleep apnea. Therefore, **do not** report a CPAP used for sleep apnea, as it does not have the same implications as other forms of mechanical ventilation.

Indications for mechanical ventilation include, but are not limited to:


- Apnea with respiratory arrest (excludes sleep apnea)
- Acute lung injury
- Vital capacity < 15 mL/kg
- Chronic obstructive pulmonary disease (COPD)
- Clinical deterioration
- Respiratory muscle fatigue
- Obtundation or coma
- Hypotension
- Tachypnea or bradypnea

For the initial form, report “Yes” if the recipient required endotracheal intubation and / or mechanical ventilation from 7 days prior to and up to 14 days after the diagnosis date reported in question 1. Report the start date of intubation in question 9.

For the follow-up form, report “Yes” if the recipient required endotracheal intubation and / or mechanical ventilation from the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death). Report the start date of intubation in question 9.

If the recipient was intubated multiple times, report the earliest date. If the exact date of intubation is not known, but the month and year are known, refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates. If the reported date is estimated, check the “Date Estimated” box next to question 9.

If neither endotracheal intubation nor mechanical ventilation were performed during the indicated time window, report “No” for question 8 and go to question 10.

#### Questions 10: Did the recipient receive corticosteroids? (systemic or intravenous)

For the initial form, report “Yes” if the recipient received systemic corticosteroids (systemic or intravenous) from 7 days prior to and up to 14 days after the diagnosis date reported in question 1.

For the follow-up form, report “Yes” if the recipient received systemic corticosteroids (systemic or intravenous) between the date of evaluation (from the initial form submission) until the resolution of the infection (or date of death).

Do not report administration of topical steroids (including oral or inhaled budesonide or beclomethasone).

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| 1 | 8/25/2023 | Remove | |
2149 will no longer have the option to be created on-demand. |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)