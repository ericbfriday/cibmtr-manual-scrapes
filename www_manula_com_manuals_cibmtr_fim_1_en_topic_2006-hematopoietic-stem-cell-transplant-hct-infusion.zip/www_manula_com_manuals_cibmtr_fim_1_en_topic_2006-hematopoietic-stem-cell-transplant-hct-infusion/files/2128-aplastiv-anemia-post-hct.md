The Aplastic Anemia Post-HSCT Data Form is one of the Comprehensive Report Forms. This form captures aplastic anemia-specific post-HSCT disease assessment data for the reporting period.

This form must be completed for all recipients whose primary disease, as reported on the Pre-TED Disease Classification Form (Form 2402) as severe aplastic anemia, paroxysmal nocturnal hemoglobinuria, or one of the following inherited abnormalities of erythrocyte differentiation or function: Shwachman-Diamond syndrome, Diamond-Blackfan anemia (pure red cell aplasia), or other constitutional anemia. Fanconi Anemia and Sickle Cell Anemia each have their own forms to complete (Forms 2129 and 2130, respectively).

The Aplastic Anemia Post-HSCT Data (Form 2128) must be completed in conjunction with each Post-HSCT follow-up form completed (Forms 2100, 2200, and 2300). Form 2128 is designed to capture specific data occurring within the timeframe of each reporting period (e.g., between day 0 and day 100 for Form 2100, between day 100 and the six-month date of contact for Form 2200 Six-Month follow-up, between the date of contact for the six-month follow-up Form 2200 and the date of contact for the one-year follow up Form 2200, etc).

[Q1-25: Disease Assessment at the Time of Assessment for This Reporting Period](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-5-disease-assessment-at-the-time-of-assessment-for-this-reporting-period)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 10/23/2020 |
|

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)