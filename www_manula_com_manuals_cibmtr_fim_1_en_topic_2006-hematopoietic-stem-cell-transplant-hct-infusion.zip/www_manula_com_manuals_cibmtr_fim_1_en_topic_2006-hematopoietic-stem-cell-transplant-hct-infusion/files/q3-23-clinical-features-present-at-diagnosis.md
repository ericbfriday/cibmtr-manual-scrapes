#### Question 3: Was peripheral neuropathy present?

Peripheral neuropathy often starts as tingling or burning in the distal extremities, and may progress to extremity numbness and weakness. The etiology of peripheral neuropathy in WM/LPL is not well understood in the absence of associated autoimmunity (such as cold agglutinin disease). Indicate if the patient reported peripheral neuropathy at diagnosis.

#### Questions 4-5: Did the recipient have known nodal involvement?

The majority of patients with WM or LPL will have bone marrow and, in some cases, lymph nodes involved by disease. Indicate if the patient had known nodal involvement at diagnosis. If “yes,” continue with question 5 and specify the size of the largest nodal mass. If “no,” continue with question 6.

#### Question 6: Was there any known extranodal or splenic involvement?

Additional sites of extranodal disease (e.g., splenomegaly, hepatomegaly, etc.) have been noted in the literature, especially in more advanced disease stages. Indicate if the patient had any known extranodal or splenic involvement at diagnosis. If “yes,” continue with question 7. If “no” or “unknown,” continue with question 15.

#### Questions 7-14: Specify the site(s) of involvement

Indicate “yes” or “no” for each site specified in questions 7-13. Do not leave any response blank. If “yes” is indicated for “other site,” specify the site in question 14. If extranodal or splenic involvement was indicated in question 6, at least one of the questions 7-13 must be answered “yes.”

#### Question 15: Were systemic symptoms (B symptoms) present?

Systemic or constitutional symptoms, often referred to as B symptoms, include fevers, drenching night sweats, and unintentional weight loss. Indicate if the patient reported B symptoms at diagnosis.

#### Question 16: Was clinical hyperviscosity syndrome present?

The clinical signs and symptoms of hyperviscosity syndrome include skin and mucosal bleeding, dizziness, retinopathy with visual disturbance, fatigue, and neurological dysfunction. Ophthalmologic examination often reveals characteristic venous engorgement of the retina. Indicate if hyperviscosity syndrome was clinically present at the time of diagnosis. If “yes,” continue with question 17. If “no” or “unknown,” continue with question 23.

#### Questions 17-22: Specify clinical symptoms present at diagnosis

Indicate “yes,” “no,” or “unknown” for each clinical symptom specified in questions 17-21. If clinical hyperviscosity syndrome was present (question 16), at least one of the questions 17-21 must be answered “yes.” If “yes” is indicated for “other,” specify clinical symptom in question 22.

#### Question 23: Was plasmapheresis or plasma exchange required?

Elevation of IgM paraprotein is associated with hyperviscosity. In an acute setting, plasmapheresis or plasma exchange may be used to rapidly reduce IgM paraprotein levels. Indicate if the patient required plasmapheresis or plasma exchange at diagnosis.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)