#### Question 10: Date of most recent complete blood count (CBC) sample drawn:

These questions are intended to determine the clinical status of the recipient at time of follow-up for this reporting period post cellular therapy. Testing may be performed multiple times post-infusion; report the most recent CBC obtained.

#### Questions 11-19: Complete blood count results available: (check all that apply)

For each cell type listed, checking the box will indicate a result is available. Provide the most recent laboratory values from the CBC on the date reported in the prior question.

**WBC:** The white blood cell count is a value that represents all the white blood cells in the blood. If the count is too high or too low, the ability to fight infection may be impaired.

**Neutrophils:** Neutrophils are a subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage or an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage. Neutrophils are also known as polymorphonuclear leukocytes (PMNs).

**Lymphocytes:** Lymphocytes are another subtype of white blood cell that fights infection. The value on the laboratory report may be a percentage of an absolute value. If an absolute value is reported, divide it by the white blood cell count for a percentage.

**Hemoglobin:** Hemoglobin is a molecule in red blood cells that delivers oxygen to tissues throughout the body. A low hemoglobin count is considered “anemia” and blood transfusions, or growth factors may be required to increase the hemoglobin level.

**Hematocrit:** The hematocrit is the percentage (sometimes displayed as a proportion) of red blood cells relative to the total blood volume. A low hematocrit may require red blood cell transfusions or growth factors. Indicate if the recipient received a red blood cell transfusion within 30 days prior to sample draw date.

If a hematocrit value is reported, also indicate if the recipient received a red blood cell transfusion within 30 days prior to the date of the CBC reported in question 17.

**Platelets:** Platelets are formed elements within the blood that help with coagulation. A low platelet count, called thrombocytopenia, may lead to easy bleeding or bruising. Thrombocytopenia may require platelet transfusions. Indicate if the recipient received a platelet transfusion within 7 days prior to testing.

If a platelet value is reported, also indicate if the recipient received a platelet transfusion within 7 days prior to the date of the CBC reported in question 19.

#### Questions 20: Did the recipient receive any growth factors <7 days before the date the sample was drawn?

Indicate if the recipient received any growth factor (e.g., GCS-F) within 7 days prior to the date the CBC sample was drawn. In the event of a long acting growth factor (e.g., pegfilgrastim (Neulasta®)), please answer this question as yes if the recipient received it within 14 days prior to the date the CBC sample was drawn.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)