To be completed in conjunction with a form 2100 – 100 Days Post-HCT Data, 2200 – Six Months to Two Years Post-HCT Data, or Form 2300 – Yearly Follow-Up for Greater than Two Years Post-HCT Data. Information reported here should reflect the date of last contact as reported in the post-HCT data collection form, or immediately prior to death.

Report the most recent findings since the date of the last report. For questions 1-3 and 6-7, also report CBC results in the Form 2100 – 100 Days Post-HCT Data, or in the Form 2200 – Six Months to Two Years Post-HCT Data.

#### Question 1: Date of most recent hematologic testing

Report the date of the most recent hematologic testing since the date of last report. Continue with question 2.

#### Question 2: WBC

Report the white blood cell (WBC) count and unit of measure as documented on the laboratory report. If the WBC was not tested, leave the count and unit fields blank and select “WBC not tested.” Continue with question 3.

#### Question 3: Lymphocytes

Report the percentage of lymphocytes as documented on the laboratory report. If lymphocytes were not tested, leave the count field blank and select “Lymphocytes not tested.” Continue with question 4.

#### Question 4: Eosinophils

Report the percentage of eosinophils as documented on the laboratory report. If eosinophils were not tested, leave the count field blank and select “Eosinophils not tested.” Continue with question 5.

#### Question 5: Polymorphonuclear leukocytes (PMN)

Polymorphonuclear leukocytes are white blood cells containing cytoplasmic granules. PMNs are also referred to as granulocytes and include neutrophils, basophils, and eosinophils; however, this question refers to neutrophils. Report the percentage of neutrophils. If neutrophils were not tested, leave the count field blank and select “Polymorphonuclear leukocytes (PMN) not tested.” Continue with question 6.

#### Question 6: Hemoglobin

Report the hemoglobin count and the unit of measure as documented on the laboratory report. If the hemoglobin was not tested, leave the count and unit fields blank and indicate “Hemoglobin not tested.”

Indicate if red blood cells (RBC) were transfused ≤ 30 days from date of test. Continue with question 7.

#### Question 7: Platelets

Report the platelet count and unit of measure as documented on the laboratory report. If the platelet count was not tested, leave the count and unit fields blank and indicate “Platelets not tested.”

Indicate if platelets were transfused ≤ 7 days from date of test. Continue with question 8.

## Immunoglobulin Analysis

Specify the most recent Immunoglobulin assessment measured since the date of the last report.

#### Question 8: IgG

Report the IgG level and the unit of measure documented on the laboratory report. Continue with question 9. If IgG was not tested, leave the value and unit fields blank and indicate “IgG not tested,” and continue with question 10.

#### Question 9: Date Tested: IgG

Report the date of IgG testing and continue with question 10.

#### Question 10: IgM

Report the IgM level and the unit of measure documented on the laboratory report. Continue with question 11. If IgM was not tested, leave the value and unit fields blank and indicate “IgM not tested,” and continue with question 12.

#### Question 11: Date Tested: IgM

Report the date of IgM testing and continue with question 12.

#### Question 12: IgA

Report the IgA level and the unit of measure documented on the laboratory report. Continue with question 13. If IgA was not tested, leave the value and unit fields blank and indicate “IgA not tested,” and continue with question 14.

#### Question 13: Date Tested: IgA

Report the date of IgA testing and continue with question 14.

#### Question 14: IgE

Report the IgE level in international units per milliliter (IU/ml). Continue with question 15. If IgE was not tested, leave the value field blank and indicate “IgE not tested,” and continue with question 16.

#### Question 15: Date Tested: IgE

Report the date of IgE testing and continue with question 16.

#### Question 16: Did the recipient receive supplemental intravenous immunoglobulins (IVIG) since the date of the last report?

IVIG is a product made from pooled human plasma that primarily contains IgG. It is used to provide immune-deficient recipients with antibodies to help prevent infection.

Indicate whether the recipient received IVIG since the date of last report. If “yes” continue with question 17. If “no” or “unknown” continue with question 18.

#### Question 17: Was therapy ongoing within one month of immunoglobulin testing?

Indicate whether the recipient received IVIG within one month prior to immunoglobulin testing. If IVIG is given within one month of immunoglobulin testing, the IgG level would not represent the recipient’s native IgG. Continue with question 18.

## Lymphocyte Analysis

Specify the most recent lymphocyte assessment measured since the date of the last report.

#### Question 18: Were lymphocyte analyses performed?

Lymphocyte analyses include quantifying specific types of T cells, B Cells, and natural killer (NK) cells. Cells can be identified by cell-specific surface molecules using the clusters of differentiation (CD) nomenclature. For example, T cells can be classified as helper (CD4+) or cytotoxic (CD8+) cells depending on their cell surface markers designated with CD notation.

Indicate if lymphocyte analyses were performed. If “yes” continue with question 19. If “no” continue with question 28.

#### Question 19: Date of most recent testing performed

Report the date of most recent lymphocyte testing since the date of the last report. Continue with question 20.

#### Question 20: Absolute lymphocyte count

Report the absolute lymphocyte count in cells per microliter (cells/µL). Continue with question 21.

#### Question 21: CD3 (T cells)

T cells are a type of lymphocyte that can be characterized by CD3. If the laboratory quantifies CD3 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD3 cells as an absolute value, then report the value in the count field and specify the count units. If CD3 cells were not tested, select the “CD3 (T cells) not tested” option. Continue with question 22.

#### Question 22: CD4 (T helper cells)

T helper cells are a subset of T cells characterized by CD4, sometimes reported as CD3+CD4+. If the laboratory quantifies CD4 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4 cells as an absolute value, then report the value in the count field and specify the count units. If CD4 cells were not tested, select the “CD4 (T cells) not tested” option. Continue with question 23.

#### Question 23: CD8 (cytotoxic T cells)

Cytotoxic T cells are a subset of T cells characterized by CD8, sometimes reported as CD3+CD8+. If the laboratory quantifies CD8 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD8 cells as an absolute value, then report the value in the count field and specify the count units. If CD8 cells were not tested, select the “CD8 (T cells) not tested” option. Continue with question 24.

#### Question 24: CD20 (B lymphocyte cells)

B cells are a type of lymphocyte that can be characterized by CD20. If the laboratory quantifies CD20 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD20 cells as an absolute value, then report the value in the count field and specify the count units. If CD20 cells were not tested, select the “CD20 (B lymphocyte cells) not tested” option. Continue with question 25.

#### Question 25: CD56 (natural killer (NK) cells)

NK cells are a type of lymphocyte that can be characterized by CD56. If the laboratory quantifies CD56 cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD56 cells as an absolute value, then report the value in the count field and specify the count units. If CD56 cells were not tested, select the “CD56 (natural killer (NK) cells) not tested” option. Continue with question 26.

#### Question 26: CD4+ / CD45RA+ (naive T cells)

Naïve T cells are a type of T cell that can be characterized by CD4+/CD45RA+. T cells are considered naïve prior to encountering an antigen. If the laboratory quantifies CD4+/CD45RA+ cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4+/CD45RA+ cells as an absolute value, then report the value in the count field and specify the count units. If CD4+/CD45RA+ cells were not tested, select the “CD4+/CD45RA+ (naïve T cells) not tested” option. Continue with question 27.

#### Question 27: CD4+ / CD45RO+ (memory T cells)

Memory T cells are a type of T cell that can be characterized by CD4+/CD45RO+. If the laboratory quantifies CD4+/CD45RO+ cells as a percent of total lymphocytes, then report the value in the percentage field. If the laboratory quantifies CD4+/CD45RO+ cells as an absolute value, then report the value in the count field and specify the count units. If CD4+/CD45RO+ cells were not tested, select the “CD4+/CD45RO+ (memory T cells) not tested” option. Continue with question 28.

## Antibody Response

The immune system produces antibodies in response to antigens. Tests that measure the antibody response to different antigens help determine if the immune system is properly functioning. Specify the most recent antibody responses measured since the date of the last report.

#### Question 28: Date antibody responses were assessed

Specify the most recent antibody responses measured since the date of the last report.

#### Questions 29-36: Antibody response assessment

For each of the antigens in questions 29-36, indicate if the antibody response was “Absent”, “Low”, “Normal”, or “Not Tested” based on normal values from the laboratory.

**Unconjugated pneumococcal polysaccharide**

The term unconjugated indicates that the pneumococcal capsule contains polysaccharides without the modification of proteins added to the surface to enhance the immune response.

Specify the number of serotypes producing a protective level out of the total serotypes tested from the vaccine. For example, if the Pneumococcal 23-valent vaccine was used for the test, then report the number of reactive serotypes out of the 23 serotype total.

**Conjugated pneumococcal polysaccharide**

The term conjugated indicates that the pneumococcal capsule contains polysaccharides that have been conjugated with proteins to enhance the immune response.

Specify the number of serotypes producing a protective level out of the total serotypes tested from the vaccine.

## Lymphocyte Function

Lymphocyte function tests assess immune function by measuring immune cell responses to antigens and mitogens relative to control responses.

#### Question 37: Date lymphocyte function was assessed

Specify the date of the most recent lymphocyte function assessment since the date of last report in question 37.

#### Questions 38-43: Lymphocyte analysis assessment

For each of the lymphocyte function tests listed in questions 38-43, indicate whether the lymphocyte response was “Absent” (<10% of control), “Low (10-30% of control),” “Normal” (>30% of control) or “Not tested.”

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)