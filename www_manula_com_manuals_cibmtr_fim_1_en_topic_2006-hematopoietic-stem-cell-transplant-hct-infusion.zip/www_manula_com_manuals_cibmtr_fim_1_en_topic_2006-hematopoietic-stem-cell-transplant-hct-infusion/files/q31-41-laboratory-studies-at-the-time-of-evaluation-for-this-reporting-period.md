#### Questions 31-32: Serum ferritin

Indicate whether serum ferritin level was “known” or “unknown” during the reporting period. If “known,” report the value and unit of measure documented on the laboratory report in question 32. If there are multiple values from the reporting period, report the latest. If “unknown,” continue with question 33.

#### Questions 33-34: Soluble interleukin-2 receptor (sIL-2R)

Indicate whether soluble interleukin-2 receptor levels were “known” or “unknown” during the reporting period. If “known,” report the value and unit of measure documented on the laboratory report in question 34. If there are multiple values from the reporting period, report the latest. If “unknown,” continue with question 35.

#### Questions 35-36: Triglycerides

Indicate whether triglyceride levels were “known” or “unknown” during the reporting period. If “known,” report the value and unit of measure documented on the laboratory report in question 36. If there are multiple values from the reporting period, report the latest. If “unknown,” continue with question 37.

#### Questions 37-38: Fibrinogen antigen assay (factor 1; fibrinogen activity; functional fibrinogen; fibrinogen antigen)

Indicate whether fibrinogen antigen levels were “known” or “unknown” during the reporting period. If “known,” report the value and unit of measure documented on the laboratory report in question 38. If there are multiple values from the reporting period, report the latest. If “unknown,” continue with question 39.

#### Question 39: Bone marrow aspirate/biopsy evidence of hemophagocytosis

Bone marrow aspirate and biopsy evidence of hemophagocytosis typically includes hypercellularity with markedly increased histiocytes and cytotoxic T-cells. Indicate if the pathologist interpretation of the marrow indicated the presence or absence of findings consistent with hemophagocytosis. If multiple evaluations were done during the reporting period, report the data from the latest. If bone marrow evaluation was not performed during the reporting period, indicate “not done.”

#### Questions 40-41: Specify the cerebrospinal fluid (CSF) findings

Indicate if protein and WBC count were elevated or normal in questions 40 and 41, respectively. If multiple evaluations were done during the reporting period, report the data from the latest. If CSF evaluation was not performed during the reporting period, indicate “not done.”

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)