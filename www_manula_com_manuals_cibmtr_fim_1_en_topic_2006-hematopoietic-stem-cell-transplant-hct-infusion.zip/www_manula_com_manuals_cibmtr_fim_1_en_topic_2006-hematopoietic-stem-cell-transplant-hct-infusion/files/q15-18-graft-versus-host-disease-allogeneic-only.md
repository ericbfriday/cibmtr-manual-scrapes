Graft versus Host Disease (**GVHD**) is an immunological phenomenon resulting from the reaction of donor immune cells against major or minor histocompatibility antigens of the recipient. GVHD is primarily caused by donor-derived T-cells. Very rarely, GVHD may occur due to autologous reactivity (autologous GVHD), third party transfusions, or with identical twin transplantation.

Factors influencing the severity of GVHD are related to three main categories: 1) donor or graft, 2) recipient, and 3) treatment. The most influential donor/graft factor is the degree of genetic disparity between the donor and the recipient (HLA match), but other risk factors include female donor to male recipient, donor parity, older donors, and T-cell dose. The occurrence of acute GVHD becomes a risk factor for the development of chronic GVHD. Recipient age and prior infections are also factors.

In the past, GVHD was classified as acute or chronic based on its time to diagnosis following transplant, and other clinical and histological (biopsy or post-mortem) features. Today, there has been increased recognition that acute and chronic GVHD are not dependent upon time since HCT, so determination of acute or chronic should rest on clinical and histologic features. **However, organ staging and overall grade should only be calculated from the clinical picture, not histology.** Acute GVHD usually begins between 10 and 40 days after HCT but can appear earlier or later. The organs most commonly affected by acute GVHD are the skin, gut, or liver. Other sites, such as the lung, may be involved.

#### Question 9: Did acute GVHD develop since the date of last report?

*Did acute GVHD develop since the date of last report* and *Did acute GVHD persist since the date of last report* questions on the Post-TED Form are meant to capture whether the recipient had active symptoms of acute GVHD during the reporting period. If the recipient had active acute GVHD during the reporting period, either *Did acute GVHD develop since the date of last report* or *Did acute GVHD persist since the date of last report* must be answered **Yes** unless there has been a prior / concurrent diagnosis of chronic GVHD (see Acute / Chronic GVHD note box above). There will not be a situation where **Yes** is reported for both *Did acute GVHD develop since the date of last report* and *Did acute GVHD persist since the date of last report* questions. If this question is answered **Yes** and a diagnosis date has been reported, the question *Did acute GVHD persist since the date of last report* will be disabled in FormsNet3SM. Centers should report **Yes** for this question to indicate the recipient developed acute GVHD in the following scenarios:

- Acute GVHD is diagnosed for the first time during the reporting period.
- An acute GVHD flare is diagnosed during the current reporting period and
**all**the following conditions are met:- The recipient’s prior acute GVHD symptoms did
**not**persist from the prior reporting period into the beginning of the current reporting period. - The flare is diagnosed after
**at least 30 days**without any active acute GVHD symptoms. - The recipient was not diagnosed with chronic GVHD on or before the date of the flare (see Acute / Chronic GVHD note box above).

- The recipient’s prior acute GVHD symptoms did

If the recipient does have active acute GVHD during the reporting period, but does not match either of the scenarios above, the center will likely need to report **No** for this question and **Yes** for the question, *Did acute GVHD persist since the date of last report*. *Did acute GVHD persist since the date of last report*, is intended to capture acute GVHD which has continued from a prior reporting period. This includes any flares which do not meet the above conditions. The intent of classifying GVHD episodes as newly developed or persistent is to avoid having centers re-report diagnosis information which has been captured on a prior form. Refer to the Acute GVHD Diagnosis Scenarios below to see examples of how to answer *Did acute GVHD develop since the date of last report* and *Did acute GVHD persist since the date of last report* questions.

Report **No** for *Did acute GVHD develop since the date of last report* and *Did acute GVHD persist since the date of last report* if the recipient had no active acute GVHD symptoms during the reporting period **OR** all acute GVHD signs / symptoms during the reporting period occurred after a diagnosis of chronic GVHD (see Acute / Chronic GVHD note box above).

Indicate **Unknown** if there is no information about the recipient’s GVHD status for the reporting period. This option should be used sparingly and only when no judgment can be made about the presence or absence of GVHD in the reporting period.

If chronic GVHD has been diagnosed in a prior reporting period, report **No** for *Did acute GVHD develop since the date of last report* and *Did acute GVHD persist since the date of last report*. Any new or persistent acute GVHD symptoms occurring after the onset of chronic GVHD must be reported in the chronic GVHD section of the form. Do not include any signs, symptoms, or treatment occurring on or after the onset of chronic GVHD when completing the acute GVHD section. This instruction has been provided in the Acute / Chronic GVHD note box above.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 10: Date of acute GVHD diagnosis

Report the date of clinical diagnosis of acute GVHD. The clinical diagnosis date may not necessarily be the date the symptoms began (example: the recipient developed a rash one week prior to the physician clinically diagnosing acute skin GVHD). If the clinical diagnosis is documented, but the diagnosis date is unclear, obtain documentation from the primary physician confirming the clinical diagnosis date.

If the recipient developed more than one episode of acute GVHD in the same reporting period, report the date of onset of the first episode of acute GVHD.

For more information regarding reporting partial or unknown dates, see General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 11: Did acute GVHD persist since the date of last report?

This question will only be enabled in FormsNet3SM if the center has reported **No** for the question *Did acute GVHD develop since the date of last report* and, therefore, has not reported a date of diagnosis. If prompted to answer this question, report **Yes** if acute GVHD was diagnosed in a prior reporting period and **any** of the following conditions are met:

- The recipient’s acute GVHD symptoms have been active since diagnosis and continue to be active during the current reporting period (i.e., no period of resolution or quiescence since diagnosis).
- The recipient’s acute GVHD symptoms had resolved before the first day of the current reporting period, but a flare occurred
**within 30 days**of symptom resolution / quiescence. - The recipient was not diagnosed with chronic GVHD on or before the date of the flare (see Acute / Chronic GVHD note box above).

Report **No** for *Did acute GVHD develop since the date of last report* and *Did acute GVHD persist since the date of last report* questions if the recipient had no active acute GVHD symptoms during the reporting period **OR** all acute GVHD signs / symptoms during the reporting period occurred after a diagnosis of chronic GVHD (see Acute / Chronic GVHD note box above).

Indicate **Unknown** if there is no information about the recipient’s GVHD status for the reporting period. This option should be used sparingly and only when no judgment can be made about the presence or absence of GVHD in the reporting period.

#### Question 12: Overall grade of acute GVHD at diagnosis

Indicate the overall grade of acute GVHD at the time of diagnosis. For reporting purposes, “at diagnosis” is defined as the period between onset of signs / symptoms and the initiation of therapy to treat GVHD (topical or systemic). The acute GVHD grading scale is based on **clinical evidence** (physician observation), not histology. Pathology reports sometimes list a histologic grade of GVHD. Do not report the histologic grade. GVHD scoring and grading is based on *clinical* severity, not histologic severity. Biopsy of affected organs allows for more precise diagnosis as to the presence or absence of GVHD. However, **overall grading remains clinical** and is based on the criteria published by Przepiorka et al., *Bone Marrow Transplant* 1995; 15(6):825-8, see the [GVHD Grading and Staging table](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#GVHD) below.

7 Harris AC, Young R, Devine S, et al. International, Multicenter Standardization of Acute Graft-versus-Host Disease Clinical Data Collection: A Report from the Mount Sinai Acute GVHD International Consortium. Biol Blood Marrow Transplant. 2015;22(1):4–10. doi:10.1016/j.bbmt.2015.09.001

If acute GVHD was present but the grade at diagnosis was not documented and it cannot be determined from the grading and staging table, report **Not applicable**.

Examples may include:


- Any other organ involvement without skin, liver, or gut symptoms attributable to GVHD
- Lower intestinal tract involvement where the stage cannot be determined in select scenarios (see
[lower intestinal tract involvement](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#lowergi)description below)

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

**GVHD Grading and Staging**

| Stage | Skin | Liver | Gut | |
|---|---|---|---|---|
| 1 | Rash on <25% of skin
|
Bilirubin 2-3 mg/dl
|
Diarrhea > 500 ml/day or persistent nausea
Pediatric: 280-555 ml/m2/day or 10-19.9 mL/kg/day |
|
| 2 | Rash on 25-50% of skin | Bilirubin 3-6 mg/dl | Diarrhea >1000 ml/dayPediatric: 556-833 ml/m2/day or 20-30 mL/kg/day |
|
| 3 | Rash on >50% of skin | Bilirubin 6-15 mg/dl | Diarrhea >1500 ml/dayPediatric: >833 ml/m2/day or > 30 mL/kg/day |
|
| 4 | Generalized erythroderma with bullous formation | Bilirubin >15 mg/dl | Severe abdominal pain, with or without ileus, and / or grossly bloody stool | |
Grade
|
||||
| I | Stage 1-2 | None | None | |
| II | Stage 3 | Stage 1 | Stage 1 | |
| III | — | Stage 2-3 | Stages 2-4 | |
| IV
|
Stage 4 | Stage 4 | — |

1 Use “Rule of Nines” ([Percent Body Surfaces table](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#Body)) or burn chart to determine extent of rash.

2 Range given as total bilirubin. Downgrade one stage if an additional cause of elevated bilirubin has been documented.

3 Volume of diarrhea applies to adults. For pediatric patients, the volume of diarrhea should be based on body surface area. Downgrade one stage if an additional cause of diarrhea has been documented.

4 Persistent nausea with or without histologic evidence of GVHD in the stomach or duodenum.

5 Criteria for grading given as minimum degree of organ involvement required to confer that grade.

6 Grade IV may also include lesser organ involvement with an extreme decrease in performance status

#### Questions 13 – 18: List the stage for each organ at diagnosis of acute GVHD

Report the stage of each organ at diagnosis. For reporting purposes, “at diagnosis” is defined as the period between onset of signs / symptoms and the initiation of therapy to treat GVHD (topical or systemic).

**Skin:** Select the stage that reflects the body surface area involved with a maculopapular rash attributed to acute GVHD at the time of acute GVHD diagnosis or flare in the reporting period. See the [Percent Body Surfaces](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#Body) table below to determine the percent of body surface area involved with a rash. Do not report ongoing rash not attributed to acute GVHD at the time of acute GVHD diagnosis or flare.

**Percent Body Surfaces**


| Body Area | Percent | Total Percentage |
|---|---|---|
| Each Arm | 9% | 18% |
| Each Leg | 18% | 36% |
| Chest & Abdomen | 18% | 18% |
| Back | 18% | 18% |
| Head | 9% | 9% |
| Pubis | 1% | 1% |

**Lower intestinal tract (use mL/day for adult recipients and mL/m 2/day for pediatric recipients):** Select the stage that reflects the volume of diarrhea attributed to acute GVHD at the time of acute GVHD diagnosis or flare in the reporting period. Use mL/day for adult recipients and mL/m

2/day for pediatric recipients. Input and output records may be useful in determining the volume of diarrhea. Do not report diarrhea ongoing but not attributed to acute GVHD at the time of acute GVHD diagnosis or flare.

**Upper intestinal tract:** Select the stage that reflects the presence of persistent nausea or vomiting attributed to acute GVHD at the time of acute GVHD diagnosis or flare in the reporting period. Do not report nausea or vomiting ongoing but not attributed to acute GVHD at the time of acute GVHD diagnosis or flare.

**Liver:** Select the stage that reflects the bilirubin level attributed to acute GVHD at the time of acute GVHD diagnosis or flare in the reporting period. Do not report hyperbilirubinemia ongoing but not attributed to acute GVHD at the time of acute GVHD diagnosis or flare.

**Other site(s) involved with acute GVHD:** Indicate whether acute GVHD affected an organ other than skin, upper GI, lower GI, or liver manifesting with hyperbilirubinemia. Report only other organ involvement at the time of acute GVHD diagnosis or flare in the reporting period. Do not report symptoms ongoing but not attributed to acute GVHD at the time of acute GVHD diagnosis or flare. Specify the other organ system involvement.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 19: Maximum Overall Grade of Acute GVHD

Indicate the overall maximum grade of acute GVHD since the date of the last report. Grading is based on **clinical evidence** (physician observation), not histology. Pathology reports sometimes list a histologic grade of GVHD. Do not report the histologic grade. GVHD scoring and grading is based on *clinical* severity, not histologic severity. Biopsy of affected organs allows for more precise diagnosis as to the presence or absence of GVHD. However, **overall grading remains clinical** and is based on the criteria published by Przepiorka et al., *Bone Marrow Transplant* 1995; 15(6):825-8; see the [GVHD Grading and Staging](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#GVHD) table above.

If chronic GVHD was diagnosed during the reporting period, report the maximum severity of acute GVHD prior to the onset of chronic GVHD.

Report the recipient’s maximum acute GVHD grade in the reporting period; **this may differ from the grade at diagnosis or may be the same.** If acute GVHD was present, but the maximum grade was not documented and it cannot be determined from the grading and staging table, report **Not applicable**.

Examples may include:


- Any other organ involvement without skin, liver, or gut symptoms attributable to GVHD
- Lower intestinal tract involvement where the stage cannot be determined in select scenarios (see
[lower intestinal tract involvement](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#lowergi)description above)

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 20: First date of maximum overall grade of acute GVHD

Report the first date of maximum acute GVHD involvement, based on clinical grade. If the recipient had multiple instances in which their GVHD reached the same maximum grade, report the earliest date, regardless of any variation in the organ staging.

If **Not applicable** was reported for *Maximum overall grade of acute GVHD*, this question must be left blank.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Questions 21 – 26: List the stage for each organ at the time of maximum overall grade of acute GVHD

Report the maximum acute GVHD stage of each organ involved in the reporting period. The maximum staging does not need to be at the time when the maximum overall grade occurred. Refer to the GVHD Grading and Staging Table above for staging guidelines. Also, review example E above for further information.

**Skin:** Select the maximum stage that reflects the body surface area involved with a maculopapular rash attributed to acute GVHD in the reporting period. See the [Percent Body Surfaces](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q15-18-graft-versus-host-disease-allogeneic-only#Body) table below to determine the percent of body surface area involved with a rash. Do not report ongoing rash not attributed to acute GVHD at the time of maximum overall grade of acute GVHD.

**Percent Body Surfaces**


| Body Area | Percent | Total Percentage |
|---|---|---|
| Each Arm | 9% | 18% |
| Each Leg | 18% | 36% |
| Chest & Abdomen | 18% | 18% |
| Back | 18% | 18% |
| Head | 9% | 9% |
| Pubis | 1% | 1% |

**Lower intestinal tract (use mL/day for adult recipients and mL/m 2/day for pediatric recipients):** Select the maximum stage that reflects the volume of diarrhea attributed to acute GVHD in the reporting period. Use mL/day for adult recipients and mL/m

2/day for pediatric recipients. Input and output records may be useful in determining the volume of diarrhea. Do not report diarrhea ongoing but not attributed to acute GVHD at the time of maximum overall grade of acute GVHD.

Report an overall grade of IV if stage 4 acute skin GVHD, stage 4 acute liver GVHD, or an extreme decrease in performance status is documented at the time point being reported (see GVHD Staging and Grading Table). Report overall grade III if stage 2-3 liver involvement is documented at the time point being reported and there is no evidence of grade IV GVHD.

**Upper intestinal tract:** Select the maximum stage that reflects the presence of persistent nausea or vomiting attributed to acute GVHD in the reporting period. Do not report nausea or vomiting ongoing but not attributed to acute GVHD at the time of maximum overall grade of acute GVHD.

**Liver:** Select the maximum stage that reflects the bilirubin level attributed to acute in the reporting period. Do not report hyperbilirubinemia ongoing but not attributed to acute GVHD at the time of maximum overall grade of acute GVHD.

**Other site(s) involved with acute GVHD:** Indicate whether acute GVHD affected an organ other than skin, upper GI, lower GI, or liver manifesting with hyperbilirubinemia. Report only other organ involvement at the time of maximum overall grade of acute GVHD in the reporting period. Do not report symptoms ongoing but not attributed to acute GVHD at the time of maximum overall grade of acute GVHD. Specify the other organ system involvement.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 27: Did chronic GVHD develop since the date of last report?

Indicate whether a new clinical diagnosis of chronic GVHD was documented during the reporting period. If chronic GVHD was diagnosed during the reporting period, report **Yes**.

If the recipient had a flare of chronic GVHD occurring after at least a 30-day period of symptom quiescence, report **Yes**. Report **No** if symptoms resolve or become quiescent prior to the date of last report and then flare within 30 days. This should be reported as persistent chronic GVHD which is captured in the question *Did chronic GVHD persist since the date of last report*.

Report **No** if chronic GVHD was not clinically diagnosed – initially or as a flare – in the reporting period; this includes instances where chronic GVHD persists from a prior reporting period.

Indicate **Unknown** if there is no information about the recipient’s GVHD status for the reporting period. This option should be used sparingly and only when no judgment can be made about the presence or absence of GVHD in the reporting period.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 28: Date of chronic GVHD diagnosis

Report the date of clinical diagnosis of chronic GVHD. The clinical diagnosis date may not necessarily be the date the symptoms began (example: the recipient developed shortness of breath one month prior to the clinical diagnosis of pulmonary chronic GVHD). If the clinical diagnosis is documented, but the diagnosis date is unclear, obtain documentation from the primary physician confirming the clinical diagnosis date.

If the recipient developed more than one episode of chronic GVHD in the same reporting period, report the date of onset of the first episode of chronic GVHD.

For more information regarding reporting partial or unknown dates, see General Instructions, [General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

#### Question 29: Did chronic GVHD persist since the date of last report?

Indicate whether chronic GVHD was clinically diagnosed during a previous reporting period and persisted, with active symptoms, into the present reporting period. Do not report quiescent or inactive chronic GVHD, or a prior history of GVHD. If **Yes**, questions concerning chronic GVHD at the time of diagnosis will be skipped. See instructions above on reporting a chronic GVHD flare.

If the recipient has no active symptoms during the reporting period, report **No**.

Indicate **Unknown** if there is no information about the recipient’s GVHD status for the reporting period. This option should be used sparingly and only when no judgment can be made about the presence or absence of GVHD in the reporting period.

#### Question 30: Maximum grade of Chronic GVHD (according to best clinical judgement)

Report the maximum chronic GVHD involvement, based on the opinion of the clinician (i.e., clinical grade), since the date of the last report. The intent of this question is to capture the maximum grade based on the best clinical judgment. If both the global severity score and the score based on the clinician’s opinion is documented, report the clinician score. If the maximum clinical grade is not documented, request documentation from the recipient’s primary care provider.

Guidelines on how to report the maximum grade of chronic GVHD are outlined below:


**Mild**: Signs and symptoms of chronic GVHD do not interfere substantially with function and do not progress once appropriately treated with local therapy or standard systemic therapy (e.g., corticosteroids and/or cyclosporine or FK 506)**Moderate**: Signs and symptoms of chronic GVHD interfere somewhat with function despite appropriate therapy or are progressive through first line systemic therapy (e.g., corticosteroids and/or cyclosporine or FK 506)**Severe**: Signs and symptoms of chronic GVHD limit function substantially despite appropriate therapy or are progressive through second line therapy

Indicate **Unknown** if there is no information about the recipient’s GVHD status for the reporting period. This option should be used sparingly and only when no judgment can be made about the presence or absence of GVHD in the reporting period.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

**Organ Scoring of Chronic GVHD**

| Organ | Score 0 | Score 1 | Score 2 | Score 3 |
|---|---|---|---|---|
Skin % BSA
|
No BSA involved | 1-18% BSA | 19-50% BSA | >50% BSA |
Skin Features |
No sclerotic features | N/A | Superficial sclerotic features, but not “hidebound” | Deep sclerotic features; “hidebound;” impaired mobility; ulceration |
Mouth |
No symptoms | Mild symptoms with disease signs but not limiting oral intake significantly |
Moderate symptoms with disease signs with partial limitation of oral intake |
Severe symptoms with disease signs with major limitation of oral intake |
Eyes |
No symptoms | Mild dry eye symptoms not affecting ADL (requirement of lubricant drops ≤ 3x/day) | Moderate dry eye symptoms partially affecting ADL (requiring lubricant drops > 3x/day or punctal plugs) WITHOUT new vision impairment due to keratoconjunctivitis sicca (KCS) |
Severe dry eye symptoms significantly affecting ADL (special eyewear to relieve pain) OR unable to work because of ocular symptoms OR loss of vision due to keratoconjunctivitis sicca (KCS) |
GI Tract |
No symptoms | Symptoms without significant weight loss (< 5%) | Symptoms associated with mild to moderate weight loss (5-15%) within 3 months OR moderate diarrhea without significant interference with daily living |
Symptoms associated with significant weight loss (> 15%) within 3 months, requires nutritional supplement for most calorie needs OR esophageal dilation OR severe diarrhea with significant interference with daily living. |
Liver |
Normal total bilirubin and ALT or AP < 3 x ULN | Normal total bilirubin with ALT ≥ 3 to 5 x ULN or AP ≥ 3 x ULN | Elevated total bilirubin but ≤ 3 mg / dL or ALT > 5 x ULN | Elevated total bilirubin > 3 mg / dL |
Lungs Symptom Score: |
No symptoms | Mild symptoms (SOB after climbing one flight of steps) | Moderate symptoms (SOB after walking on flat ground) | Severe symptoms (SOB at rests; requires O2) |
Lungs Lung Score: |
FEV1 ≥ 80% | FEV1 60-79% | FEV1 40-59% | FEV1 ≤ 39% |
Joints and Fascia |
No symptoms | Mild tightness of arms or legs, normal or mild decreased range of motion AND not affecting ADL |
Tightness of arms or legs OR joint contractures, erythema thought to be due to fasciitis, moderate decrease of range of motion AND mild to moderate limitation of ADL |
Contractures WITH significant decrease of range of motion AND significant limitation of ADL (unable to tie shoes, button shirts, dress self, etc.) |
Genital Tract
|
No signs | Mild signs and females with or without discomfort on exam | Moderate signs and may have signs of discomfort on exam | Severe signs with or without symptoms |
Other Features
|
No GVHD | Mild | Moderate | Severe |

1 Features to be scored by BSA: Maculopapular rash, lichen planus-like features, sclerotic features, papulosquamous lesions or ichthyosis, keratosis pilaris-like GVHD.

2 Scoring is based on severity of the signs instead of symptoms, based on limited available data and the opinions of experts. Female or male genital GVHD is not scored if a practitioner is unable to examine the patient.

3 May include ascites, pericardial effusion, pleural effusion(s), nephrotic syndrome, myasthenia gravis, peripheral neuropathy, polymyositis, weight loss without GI symptoms, eosinophilia > 500/μL, platelets < 100,000/μL, others.

#### Question 31: Date of maximum grade of chronic GVHD

Report the date of maximum chronic GVHD involvement, based on clinical grade, during the current reporting period. If the recipient had multiple instances in which their GVHD reached the same maximum grade, report the earliest date.

For more information regarding reporting partial or unknown dates, see [General Instructions, General Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms).

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 32: Specify if chronic GVHD was limited or extensive

The grading system for chronic GVHD is divided into two categories: limited and extensive. Definitions are based on Sullivan KM, *Blood* 1981; 57:267.

Report **Limited** if chronic GVHD includes only localized skin involvement and / or liver dysfunction. Report **Extensive** if **any** of the following symptoms are attributed to chronic GVHD:


- Generalized skin involvement and / or liver dysfunction
- Liver histology showing chronic aggressive hepatitis, bridging necrosis, or cirrhosis
- Involvement of the eye: Schirmer’s test with <5 mm wetting, or
- Involvement of the salivary glands or oral mucosa demonstrated on labial biopsy (labial biopsy not required), or
- Involvement of any other target organ

The intent of this question is to capture if chronic GVHD was limited or extensive throughout the entire reporting period and is not dependent on the maximum grade and date of chronic GVHD. If the criteria to report extensive was met at any time in the reporting period, report **Extensive**.

#### Question 33: Is the recipient still taking systemic steroids? (Do not report steroids for adrenal insufficiency, ≤10 mg/day for adults, <0.1 mg/kg/day for children)

Indicate whether the recipient is still taking systemic steroids to treat or prevent GVHD on the date of contact. Refer to the guidelines included in the question text if the recipient is taking low dose steroids or steroids for adrenal insufficiency.

Indicate **Not applicable** in any of the following scenarios:


- The recipient has never received systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD.
- This form is being completed for a subsequent HCT and the recipient has never received systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD since the start of the preparative regimen for the most recent infusion (or since the date of the most recent infusion if no preparative regimen is given).
- The recipient stopped taking systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) to treat or prevent GVHD in a previous reporting period and did not restart systemic steroids (> 10 mg / day for adults or ≥ 0.1 mg / kg / day for children) during the current reporting period.

Indicate **Unknown** if there is no information to determine if the recipient is still taking systemic steroids. This option should be used sparingly and only when no judgment can be made about the recipient still receiving treatment for GVHD on the date of contact.

If the recipient has died prior to the discontinuation of systemic steroids used to treat or prevent acute and / or chronic GVHD, select **Yes**.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

#### Question 34: Is the recipient still taking (non-steroid) immunosuppressive agents (including PUVA) for GVHD?

Indicate whether the recipient is still taking systemic non-steroidal immunosuppressive agents (including PUVA) to treat or prevent acute and / or chronic GVHD on the date of contact. Descriptions of many immunosuppressive agents are included below. Only report systemic non-steroidal immunosuppressive agents and not topical non-steroids immunosuppressive agents, such as Restasis and or Protopic.

If the recipient did not receive systemic non-steroidal immunosuppressive agents to treat or prevent acute and / or chronic GVHD during the reporting period, report **Not applicable**.

Indicate **Not applicable** in any of the following scenarios:


- The recipient has never received systemic non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD.
- This form is being completed for a subsequent HCT and the recipient has never received systemic non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD since the start of the preparative regimen for the most recent infusion (or since the date of the most recent infusion if no preparative regimen was given).
- The recipient stopped systemic taking non-steroidal immunosuppressive agents (including PUVA) to treat or prevent GVHD in a previous reporting period and did not restart non-steroidal immunosuppressive agents (including PUVA) during the current reporting period.
- The recipient only received
*topical*non-steroidal immunosuppressive agents (i.e., systemic non-steroidal immunosuppressive agents were never administered).

Indicate **Unknown** if there is no information to determine if the recipient is still taking non-steroidal immunosuppressive agents. This option should be used sparingly and only when no judgment can be made about the recipient still receiving treatment for GVHD in the reporting period.

Review the [GVHD Reporting Instruction Overview](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/gvhd) for various GVHD reporting examples.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)