#### Question 11: Was any therapy given for relapsed, persistent, or progressive disease since the date of last report?

Indicate if the recipient received treatment for relapsed JMML during the current reporting period. Do not report therapy given for maintenance (to prolong remission or for minimal residual disease). If the patient received therapy for relapsed, persistent, or progressive disease, check “yes” and continue with question 12. If the patient did not receive therapy, or only received therapy for maintenance, check “no” and continue with question 21.

#### Question 12: Systemic therapy

Systemic therapy refers to a delivery mechanism where a therapeutic agent is delivered orally or intravenously, enters the bloodstream, and is distributed throughout the body.

Indicate “yes” if the patient received systemic and continue with question 12. If the patient did not receive systemic therapy, indicate “no” and continue with question 17.

#### Questions 13-16: Specify systemic therapy agent(s)

Indicate “yes” or “no” for each drug administered for therapy during the current reporting period for reasons relapse, progressive, or persistent disease. Do not leave any responses blank. If the recipient received an agent that is not listed, check “yes” for “other systemic therapy” and specify the treatment in question 16.

#### Question 17: Donor cellular infusion

A donor cellular infusion, or DCI, is a form of immunotherapy that is commonly used for a variety of purposes, including the treatment of refractory or recurrent disease. In the setting of relapsed, persistent, or progressive disease, the DCI is used to create a graft-versus-leukemia/tumor (GVL/GVT) effect. In general, the recipient does not receive a preparative regimen prior to receiving the additional donor cells since replacement of the marrow is not the goal.

Indicate “yes” if the patient received one or more donor cellular infusion(s); also report the DCI on the corresponding Form 2100, 2200, or 2300. If the patient did not receive a donor cellular infusion, check “no.”

#### Question 18: Subsequent HCT

An HCT is an infusion of a product (i.e., bone marrow, peripheral blood stem cells, cord blood, etc.) that contains CD34+ cells. Refer to [Appendix D](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/appendix-d) for further clarification on defining a subsequent HCT.

The intention of an HCT is to restore hematopoiesis and immunity. It is usually preceded by a preparative regimen used to both reduce disease burden and prevent rejection of the new stem cells by killing normal and malignant cells, if present. In some cases, a preparative regimen might not be used prior to the infusion of CD34+ cells, but this would still be considered an HCT.

A subsequent HCT may be administered to replace or repopulate the recipient’s marrow and reconstitute the immune system. If the recipient receives a subsequent HCT as treatment for relapsed disease, check “yes” and continue with question 19. Only report a subsequent HCT given for relapsed, persistent, or progressive disease. If a subsequent HCT is reported in question 18, it must also be reported on the corresponding Form 2100, 2200, or 2300.

If a recipient receives a subsequent HCT between the HCT follow-up time points (100 day, six months, annually), the comprehensive report form sequence will start over with another Pre-TED Form (2400), Recipient Baseline Data Form (2000), and Juvenile Myelomonocytic Leukemia Pre-HCT Data Form (2015). However, if the recipient receives an autologous HCT as a result of a poor graft or graft failure, the comprehensive report form sequence **will not** start over if the preceding HCT was also autologous. Generally this type of infusion (autologous rescue) is used to treat the recipient’s poor graft response, rather than to treat the recipient’s disease.

#### Question 19: Other therapy

If the patient received a therapy that is not listed, indicate “yes” and specify the therapy in question 20. If the patient did not receive another therapy not listed, check “no.”

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)