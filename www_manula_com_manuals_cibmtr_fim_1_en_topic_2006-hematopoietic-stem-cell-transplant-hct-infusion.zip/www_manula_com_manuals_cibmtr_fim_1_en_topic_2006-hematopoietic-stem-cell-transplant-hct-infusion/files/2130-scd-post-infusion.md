The Sickle Cell Disease Post-Infusion (2130) Form is one of the Comprehensive Report Forms. This form captures Sickle Cell Disease (SCD) post-HCT data for the reporting period.

This form must be completed for all recipients whose primary disease, as reported on the Disease Classification (2402) Form, is **Sickle Cell Disease (SCD)**. The Sickle Cell Disease Post-Infusion (2130) Form must be completed in conjunction with each Post-Infusion Follow-up (2100) Form. This form is designed to capture specific data occurring within the timeframe of each reporting period (i.e., between day 0 and day 100; between day 100 and the six-month date of contact for six-month follow-up; and between the date of contact for the six-month follow-up and the date of contact for the one-year follow-up, etc.).

**Links to Sections of the Form**

[Q1 – 5: Physical Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-5-physical-assessments)

[Q6 – 8: Transfusion Therapy](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q6-8-transfusion-therapy)

[Q9 – 22: Therapy for Iron Overload](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-22-therapy-for-iron-overload)

[Q23 – 27: Pulmonary Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q9-13-pulmonary-assessments)

[Q28 – 48: Cardiovascular Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q14-30-cardiovascular-assessments)

[Q49 – 58: Hepatic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q49-58-hepatic-assessments)

[Q59 – 65: Renal Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q31-37-renal-assessments)

[Q66 – 70: Splenic Assessments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q38-42-splenic-assessments)

[Q71 – 74: Acute Chest Syndrome](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q43-acute-chest-syndrome)

[Q75 – 80: Pain](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q44-46-pain)

[Q81 – 83: Avascular Necrosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q47-49-avascular-necrosis)

[Q84 – 92: Central Nervous System](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q50-58-central-nervous-system)

[Q93 – 104: Other Symptoms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q59-66-other-symptoms)

[Q105 – 116: Existing Organ Impairments](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q105-116-existing-organ-impairments)

[Q117 – 123: Disease Modifying Therapies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q67-73-disease-modifying-therapies)

[Q124 – 147: Other Laboratory Studies](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q74-100-other-laboratory-studies)

[Q148: Disease Status](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q101-disease-status)

[Q149: Marrow Evaluation](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q149-marrow-evaluation)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. The most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

If you need to reference the historical Manual Change History for this form, please [click here](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/Documents/2116.PCD%20Pre-HCT%20Data%20Manual%20Change%20History%20through%203.31.15.pdf) or reference the retired manual section on the [Retired Forms Manuals](http://www.cibmtr.org/DataManagement/TrainingReference/Manuals/Retired%20Forms%20Manuals/pages/index.aspx) webpage.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 1/24/2025 |
|

~~and blood pressure are~~ is currently disabled and cannot be answered at this time.**Abdominal girth**~~and Blood Pressure~~: Abdominal girth[2130 SCD Post-Infusion](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2130-scd-post-infusion)
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)