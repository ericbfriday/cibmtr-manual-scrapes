The Wiskott-Aldrich Syndrome Pre-HCT Data Form is one of the Comprehensive Report Forms. This form captures WAS-specific pre-HCT data such as: the recipient’s clinical and genetic findings at the time of diagnosis and prior to the start of the preparative regimen, pre-HCT treatments administered, and disease manifestations prior to the preparative regimen.

This form must be completed for all recipients randomized to the Comprehensive Report Form (CRF) track whose primary disease is reported on the Pre-TED Disease Classifciation Form (Form 2402) as Wiskott-Aldrich syndrome under “disorders of the immune system.”

#### Subsequent Transplant

If this is a report of a second or subsequent transplant for the same disease subtype, and this baseline disease insert has not been completed for the previous transplant (e.g., patient was on TED track for the prior HCT, prior HCT was autologous with no consent, etc.), begin at question 1. If this is a report of a second or subsequent transplant for a different disease (e.g., patient was previously transplanted for a disease other than Wiskott-Aldrich syndrome), begin at question 1.

If this is a report of a second or subsequent transplant for the same disease and this baseline disease insert has previously been completed, check the indicator box and continue with question 67.

[Q1-13: Disease Assessment at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q1-13-disease-assessment-at-diagnosis)[Q14-41: Laboratory Studies at Diagnosis](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q14-41-laboratory-studies-at-diagnosis)[Q42-130:Clinical Features Assessed between Diagnosis and the Start of the Preparative Regimen](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/q42-130-clinical-features-assessed-between-diagnosis-and-the-start-of-the-preparative-regimen)

Manual Updates:

Sections of the Forms Instruction Manual are frequently updated. In addition to documenting the changes within each manual section, the most recent updates to the manual can be found below. For additional information, select the manual section and review the updated text.

| Date | Manual Section | Add/Remove/Modify | Description |
|---|---|---|---|
| 4/21/2023 |
|

[2033/2133: Wiskott Aldrich Syndrome](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2033-2133-wiskott-aldrich-syndome-was)**Published new manual for**[2033](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2033-was-pre-hct-data)&[2131](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/2133-was-post-hct-data)WAS Pre- and Post-HCT.
Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)