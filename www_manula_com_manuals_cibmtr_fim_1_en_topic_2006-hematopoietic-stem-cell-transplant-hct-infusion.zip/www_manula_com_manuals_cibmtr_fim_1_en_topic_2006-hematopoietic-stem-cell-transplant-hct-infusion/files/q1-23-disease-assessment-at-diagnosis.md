#### Question 1: Is this recipient a registered participant in the United States Immunodeficiency Network (USIDNET)?

The United Stated Immunodeficiency Network (USIDNET) is a research consortium studying primary immune deficiencies. They maintain a registry of primary immunodeficiency patients and act as a resource for clinical and laboratory research. Indicate if the recipient is a registered participant in the USIDNET. If “yes,” continue with question 2. If “no,” continue with question 3.

#### Question 2: USIDNET ID

Report the recipient’s USIDNET participant identification number.

#### Question 3: What was the date of diagnosis?

X-linked lymphoproliferative syndrome (XLP) is characterized by multiple clinical, laboratory, and genetic features, rather than distinct pathological characteristics. Examples of testing done to confirm a diagnosis of XLP include peripheral blood sample analysis to determine the presence or absence of functional *SH2D1A* or *BIRC4* proteins, or molecular testing for SH2D1A or BIRC4 mutations. The date of diagnosis should be the date of sample collection of last assessment used to establish a diagnosis of XLP. If there is a strong family history of XLP and no testing is done to confirm the diagnosis, report the recipient date of birth.

#### Question 4: Was genetic testing used to confirm the diagnosis?

X-linked lymphoproliferative syndrome is known to be an inherited disorder; for that reason, genetic testing is often done to confirm the diagnosis. If there is known family history of XLP, or the mother is a known carrier, genetic testing may be done prior to the onset of symptoms or even prenatally. The presence of *SH2D1A* (XLP1/XLP) or *BIRC4* (XLP2/XIAP) mutations are associated with XLP. Other gene mutations may be present and should be reported even if their clinical significance is uncertain. Indicate if genetic testing was performed.

If genetic testing was performed, check “yes” and continue with question 5. If genetic testing was not done or it is unknown if genetic testing was performed, indicate “no” or “unknown” and continue with question 10.

#### Questions 5-8: Specify genetic mutation(s) present at diagnosis

If question 4 indicates that genetic testing was performed, each of questions 5-7 must be answered. Indicate “yes” if testing revealed the specified gene mutation; indicate “no” if testing was done but did not reveal the specified gene mutation. If testing for the specified gene mutation was not done or it is unknown if testing was performed, specify this. Do not leave any response blank. If a genetic mutation was found that is best classified as “other mutation,” specify in question 8.

#### Question 9: Was documentation submitted to the CIBMTR? (e.g., pathology report)

Indicate if a copy of the genetic testing report is attached. Use the Log of Appended Documents (Form 2800) to attach a copy of the genetic report. Attaching a copy of the report may prevent additional queries.

#### Question 10: Was X-linked inheritance demonstrated in the recipient’s maternal family members?

X-linked patterns of inheritance are caused by genetic mutations carried on the X chromosome, which is a sex chromosome (allosome). Males normally carry one copy of the X chromosome and one copy of the Y chromosome. For this reason, a faulty X chromosome will affect all men who carry it, since it is the only X chromosome they can express; men will be symptomatic for x-linked recessive patterns of inheritance. X-linked traits cannot be passed from father to son (since the father will supply the son’s Y chromosome). Women carry two copies of the X chromosome. This means they will be carriers for x-linked recessive traits, but will rarely be symptomatic since they will *generally* have a normal X chromosome that is expressed. (For x-linked *dominant* patterns of inheritance, only a single mutated X chromosome is necessary for symptomatic expression. Therefore, x-linked dominant patterns of inheritance affect both men and women.)

XLP follows an x-linked recessive pattern of inheritance. Indicate if the patient’s maternal family members exhibit evidence of x-linked recessive inheritance; this would be shown by a brother, male maternal cousin, maternal uncle, and/or maternal grandfather being affected by the disease. Do not report “yes” based only on known carrier status in female family members. Specify “no” if the recipient’s brother(s) and/or male cousin(s) all exhibit normal X chromosome expression (no evidence of disease). Indicate “unknown” if information is not available about the recipient’s family history or if the recipient is the only male child and does not have male maternal cousins.

#### Specify if the following disorders were present at diagnosis

XLP typically presents following an exaggerated response to Epstein-Barr virus. Other common clinical presentations of XLP are dysgammaglobulinemia and/or lymphoproliferative processes. Additional clinical manifestations may include a lesser response to EBV or other pathogen, cytopenias including aplastic anemia, autoimmune processes including vasculitis or psoriasis, lymphoma, and/or colitis. Specify if the recipient had any of the following at the time of diagnosis.

#### Question 11: Aplastic anemia

Aplastic anemia is a hematologic condition defined by peripheral blood cytopenia(s) and markedly hypocellular marrow with pancytopenia. Indicate if the patient had aplastic anemia at the time of XLP diagnosis.

#### Question 12: Colitis

Colitis refers to inflammation of the large intestine, often manifesting as diarrhea, abdominal pain and bloating, and melena (black “tarry” feces) or hematochezia (passage of fresh blood in feces). Indicate if the patient had colitis at the time of XLP diagnosis.

#### Question 13: Epstein-Barr Virus (EBV) infection with evidence of Hemophagocytic Lymphohistiocytosis (HLH)

Epstein-Barr viral infection is ubiquitous and rarely causes life-threatening complications. EBV generally infects the B-lymphocytes; however, in rare circumstances it may infect natural killer (NK) cells and T-lymphocytes. This unusual event is associated with aggressive lymphoproliferative manifestations, including hemophagocytic lymphohistiocytosis (HLH). HLH leads to an abnormal proliferation of macrophages and histiocytes, leading to the phagocytosis of healthy circulating blood cells. Indicate if the patient had evidence of HLH secondary to EBV at the time of diagnosis.

#### Question 14: EBV infection without HLH

EBV sensitivity is a common characteristic of XLP. The majority of patients present after acute EBV infection has caused an exaggerated response of the immune system and subsequent excessive proliferation of lymphocytes. Indicate if the patient had evidence of an EBV infection *without* HLH prior to or at time of diagnosis.

#### Question 15: Hypogammaglobulinemia

Hypogammaglobulinemia is a condition in which the body does not make enough antibodies or immunoglobulins. It is generally due to decreased numbers of B-lymphocytes. Indicate if the patient had hypogammaglobulinemia at the time of XLP diagnosis.

#### Question 16: Lymphoproliferative disorder

Various lymphoproliferative disorders caused by clonal lymphocyte proliferation may present with XLP due to the exaggerated, dysfunctional immune response caused by the disease. Examples of lymphoproliferative disorders include large granular lymphocytic leukemia (LGL) and lymphoplasmacytic lymphoma (also known as Waldenström’s macroglobulinemia). Indicate if the patient had a lymphoproliferative disorder *other than lymphoma* at the time of XLP diagnosis.

#### Question 17: Lymphoma

XLP is associated with a higher incidence of lymphoma, which may be secondary to EBV infection; however, not all lymphomas in the setting of XLP exhibit EBV clonality. There is speculation that lymphoma risk is increased secondary to aberrant invariant natural killer T-cell (iNKT), NK cell, and T-cell cytotoxic function. The majority of lymphomas seen in XLP patients are T-cell lymphomas. Indicate if the patient had lymphoma at the time of XLP diagnosis. If yes, also complete Form 2018, Hodgkin and Non-Hodgkin Lymphoma Pre-HCT Data.

#### Question 18: Psoriasis

Psoriasis is an immune-mediated skin condition characterized by dry, thick patches of skin that are primarily red with silver-white scaling. Indicate if the patient had psoriasis at the time of XLP diagnosis.

#### Question 19: Vasculitis

Vasculitis refers to inflammation of the vasculature (blood vessels), including both veins and arteries. Vasculitis may impact blood vessels of any size, from capillaries and arterioles to the great truncal vessels. It is typically caused by autoimmunity. Indicate if the patient had vasculitis (any presentation) at the time of XLP diagnosis. If “yes,” continue with questions 20-23. Answer each of questions 20-22 and do not leave any response blank. If “no,” continue with question 24.

#### Question 20: Central nervous system

CNS vasculitis refers to inflammation of the vasculature of the brain and/or spinal cord. Indicate if the patient had CNS vasculitis.

#### Question 21: Pulmonary system

Pulmonary vasculitis involves inflammation of pulmonary vasculature. This can range from the great vessels, such as the pulmonary arteries, to the small alveolar capillaries. Indicate if the patient had pulmonary vasculitis.

#### Question 22: Other vasculitis involvement

Indicate if the patient had other vasculitis involvement. Specify involvement in question 23. Examples include systemic vasculitis, urticarial vasculitis, or gastrointestinal vasculitis.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)