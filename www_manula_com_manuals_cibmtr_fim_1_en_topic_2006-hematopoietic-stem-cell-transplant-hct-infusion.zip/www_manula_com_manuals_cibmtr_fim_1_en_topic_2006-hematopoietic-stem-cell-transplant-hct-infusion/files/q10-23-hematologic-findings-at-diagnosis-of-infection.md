#### Question 11-21: Complete Blood Count

For the initial form, report the date and values of the complete blood count (CBC) performed closest to the date of diagnosis, within seven days of the date of diagnosis of the respiratory viral infection being reported on this form. If multiple CBCs are performed within seven days of the infection diagnosis, report the CBC collected as close to the date of infection diagnosis as possible.

For the follow-up form, report the date and values of the complete blood count (CBC) performed closest to the date of infection resolution (or date of death).

For each value listed in questions 12-21, indicate whether the value was known or unknown on the date reported in question 11. If known, report the value and corresponding units (if applicable). If the value is not known on the date reported in question 10, report “Unknown” and go to the next value.

If the exact date of the CBC is not known, refer to General Instructions, [Guidelines for Completing Forms](https://www.manula.com/manuals/cibmtr/fim/1/en/topic/general-guidelines-for-completing-forms), for information about reporting partial or unknown dates.

#### Question 22-24: IgG

Report the result of the IgG test performed closest to the date of diagnosis (± 7 days) of the respiratory viral infection being reported on this form. The test must have been performed within 7 days of the date of diagnosis. If known, report the value, associated units, and date collected in questions 23-24.

If an IgG test was not performed within seven days of the viral infection diagnosis, or it is not known if an IgG test was performed, report “Unknown” for question 22 and go to question 25.

**Section Updates:**

| Question Number | Date of Change | Add/Remove/Modify | Description | Reasoning (If applicable) |
|---|---|---|---|---|
| . | . | . | . | . |

Need more help with this?

[
Don’t hesitate to contact us here. ](mailto: cibmtrformsmanualcomments@nmdp.org)